// Copyright Qibo Pang 2023. All Rights Reserved.

using System.IO;
using UnrealBuildTool;

public class UMGSubSequence : ModuleRules
{
	public UMGSubSequence(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicIncludePaths.Add(Path.Combine(ModuleDirectory, "Public"));
		PrivateIncludePaths.Add(Path.Combine(ModuleDirectory, "Private"));

		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				"ApplicationCore",
				"CoreUObject",
				"Engine",
				"UMG",
				"Slate",
				"SlateCore",
				"MovieScene",
				"MovieSceneTracks",
			}
		);
	}
}
