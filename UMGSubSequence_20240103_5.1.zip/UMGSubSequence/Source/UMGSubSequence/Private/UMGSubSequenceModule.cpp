// Copyright Qibo Pang 2023. All Rights Reserved.


#include "UMGSubSequenceModule.h"

#define LOCTEXT_NAMESPACE "FUMGSubSequenceModule"

void FUMGSubSequenceModule::StartupModule()
{
	

}

void FUMGSubSequenceModule::ShutdownModule()
{
	
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FUMGSubSequenceModule, UMGSubSequence)