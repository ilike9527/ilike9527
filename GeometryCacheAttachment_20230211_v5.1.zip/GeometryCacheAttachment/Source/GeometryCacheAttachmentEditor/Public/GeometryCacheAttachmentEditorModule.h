// Copyright Qibo Pang 2023. All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Modules/ModuleManager.h"

DECLARE_LOG_CATEGORY_EXTERN(GeometryCacheAttachmentEditor, Log, All);

class  FGeometryCacheAttachmentEditorModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */


	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};
