// Copyright Qibo Pang 2023. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Layout/Visibility.h"
#include "Input/Reply.h"

#include "GeometryCacheAttachmentComponent.h"
#include "IDetailCustomization.h"

class IDetailLayoutBuilder;

//////////////////////////////////////////////////////////////////////////
// FGeometryCacheAttachmentDetailsCustomization

class FGeometryCacheAttachmentDetailsCustomization: public IDetailCustomization
{
public:
	// Makes a new instance of this detail layout class for a specific detail view requesting it
	static TSharedRef<IDetailCustomization> MakeInstance();

	// IDetailCustomization interface
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailLayout) override;
	// End of IDetailCustomization interface

private:

	void OnAttachButtonClicked();
	void OnRemoveButtonClicked();

private:

	TWeakObjectPtr<UGeometryCacheAttachmentComponent> GeometryCacheAttachmentComponentPtr;

	IDetailLayoutBuilder* MyDetailLayout;

};
