// Copyright Qibo Pang 2024. All Rights Reserved.

#include "UMGPolygonRenderBatch.h"

FUMGPolygonRenderBatch::FUMGPolygonRenderBatch(
	TArray<FSlateVertex>* InSourceVertexArray,
	TArray<SlateIndex>* InSourceIndexArray)
	: SourceVertices(InSourceVertexArray)
	, SourceIndices(InSourceIndexArray)
	, NumVertices(0)
	, NumIndices(0)
{
}