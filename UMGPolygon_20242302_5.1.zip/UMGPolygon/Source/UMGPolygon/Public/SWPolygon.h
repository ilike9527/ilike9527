// Copyright Qibo Pang 2024. All Rights Reserved.

#pragma once

// Core Include
#include "CoreMinimal.h"
#include "Widgets/SLeafWidget.h"

// Misc Includes
#include "Misc/Attribute.h"
#include "Input/Reply.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Framework/SlateDelegates.h"
#include "Rendering/DrawElements.h"
#include "Styling/CoreStyle.h"
#include "UMGPolygonDefine.h"

class FPaintArgs;
class FSlateWindowElementList;
struct FSlateBrush;

/**
 * 
 * @Note: Because someone thought hardcoding it is reasonable?
 */
class UMGPOLYGON_API SWPolygon : public SLeafWidget
{
public:

    SLATE_BEGIN_ARGS(SWPolygon)
        : _PolygonInfo()
        , _OnValueChanged()
        { }

        /// Attributes ///
    
        SLATE_ATTRIBUTE(FUMGPolygonInfo, PolygonInfo)

        /// Arguments ///
   

        /// Events ///

        /** Invoked when a new value is seted on the spline. */
        SLATE_EVENT(FOnLinearColorValueChanged, OnValueChanged)

    SLATE_END_ARGS()

public:

    /**
     * Construct this widget.
     *
     * @param InArgs The declaration data for this widget.
     */
    void Construct(const FArguments& InArgs);
	
    
#pragma region Overrides
    
    // SWidget overrides
    virtual FVector2D ComputeDesiredSize(float) const override;
    
    virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect,
                          FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle,
                          bool bParentEnabled) const override;

#pragma endregion Overrides

    bool CheckPointInPolygon(const FVector2D& Point) const;

protected:

    /** Paint a spline with custom verts draw function*/
    void PaintPolygon_CustomVerts(const FUMGPolygonInfo& InPolygonInfo, const FGeometry& AllottedGeometry, FSlateWindowElementList& OutDrawElements,
        int32 LayerId, const FSlateRect& MyCullingRect, ESlateDrawEffect DrawEffects, const FWidgetStyle& InWidgetStyle) const;

private:

    TAttribute<FUMGPolygonInfo> PolygonInfo;

    TSharedPtr <FPoygonVertsCache> PoygonVertsCache = nullptr;

private:

    /** Invoked when a new value is seted on the spline. */
    FOnLinearColorValueChanged OnValueChanged;

};
