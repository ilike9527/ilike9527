// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "BackgroundBlurWithMaskDefine.generated.h"

/**
 * Enumerates background blur mask texture channel.
 */
UENUM(BlueprintType)
enum EMaskTextureChannel
{
	R UMETA(DisplayName = "R"),

	G UMETA(DisplayName = "G"),

	B UMETA(DisplayName = "B"),

	A UMETA(DisplayName = "A"),
};
