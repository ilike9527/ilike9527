// Copyright Qibo Pang 2022. All Rights Reserved.

#include "GeometryCacheCollisionDetailsCustomization.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "EditorModeManager.h"

#include "PropertyHandle.h"
#include "DetailLayoutBuilder.h"
#include "DetailWidgetRow.h"
#include "IDetailPropertyRow.h"
#include "DetailCategoryBuilder.h"

#define LOCTEXT_NAMESPACE "GeometryCacheCollision"

//////////////////////////////////////////////////////////////////////////
// FGeometryCacheCollisionWidgetDetailsCustomization

TSharedRef<IDetailCustomization> FGeometryCacheCollisionWidgetDetailsCustomization::MakeInstance()
{
	return MakeShareable(new FGeometryCacheCollisionWidgetDetailsCustomization);
}

void FGeometryCacheCollisionWidgetDetailsCustomization::CustomizeDetails(IDetailLayoutBuilder& DetailLayout)
{
	const TArray< TWeakObjectPtr<UObject> >& SelectedObjects = DetailLayout.GetSelectedObjects();
	if (SelectedObjects.Num() != 1)
	{
		return;
	}
	
	UGeometryCacheCollisionComponent* GeometryCacheCollisionComponent = nullptr;
	for (int32 ObjectIndex = 0; ObjectIndex < SelectedObjects.Num(); ++ObjectIndex)
	{
		UObject* TestObject = SelectedObjects[ObjectIndex].Get();
		if (UGeometryCacheCollisionComponent* TestGeometryCacheCollisionComponent = Cast<UGeometryCacheCollisionComponent>(TestObject))
		{
			GeometryCacheCollisionComponent = TestGeometryCacheCollisionComponent;
			break;
		}
	}

	if (!GeometryCacheCollisionComponent)
	{
		return;
	}

	GeometryCacheCollisionComponentPtr = GeometryCacheCollisionComponent;

	//DetailLayout.HideCategory(TEXT("Transform"));
	DetailLayout.HideCategory(TEXT("Collision"));
	DetailLayout.HideCategory(TEXT("Physics"));
	DetailLayout.HideCategory(TEXT("Lighting"));
	DetailLayout.HideCategory(TEXT("Rendering"));
	DetailLayout.HideCategory(TEXT("Navigation"));
	DetailLayout.HideCategory(TEXT("Tags"));
	DetailLayout.HideCategory(TEXT("Activation"));
	DetailLayout.HideCategory(TEXT("Cooking"));
	DetailLayout.HideCategory(TEXT("HLOD"));
	DetailLayout.HideCategory(TEXT("Mobile"));
	DetailLayout.HideCategory(TEXT("AssetUserData"));

	MyDetailLayout = &DetailLayout;
}

//////////////////////////////////////////////////////////////////////////

#undef LOCTEXT_NAMESPACE
