// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

// Core Include
#include "Framework/SlateDelegates.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SWidget.h"
#include "Layout/Margin.h"
#include "Widgets/SCompoundWidget.h"

class UWidget;

/**
*
*/
class SFinalColorRecorder : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SFinalColorRecorder)
	{
		_Visibility = EVisibility::SelfHitTestInvisible;
	}
	SLATE_DEFAULT_SLOT(FArguments, Content)
	SLATE_END_ARGS()

public:
	
	SFinalColorRecorder();
	~SFinalColorRecorder();

	void Construct(const FArguments& InArgs);
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;

protected:
	
	/** Draws the background blur in Slate */
	TSharedPtr<class FFinalColorDrawer, ESPMode::ThreadSafe> FinalColorDrawer;

};
