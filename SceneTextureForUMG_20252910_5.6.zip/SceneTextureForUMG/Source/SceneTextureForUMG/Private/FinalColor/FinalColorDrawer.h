// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "RenderResource.h"
#include "RendererInterface.h"
#include "Rendering/RenderingCommon.h"
#include "CanvasTypes.h"
#include "Widgets/SLeafWidget.h"

class FRHICommandListImmediate;

struct FSceneTextureForTextRenderParams
{
	FVector4 QuadPositionData;

	const FSlateClippingState* ClippingState;

	FVector2D ViewportSize;

	FSceneTextureForTextRenderParams()
	{
		ClippingState = nullptr;
	}
};


/**
 * Custom Slate drawer to render a SceneTextureForText with mask
 */
class FFinalColorDrawer : public ICustomSlateElement
{
public:
	FFinalColorDrawer();
	~FFinalColorDrawer();

	bool InitializeSceneTextureForTextParams(FSlateWindowElementList& ElementList, uint32 InLayer, const FPaintGeometry& PaintGeometry);

private:
	/**
	 * ICustomSlateElement interface 
	 */
	virtual void Draw_RenderThread(FRDGBuilder& GraphBuilder, const FDrawPassInputs& Inputs) override;

	const FSlateClippingState* ResolveClippingState(FSlateWindowElementList& ElementList) const;

private:
	
	FVector4 CachedQuadPositionData; 
	FTextureResource* CachedCopyTextureResource = nullptr;
	TRefCountPtr<IPooledRenderTarget> CopyPooledTexture = nullptr;
	FSceneTextureForTextRenderParams RenderParams;
	
};
