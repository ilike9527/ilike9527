﻿// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SceneTextureCopySceneViewExtension.h"
#include "RHI.h"
#include "SceneView.h"
#include "PostProcess/PostProcessing.h"
#include "ScreenPass.h"
#include "CommonRenderResources.h"
#include "Containers/DynamicRHIResourceArray.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "SceneRendering.h"
#include "Engine/TextureRenderTarget2D.h"
#include "DynamicResolutionState.h"
#include "TextureResource.h"

#include "SceneTextureForUMGRenderer.h"
#include "SceneTextureCopySubsystem.h"
#include "SceneTextureCopyMaterial.h"
#include "SceneTextureForUMGSettings.h"

namespace
{
	template<typename TSetupFunction>
	void DrawScreenPass(
		FRHICommandListImmediate& RHICmdList,
		const FScreenPassViewInfo ViewInfo,
		const FScreenPassTextureViewport& OutputViewport,
		const FScreenPassTextureViewport& InputViewport,
		const FScreenPassPipelineState& PipelineState,
		EScreenPassDrawFlags Flags,
		TSetupFunction SetupFunction)
	{
		PipelineState.Validate();

		const FIntRect InputRect = InputViewport.Rect;
		const FIntPoint InputSize = InputViewport.Extent;
		const FIntRect OutputRect = OutputViewport.Rect;
		const FIntPoint OutputSize = OutputRect.Size();

		//UE_LOG(LogTemp, Warning, TEXT("RHICmdList.SetViewport(%d,%d,%d,%d)"), OutputRect.Min.X, OutputRect.Min.Y, OutputRect.Max.X, OutputRect.Max.Y);
		RHICmdList.SetViewport(OutputRect.Min.X, OutputRect.Min.Y, 0.0f, OutputRect.Max.X, OutputRect.Max.Y, 1.0f);

		SetScreenPassPipelineState(RHICmdList, PipelineState);

		// Setting up buffers.
		SetupFunction(RHICmdList);

		DrawScreenPass_PostSetup(RHICmdList, ViewInfo, OutputViewport, InputViewport, PipelineState, Flags);
	}

	FVector4 Clamp(const FVector4 & VectorToClamp, float Min, float Max)
	{
		return FVector4(FMath::Clamp(VectorToClamp.X, Min, Max),
						FMath::Clamp(VectorToClamp.Y, Min, Max),
						FMath::Clamp(VectorToClamp.Z, Min, Max),
						FMath::Clamp(VectorToClamp.W, Min, Max));
	}
}

FSceneTextureCopySceneViewExtension::FSceneTextureCopySceneViewExtension(const FAutoRegister& AutoRegister, USceneTextureCopySubsystem* InWorldSubsystem) :
	FSceneViewExtensionBase(AutoRegister), WorldSubsystem(InWorldSubsystem)
{
}

void FSceneTextureCopySceneViewExtension::PostRenderBasePassMobile_RenderThread(FRHICommandList& RHICmdList, FSceneView& InView)
{
	if (!WorldSubsystem)
	{
		return;
	}

	bool EnableSceneColor = USceneTextureForUMGSettings::GetInstance()->EnableSceneColor;
	bool EnableSceneDepth = USceneTextureForUMGSettings::GetInstance()->EnableSceneDepth;
	bool EnableCustomDepth = USceneTextureForUMGSettings::GetInstance()->EnableCustomDepth;
	if (!EnableSceneColor && !EnableSceneDepth && !EnableCustomDepth)
	{
		return;
	}

	const FSceneViewFamily& ViewFamily = *InView.Family;
	DynamicRenderScaling::TMap<float> UpperBounds = ViewFamily.GetScreenPercentageInterface()->GetResolutionFractionsUpperBound();
	const auto FeatureLevel = InView.GetFeatureLevel();
	const float ScreenPercentage = UpperBounds[GDynamicPrimaryResolutionFraction] * ViewFamily.SecondaryViewFraction;

	//checkSlow(View.bIsViewInfo); // can't do dynamic_cast because FViewInfo doesn't have any virtual functions.
	const FIntRect PrimaryViewRect = static_cast<const FViewInfo&>(InView).ViewRect;

	const FSceneTextures& SceneTextures = static_cast<const FViewInfo&>(InView).GetSceneTextures();

	TRDGUniformBufferRef<FMobileSceneTextureUniformParameters> SceneTexturesBuffer = SceneTextures.MobileUniformBuffer;
	// Scene Textures
	FScreenPassTexture SceneColor((*SceneTexturesBuffer)->SceneDepthTexture, PrimaryViewRect);
	FScreenPassTexture SceneDepth((*SceneTexturesBuffer)->SceneDepthTexture, PrimaryViewRect);
	FScreenPassTexture CustomDepth((*SceneTexturesBuffer)->CustomDepthTexture, PrimaryViewRect);

	if (!SceneColor.IsValid() && !SceneDepth.IsValid() && !CustomDepth.IsValid())
	{
		return;
	}

	EnableSceneColor = EnableSceneColor && SceneColor.IsValid();
	EnableSceneDepth = EnableSceneDepth && SceneDepth.IsValid();
	EnableCustomDepth = EnableCustomDepth && CustomDepth.IsValid();

	// Get ViewportSize
	const FScreenPassTextureViewport RegionViewport(SceneColor);
	FIntPoint ViewportSize = RegionViewport.Rect.Size();
	if (ViewportSize != FSceneTextureForUMGRenderer::Get().GetRenderTargetSize())
	{
		ReleasePooledTextures();
		FSceneTextureForUMGRenderer::Get().UpdateRenderTargetSize_GameThread(ViewportSize);
		return;
	}

	InitPooledTextures();

	FGlobalShaderMap* GlobalShaderMap = GetGlobalShaderMap(GMaxRHIFeatureLevel);
	FRHIBlendState* DefaultBlendState = FScreenPassPipelineState::FDefaultBlendState::GetRHI();

	//if (SceneColorPooledTexture && EnableSceneColor)
	//{
	//	FRDGBuilder GraphBuilder(RHICmdList);
	//	FUMGCopySceneColorPS::FParameters* Parameters = GraphBuilder.AllocParameters<FUMGCopySceneColorPS::FParameters>();
	//	Parameters->SceneColorTexture = SceneColor.Texture;
	//	Parameters->SceneColorSampler = TStaticSamplerState</*SF_Bilinear*/SF_Point, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();

	//	TShaderMapRef<FSceneTextureCopyScreenPassVS> ScreenPassVS(GlobalShaderMap);
	//	auto CopyPixelShader = GlobalShaderMap->GetShader<FUMGCopySceneColorPS>();

	//	FRDGTextureRef RDGSceneColorTexture = GraphBuilder.RegisterExternalTexture(SceneColorPooledTexture);
	//	Parameters->RenderTargets[0] = FRenderTargetBinding(RDGSceneColorTexture, ERenderTargetLoadAction::EClear);

	//	GraphBuilder.AddPass(
	//		RDG_EVENT_NAME("CopySceneColor"),
	//		Parameters,
	//		ERDGPassFlags::Raster,
	//		[&InView, ScreenPassVS, CopyPixelShader, RegionViewport, Parameters, DefaultBlendState](FRHICommandListImmediate& RHICmdList)
	//		{
	//			DrawScreenPass(
	//				RHICmdList,
	//				InView,
	//				RegionViewport,
	//				RegionViewport,
	//				FScreenPassPipelineState(ScreenPassVS, CopyPixelShader, DefaultBlendState),
	//				[&](FRHICommandListImmediate&)
	//				{
	//					SetShaderParameters(RHICmdList, CopyPixelShader, CopyPixelShader.GetPixelShader(), *Parameters);
	//				});
	//		});
	//}

	//if (SceneDepthPooledTexture && EnableSceneDepth)
	//{
	//	FRDGBuilder GraphBuilder(RHICmdList);
	//	FUMGCopyDepthPS::FParameters* Parameters = GraphBuilder.AllocParameters<FUMGCopyDepthPS::FParameters>();
	//	Parameters->CustomDepthTexture = SceneDepth.Texture;
	//	Parameters->CustomDepthSampler = TStaticSamplerState</*SF_Bilinear*/SF_Point, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();

	//	TShaderMapRef<FSceneTextureCopyScreenPassVS> ScreenPassVS(GlobalShaderMap);
	//	auto CopyPixelShader = GlobalShaderMap->GetShader<FUMGCopyDepthPS>();

	//	FRDGTextureRef RDGSceneDepthTexture = GraphBuilder.RegisterExternalTexture(SceneDepthPooledTexture);
	//	Parameters->RenderTargets[0] = FRenderTargetBinding(RDGSceneDepthTexture, ERenderTargetLoadAction::EClear);

	//	GraphBuilder.AddPass(
	//		RDG_EVENT_NAME("CopySceneDepth"),
	//		Parameters,
	//		ERDGPassFlags::Raster,
	//		[&InView, ScreenPassVS, CopyPixelShader, RegionViewport, Parameters, DefaultBlendState](FRHICommandListImmediate& RHICmdList)
	//		{
	//			DrawScreenPass(
	//				RHICmdList,
	//				InView,
	//				RegionViewport,
	//				RegionViewport,
	//				FScreenPassPipelineState(ScreenPassVS, CopyPixelShader, DefaultBlendState),
	//				[&](FRHICommandListImmediate&)
	//				{
	//					SetShaderParameters(RHICmdList, CopyPixelShader, CopyPixelShader.GetPixelShader(), *Parameters);
	//				});
	//		});
	//}

	//if (CustomDepthPooledTexture && EnableCustomDepth)
	//{
	//	FRDGBuilder GraphBuilder(RHICmdList);
	//	FUMGCopyDepthPS::FParameters* Parameters = GraphBuilder.AllocParameters<FUMGCopyDepthPS::FParameters>();
	//	Parameters->CustomDepthTexture = CustomDepth.Texture;
	//	Parameters->CustomDepthSampler = TStaticSamplerState</*SF_Bilinear*/SF_Point, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();

	//	TShaderMapRef<FSceneTextureCopyScreenPassVS> ScreenPassVS(GlobalShaderMap);
	//	auto CopyPixelShader = GlobalShaderMap->GetShader<FUMGCopyDepthPS>();

	//	FRDGTextureRef RDGCustomDepthTexture = GraphBuilder.RegisterExternalTexture(CustomDepthPooledTexture);
	//	Parameters->RenderTargets[0] = FRenderTargetBinding(RDGCustomDepthTexture, ERenderTargetLoadAction::EClear);

	//	GraphBuilder.AddPass(
	//		RDG_EVENT_NAME("CopyCustomDepth"),
	//		Parameters,
	//		ERDGPassFlags::Raster,
	//		[&InView, ScreenPassVS, CopyPixelShader, RegionViewport, Parameters, DefaultBlendState](FRHICommandListImmediate& RHICmdList)
	//		{
	//			DrawScreenPass(
	//				RHICmdList,
	//				InView,
	//				RegionViewport,
	//				RegionViewport,
	//				FScreenPassPipelineState(ScreenPassVS, CopyPixelShader, DefaultBlendState),
	//				[&](FRHICommandListImmediate&)
	//				{
	//					SetShaderParameters(RHICmdList, CopyPixelShader, CopyPixelShader.GetPixelShader(), *Parameters);
	//				});
	//		});
	//}
}

void FSceneTextureCopySceneViewExtension::PrePostProcessPass_RenderThread(FRDGBuilder& GraphBuilder, const FSceneView& View, const FPostProcessingInputs& Inputs)
{
	if (!WorldSubsystem)
	{
		return;
	}

	bool EnableSceneColor = USceneTextureForUMGSettings::GetInstance()->EnableSceneColor;
	bool EnableSceneDepth = USceneTextureForUMGSettings::GetInstance()->EnableSceneDepth;
	bool EnableCustomDepth = USceneTextureForUMGSettings::GetInstance()->EnableCustomDepth;
	bool EnableCustomStencil = USceneTextureForUMGSettings::GetInstance()->EnableCustomStencil;
	if (!EnableSceneColor && !EnableSceneDepth && !EnableCustomDepth && !EnableCustomStencil)
	{
		return;
	}

	Inputs.Validate();

	const FSceneViewFamily& ViewFamily = *View.Family;
	DynamicRenderScaling::TMap<float> UpperBounds = ViewFamily.GetScreenPercentageInterface()->GetResolutionFractionsUpperBound();
	const auto FeatureLevel = View.GetFeatureLevel();
	const float ScreenPercentage = UpperBounds[GDynamicPrimaryResolutionFraction] * ViewFamily.SecondaryViewFraction;

	checkSlow(View.bIsViewInfo); // can't do dynamic_cast because FViewInfo doesn't have any virtual functions.
	const FViewInfo& ViewInfo = static_cast<const FViewInfo&>(View);
	const FIntRect PrimaryViewRect = static_cast<const FViewInfo&>(View).ViewRect;
	EScreenPassDrawFlags Flags = EScreenPassDrawFlags::None;
	
	FSceneTextures SceneTextures = static_cast<const FViewInfo&>(View).GetSceneTextures();
	TRDGUniformBufferRef<FSceneTextureUniformParameters> SceneTexturesBuffer = SceneTextures.UniformBuffer;

	// Scene Textures
	FScreenPassTexture SceneColor((*SceneTexturesBuffer)->SceneColorTexture, PrimaryViewRect);
	FScreenPassTexture SceneDepth((*SceneTexturesBuffer)->SceneDepthTexture, PrimaryViewRect);
	FScreenPassTexture CustomDepth((*SceneTexturesBuffer)->CustomDepthTexture, PrimaryViewRect);
	FRDGTextureSRVRef CustomStencil((*SceneTexturesBuffer)->CustomStencilTexture);

	if (!SceneColor.IsValid() && !SceneDepth.IsValid() && !CustomDepth.IsValid())
	{
		return;
	}

	EnableSceneColor = EnableSceneColor && SceneColor.IsValid();
	EnableSceneDepth = EnableSceneDepth && SceneDepth.IsValid();
	EnableCustomDepth = EnableCustomDepth && CustomDepth.IsValid();

	// Get ViewportSize
	const FScreenPassTextureViewport RegionViewport(SceneColor);
	FIntPoint ViewportSize = RegionViewport.Rect.Size();
	static bool bJumpNextFrame = false;
	if (!FSceneTextureForUMGRenderer::Get().CheckRenderTargetSizeMatch(ViewportSize))
	{
		ReleasePooledTextures();
		FSceneTextureForUMGRenderer::Get().UpdateRenderTargetSize_GameThread(ViewportSize);
		bJumpNextFrame = true;
		return;
	}
	else if (bJumpNextFrame)
	{
		bJumpNextFrame = false;
		return;
	}

	InitPooledTextures();

	if (SceneColorPooledTexture && SceneDepthPooledTexture && CustomDepthPooledTexture)
	{
		FGlobalShaderMap* GlobalShaderMap = GetGlobalShaderMap(GMaxRHIFeatureLevel);

		// Get BlendState
		FRHIBlendState* DefaultBlendState = FScreenPassPipelineState::FDefaultBlendState::GetRHI();
		//FRHISamplerState* PointClampSampler = TStaticSamplerState<SF_Point, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();

		//Create Copy PS Shader Parameters
		FCopyTexturePS::FParameters* Parameters = GraphBuilder.AllocParameters<FCopyTexturePS::FParameters>();

		TShaderMapRef<FSceneTextureCopyScreenPassVS> ScreenPassVS(GlobalShaderMap);
		//TShaderMapRef<FCopyTexturePS> CopyPixelShader(GlobalShaderMap);

		FCopyTexturePS::FPermutationDomain PermutationVector;
		PermutationVector.Set<FCopyTexturePS::FCopySceneColor>(EnableSceneColor);
		PermutationVector.Set<FCopyTexturePS::FCopySceneDepth>(EnableSceneDepth);
		PermutationVector.Set<FCopyTexturePS::FCopyCustomDepth>(EnableCustomDepth);
		PermutationVector.Set<FCopyTexturePS::FCopyCustomStencil>(EnableCustomStencil);
		auto CopyPixelShader = GlobalShaderMap->GetShader<FCopyTexturePS>(PermutationVector);

		if (EnableSceneColor)
		{
			Parameters->SceneColorCopyTexture = SceneColor.Texture;
			Parameters->SceneColorCopySampler = TStaticSamplerState</*SF_Bilinear*/SF_Point, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();

		}

		if (EnableSceneDepth)
		{
			Parameters->SceneDepthCopyTexture = SceneDepth.Texture;
			Parameters->SceneDepthCopySampler = TStaticSamplerState</*SF_Bilinear*/SF_Point, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();

		}

		if (EnableCustomDepth)
		{
			Parameters->CustomDepthCopyTexture = CustomDepth.Texture;
			Parameters->CustomDepthCopySampler = TStaticSamplerState</*SF_Bilinear*/SF_Point, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();

		}

		if (EnableCustomStencil)
		{
			Parameters->CustomStencilCopyTexture = CustomStencil;
			Parameters->BufferSize = ViewportSize;
			//Parameters->CustomDepthCopySampler = TStaticSamplerState</*SF_Bilinear*/SF_Point, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();
		}

		FRDGTextureRef RDGSceneColorTexture = GraphBuilder.RegisterExternalTexture(SceneColorPooledTexture);
		FRDGTextureRef RDGSceneDepthTexture = GraphBuilder.RegisterExternalTexture(SceneDepthPooledTexture);
		FRDGTextureRef RDGCustomDepthTexture = GraphBuilder.RegisterExternalTexture(CustomDepthPooledTexture);
		FRDGTextureRef RDGCustomStencilTexture = GraphBuilder.RegisterExternalTexture(CustomStencilPooledTexture);

		Parameters->RenderTargets[0] = FRenderTargetBinding(RDGSceneDepthTexture, ERenderTargetLoadAction::EClear);
		Parameters->RenderTargets[1] = FRenderTargetBinding(RDGCustomDepthTexture, ERenderTargetLoadAction::EClear);
		Parameters->RenderTargets[2] = FRenderTargetBinding(RDGSceneColorTexture, ERenderTargetLoadAction::EClear);
		Parameters->RenderTargets[3] = FRenderTargetBinding(RDGCustomStencilTexture, ERenderTargetLoadAction::EClear);

		//UE_LOG(LogTemp, Warning, TEXT("CopySceneTextures (%d,%d,%d,%d)"), RegionViewport.Rect.Min.X, RegionViewport.Rect.Min.Y, RegionViewport.Rect.Max.X, RegionViewport.Rect.Max.Y);

		GraphBuilder.AddPass(
			RDG_EVENT_NAME("CopySceneTextures"),
			Parameters,
			ERDGPassFlags::Raster,
			[&ViewInfo, ScreenPassVS, CopyPixelShader, RegionViewport, Parameters, DefaultBlendState, Flags](FRHICommandListImmediate& RHICmdList)
			{
				DrawScreenPass(
					RHICmdList,
					ViewInfo,
					RegionViewport,
					RegionViewport,
					FScreenPassPipelineState(ScreenPassVS, CopyPixelShader, DefaultBlendState),
					Flags,
					[&](FRHICommandListImmediate&)
					{
						SetShaderParameters(RHICmdList, CopyPixelShader, CopyPixelShader.GetPixelShader(), *Parameters);
					});
			});
	}
}

void FSceneTextureCopySceneViewExtension::InitPooledTextures()
{
	if (!SceneColorPooledTexture)
	{
		UTextureRenderTarget2D* RT_SceneColor = FSceneTextureForUMGRenderer::Get().GetSceneColor();
		if (RT_SceneColor && RT_SceneColor->GetRenderTargetResource())
		{
			FRHITexture* RHISceneColorTexture = RT_SceneColor->GetRenderTargetResource()->GetRenderTargetTexture();
			SceneColorPooledTexture = CreateRenderTarget(RHISceneColorTexture, TEXT("SceneColorForUMG"));
		}
	}

	if (!SceneDepthPooledTexture)
	{
		UTextureRenderTarget2D* RT_SceneDepth = FSceneTextureForUMGRenderer::Get().GetSceneDepth();
		if (RT_SceneDepth && RT_SceneDepth->GetRenderTargetResource())
		{
			FRHITexture* RHISceneDepthTexture = RT_SceneDepth->GetRenderTargetResource()->GetRenderTargetTexture();
			SceneDepthPooledTexture = CreateRenderTarget(RHISceneDepthTexture, TEXT("SceneDepthForUMG"));
		}
	}

	if (!CustomDepthPooledTexture)
	{
		UTextureRenderTarget2D* RT_CustomDepth = FSceneTextureForUMGRenderer::Get().GetCustomDepth();
		if (RT_CustomDepth && RT_CustomDepth->GetRenderTargetResource())
		{
			FRHITexture* RHICustomDepthTexture = RT_CustomDepth->GetRenderTargetResource()->GetRenderTargetTexture();
			CustomDepthPooledTexture = CreateRenderTarget(RHICustomDepthTexture, TEXT("CustomDepthForUMG"));
		}
	}

	if (!CustomStencilPooledTexture)
	{
		UTextureRenderTarget2D* RT_CustomStencil = FSceneTextureForUMGRenderer::Get().GetCustomStencil();
		if (RT_CustomStencil && RT_CustomStencil->GetRenderTargetResource())
		{
			FRHITexture* RHICustomDepthTexture = RT_CustomStencil->GetRenderTargetResource()->GetRenderTargetTexture();
			CustomStencilPooledTexture = CreateRenderTarget(RHICustomDepthTexture, TEXT("CustomStencilForUMG"));
		}
	}
}

void FSceneTextureCopySceneViewExtension::ReleasePooledTextures()
{
	if (SceneColorPooledTexture)
	{
		SceneColorPooledTexture.SafeRelease();
		SceneColorPooledTexture = nullptr;
	}

	if (SceneDepthPooledTexture)
	{
		SceneDepthPooledTexture.SafeRelease();
		SceneDepthPooledTexture = nullptr;
	}

	if (CustomDepthPooledTexture)
	{
		CustomDepthPooledTexture.SafeRelease();
		CustomDepthPooledTexture = nullptr;
	}

	if (CustomStencilPooledTexture)
	{
		CustomStencilPooledTexture.SafeRelease();
		CustomStencilPooledTexture = nullptr;
	}
}

