// Copyright Qibo Pang 2023. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

struct FGeometryCacheToVATGridSearchEntity
{
    FVector2D Point;
    uint32 Index;
    FGeometryCacheToVATGridSearchEntity() : Point(FVector2D(0, 0)), Index(0) {};
    FGeometryCacheToVATGridSearchEntity(FVector2D InPoint, uint32 InIndex) : Point(InPoint), Index(InIndex) {};
};

struct FGeometryCacheToVATGridSearch
{
public:
    FGeometryCacheToVATGridSearch(int32 InGridSize, TArray<FGeometryCacheToVATGridSearchEntity>& InPoints)
    {
        GridSize = InGridSize;
        GridCells.Init(TArray<FGeometryCacheToVATGridSearchEntity>(), GridSize * GridSize);
        for (FGeometryCacheToVATGridSearchEntity& Point : InPoints)
        {
            int32 GridX = FMath::FloorToInt(Point.Point.X * (float)GridSize);
            int32 GridY = FMath::FloorToInt(Point.Point.Y * (float)GridSize);
            int32 CellIndex = GridX + GridY * GridSize;
            if (CellIndex < 0 || CellIndex >= GridCells.Num())
				continue;
            GridCells[CellIndex].Add(Point);
        }
    }

    FGeometryCacheToVATGridSearchEntity* FindClosest(FVector2D Target)
    {
        int32 GridX = FMath::FloorToInt(Target.X * (float)GridSize);
        int32 GridY = FMath::FloorToInt(Target.Y * (float)GridSize);

        FGeometryCacheToVATGridSearchEntity* ClosestNode = nullptr;
        float ClosestDistance = FLT_MAX;

        for (int32 x = GridX - 1; x <= GridX + 1; x++)
        {
            for (int32 y = GridY - 1; y <= GridY + 1; y++)
            {
                int32 CellIndex = x + y * GridSize;
                if (CellIndex < 0 || CellIndex >= GridCells.Num())
                    continue;

                for (FGeometryCacheToVATGridSearchEntity& Point : GridCells[CellIndex])
                {
                    float Distance = FVector2D::DistSquared(Target, Point.Point);
                    if (Distance < ClosestDistance)
                    {
                        ClosestDistance = Distance;
                        ClosestNode = &Point;
                    }
                }
            }
        }

        return ClosestNode;
    }

private:
    TArray<TArray<FGeometryCacheToVATGridSearchEntity>> GridCells;
    int32 GridSize;
};
