// Copyright Qibo Pang 2023. All Rights Reserved.

#include "GeometryCacheToVATBPLibrary.h"
#include "GeometryCacheToVATUtils.h"
#include "GeometryCacheToVATTypes.h"
#include "GeometryCacheMeshData.h"
#include "GeometryCacheToVATGridSearch.h"

#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 2
#include "MaterialDomain.h"
#endif

#include "LevelEditor.h"
#include "RawMesh.h"
#include "MeshUtilities.h"
#include "Modules/ModuleManager.h"
#include "Engine/SkeletalMesh.h"
#include "Components/SkeletalMeshComponent.h"
#include "Animation/Skeleton.h"
#include "Animation/AnimSequence.h"
#include "Math/Vector.h"
#include "Math/NumericLimits.h"
#include "MeshDescription.h"
#include "Materials/MaterialInstanceConstant.h"
#include "MaterialEditingLibrary.h"
#include "Misc/ScopedSlowTask.h"
#include "Misc/Paths.h"
#include "Misc/FileHelper.h"
#include "GeometryCache.h"
#include "StaticMeshAttributes.h"


#define LOCTEXT_NAMESPACE "GeometryCacheToVATEditor"

DEFINE_LOG_CATEGORY(LogGeometryCacheToVAT);

using namespace GeometryCacheToVAT_Private;

UGeometryCacheToVATBPLibrary::UGeometryCacheToVATBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

bool UGeometryCacheToVATBPLibrary::GeometryCacheToVertexAnimation(UGeometryCache* GeometryCache, FGeometryCacheToVATContext& Context)
{
	if (!GeometryCache)
	{
		RecordError(TEXT("Invalid GeometryCache"), Context.ErrorCallback);
		return false;
	}

	// Check Context
	if (!CheckContextValid(Context))
	{
		return false;
	}

	// Get Settings
	FGeometryCacheToVATInput& Input = Context.Input;
	FGeometryCacheToVATConfig& Config = Context.Config;
	FGeometryCacheToVATOutput& Output = Context.Output;

	FString SubDirectoryName = GeometryCache->GetName();
	FString OutputContentPath = FPaths::Combine(Output.OutputFilePath.Path, SubDirectoryName);

	Context.CacheSubDirectoryName = SubDirectoryName;
	FString OutputFilePath = Context.GetOutputPath();
	if (OutputFilePath.StartsWith(TEXT("/Game/")))
		OutputFilePath = FPaths::Combine(FPaths::ProjectContentDir(), OutputFilePath.Replace(TEXT("/Game/"), TEXT("")));
	FString OutputFilePathFull = FPaths::ConvertRelativePathToFull(OutputFilePath);

	// ---------------------------------------------------------------------------
	// Init Render Mesh
	//		

	int32 NumVertices = 0;
	int32 FrameNum = 0;
	float TotalDuration = GeometryCache->CalculateDuration();
	FGeometryCacheRenderMesh RenderMesh;
	{
		TArray<FGeometryCacheMeshData> ZeroFrameMeshData;
		GeometryCache->GetMeshDataAtTime(0.0f, ZeroFrameMeshData);

		for (const FGeometryCacheMeshData& MeshData : ZeroFrameMeshData)
		{
			NumVertices += MeshData.Positions.Num();

			FGeometryCacheRenderMeshSection Section;
			Section.Positions = MeshData.Positions;
			Section.Normals = MeshData.TangentsZ;
			Section.Colors = MeshData.Colors;
			Section.Uvs = MeshData.TextureCoordinates;
			Section.Indices = MeshData.Indices;
			/*Section.MaterialInterface = MeshData.Material;
			Section.SectionName = MeshData.SectionName;
			Section.MaterialName = MeshData.MaterialName;*/
			RenderMesh.Sections.Add(Section);
		}

		if (RenderMesh.Sections.Num() == 0)
		{
			RecordError(TEXT("GenerateRenderMesh failed!"), Context.ErrorCallback);
			return false;
		}

		NumVertices = RenderMesh.GetTotalVertexCount();
	}
	UE_LOG(LogGeometryCacheToVAT, Warning, TEXT("NumVertices: %ix"), NumVertices);

	// ---------------------------------------------------------------------------
	// Get Vertex Data (for all frames)
	//		
	TArray<FVector3f> VertexDeltas;
	TArray<FVector3f> VertexNormals;
	
	int32 NumFrames = 0;
	{
		float FrameRate = FMath::Max(1.0f, Config.SampleRate);
		float AverageFrameDelta = 1.0f / FrameRate;
		FrameNum = FMath::CeilToInt(TotalDuration / AverageFrameDelta);

		UpdateProgress(0 /*Percentage*/, Context.ProgressCallback);
		for (int32 FrameIdx = 0; FrameIdx <= FrameNum; ++FrameIdx)
		{
			float FrameTime = (FrameIdx)*AverageFrameDelta;
			
			TArray<FGeometryCacheMeshData> FrameMeshData;
			if (FrameIdx == FrameNum)
			{
				GeometryCache->GetMeshDataAtTime(TotalDuration, FrameMeshData);
				UpdateProgress(100/*Percentage*/, Context.ProgressCallback);
			}
			else if (FrameTime < TotalDuration)
			{
				GeometryCache->GetMeshDataAtTime(FrameTime, FrameMeshData);
				UpdateProgress((FrameIdx * 100) / FrameNum /*Percentage*/, Context.ProgressCallback);
			}
			else
			{
				break;
			}

			for (int PieceIndex = 0; PieceIndex < FrameMeshData.Num(); PieceIndex++)
			{
				// check topology is the same
				if (RenderMesh.Sections[PieceIndex].Positions.Num() == FrameMeshData[PieceIndex].Positions.Num()
					&& RenderMesh.Sections[PieceIndex].Normals.Num() == FrameMeshData[PieceIndex].TangentsZ.Num())
				{
					TArray<FVector3f> VertexFrameDeltas;
					TArray<FVector3f> VertexFrameNormals;

					GetVertexDeltasAndNormals(RenderMesh.Sections[PieceIndex].Positions,
						FrameMeshData[PieceIndex].Positions,
						FrameMeshData[PieceIndex].TangentsZ,
						Config.RootTransform,
						VertexFrameDeltas, VertexFrameNormals);

					VertexDeltas.Append(VertexFrameDeltas);
					VertexNormals.Append(VertexFrameNormals);
				}
			}
			NumFrames++;
			if (Config.MaxExportFrames != -1 && NumFrames >= Config.MaxExportFrames)
			{
				break;
			}
		}
	}
	
	
	if (NumVertices > 0 && NumFrames > 0)
	{
		// Find Best Resolution for Vertex Data
		int32 Height, Width;
		if (!FindBestResolution(NumFrames, NumVertices,
			Height, Width, Context.VertexRowsPerFrame,
			Config.MaxHeight, Config.MaxWidth, Config.bEnforcePowerOfTwo))
		{
			FString Message = FString::Printf(TEXT("Vertex Animation data cannot be fit in a %ix%i texture."), Config.MaxHeight, Config.MaxWidth);
			RecordError(Message, Context.ErrorCallback);
			return false;
		}
		Context.TextureHeight = Height;
		Context.TextureWidth = Width;

		// ---------------------------------------------------------------------------		
		// Generate StaticMesh
		//
		CreateUVChannel(RenderMesh, Config.UVChannel, Height, Width);

		UStaticMesh* StaticMesh = nullptr;
		FString PackagePath = Output.OutputFilePath.Path;
		if (!PackagePath.EndsWith(TEXT("/")))
		{
			PackagePath += TEXT("/");
		}
		FString PackageName = GeometryCache->GetName();
		int32 LODIndex = 0;
		if (!PackagePath.IsEmpty() /*&& FPackageName::IsValidObjectPath(PackagePath)*/)
		{
			StaticMesh = ConvertGeometryCacheToStaticMesh(RenderMesh, PackagePath, PackageName, LODIndex);
		}

		if (!StaticMesh)
		{
			RecordError(TEXT("Failed to convert Geometry to StaticMesh"), Context.ErrorCallback);
			return false;
		}

		SetLightMapIndex(StaticMesh, LODIndex, 3, true);

		// ---------------------------------------------------------------------------
		// Write Data to Textures
		//
		
		// Normalize Vertex Data
		TArray<FVector3f> NormalizedVertexDeltas;
		TArray<FVector3f> NormalizedVertexNormals;
		NormalizeVertexData(
			VertexDeltas, VertexNormals,
			Context.VertexMinBBox, Context.VertexSizeBBox,
			NormalizedVertexDeltas, NormalizedVertexNormals);

		UE_LOG(LogGeometryCacheToVAT, Warning, TEXT("Vertex Animation data output a %ix%i texture. VertexMinBBox(%s) VertexSizeBBox(%s)"), Height, Width, *Context.VertexMinBBox.ToString(), *Context.VertexSizeBBox.ToString());

		// Write Textures
		if (Config.Precision == EGeometryCacheToVATPrecision::SixteenBits)
		{
			Context.VertexPositionTexture = WriteVectorsToTexture<FVector3f, FHighPrecision>(Context, TEXT("VertextOffset"), NumFrames, Height, Width, NormalizedVertexDeltas);
			Context.VertexNormalTexture = WriteVectorsToTexture<FVector3f, FHighPrecision>(Context, TEXT("VertextNormal"), NumFrames, Height, Width, NormalizedVertexNormals);
		}
		else
		{
			Context.VertexPositionTexture = WriteVectorsToTexture<FVector3f, FLowPrecision>(Context, TEXT("VertextOffset"), NumFrames, Height, Width, NormalizedVertexDeltas);
			Context.VertexNormalTexture = WriteVectorsToTexture<FVector3f, FLowPrecision>(Context, TEXT("VertextNormal"), NumFrames, Height, Width, NormalizedVertexNormals);
		}		

		// Update Bounds
		SetBoundsExtensions(StaticMesh, (FVector)Context.VertexMinBBox, (FVector)Context.VertexSizeBBox);

		Context.NumFrames = NumFrames;
		Context.StaticMesh = StaticMesh;

		if (Config.bNaniteSupport)
		{
			GenerateNaniteTexture(Context);
		}
	}
	else
	{
		RecordError(TEXT("No Vertex Animation data to write."), Context.ErrorCallback);
		return false;
	}

	// ---------------------------------------------------------------------------
	// Map material instances
	//
	for (UMaterialInstance* MaterialInstance : Config.MaterialInstancesToUpdate)
	{
		if (UMaterialInstanceConstant* MaterialInstanceConstant = Cast<UMaterialInstanceConstant>(MaterialInstance))
		{
			UGeometryCacheToVATBPLibrary::UpdateMaterialInstanceFromDataAsset(Context, MaterialInstanceConstant, EMaterialParameterAssociation::LayerParameter);
		}
	}
		
	// All good here !
	return true;
}

static FMeshDescription BuildMeshDescription(const FGeometryCacheRenderMesh& RenderMesh)
{
	FMeshDescription MeshDescription;

	FStaticMeshAttributes AttributeGetter(MeshDescription);
	AttributeGetter.Register();

	TPolygonGroupAttributesRef<FName> PolygonGroupNames = AttributeGetter.GetPolygonGroupMaterialSlotNames();
	TVertexAttributesRef<FVector3f> VertexPositions = AttributeGetter.GetVertexPositions();
	TVertexInstanceAttributesRef<FVector3f> Tangents = AttributeGetter.GetVertexInstanceTangents();
	TVertexInstanceAttributesRef<float> BinormalSigns = AttributeGetter.GetVertexInstanceBinormalSigns();
	TVertexInstanceAttributesRef<FVector3f> Normals = AttributeGetter.GetVertexInstanceNormals();
	TVertexInstanceAttributesRef<FVector4f> Colors = AttributeGetter.GetVertexInstanceColors();
	TVertexInstanceAttributesRef<FVector2f> UVs = AttributeGetter.GetVertexInstanceUVs();

	// Materials to apply to new mesh
	const int32 NumSections = RenderMesh.Sections.Num();
	int32 VertexCount = 0;
	int32 VertexInstanceCount = 0;
	int32 PolygonCount = 0;

	// Each section belong to individual group
	TArray<FPolygonGroupID> PolygonGroupForSection;
	PolygonGroupForSection.Reserve(NumSections);

	// Calculate the totals for each ProcMesh element type
	for (int32 SectionIdx = 0; SectionIdx < NumSections; SectionIdx++)
	{
		const FGeometryCacheRenderMeshSection& MeshSection =
			RenderMesh.Sections[SectionIdx];
		VertexCount += MeshSection.Positions.Num();
		VertexInstanceCount += MeshSection.Indices.Num();
		PolygonCount += MeshSection.Indices.Num() / 3;
	}
	MeshDescription.ReserveNewVertices(VertexCount);
	MeshDescription.ReserveNewVertexInstances(VertexInstanceCount);
	MeshDescription.ReserveNewPolygons(PolygonCount);
	MeshDescription.ReserveNewEdges(PolygonCount * 2);
	UVs.SetNumIndices(4);

	// Create the Polygon Groups
	for (int32 SectionIdx = 0; SectionIdx < NumSections; SectionIdx++)
	{
		const FGeometryCacheRenderMeshSection& MeshSection =
			RenderMesh.Sections[SectionIdx];
		UMaterialInterface* Material = MeshSection.MaterialInterface;
		if (Material == nullptr)
		{
			Material = UMaterial::GetDefaultMaterial(EMaterialDomain::MD_Surface);
		}

		FPolygonGroupID PolygonGroupID = MeshDescription.CreatePolygonGroup();
		PolygonGroupForSection.Add(PolygonGroupID);
		PolygonGroupNames[PolygonGroupID] = Material->GetFName();
	}

	// Add Vertex and VertexInstance and polygon for each section
	for (int32 SectionIdx = 0; SectionIdx < NumSections; SectionIdx++)
	{
		const FGeometryCacheRenderMeshSection& MeshSection =
			RenderMesh.Sections[SectionIdx];
		FPolygonGroupID PolygonGroupID = PolygonGroupForSection[SectionIdx];
		// Create the vertex
		int32 NumVertex = MeshSection.Positions.Num();
		TMap<int32, FVertexID> VertexIndexToVertexID;
		VertexIndexToVertexID.Reserve(NumVertex);
		for (int32 VertexIndex = 0; VertexIndex < NumVertex; ++VertexIndex)
		{
			const FVector3f& Vert = MeshSection.Positions[VertexIndex];
			const FVertexID VertexID = MeshDescription.CreateVertex();
			VertexPositions[VertexID] = FVector3f(Vert);
			VertexIndexToVertexID.Add(VertexIndex, VertexID);
		}
		// Create the VertexInstance
		int32 NumIndices = MeshSection.Indices.Num();
		int32 NumTri = NumIndices / 3;
		TMap<int32, FVertexInstanceID> IndiceIndexToVertexInstanceID;
		IndiceIndexToVertexInstanceID.Reserve(NumVertex);
		for (int32 IndiceIndex = 0; IndiceIndex < NumIndices; IndiceIndex++)
		{
			const int32 VertexIndex = MeshSection.Indices[IndiceIndex];
			const FVertexID VertexID = VertexIndexToVertexID[VertexIndex];
			const FVertexInstanceID VertexInstanceID =
				MeshDescription.CreateVertexInstance(VertexID);
			IndiceIndexToVertexInstanceID.Add(IndiceIndex, VertexInstanceID);

			Tangents[VertexInstanceID] = FVector3f(1.f, 0.f, 0.f);
			Normals[VertexInstanceID] = MeshSection.Normals[VertexIndex].ToFVector3f();
			BinormalSigns[VertexInstanceID] =
				/*ProcVertex.Tangent.bFlipTangentY ? -1.f :*/ 1.f;

			Colors[VertexInstanceID] = FLinearColor(MeshSection.Colors[VertexIndex]);

			UVs.Set(VertexInstanceID, 0, FVector2f(MeshSection.Uvs[VertexIndex]));
			UVs.Set(VertexInstanceID, 1, FVector2f(MeshSection.UV1[VertexIndex]));
			UVs.Set(VertexInstanceID, 2, FVector2f(MeshSection.UV2[VertexIndex]));
			UVs.Set(VertexInstanceID, 3, FVector2f(MeshSection.UV3[VertexIndex]));
		}

		// Create the polygons for this section
		for (int32 TriIdx = 0; TriIdx < NumTri; TriIdx++)
		{
			FVertexID VertexIndexes[3];
			TArray<FVertexInstanceID> VertexInstanceIDs;
			VertexInstanceIDs.SetNum(3);

			for (int32 CornerIndex = 0; CornerIndex < 3; ++CornerIndex)
			{
				const int32 IndiceIndex = (TriIdx * 3) + CornerIndex;
				const int32 VertexIndex = MeshSection.Indices[IndiceIndex];
				VertexIndexes[CornerIndex] = VertexIndexToVertexID[VertexIndex];
				VertexInstanceIDs[CornerIndex] =
					IndiceIndexToVertexInstanceID[IndiceIndex];
			}

			// Insert a polygon into the mesh
			MeshDescription.CreatePolygon(PolygonGroupID, VertexInstanceIDs);
		}
	}
	return MeshDescription;
}

UStaticMesh* UGeometryCacheToVATBPLibrary::ConvertGeometryCacheToStaticMesh(const FGeometryCacheRenderMesh& RenderMesh, const FString& PackagePath, const FString& PackageName, const int32 LODIndex)
{
	FString PackageFullName = PackagePath + PackageName + TEXT("/Mesh/") + PackageName;
	UStaticMesh* StaticMesh = LoadObject<UStaticMesh>(nullptr, *PackageFullName);
	FMeshDescription MeshDescription = BuildMeshDescription(RenderMesh);
	if (MeshDescription.Polygons().Num() > 0)
	{
		if (!StaticMesh)
		{
			// Then find/create it.
			UPackage* Package = CreatePackage(*PackageFullName);
			if (!Package)
			{
				FText Message = FText::FromString(PackageName + TEXT(" Package Create Fail,Please Check Name!"));
				return nullptr;
			}
			check(Package);
			Package->FullyLoad();
			// Create StaticMesh object
			StaticMesh = NewObject<UStaticMesh>(Package, FName(*PackageName), RF_Public | RF_Standalone);
		}
		StaticMesh->InitResources();
		StaticMesh->SetLightingGuid(FGuid::NewGuid());
#if WITH_EDITOR
		if (StaticMesh->GetNumSourceModels() == 0)
			StaticMesh->AddSourceModel();
		FStaticMeshSourceModel& SrcModel = StaticMesh->GetSourceModel(0);
		SrcModel.BuildSettings.bRecomputeNormals = false;
		SrcModel.BuildSettings.bRecomputeTangents = false;
		SrcModel.BuildSettings.bRemoveDegenerates = false;
		SrcModel.BuildSettings.bUseHighPrecisionTangentBasis = false;
		SrcModel.BuildSettings.bUseFullPrecisionUVs = true;
		SrcModel.BuildSettings.bGenerateLightmapUVs = true;
		SrcModel.BuildSettings.SrcLightmapIndex = 0;
		SrcModel.BuildSettings.DstLightmapIndex = 1;
		StaticMesh->CreateMeshDescription(0, MoveTemp(MeshDescription));
		StaticMesh->CommitMeshDescription(0);
#else
		// Add source to new StaticMesh
		UStaticMesh::FBuildMeshDescriptionsParams MdParams;
		MdParams.bBuildSimpleCollision = true;
#ifdef GeometryCache_UE_5
		MdParams.bFastBuild = true;
#endif
#endif
		TArray<FString> MaterialIDs;
		TArray<UMaterialInterface*> UniqueMaterials;
		const int32 NumSections = RenderMesh.Sections.Num();
		for (int32 SectionIdx = 0; SectionIdx < NumSections; SectionIdx++)
		{
			UMaterialInterface* MaterialAsset = RenderMesh.Sections[SectionIdx].MaterialInterface;
			UniqueMaterials.AddUnique(MaterialAsset);
		}
		// Copy materials to new mesh
		StaticMesh->GetStaticMaterials().Empty();
		for (auto* Material : UniqueMaterials)
		{
			StaticMesh->GetStaticMaterials().Add(FStaticMaterial(Material));
		}
		// Set section info
		for (int32 SectionIdx = 0; SectionIdx < NumSections; SectionIdx++)
		{
			FMeshSectionInfo Info;
			UMaterialInterface* Material = RenderMesh.Sections[SectionIdx].MaterialInterface;
			for (int m = 0, NumM = StaticMesh->GetStaticMaterials().Num(); m < NumM; ++m)
			{
				if (Material == StaticMesh->GetStaticMaterials()[m])
				{
					Info.MaterialIndex = m;
					break;
				}
			}
#if WITH_EDITOR
			StaticMesh->GetSectionInfoMap().Set(0, SectionIdx, Info);
#endif
		}
		//Set the Imported version before calling the build
#if WITH_EDITOR
		StaticMesh->ImportVersion = EImportStaticMeshVersion::LastVersion;
		StaticMesh->Build(false);
		StaticMesh->UpdateUVChannelData(false);
#else
		// Build mesh from source
		TArray<const FMeshDescription*> MeshDescPtrs;
		MeshDescPtrs.Emplace(&MeshDescription);
		StaticMesh->BuildFromMeshDescriptions(MeshDescPtrs, MdParams);
		for (FStaticMaterial& Material : StaticMesh->GetStaticMaterials())
		{
			Material.UVChannelData.bInitialized = true;
		}
#endif
#if WITH_EDITOR
		StaticMesh->PostEditChange();
		// Notify asset registry of new asset
		FAssetRegistryModule::AssetCreated(StaticMesh);
		FString PackageFileName = FPackageName::LongPackageNameToFilename(PackageFullName, FPackageName::GetAssetPackageExtension());
		//if (!GeometryCacheAsset->HasAnyFlags(RF_Transient))
		UPackage::SavePackage(StaticMesh->GetPackage(), StaticMesh, EObjectFlags::RF_Public | EObjectFlags::RF_Standalone, *PackageFileName);
#else
		// Notify asset registry of new asset
		FAssetRegistryModule::AssetCreated(StaticMesh);
		FString PackageFileName = FPackageName::LongPackageNameToFilename(PackageName, PackageFullName::GetAssetPackageExtension());
#endif
	}

	return StaticMesh;
}

bool UGeometryCacheToVATBPLibrary::CheckContextValid(const FGeometryCacheToVATContext& Context)
{
	if (Context.Config.UVChannel < 0 || Context.Config.UVChannel > 3)
	{
		RecordError(TEXT("Invalid UVChannel"), Context.ErrorCallback);
		return false;
	}

	if (Context.Config.StaticLODIndex < 0)
	{
		RecordError(TEXT("Invalid StaticLODIndex"), Context.ErrorCallback);
		return false;
	}

	if (Context.Config.MaxHeight <= 0 || Context.Config.MaxWidth <= 0)
	{
		RecordError(TEXT("Invalid MaxHeight or MaxWidth"), Context.ErrorCallback);
		return false;
	}

	if (Context.Config.SampleRate <= 0)
	{
		RecordError(TEXT("Invalid SampleRate"), Context.ErrorCallback);
		return false;
	}

	if (Context.Config.MaxExportFrames < -1)
	{
		RecordError(TEXT("Invalid MaxExportFrames"), Context.ErrorCallback);
		return false;
	}

	if (!Context.Output.OutputFilePath.Path.Len())
	{
		RecordError(TEXT("Invalid OutputFilePath"), Context.ErrorCallback);
		return false;
	}

	// All Good !
	return true;
}

// 
void UGeometryCacheToVATBPLibrary::GetVertexDeltasAndNormals(const TArray<FVector3f>& SourceVertices, const TArray<FVector3f>& DeformedVertices,
	const TArray<FPackedNormal>& DeformedNormals, const FTransform RootTransform, TArray<FVector3f>& OutVertexDeltas, TArray<FVector3f>& OutVertexNormals)
{
	OutVertexDeltas.Reset();
	OutVertexNormals.Reset();
		
	const int32 NumVertices = SourceVertices.Num();

	// Allocate
	check(DeformedVertices.Num() == NumVertices && DeformedNormals.Num() == NumVertices);
	OutVertexDeltas.SetNumUninitialized(NumVertices);
	OutVertexNormals.SetNumUninitialized(NumVertices);

	// Transform Vertices and Normals with RootTransform
	for (int32 VertexIndex = 0; VertexIndex < NumVertices; VertexIndex++)
	{
		const FVector3f& SourceVertex   = SourceVertices[VertexIndex];
		const FVector3f& DeformedVertex = DeformedVertices[VertexIndex];
		const FVector3f& DeformedNormal = DeformedNormals[VertexIndex].ToFVector3f();
	
		// Transform Position and Delta with RootTransform
		const FVector3f TransformedVertexDelta = (FVector3f)(/*RootTransform.TransformPosition*/(DeformedVertex)-SourceVertex);
		const FVector3f TransformedVertexNormal = (FVector3f)/*RootTransform.TransformVector*/(DeformedNormal);
		
		OutVertexDeltas[VertexIndex] = TransformedVertexDelta;
		OutVertexNormals[VertexIndex] = TransformedVertexNormal;
	}
}

void UGeometryCacheToVATBPLibrary::UpdateMaterialInstanceFromDataAsset(FGeometryCacheToVATContext& Context, UMaterialInstanceConstant* MaterialInstance,
	const EMaterialParameterAssociation MaterialParameterAssociation)
{
	check(MaterialInstance);
	FGeometryCacheToVATConfig& Config = Context.Config;

	// Set UVChannel
	switch (Config.UVChannel)
	{
		case 0:
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV0, true, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV1, false, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV2, false, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV3, false, MaterialParameterAssociation);
			break;
		case 1:
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV0, false, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV1, true, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV2, false, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV3, false, MaterialParameterAssociation);
			break;
		case 2:
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV0, false, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV1, false, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV2, true, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV3, false, MaterialParameterAssociation);
			break;
		case 3:
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV0, false, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV1, false, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV2, false, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV3, true, MaterialParameterAssociation);
			break;
		default:
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV0, false, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV1, true, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV2, false, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::UseUV3, false, MaterialParameterAssociation);
			break;
	}

	// Update Vertex Params
	{
		UMaterialEditingLibrary::SetMaterialInstanceVectorParameterValue(MaterialInstance, GeometryCacheToVATParamNames::MinBBox, FLinearColor(Context.VertexMinBBox), MaterialParameterAssociation);
		UMaterialEditingLibrary::SetMaterialInstanceVectorParameterValue(MaterialInstance, GeometryCacheToVATParamNames::SizeBBox, FLinearColor(Context.VertexSizeBBox), MaterialParameterAssociation);
		UMaterialEditingLibrary::SetMaterialInstanceScalarParameterValue(MaterialInstance, GeometryCacheToVATParamNames::RowsPerFrame, Context.VertexRowsPerFrame, MaterialParameterAssociation);
		UMaterialEditingLibrary::SetMaterialInstanceTextureParameterValue(MaterialInstance, GeometryCacheToVATParamNames::VertexPositionTexture, Context.VertexPositionTexture.Get(), MaterialParameterAssociation);
		UMaterialEditingLibrary::SetMaterialInstanceTextureParameterValue(MaterialInstance, GeometryCacheToVATParamNames::VertexNormalTexture, Context.VertexNormalTexture.Get(), MaterialParameterAssociation);
	}

	// AutoPlay
	UMaterialEditingLibrary::SetMaterialInstanceStaticSwitchParameterValue(MaterialInstance, GeometryCacheToVATParamNames::AutoPlay, Config.bAutoPlay, MaterialParameterAssociation);
	if (Config.bAutoPlay)
	{
		int32 StartFrame = 0;
		int32 EndFrame = Context.NumFrames - 1;
		if (Context.NumFrames > 0)
		{
			UMaterialEditingLibrary::SetMaterialInstanceScalarParameterValue(MaterialInstance, GeometryCacheToVATParamNames::StartFrame, StartFrame, MaterialParameterAssociation);
			UMaterialEditingLibrary::SetMaterialInstanceScalarParameterValue(MaterialInstance, GeometryCacheToVATParamNames::EndFrame, EndFrame, MaterialParameterAssociation);
		}
		else
		{
			UE_LOG(LogGeometryCacheToVAT, Warning, TEXT("Invalid frame range: start-%i, end-%i"), StartFrame, EndFrame);
		}
	}
	else
	{
		if (Config.Frame >= 0 && Config.Frame < Context.NumFrames)
		{
			UMaterialEditingLibrary::SetMaterialInstanceScalarParameterValue(MaterialInstance, GeometryCacheToVATParamNames::Frame, Config.Frame, MaterialParameterAssociation);
		}
		else
		{
			UE_LOG(LogGeometryCacheToVAT, Warning, TEXT("Frame out of range: %i"), Config.Frame);
		}
	}
	
	// NumFrames
	UMaterialEditingLibrary::SetMaterialInstanceScalarParameterValue(MaterialInstance, GeometryCacheToVATParamNames::NumFrames, Context.NumFrames, MaterialParameterAssociation);

	// SampleRate
	UMaterialEditingLibrary::SetMaterialInstanceScalarParameterValue(MaterialInstance, GeometryCacheToVATParamNames::SampleRate, Config.SampleRate, MaterialParameterAssociation);

	// Update Material
	UMaterialEditingLibrary::UpdateMaterialInstance(MaterialInstance);

	// Rebuild Material
	UMaterialEditingLibrary::RebuildMaterialInstanceEditors(MaterialInstance->GetMaterial());

	// Set Preview Mesh
	if (Context.StaticMesh.IsValid())
	{
		MaterialInstance->PreviewMesh = Context.StaticMesh.Get();
	}

	MaterialInstance->MarkPackageDirty();
}


bool UGeometryCacheToVATBPLibrary::SetLightMapIndex(UStaticMesh* StaticMesh, const int32 LODIndex, const int32 LightmapIndex, bool bGenerateLightmapUVs)
{
	check(StaticMesh);

	if (!StaticMesh->IsSourceModelValid(LODIndex))
	{
		return false;
	}

	for (int32 Index=0; Index < LightmapIndex; Index++)
	{
		if (LightmapIndex > StaticMesh->GetNumUVChannels(LODIndex))
		{
			StaticMesh->AddUVChannel(LODIndex);
		}
	}

	// Set Build Settings
	FStaticMeshSourceModel& SourceModel = StaticMesh->GetSourceModel(LODIndex);
	SourceModel.BuildSettings.bGenerateLightmapUVs = bGenerateLightmapUVs;
	SourceModel.BuildSettings.DstLightmapIndex = LightmapIndex;
	StaticMesh->SetLightMapCoordinateIndex(LightmapIndex);

	// Build Mesh
	StaticMesh->Build(false);
	StaticMesh->PostEditChange();
	StaticMesh->MarkPackageDirty();

	return true;
}

void UGeometryCacheToVATBPLibrary::NormalizeVertexData(
	const TArray<FVector3f>& Deltas, const TArray<FVector3f>& Normals,
	FVector3f& OutMinBBox, FVector3f& OutSizeBBox,
	TArray<FVector3f>& OutNormalizedDeltas, TArray<FVector3f>& OutNormalizedNormals)
{
	check(Deltas.Num() == Normals.Num());

	// ---------------------------------------------------------------------------
	// Compute Bounding Box
	//
	OutMinBBox = { TNumericLimits<float>::Max(), TNumericLimits<float>::Max(), TNumericLimits<float>::Max() };
	FVector3f MaxBBox = { TNumericLimits<float>::Min(), TNumericLimits<float>::Min(), TNumericLimits<float>::Min() };
	
	for (const FVector3f& Delta: Deltas)
	{
		// Find Min/Max BoundingBox
		OutMinBBox.X = FMath::Min(Delta.X, OutMinBBox.X);
		OutMinBBox.Y = FMath::Min(Delta.Y, OutMinBBox.Y);
		OutMinBBox.Z = FMath::Min(Delta.Z, OutMinBBox.Z);

		MaxBBox.X = FMath::Max(Delta.X, MaxBBox.X);
		MaxBBox.Y = FMath::Max(Delta.Y, MaxBBox.Y);
		MaxBBox.Z = FMath::Max(Delta.Z, MaxBBox.Z);
	}

	OutSizeBBox = MaxBBox - OutMinBBox;

	// ---------------------------------------------------------------------------
	// Normalize Vertex Position Deltas
	// Basically we want all deltas to be between [0, 1]
	
	// Compute Normalization Factor per-axis.
	const FVector3f NormFactor = {
		1.f / static_cast<float>(OutSizeBBox.X),
		1.f / static_cast<float>(OutSizeBBox.Y),
		1.f / static_cast<float>(OutSizeBBox.Z) };

	OutNormalizedDeltas.SetNumUninitialized(Deltas.Num());
	for (int32 Index = 0; Index < Deltas.Num(); ++Index)
	{
		OutNormalizedDeltas[Index] = (Deltas[Index] - OutMinBBox) * NormFactor;
	}

	// ---------------------------------------------------------------------------
	// Normalize Vertex Normals
	// And move them to [0, 1]
	
	OutNormalizedNormals.SetNumUninitialized(Normals.Num());
	for (int32 Index = 0; Index < Normals.Num(); ++Index)
	{
		OutNormalizedNormals[Index] = (Normals[Index].GetSafeNormal() + FVector3f::OneVector) * 0.5f;
	}

}

bool UGeometryCacheToVATBPLibrary::CreateUVChannel(FGeometryCacheRenderMesh& RenderMesh, const int32 UVChannelIndex,
	const int32 Height, const int32 Width)
{

	int32 NumVertices = RenderMesh.GetTotalVertexCount();
	int32 VertexIndex = 0;
	for (int32 Index = 0; Index < RenderMesh.Sections.Num(); Index++)
	{
		RenderMesh.Sections[Index].UV1 = RenderMesh.Sections[Index].Uvs;
		RenderMesh.Sections[Index].UV2 = RenderMesh.Sections[Index].Uvs;
		RenderMesh.Sections[Index].UV3 = RenderMesh.Sections[Index].Uvs;

		TArray<FVector2f>* Uvs = nullptr;
		//Uvs = &RenderMesh.Sections[Index].Uvs;
		switch (UVChannelIndex)
		{
			case 0:
				Uvs = &RenderMesh.Sections[Index].Uvs;
				break;
			case 1:
				Uvs = &RenderMesh.Sections[Index].UV1;
				break;
			case 2:
				Uvs = &RenderMesh.Sections[Index].UV2;
				break;
			case 3:
				Uvs = &RenderMesh.Sections[Index].UV3;
				break;
			default:
				UE_LOG(LogGeometryCacheToVAT, Warning, TEXT("Invalid UVChannel: %i"), UVChannelIndex);
				return false;
		}

		if (Uvs)
		{
			//Uvs->SetNumUninitialized(RenderMesh.Sections[Index].Positions.Num());
			for (int32 UVIndex = 0; UVIndex < Uvs->Num(); UVIndex++)
			{
				double U = (0.5f / (double)Width) + (VertexIndex % Width) / (double)Width;
				double V = (0.5f / (double)Height) + (VertexIndex / Width) / (double)Height;
				(*Uvs)[UVIndex] = FVector2f(U, V);

				//UE_LOG(LogGeometryCacheToVAT, Warning, TEXT("VertexIndex: %i - UV: %f,%f"), VertexIndex, U, V);
				VertexIndex++;
			}
		}
	}

	return true;
}

bool UGeometryCacheToVATBPLibrary::FindBestResolution(
	const int32 NumFrames, const int32 NumElements,
	int32& OutHeight, int32& OutWidth, int32& OutRowsPerFrame,
	const int32 MaxHeight, const int32 MaxWidth, bool bEnforcePowerOfTwo)
{
	if (bEnforcePowerOfTwo)
	{
		OutWidth = 2;
		while (OutWidth < NumElements && OutWidth < MaxWidth)
		{
			OutWidth *= 2;
		}
		OutRowsPerFrame = FMath::CeilToInt(NumElements / (float)OutWidth);

		const int32 TargetHeight = NumFrames * OutRowsPerFrame;
		OutHeight = 2;
		while (OutHeight < TargetHeight)
		{
			OutHeight *= 2;
		}
	}
	else
	{
		OutRowsPerFrame = FMath::CeilToInt(NumElements / (float)MaxWidth);
		OutWidth = FMath::CeilToInt(NumElements / (float)OutRowsPerFrame);
		OutHeight = NumFrames * OutRowsPerFrame;
	}

	const bool bValidResolution = OutWidth <= MaxWidth && OutHeight <= MaxHeight;
	return bValidResolution;
};

void UGeometryCacheToVATBPLibrary::SetFullPrecisionUVs(UStaticMesh* StaticMesh, int32 LODIndex, bool bFullPrecision)
{
	check(StaticMesh);

	if (StaticMesh->IsSourceModelValid(LODIndex))
	{
		FStaticMeshSourceModel& SourceModel = StaticMesh->GetSourceModel(LODIndex);
		SourceModel.BuildSettings.bUseFullPrecisionUVs = bFullPrecision;
	}
}

void UGeometryCacheToVATBPLibrary::SetBoundsExtensions(UStaticMesh* StaticMesh, const FVector& MinBBox, const FVector& SizeBBox)
{
	check(StaticMesh);

	// Calculate MaxBBox
	const FVector MaxBBox = SizeBBox + MinBBox;

	// Reset current extension bounds
	const FVector PositiveBoundsExtension = StaticMesh->GetPositiveBoundsExtension();
	const FVector NegativeBoundsExtension = StaticMesh->GetNegativeBoundsExtension();
		
	// Get current BoundingBox including extensions
	FBox BoundingBox = StaticMesh->GetBoundingBox();
		
	// Remove extensions from BoundingBox
	BoundingBox.Max -= PositiveBoundsExtension;
	BoundingBox.Min += NegativeBoundsExtension;
		
	// Calculate New BoundingBox
	FVector NewMaxBBox(
		FMath::Max(BoundingBox.Max.X, MaxBBox.X),
		FMath::Max(BoundingBox.Max.Y, MaxBBox.Y),
		FMath::Max(BoundingBox.Max.Z, MaxBBox.Z)
	);
		
	FVector NewMinBBox(
		FMath::Min(BoundingBox.Min.X, MinBBox.X),
		FMath::Min(BoundingBox.Min.Y, MinBBox.Y),
		FMath::Min(BoundingBox.Min.Z, MinBBox.Z)
	);

	// Calculate New Extensions
	FVector NewPositiveBoundsExtension = NewMaxBBox - BoundingBox.Max;
	FVector NewNegativeBoundsExtension = BoundingBox.Min - NewMinBBox;
				
	// Update StaticMesh
	StaticMesh->SetPositiveBoundsExtension(NewPositiveBoundsExtension);
	StaticMesh->SetNegativeBoundsExtension(NewNegativeBoundsExtension);
	StaticMesh->CalculateExtendedBounds();
}

void UGeometryCacheToVATBPLibrary::GenerateNaniteTexture(FGeometryCacheToVATContext& Context)
{
	FIntPoint Size = FIntPoint(Context.Config.NaniteTextureSize, Context.Config.NaniteTextureSize);

	const uint32 LODIndex = 0;
	UStaticMesh* StaticMesh = Context.StaticMesh.LoadSynchronous();

	const uint32 UVLightChannel = StaticMesh->GetLightMapCoordinateIndex();
	if (UVLightChannel == INDEX_NONE)
	{
		UE_LOG(LogGeometryCacheToVAT, Warning, TEXT("No Lightmap UV Channel found"));
		return;
	}

	const FStaticMeshRenderData* RenderData = StaticMesh->GetRenderData();
	const FRawStaticIndexBuffer& IndexBuffer = RenderData->LODResources[0].IndexBuffer;
	const FStaticMeshVertexBuffer& VertexBuffer = RenderData->LODResources[0].VertexBuffers.StaticMeshVertexBuffer;

	const int32 GridSize = 16;
	TArray<FGeometryCacheToVATGridSearchEntity> SearchData;
	for (int32 v = 0; v < IndexBuffer.GetNumIndices(); v++)
	{
		uint32 VertexIndex = IndexBuffer.GetIndex(v);
		FVector2D LightmapUV = FVector2D(VertexBuffer.GetVertexUV(VertexIndex, UVLightChannel));
		// UE_LOG(LogGeometryCacheToVAT, Warning, TEXT("LightmapUV: %f,%f"), VertexIndex, LightmapUV.X, LightmapUV.Y);
		SearchData.Add(FGeometryCacheToVATGridSearchEntity(LightmapUV, VertexIndex));
	}

	FGeometryCacheToVATGridSearch Search(GridSize, SearchData);

	// Progress dialog
	FScopedSlowTask Progress(Size.Y, LOCTEXT("BakeAnimation", "Generate Nanite UV Texture"));
	Progress.MakeDialog();

	TArray<typename FHighPrecision::ColorType> Data;
	Data.SetNumZeroed(Size.X * Size.Y);

	ParallelFor(Size.Y, [&Progress, &Size, &Search, &VertexBuffer, &Context, &Data](int32 Y)
		{
			//Progress.EnterProgressFrame();
			for (int32 X = 0; X < Size.X; X++)
			{
				const uint32 DataIndex = X + Y * Size.X;

				const double U = ((double)X + 0.5) / (double)Size.X;
				const double V = ((double)Y + 0.5) / (double)Size.Y;

				const FVector2D UV = FVector2D(U, V);
				FGeometryCacheToVATGridSearchEntity* SearchResult = Search.FindClosest(UV);

				if (SearchResult)
				{
					uint32 ClosestVertexIndex = SearchResult->Index;

					FVector2D UVMapping = FVector2D(VertexBuffer.GetVertexUV(ClosestVertexIndex, Context.Config.UVChannel));

					FVector4u16 Pixel;
					// if (InProfile->Mode == EVertexMode::Vertex)
					{
						// We just map onto the vertex texture, we ensure correct Y value, center of the first row
						Pixel.X = UVMapping.X * 65535.0f;
						Pixel.Y = (0.5f / (float)Context.TextureHeight) * 65535.0f;
						Pixel.Z = 0.0f;
						Pixel.W = 0.0f;
					}

					if (Data.IsValidIndex(DataIndex))
					{
						Data[DataIndex] = Pixel;
					}
				}
			}
		}
	);

	// Write to texture
	Context.Nanite = CreateTexture(Context, Context.Nanite, "VertexNanite", Size, Data);
	WriteToTexture<FHighPrecision>(Context.Nanite.Get(), (uint32)Size.X, (uint32)Size.Y, Data);

	// if (InProfile->Mode == EVertexMode::Vertex)
	{
		// Convert to HalfFloat it needs only one layer in vertex mode
		ChangeTextureCompressionSettings(Context.Nanite.Get(), TextureCompressionSettings::TC_HalfFloat);
	}
}

void UGeometryCacheToVATBPLibrary::UpdateProgress(int32 Percentage, const TFunction<void(int32)> ProgressCallback)
{
	if (ProgressCallback)
	{
		ProgressCallback(Percentage);
	}
}

void UGeometryCacheToVATBPLibrary::RecordError(const FString& ErrorMessage, const TFunction<void(const FString&)> ErrorCallback)
{
	UE_LOG(LogGeometryCacheToVAT, Error, TEXT("%s"), *ErrorMessage);

	if (ErrorCallback)
	{
		ErrorCallback(ErrorMessage);
	}
}


#undef LOCTEXT_NAMESPACE
