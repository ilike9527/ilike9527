// Copyright Qibo Pang 2023. All Rights Reserved.

#include "GeometryCacheToVATConfigPanel.h"
#include "GeometryCacheToVATConfigObject.h"
#include "GeometryCacheToVATBPLibrary.h"
#include "GeometryCacheToVATNotification.h"

#include "PropertyEditing.h"
#include "Interfaces/IPluginManager.h"
#include "Interfaces/IMainFrameModule.h"
#include "DesktopPlatformModule.h"
#include "Misc/ScopedSlowTask.h"

#define LOCTEXT_NAMESPACE "GeometryCacheToVATConfigPanel"

SGeometryCacheToVATConfigPanel::~SGeometryCacheToVATConfigPanel()
{
	if (ConfigObject.Get())
	{
		ConfigObject.Get()->RemoveFromRoot();
	}
}

void SGeometryCacheToVATConfigPanel::Construct(const FArguments& InArgs)
{
	ConfigObject = InArgs._ConfigObject;

	auto& PropertyModule = FModuleManager::LoadModuleChecked< FPropertyEditorModule >("PropertyEditor");
	FDetailsViewArgs DetailsViewArgs(false, false, false, FDetailsViewArgs::HideNameArea, true);
	ConfigPanel = PropertyModule.CreateDetailView(DetailsViewArgs);

	ConfigPanel->SetObject(ConfigObject.Get());

	ChildSlot
		[
			SNew(SVerticalBox)

			+ SVerticalBox::Slot()
			.MaxHeight(800)
			[
				SNew(SBox)
				.HAlign(HAlign_Fill)
				.VAlign(VAlign_Fill)
				[
					SNew(SBorder)
					[
						ConfigPanel.ToSharedRef()
					]
				]
			]
			+ SVerticalBox::Slot()
			.HAlign(HAlign_Center)
			.AutoHeight()
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot().HAlign(HAlign_Fill).VAlign(VAlign_Fill).AutoWidth()
				.Padding(5, 5, 5, 5)
				[
					SNew(SButton)
					.OnClicked(this, &SGeometryCacheToVATConfigPanel::OnConvertButtonClicked)
					[
						SNew(SEditableText)
						.RenderTransformPivot(FVector2D(0.5f, 0.5f))
						.RenderTransform(FSlateRenderTransform(FScale2D(1.f, 1.f)))
						.Text(FText::FromString("Convert")).Visibility(EVisibility::HitTestInvisible)
					]
				]
				+ SHorizontalBox::Slot().HAlign(HAlign_Fill).VAlign(VAlign_Fill).AutoWidth()
				.Padding(5, 5, 5, 5)
				[
					SNew(SButton)
					.OnClicked(this, &SGeometryCacheToVATConfigPanel::OnCancelButtonClicked)
					[
						SNew(SEditableText)
						.RenderTransformPivot(FVector2D(0.5f, 0.5f))
						.RenderTransform(FSlateRenderTransform(FScale2D(1.f, 1.f)))
						.Text(FText::FromString("Cancel")).Visibility(EVisibility::HitTestInvisible)
					]
				]
			]
		];
}

FReply SGeometryCacheToVATConfigPanel::OnConvertButtonClicked()
{
	FGeometryCacheToVATInput& Input = ConfigObject.Get()->Input;
	FGeometryCacheToVATConfig& Config = ConfigObject.Get()->Config;
	FGeometryCacheToVATOutput& Output = ConfigObject.Get()->Output;


	{
		FScopedSlowTask SlowTask(100, FText::FromString(FString(TEXT("Converting Geometry Cache To Vertex Animation"))));
		SlowTask.MakeDialog(true);

		int32 PrePercentage = 0;
		auto ProgressCallback = [&SlowTask, &PrePercentage](int32 ProgressPercentage)
			{
				if (ProgressPercentage > PrePercentage)
				{
					if (IsInGameThread())
					{
						SlowTask.EnterProgressFrame(ProgressPercentage - PrePercentage);
					}
					PrePercentage = ProgressPercentage;

				}
			};

		auto ErrorCallback = [](FString ErrorMessage)
			{
				FGeometryCacheToVATNotification::PopOnce(FText::FromString(ErrorMessage), SNotificationItem::CS_Fail, 3.0f);
			};

		// Call the Blueprint Library function
		FGeometryCacheToVATContext Context = FGeometryCacheToVATContext();
		Context.Input = Input;
		Context.Config = Config;
		Context.Output = Output;
		Context.ErrorCallback = ErrorCallback;
		Context.ProgressCallback = ProgressCallback;

		if (UGeometryCacheToVATBPLibrary::GeometryCacheToVertexAnimation(Input.GeometryCache, Context))
		{
			FGeometryCacheToVATNotification::PopOnce(LOCTEXT("GeometryCacheToVertexAnimationSuccess", "Geometry Cache Convert to Vertex Animation success!"), SNotificationItem::CS_Success, 1.0f);
		}
	}

	return FReply::Handled();
}

FReply SGeometryCacheToVATConfigPanel::OnCancelButtonClicked()
{
	if (GeometryCacheWindow.IsValid())
	{
		GeometryCacheWindow->RequestDestroyWindow();
		GeometryCacheWindow.Reset();
		GeometryCacheWindow = nullptr;
	}

	return FReply::Handled();
}

TSharedPtr<SWindow> SGeometryCacheToVATConfigPanel::PopVertexAnimationConvertConfigWindow(UGeometryCache* GeometryCache)
{

	TSharedPtr<SGeometryCacheToVATConfigPanel> ConfigPanel;

	UGeometryCacheToVATConfigObject* ConfigObject = NewObject<UGeometryCacheToVATConfigObject>();
	ConfigObject->InitConfig();
	ConfigObject->Input.GeometryCache = GeometryCache;
	ConfigObject->AddToRoot();

	TSharedPtr<SWindow> GeometryCacheWindow = SNew(SWindow)
		.Title(FText::FromString(TEXT("Geometry Cache To Vertex Animation")))
		.ClientSize(FVector2D(500, 560))
		.SupportsMinimize(false)
		.SupportsMaximize(false)
		.SizingRule(ESizingRule::FixedSize)
		[
			// Put your tab content here!
			SNew(SBox)
			.HAlign(HAlign_Fill)
			.VAlign(VAlign_Fill)
			[
				SNew(SBorder)
				[
					SAssignNew(ConfigPanel, SGeometryCacheToVATConfigPanel)
					.ConfigObject(ConfigObject)
				]
			]
		];

	ConfigPanel->SetWindow(GeometryCacheWindow);

	IMainFrameModule& MainModule = FModuleManager::LoadModuleChecked<IMainFrameModule>(TEXT("MainFrame"));
	if (MainModule.GetParentWindow().IsValid())
	{
		FSlateApplication::Get().AddWindowAsNativeChild(GeometryCacheWindow.ToSharedRef(), MainModule.GetParentWindow().ToSharedRef());
	}
	else
	{
		FSlateApplication::Get().AddWindow(GeometryCacheWindow.ToSharedRef(), true);
	}

	return GeometryCacheWindow;
}

void FGeometryCacheToVATConfigDetailCustomization::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{

	TSharedPtr<IPropertyHandle> Property_Input = DetailBuilder.GetProperty(GET_MEMBER_NAME_CHECKED(UGeometryCacheToVATConfigObject, Input));
	DetailBuilder.EditDefaultProperty(Property_Input)->ShouldAutoExpand(true);

	TSharedPtr<IPropertyHandle> Property_Config = DetailBuilder.GetProperty(GET_MEMBER_NAME_CHECKED(UGeometryCacheToVATConfigObject, Config));
	DetailBuilder.EditDefaultProperty(Property_Config)->ShouldAutoExpand(true);

	TSharedPtr<IPropertyHandle> Property_Output = DetailBuilder.GetProperty(GET_MEMBER_NAME_CHECKED(UGeometryCacheToVATConfigObject, Output));
	DetailBuilder.EditDefaultProperty(Property_Output)->ShouldAutoExpand(true);

}

TSharedRef<IDetailCustomization> FGeometryCacheToVATConfigDetailCustomization::MakeInstance()
{
	return MakeShared<FGeometryCacheToVATConfigDetailCustomization>();
}


#undef LOCTEXT_NAMESPACE
