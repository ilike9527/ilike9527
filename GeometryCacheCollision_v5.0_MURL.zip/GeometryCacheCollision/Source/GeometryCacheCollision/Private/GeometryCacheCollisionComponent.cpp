// Copyright Qibo Pang 2022. All Rights Reserved.

#include "GeometryCacheCollisionComponent.h"
#include "GeometryCacheComponent.h"
#include "GeometryCache.h"
#include "GeometryCacheSceneProxy.h"
#include "GeometryCacheTrack.h"

#include "Engine.h"
#include "Async/Async.h"
#include "PhysicsEngine/BodySetup.h"
#include "MaterialShared.h"
#include "Materials/Material.h"
#include "PhysicsEngine/PhysicsSettings.h"

#define LOCTEXT_NAMESPACE "GeometryCacheCollisionComponent"

//////////////////////////////////////////////////////////////////////////

FGeometryCacheStatus::FGeometryCacheStatus(UGeometryCacheComponent* InGeometryCacheComponent)
	: GeometryCacheComponent(InGeometryCacheComponent)
{
	if (InGeometryCacheComponent)
	{
		GeometryCache = InGeometryCacheComponent->GetGeometryCache();
		if (FGeometryCacheSceneProxy* SceneProxy = static_cast<FGeometryCacheSceneProxy*>(InGeometryCacheComponent->SceneProxy))
		{
			GeometryCacheSceneProxy = SceneProxy;
		}
		AnimationTime = GeometryCacheComponent->GetAnimationTime();
	}
}

bool FGeometryCacheStatus::ResetWhenChanged()
{
	if (GeometryCacheComponent)
	{
		if (GeometryCacheComponent->GetGeometryCache() != GeometryCache
			|| GeometryCacheComponent->SceneProxy != GeometryCacheSceneProxy)
		{
			if (FGeometryCacheSceneProxy* SceneProxy = static_cast<FGeometryCacheSceneProxy*>(GeometryCacheComponent->SceneProxy))
			{
				const TArray<FGeomCacheTrackProxy*>& Tracks = SceneProxy->GetTracks();
				bool bAllTrackInited = Tracks.Num() > 0;
				for (FGeomCacheTrackProxy* Track: Tracks)
				{
					if (Track->FrameIndex == -1 && Track->NextFrameIndex == -1)
					{
						bAllTrackInited = false;
						break;
					}
				}

				if (bAllTrackInited)
				{
					GeometryCache = GeometryCacheComponent->GetGeometryCache();
					GeometryCacheSceneProxy = SceneProxy;
				
					AnimationTime = GeometryCacheComponent->GetAnimationTime();
					return true;
				}
			}
		}
	}

	return false;
}

bool FGeometryCacheStatus::TracksInited()
{
	if (GeometryCacheSceneProxy)
	{
		const TArray<FGeomCacheTrackProxy*>& Tracks = GeometryCacheSceneProxy->GetTracks();
		bool bAllTrackInited = Tracks.Num() > 0;
		for (FGeomCacheTrackProxy* Track : Tracks)
		{
			if (Track->FrameIndex == -1 && Track->NextFrameIndex == -1)
			{
				bAllTrackInited = false;
				break;
			}
		}

		return bAllTrackInited;
	}
	return false;
}

bool FGeometryCacheStatus::CheckStatusChanged()
{
	if (GeometryCacheComponent && !FMath::IsNearlyEqual(GeometryCacheComponent->GetAnimationTime(),AnimationTime))
	{
		AnimationTime = GeometryCacheComponent->GetAnimationTime();
		return true;
	}
	return false;
}

//////////////////////////////////////////////////////////////////////////

UGeometryCacheCollisionSceneProxy::UGeometryCacheCollisionSceneProxy(UGeometryCacheCollisionComponent* Component)
	: FPrimitiveSceneProxy(Component)
{
	GeometryCacheCollisionComponent = Component;
	if (Component && Component->GetGeometryCacheComponent())
	{
		if (FGeometryCacheSceneProxy* SceneProxy = static_cast<FGeometryCacheSceneProxy*>(Component->GetGeometryCacheComponent()->SceneProxy))
		{
			GeometryCacheSceneProxy = SceneProxy;

			const TArray<FGeomCacheTrackProxy*>& Tracks = GeometryCacheSceneProxy->GetTracks();
			check(Component->TrackSections.Num() == Tracks.Num());


			for (int Index = 0; Index < Component->TrackSections.Num(); Index++)
			{
				FTrackSectionCollisionData* CollisionData = new FTrackSectionCollisionData();
				CollisionData->bEnableCollision = Component->TrackSections[Index].bEnableCollision;
				TrackSectionsCollisionData.Add(CollisionData);
			}
		}
	}

	// Update at least once after the scene proxy has been constructed
	// Otherwise it is invisible until animation starts
	if (Component && Component->GetGeometryCacheComponent())
	{
		ENQUEUE_RENDER_COMMAND(FGeometryCacheCollisionUpdateFrame)(
			[this](FRHICommandList& RHICmdList)
		{
			this->UpdateFrame();
		}
		);
	}
}

UGeometryCacheCollisionSceneProxy::~UGeometryCacheCollisionSceneProxy()
{
	for (int32 Index = 0; Index < TrackSectionsCollisionData.Num(); Index++)
	{
		FTrackSectionCollisionData* SectionData = TrackSectionsCollisionData[Index];
		SectionData->Clear();
		delete SectionData;
	}
}

void UGeometryCacheCollisionSceneProxy::GetDynamicMeshElements(const TArray<const FSceneView*>& Views, const FSceneViewFamily& ViewFamily, uint32 VisibilityMap, FMeshElementCollector& Collector) const 
{
	const bool bVisible = [&Views, VisibilityMap]()
	{
		for (int32 ViewIndex = 0; ViewIndex < Views.Num(); ViewIndex++)
		{
			if (VisibilityMap & (1 << ViewIndex))
			{
				return true;
			}
		}
		return false;
	}();

	auto NeedUpdate = [this]()
	{
		if (!GeometryCacheCollisionComponent->bUseComplexAsSimpleCollision)
		{
			return false;
		}

		if (GeometryCacheCollisionComponent->bRuntimeTicking)
		{
			if (!GeometryCacheCollisionComponent->bRuntimeInited)
			{
				return true;
			}
			else
			{
				if (!GeometryCacheCollisionComponent->bManualUpdateCollision && GeometryCacheCollisionComponent->AccumulateDeltaTime >= GeometryCacheCollisionComponent->UpdateCollisionInterval)
				{
					if (GeometryCacheCollisionComponent->GeometryCacheStatus.CheckStatusChanged())
					{
						return true;
					}
				}
			}

		}
		else
		{
			return true;
		}

		return false;
	};

	if (bVisible && NeedUpdate())
	{
		UpdateFrame();
	}


	// Draw bounds
#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)

	bool bDrawCollision = IsCollisionEnabled() && AllowDebugViewmodes() && (ViewFamily.EngineShowFlags.Collision || GeometryCacheCollisionComponent->bShowCollisionWireFrame);
	bool bDrawComplexWireframeCollision = bDrawCollision && GeometryCacheCollisionComponent->bUseComplexAsSimpleCollision;// GetBodySetup()->GetCollisionTraceFlag() == ECollisionTraceFlag::CTF_UseComplexAsSimple;
	bool bDrawSimpleCollision = bDrawCollision && !GeometryCacheCollisionComponent->bUseComplexAsSimpleCollision;// GetBodySetup()->GetCollisionTraceFlag() != ECollisionTraceFlag::CTF_UseComplexAsSimple;

	FColor SimpleCollisionColor = FColor(157, 149, 223, 255);
	FColor ComplexCollisionColor = FColor(0, 255, 255, 255);

	for (int32 ViewIndex = 0; ViewIndex < Views.Num(); ViewIndex++)
	{
		if (VisibilityMap & (1 << ViewIndex))
		{
			if (bDrawComplexWireframeCollision)
			{
				static FVector3f const PosX(1.f, 0, 0);
				static FVector3f const PosY(0, 1.f, 0);
				static FVector3f const PosZ(0, 0, 1.f);

				UMaterial* MaterialToUse = UMaterial::GetDefaultMaterial(MD_Surface);
				FLinearColor DrawCollisionColor = GetWireframeColor();
				// Collision view modes draw collision mesh as solid
				//if (bInCollisionView)
				//{
				//	MaterialToUse = GEngine->ShadedLevelColorationUnlitMaterial;
				//}
				// Wireframe, choose color based on complex or simple
				//else
				if (GEngine->WireframeMaterial)
				{
					MaterialToUse = GEngine->WireframeMaterial;
					DrawCollisionColor = ComplexCollisionColor;
				}
				// Create colored proxy
				FColoredMaterialRenderProxy* CollisionMaterialInstance = new FColoredMaterialRenderProxy(MaterialToUse?MaterialToUse->GetRenderProxy():nullptr, DrawCollisionColor);
				Collector.RegisterOneFrameMaterialProxy(CollisionMaterialInstance);

				// Iterate over sections
				for (int32 SectionIndex = 0; SectionIndex < TrackSectionsCollisionData.Num(); SectionIndex++)
				{
					const FTrackSectionCollisionData* SectionData = TrackSectionsCollisionData[SectionIndex];
					if (SectionData->bEnableCollision && SectionData->IndexBuffer.Num() > 0)
					{
						const FSceneView* View = Views[ViewIndex];

						// this seems far from optimal in terms of perf, but it's for debugging
						FDynamicMeshBuilder MeshBuilder(View->GetFeatureLevel());

						// set up geometry
						for (int32 VertIdx = 0; VertIdx < SectionData->PositionBuffer.Num(); ++VertIdx)
						{
							MeshBuilder.AddVertex(SectionData->PositionBuffer[VertIdx], FVector2f::ZeroVector, PosX, PosY, PosZ, FColor::White);
						}
						//MeshBuilder.AddTriangles(SectionData.IndexBuffer);
						for (int32 Idx = 0; Idx < SectionData->IndexBuffer.Num(); Idx += 3)
						{
							MeshBuilder.AddTriangle(SectionData->IndexBuffer[Idx], SectionData->IndexBuffer[Idx + 1], SectionData->IndexBuffer[Idx + 2]);
						}

						MeshBuilder.GetMesh(GetLocalToWorld(), CollisionMaterialInstance, SDPG_World, false, false, ViewIndex, Collector);
					}
				}
			}
			// Draw simple collision as wireframe if 'show collision', and collision is enabled
			else if (bDrawSimpleCollision)
			{
				FTransform GeomTransform(GetLocalToWorld());
				GeometryCacheCollisionComponent->GetBodySetup()->AggGeom.GetAggGeom(GeomTransform, GetSelectionColor(FColor(157, 149, 223, 255), IsSelected(), IsHovered()).ToFColor(true), NULL, false, false, DrawsVelocity(), ViewIndex, Collector);
			}

			// Render bounds
			//RenderBounds(Collector.GetPDI(ViewIndex), ViewFamily.EngineShowFlags, GetBounds(), IsSelected());
		}
	}
#endif
}

FPrimitiveViewRelevance UGeometryCacheCollisionSceneProxy::GetViewRelevance(const FSceneView* View) const
{
	// Should we draw this because collision drawing is enabled, and we have collision
	const bool bShowForCollision = View->Family->EngineShowFlags.Collision && IsCollisionEnabled();

	FPrimitiveViewRelevance Result;
	Result.bDrawRelevance = IsShown(View) || bShowForCollision;
	Result.bShadowRelevance = IsShadowCast(View);
	Result.bDynamicRelevance = true;
	return Result;
}

void UGeometryCacheCollisionSceneProxy::UpdateFrame() const
{
	if (!GeometryCacheSceneProxy || TrackSectionsCollisionData.Num() == 0 || !GeometryCacheCollisionComponent->GetGeometryCacheComponent())
	{
		return;
	}

	const TArray<FGeomCacheTrackProxy*>& Tracks = GeometryCacheSceneProxy->GetTracks();
	if (TrackSectionsCollisionData.Num() != Tracks.Num())
	{
		return;
	}

	UGeometryCacheComponent* GeometryCacheComponent = GeometryCacheCollisionComponent->GetGeometryCacheComponent();

	float Time = GeometryCacheComponent->GetAnimationTime();
	bool bLooping = GeometryCacheComponent->IsLooping();
	bool bExtrapolateFrames = GeometryCacheComponent->IsExtrapolatingFrames();

	bool bCopyUVs = UPhysicsSettings::Get()->bSupportUVFromHitResults;
	for (int32 SectionIndex = 0;  SectionIndex < Tracks.Num(); SectionIndex++)
	{
		FGeomCacheTrackProxy* TrackProxy = Tracks[SectionIndex];
		FTrackSectionCollisionData* SectionData = TrackSectionsCollisionData[SectionIndex];

		// Render out stored TrackProxy's
		if (TrackProxy != nullptr && SectionData->bEnableCollision)
		{
			const FVisibilitySample& VisibilitySample = TrackProxy->GetVisibilitySample(Time, bLooping);
			if (!VisibilitySample.bVisibilityState)
			{
				continue;
			}

			//const bool bInitFrame = SectionData.FrameIndex == -1 && TrackProxy->FrameIndex == -1 && TrackProxy->PreviousFrameIndex == -1;

			// Check if we can interpolate between the two frames we have available
			const bool bCanInterpolate = (TrackProxy->FrameIndex != TrackProxy->NextFrameIndex) && TrackProxy->IsTopologyCompatible(TrackProxy->FrameIndex, TrackProxy->NextFrameIndex);
			float InterpolationFactor = TrackProxy->InterpolationFactor;
			const bool bFrameIndicesChanged = TrackProxy->FrameIndex != SectionData->FrameIndex;
			const bool bDifferentRoundedInterpolationFactor = FMath::RoundToInt(InterpolationFactor) != FMath::RoundToInt(TrackProxy->PreviousInterpolationFactor);
			const bool bDifferentInterpolationFactor = !FMath::IsNearlyEqual(InterpolationFactor, TrackProxy->PreviousInterpolationFactor);
				
			SectionData->FrameIndex = TrackProxy->FrameIndex;

			// Check if we have explicit motion vectors
			const bool bHasMotionVectors = (
				TrackProxy->MeshData->VertexInfo.bHasMotionVectors &&
				TrackProxy->NextFrameMeshData->VertexInfo.bHasMotionVectors &&
				TrackProxy->MeshData->Positions.Num() == TrackProxy->MeshData->MotionVectors.Num())
				&& (TrackProxy->NextFrameMeshData->Positions.Num() == TrackProxy->NextFrameMeshData->MotionVectors.Num());

			// Can we interpolate the vertex data?
			if (bCanInterpolate && (bDifferentInterpolationFactor || bFrameIndicesChanged))
			{
			
				const float OneMinusInterp = 1.0 - InterpolationFactor;
				const int32 InterpFixed = (int32)(InterpolationFactor * 255.0f);
				const int32 OneMinusInterpFixed = 255 - InterpFixed;
				const VectorRegister4Float WeightA = VectorSetFloat1(OneMinusInterp);
				const VectorRegister4Float WeightB = VectorSetFloat1(InterpolationFactor);
				const VectorRegister4Float Half = VectorSetFloat1(0.5f);

				const int32 NumVerts = TrackProxy->MeshData->Positions.Num();
				SectionData->Prepare(NumVerts);

#define VALIDATE 0
				{
					check(TrackProxy->MeshData->Positions.Num() >= NumVerts);
					check(TrackProxy->NextFrameMeshData->Positions.Num() >= NumVerts);
					check(SectionData->PositionBuffer.Num() >= NumVerts);
					const FVector3f* PositionAPtr = TrackProxy->MeshData->Positions.GetData();
					const FVector3f* PositionBPtr = TrackProxy->NextFrameMeshData->Positions.GetData();
					FVector3f* InterpolatedPositionsPtr = SectionData->PositionBuffer.GetData();

					// Unroll 4 times so we can do 4 wide SIMD
					{
						const FVector4f* PositionAPtr4 = (const FVector4f*)PositionAPtr;
						const FVector4f* PositionBPtr4 = (const FVector4f*)PositionBPtr;
						FVector4f* InterpolatedPositionsPtr4 = (FVector4f*)InterpolatedPositionsPtr;

						int32 Index = 0;
						for (; Index + 3 < NumVerts; Index += 4)
						{
							VectorRegister4Float Pos0xyz_Pos1x = VectorMultiplyAdd(VectorLoad(PositionAPtr4 + 0), WeightA, VectorMultiply(VectorLoad(PositionBPtr4 + 0), WeightB));
							VectorRegister4Float Pos1yz_Pos2xy = VectorMultiplyAdd(VectorLoad(PositionAPtr4 + 1), WeightA, VectorMultiply(VectorLoad(PositionBPtr4 + 1), WeightB));
							VectorRegister4Float Pos2z_Pos3xyz = VectorMultiplyAdd(VectorLoad(PositionAPtr4 + 2), WeightA, VectorMultiply(VectorLoad(PositionBPtr4 + 2), WeightB));
							VectorStore(Pos0xyz_Pos1x, InterpolatedPositionsPtr4 + 0);
							VectorStore(Pos1yz_Pos2xy, InterpolatedPositionsPtr4 + 1);
							VectorStore(Pos2z_Pos3xyz, InterpolatedPositionsPtr4 + 2);
							PositionAPtr4 += 3;
							PositionBPtr4 += 3;
							InterpolatedPositionsPtr4 += 3;
						}

						for (; Index < NumVerts; Index++)
						{
							InterpolatedPositionsPtr[Index] = PositionAPtr[Index] * OneMinusInterp + PositionBPtr[Index] * InterpolationFactor;
						}
					}
				}

				if (TrackProxy->MeshData->VertexInfo.bHasUV0 && bCopyUVs)
				{
					check(TrackProxy->MeshData->TextureCoordinates.Num() >= NumVerts);
					check(TrackProxy->NextFrameMeshData->TextureCoordinates.Num() >= NumVerts);
					check(SectionData->UVBuffer.Num() >= NumVerts);
					const FVector2f* UVAPtr = TrackProxy->MeshData->TextureCoordinates.GetData();
					const FVector2f* UVBPtr = TrackProxy->NextFrameMeshData->TextureCoordinates.GetData();
					FVector2f* InterpolatedUVsPtr = SectionData->UVBuffer.GetData();


					// Unroll 2x so we can use 4 wide ops. OOP will hopefully take care of the rest.
					{
						int32 Index = 0;
						for (; Index + 1 < NumVerts; Index += 2)
						{
							VectorRegister4Float InterpolatedUVx2 = VectorMultiplyAdd( VectorLoad(&UVAPtr[Index].X),
								WeightA,
								VectorMultiply(VectorLoad(&UVBPtr[Index].X), WeightB));
							VectorStore(InterpolatedUVx2, &(InterpolatedUVsPtr[Index].X));
						}

						if (Index < NumVerts)
						{
							InterpolatedUVsPtr[Index] = UVAPtr[Index] * OneMinusInterp + UVBPtr[Index] * InterpolationFactor;
						}
					}
				}

				SectionData->IndexBuffer = TrackProxy->MeshData->Indices; //.UpdateIndices(TrackProxy->MeshData->Indices);
				check(TrackProxy->MeshData->Indices.Num() % 3 == 0);

				SectionData->BatchesInfo = TrackProxy->MeshData->BatchesInfo;

#undef VALIDATE
			}
			else
			{
				// We just don't interpolate between frames if we got GPU to burn we could someday render twice and stipple fade between it :-D like with lods

				// Only bother uploading if anything changed or when the we failed to decode anything make sure update the gpu buffers regardless
				if (bFrameIndicesChanged || bDifferentRoundedInterpolationFactor || (bDifferentInterpolationFactor && bExtrapolateFrames))
				{
					const bool bNextFrame = !!FMath::RoundToInt(InterpolationFactor) && TrackProxy->NextFrameMeshData->Positions.Num() > 0; // use next frame only if it's valid
					const uint32 FrameIndexToUse = bNextFrame ? TrackProxy->NextFrameIndex : TrackProxy->FrameIndex;
					FGeometryCacheMeshData* MeshDataToUse = bNextFrame ? TrackProxy->NextFrameMeshData : TrackProxy->MeshData;

					SectionData->UpdateIndices(MeshDataToUse->Indices);
					SectionData->UpdatePositions(MeshDataToUse->Positions);
					SectionData->UpdateUVs(MeshDataToUse->TextureCoordinates);

					SectionData->BatchesInfo = TrackProxy->MeshData->BatchesInfo;
				}
			}
		}
	}
}


//////////////////////////////////////////////////////////////////////////


UGeometryCacheCollisionComponent::UGeometryCacheCollisionComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	//PrimaryComponentTick.TickGroup = TG_PrePhysics;
	PrimaryComponentTick.bStartWithTickEnabled = true;
	PrimaryComponentTick.bCanEverTick = true;
	//PrimaryComponentTick.bTickEvenWhenPaused = true;
	bTickInEditor = true;
}

void UGeometryCacheCollisionComponent::BeginPlay()
{
	Super::BeginPlay();
	
	if (GeometryCacheStatus.GeometryCacheComponent == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("UGeometryCacheCollisionComponent: Failed to find geometry cache component. (%s)"), *(GetOwner()->GetName()));
	}

	bRuntimeTicking = true;
}

void UGeometryCacheCollisionComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	bRuntimeTicking = false;
	bRuntimeInited = false;
}

void UGeometryCacheCollisionComponent::OnRegister()
{
	ResetGeometryCacheStatusWhenChanged(true);

	Super::OnRegister();
}

void UGeometryCacheCollisionComponent::OnUnregister()
{
	Super::OnUnregister();
	
	ClearGeometryCacheStatus();
}

void UGeometryCacheCollisionComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	
	auto NeedUpdate = [this, DeltaTime]()
	{
		this->ResetGeometryCacheStatusWhenChanged(false);
		if (GeometryCacheStatus.bStatusReseted)
		{
			GeometryCacheStatus.bStatusReseted = false;
			return true;
		}

		if (this->bRuntimeTicking)
		{
			if (!bRuntimeInited)
			{
				if (GeometryCacheStatus.TracksInited())
				{
					bRuntimeInited = true;
					return true;
				}
			}
			else
			{
				if (!bManualUpdateCollision && this->AccumulateDeltaTime > UpdateCollisionInterval)
				{
					//if (GeometryCacheStatus.CheckStatusChanged())
					{
						return true;
					}
				}
			}
			
		}
		
		return false;
	};

	// Update Collision
	if (NeedUpdate())
	{
		this->AccumulateDeltaTime = 0.0f;

		// Game thread update:
		// This mainly just updates the matrix and bounding boxes. All render state (meshes) is done on the render thread
		bool bUpdatedBoundsOrMatrix = false;
		for (int32 TrackIndex = 0; TrackIndex < TrackSections.Num(); ++TrackIndex)
		{
			bUpdatedBoundsOrMatrix |= UpdateTrackSection(TrackIndex);
		}

		if (bUpdatedBoundsOrMatrix)
		{
			UpdateLocalBounds();

			// Mark the transform as dirty, so the bounds are updated and sent to the render thread
			MarkRenderTransformDirty();
		}
		
		//Update collision directly
		UpdateCollision();
	}
	
	if (this->bRuntimeTicking)
	{
		this->AccumulateDeltaTime += DeltaTime;
	}
}

bool UGeometryCacheCollisionComponent::ResetGeometryCacheStatusWhenChanged(bool bForceReset)
{
	if (bForceReset)
	{
		UGeometryCacheComponent* GeometryCacheComponent = Cast<UGeometryCacheComponent>(GetOwner()->GetComponentByClass(UGeometryCacheComponent::StaticClass()));
		GeometryCacheStatus = FGeometryCacheStatus(GeometryCacheComponent);
	}

	if (bForceReset || GeometryCacheStatus.ResetWhenChanged())
	{
		ClearTrackData();
		SetupTrackData();

		if (GeometryCacheStatus.GeometryCacheComponent)
		{
			FVector ToWorldScale3D = GetRelativeScale3D() * GeometryCacheStatus.GeometryCacheComponent->GetRelativeScale3D();
			if ((ToWorldScale3D - FVector::OneVector).IsNearlyZero()
				&& GetRelativeLocation() == FVector::ZeroVector
				&& GetRelativeRotation() == FRotator::ZeroRotator)
			{
				ResetRelativeTransform();
			}
		}

		SynchronizationCollisionSettings();
		
		GeometryCacheStatus.bStatusReseted = true;
		return true;
	}

	return false;
}

void UGeometryCacheCollisionComponent::ClearGeometryCacheStatus()
{
	GeometryCacheStatus.Clear();

	ClearTrackData();
}

void UGeometryCacheCollisionComponent::ClearTrackData()
{
	NumTracks = 0;
	TrackSections.Empty();
}

void UGeometryCacheCollisionComponent::SetupTrackData()
{
	if (GeometryCacheStatus.GeometryCacheComponent != nullptr && GeometryCacheStatus.GeometryCacheComponent->GetGeometryCache() != nullptr)
	{
		// Refresh NumTracks and clear Index Arrays
		NumTracks = GeometryCacheStatus.GeometryCacheComponent->GetGeometryCache()->Tracks.Num();

		// Create mesh sections for each GeometryCacheTrack
		for (int32 TrackIndex = 0; TrackIndex < NumTracks; ++TrackIndex)
		{
			// First time so create rather than update the mesh sections
			CreateTrackSection(TrackIndex);

		}
	}
	UpdateLocalBounds();
}

void UGeometryCacheCollisionComponent::CreateTrackSection(int32 TrackIndex)
{
	// Ensure sections array is long enough
	if (TrackSections.Num() <= TrackIndex)
	{
		TrackSections.SetNum(TrackIndex + 1, false);
	}
	TrackSections[TrackIndex].bEnableCollision = CheckTrackSectionCollisionEnabled(TrackIndex);

	UpdateTrackSection(TrackIndex);
	MarkRenderStateDirty(); // Recreate scene proxy
}

bool UGeometryCacheCollisionComponent::CheckTrackSectionCollisionEnabled(int32 TrackIndex)
{
	checkf(TrackIndex < TrackSections.Num(), TEXT("Invalid SectionIndex"));

	if (bEnableCollision)
	{
		if (bOnlyBuildCollisionForEnabledTracks)
		{
			return EnabledTrackIDs.Contains(TrackIndex);
		}
		else
		{
			return true;
		}
	}
	return false;
}

bool UGeometryCacheCollisionComponent::UpdateTrackSection(int32 TrackIndex)
{
	checkf(TrackIndex < TrackSections.Num(), TEXT("Invalid SectionIndex"));

	FTrackSectionRenderData& UpdateSection = TrackSections[TrackIndex];
	UGeometryCacheTrack* Track = GeometryCacheStatus.GeometryCacheComponent->GetGeometryCache()->Tracks[TrackIndex];

	FMatrix Matrix;
	FBox TrackBounds;
	const bool bUpdateMatrix = Track->UpdateMatrixData(GeometryCacheStatus.GeometryCacheComponent->GetAnimationTime(), GeometryCacheStatus.GeometryCacheComponent->IsLooping(), UpdateSection.MatrixSampleIndex, Matrix);
	const bool bUpdateBounds = Track->UpdateBoundsData(GeometryCacheStatus.GeometryCacheComponent->GetAnimationTime(), GeometryCacheStatus.GeometryCacheComponent->IsLooping(), (GeometryCacheStatus.GeometryCacheComponent->IsPlayingReversed()) ? true : false, UpdateSection.BoundsSampleIndex, TrackBounds);

	if (bUpdateBounds)
	{
		UpdateSection.BoundingBox = TrackBounds;
	}

	if (bUpdateMatrix)
	{
		UpdateSection.Matrix = Matrix;
	}

	// Update sections according what is required
	if (bUpdateMatrix || bUpdateBounds)
	{
		return true;
	}

	return false;
}


void UGeometryCacheCollisionComponent::UpdateLocalBounds()
{
	FBox LocalBox(ForceInit);

	for (const FTrackSectionRenderData& Section : TrackSections)
	{
		if (Section.bEnableCollision)
		{
			// Use World matrix per section for correct bounding box
			LocalBox += (Section.BoundingBox.TransformBy(Section.Matrix));
		}
	}

	LocalBounds = LocalBox.IsValid ? FBoxSphereBounds(LocalBox) : FBoxSphereBounds(FVector(0, 0, 0), FVector(0, 0, 0), 0); // fallback to reset box sphere bounds

	// Update global bounds
	UpdateBounds();
}


void UGeometryCacheCollisionComponent::SetCollisionConvexMeshes(const TArray< TArray<FVector> >& ConvexMeshes)
{
	CollisionConvexElems.Reset();

	// Create element for each convex mesh
	for (int32 ConvexIndex = 0; ConvexIndex < ConvexMeshes.Num(); ConvexIndex++)
	{
		FKConvexElem NewConvexElem;
		NewConvexElem.VertexData = ConvexMeshes[ConvexIndex];
		NewConvexElem.ElemBox = FBox(NewConvexElem.VertexData);

		CollisionConvexElems.Add(NewConvexElem);
	}

	UpdateCollision();
}

void UGeometryCacheCollisionComponent::AddCollisionConvexMesh(TArray<FVector> ConvexVerts)
{
	if (ConvexVerts.Num() >= 4)
	{
		// New element
		FKConvexElem NewConvexElem;
		// Copy in vertex info
		NewConvexElem.VertexData = ConvexVerts;
		// Update bounding box
		NewConvexElem.ElemBox = FBox(NewConvexElem.VertexData);
		// Add to array of convex elements
		CollisionConvexElems.Add(NewConvexElem);
		// Refresh collision
		UpdateCollision();
	}
}

void UGeometryCacheCollisionComponent::ClearCollisionConvexMeshes()
{
	// Empty simple collision info
	CollisionConvexElems.Empty();
	// Refresh collision
	UpdateCollision();
}


FBoxSphereBounds UGeometryCacheCollisionComponent::CalcBounds(const FTransform& LocalToWorld) const
{
	FBoxSphereBounds Ret(LocalBounds.TransformBy(LocalToWorld));

	Ret.BoxExtent *= BoundsScale;
	Ret.SphereRadius *= BoundsScale;

	return Ret;
}

bool UGeometryCacheCollisionComponent::GetPhysicsTriMeshData(struct FTriMeshCollisionData* CollisionData, bool InUseAllTriData)
{
	int32 VertexBase = 0; // Base vertex index for current section

	// See if we should copy UVs
	bool bCopyUVs = UPhysicsSettings::Get()->bSupportUVFromHitResults;
	if (bCopyUVs)
	{
		CollisionData->UVs.AddZeroed(1); // only one UV channel
	}

	if (UGeometryCacheCollisionSceneProxy* CastedProxy = static_cast<UGeometryCacheCollisionSceneProxy*>(SceneProxy))
	{
		UGeometryCacheCollisionSceneProxy* InSceneProxy = CastedProxy;

		int32 MaterialIdx = 0;
		// For each section..
		for (int32 SectionIdx = 0; SectionIdx < InSceneProxy->TrackSectionsCollisionData.Num(); SectionIdx++)
		{
			FTrackSectionCollisionData* Section = InSceneProxy->TrackSectionsCollisionData[SectionIdx];
			// Do we have collision enabled?
			if (Section->bEnableCollision)
			{
				if (bCopyUVs)
				{
					check(Section->PositionBuffer.Num() == Section->UVBuffer.Num());
				}

				// Copy vert data
				for (int32 VertIdx = 0; VertIdx < Section->PositionBuffer.Num(); VertIdx++)
				{
					CollisionData->Vertices.Add(Section->PositionBuffer[VertIdx]);

					// Copy UV if desired
					if (bCopyUVs)
					{
						CollisionData->UVs[0].Add(FVector2D(Section->UVBuffer[VertIdx]));
					}
				}

				int32 VertexBatch = 0;
				for (int32 BatchIdx = 0; BatchIdx < Section->BatchesInfo.Num(); BatchIdx++)
				{
					// Copy triangle data
					const int32 NumTriangles = Section->BatchesInfo[BatchIdx].NumTriangles;
					//const int32 MaterialIdx = Section.BatchesInfo[BatchIdx].MaterialIndex;
					const int32 StartIdx = Section->BatchesInfo[BatchIdx].StartIndex;
					const int32 EndIdx = StartIdx + NumTriangles*3;
					for (int32 TriIdx = StartIdx; TriIdx < EndIdx; TriIdx+=3)
					{
						// Need to add base offset for indices
						FTriIndices Triangle;
						Triangle.v0 = Section->IndexBuffer[TriIdx + 0] + VertexBase;
						Triangle.v1 = Section->IndexBuffer[TriIdx + 1] + VertexBase;
						Triangle.v2 = Section->IndexBuffer[TriIdx + 2] + VertexBase;
						CollisionData->Indices.Add(Triangle);

						// Also store material info
						CollisionData->MaterialIndices.Add(MaterialIdx);
					}

					//MaterialIdx++;
					VertexBatch += NumTriangles;
				}
				

				// Remember the base index that new verts will be added from in next section
				VertexBase = CollisionData->Vertices.Num();
			}
		}

		CollisionData->bFlipNormals = true;
		CollisionData->bDeformableMesh = true;
		CollisionData->bFastCook = true;
	}

	return true;
}

bool UGeometryCacheCollisionComponent::ContainsPhysicsTriMeshData(bool InUseAllTriData) const
{
	if (UGeometryCacheCollisionSceneProxy* CastedProxy = static_cast<UGeometryCacheCollisionSceneProxy*>(SceneProxy))
	{
		UGeometryCacheCollisionSceneProxy* InSceneProxy = CastedProxy;

		for (const FTrackSectionCollisionData* Section : InSceneProxy->TrackSectionsCollisionData)
		{
			if (Section->IndexBuffer.Num() >= 3 && Section->bEnableCollision)
			{
				return true;
			}
		}
	}

	return false;
}

UBodySetup* UGeometryCacheCollisionComponent::CreateBodySetupHelper()
{
	// The body setup in a template needs to be public since the property is Tnstanced and thus is the archetype of the instance meaning there is a direct reference
	UBodySetup* NewBodySetup = NewObject<UBodySetup>(this, NAME_None, (IsTemplate() ? RF_Public | RF_ArchetypeObject : RF_NoFlags));
	NewBodySetup->BodySetupGuid = FGuid::NewGuid();

	NewBodySetup->bGenerateMirroredCollision = false;
	NewBodySetup->bDoubleSidedGeometry = true;
	NewBodySetup->CollisionTraceFlag = bUseComplexAsSimpleCollision ? CTF_UseComplexAsSimple : CTF_UseDefault;

	return NewBodySetup;
}

void UGeometryCacheCollisionComponent::CreateGeometryCacheBodySetup()
{
	if (GeometryCacheBodySetup == nullptr)
	{
		GeometryCacheBodySetup = CreateBodySetupHelper();
	}
}

void UGeometryCacheCollisionComponent::UpdateCollision()
{
	// Avoid crash at "GetWorld"
	if (!IsRegistered() || IsBeingDestroyed())
	{
		return;
	}

	UWorld* World = GetWorld();
	// Always prefer using async cooking.
	const bool bUseAsyncCook = World && World->IsGameWorld() && bUseComplexAsSimpleCollision && bUseAsyncCooking;

	if (bUseAsyncCook)
	{
		// Abort all previous ones still standing
		for (UBodySetup* OldBody : AsyncBodySetupQueue)
		{
			OldBody->AbortPhysicsMeshAsyncCreation();
		}

		AsyncBodySetupQueue.Add(CreateBodySetupHelper());
	}
	else
	{
		AsyncBodySetupQueue.Empty();	//If for some reason we modified the async at runtime, just clear any pending async body setups
		CreateGeometryCacheBodySetup();
	}

	UBodySetup* UseBodySetup = bUseAsyncCook ? AsyncBodySetupQueue.Last() : GeometryCacheBodySetup;

	// Fill in simple collision convex elements
	UseBodySetup->AggGeom.ConvexElems = CollisionConvexElems;

	UseBodySetup->AggGeom.BoxElems.Empty();
	UseBodySetup->AggGeom.SphereElems.Empty();
	if (!bUseComplexAsSimpleCollision && bBuildSimpleCollision)
	{
		if (bMergeSimpleCollision)
		{
			if (SimpleCollisionShape == ESimpleCollisionShape::Box)
			{
				FKBoxElem BoxElem;
				BoxElem.Center = LocalBounds.Origin;
				BoxElem.X = LocalBounds.BoxExtent.X * 2.0f;
				BoxElem.Y = LocalBounds.BoxExtent.Y * 2.0f;
				BoxElem.Z = LocalBounds.BoxExtent.Z * 2.0f;
				UseBodySetup->AggGeom.BoxElems.Add(BoxElem);
			}
			else
			{
				FKSphereElem SphereElem;
				SphereElem.Center = LocalBounds.Origin;
				SphereElem.Radius = LocalBounds.SphereRadius;
				UseBodySetup->AggGeom.SphereElems.Add(SphereElem);
			}
		}
		else
		{
			for (const FTrackSectionRenderData& Section : TrackSections)
			{
				if (Section.bEnableCollision)
				{
					// Use World matrix per section for correct bounding box
					FBox LocalBox = (Section.BoundingBox.TransformBy(Section.Matrix));
					if (LocalBox.IsValid)
					{
						if (SimpleCollisionShape == ESimpleCollisionShape::Box)
						{

							FKBoxElem BoxElem;
							BoxElem.Center = LocalBox.GetCenter();
							BoxElem.X = LocalBox.GetExtent().X * 2.0f;
							BoxElem.Y = LocalBox.GetExtent().Y * 2.0f;
							BoxElem.Z = LocalBox.GetExtent().Z * 2.0f;
							UseBodySetup->AggGeom.BoxElems.Add(BoxElem);
						}
						else
						{
							FBoxSphereBounds TrackBounds = FBoxSphereBounds(LocalBox);
							FKSphereElem SphereElem;
							SphereElem.Center = TrackBounds.Origin;
							SphereElem.Radius = TrackBounds.SphereRadius;
							UseBodySetup->AggGeom.SphereElems.Add(SphereElem);
						}
					}
				}
			}
		}
	}

	// Set trace flag
	UseBodySetup->CollisionTraceFlag = bUseComplexAsSimpleCollision ? CTF_UseComplexAsSimple : CTF_UseDefault;

	if (bUseAsyncCook)
	{
		UseBodySetup->CreatePhysicsMeshesAsync(FOnAsyncPhysicsCookFinished::CreateUObject(this, &UGeometryCacheCollisionComponent::FinishPhysicsAsyncCook, UseBodySetup));
	}
	else
	{
		// New GUID as collision has changed
		UseBodySetup->BodySetupGuid = FGuid::NewGuid();
		// Also we want cooked data for this
		UseBodySetup->bHasCookedCollisionData = true;
		UseBodySetup->InvalidatePhysicsData();
		UseBodySetup->CreatePhysicsMeshes();
		RecreatePhysicsState();

		OnCollisionUpdated.Broadcast();
	}
}

void UGeometryCacheCollisionComponent::FinishPhysicsAsyncCook(bool bSuccess, UBodySetup* FinishedBodySetup)
{
	TArray<UBodySetup*> NewQueue;
	NewQueue.Reserve(AsyncBodySetupQueue.Num());

	int32 FoundIdx;
	if (AsyncBodySetupQueue.Find(FinishedBodySetup, FoundIdx))
	{
		if (bSuccess)
		{
			//The new body was found in the array meaning it's newer so use it
			GeometryCacheBodySetup = FinishedBodySetup;
			RecreatePhysicsState();

			//remove any async body setups that were requested before this one
			for (int32 AsyncIdx = FoundIdx + 1; AsyncIdx < AsyncBodySetupQueue.Num(); ++AsyncIdx)
			{
				NewQueue.Add(AsyncBodySetupQueue[AsyncIdx]);
			}

			AsyncBodySetupQueue = NewQueue;

			OnCollisionUpdated.Broadcast();
		}
		else
		{
			AsyncBodySetupQueue.RemoveAt(FoundIdx);
		}
	}
}

FPrimitiveSceneProxy* UGeometryCacheCollisionComponent::CreateSceneProxy()
{
	return new UGeometryCacheCollisionSceneProxy(this);
}

UBodySetup* UGeometryCacheCollisionComponent::GetBodySetup()
{
	CreateGeometryCacheBodySetup();
	return GeometryCacheBodySetup;
}

UMaterialInterface* UGeometryCacheCollisionComponent::GetMaterialFromCollisionFaceIndex(int32 FaceIndex, int32& SectionIndex) const
{
	UMaterialInterface* Result = nullptr;
	SectionIndex = 0;

	if (FaceIndex >= 0)
	{
		if (UGeometryCacheCollisionSceneProxy* CastedProxy = static_cast<UGeometryCacheCollisionSceneProxy*>(SceneProxy))
		{
			UGeometryCacheCollisionSceneProxy* InSceneProxy = CastedProxy;

			// Look for element that corresponds to the supplied face
			int32 TotalFaceCount = 0;
			for (int32 SectionIdx = 0; SectionIdx < InSceneProxy->TrackSectionsCollisionData.Num(); SectionIdx++)
			{
				const FTrackSectionCollisionData* Section = InSceneProxy->TrackSectionsCollisionData[SectionIdx];
				if (Section->bEnableCollision)
				{
					for (int32 BatchIdx = 0; BatchIdx < Section->BatchesInfo.Num(); BatchIdx++)
					{
						int32 NumFaces = Section->BatchesInfo[BatchIdx].NumTriangles;
						TotalFaceCount += NumFaces;

						if (FaceIndex < TotalFaceCount)
						{
							int32 MaterialIndex = Section->BatchesInfo[BatchIdx].MaterialIndex;
							// Grab the material
							Result = GeometryCacheStatus.GeometryCacheComponent->GetMaterial(MaterialIndex);
							SectionIndex = MaterialIndex;
							break;
						}
					}
				}
			}
		}
	}

	return Result;
}

bool UGeometryCacheCollisionComponent::GetHitTrackInfoFromCollisionFaceIndex(int32 FaceIndex, FGeometryCacheHitTrackInfo& HitTrackInfo) const 
{
	if (FaceIndex >= 0)
	{
		if (UGeometryCacheCollisionSceneProxy* CastedProxy = static_cast<UGeometryCacheCollisionSceneProxy*>(SceneProxy))
		{
			UGeometryCacheCollisionSceneProxy* InSceneProxy = CastedProxy;

			// Look for element that corresponds to the supplied face
			int32 TotalFaceCount = 0;
			for (int32 SectionIdx = 0; SectionIdx < InSceneProxy->TrackSectionsCollisionData.Num(); SectionIdx++)
			{
				const FTrackSectionCollisionData* Section = InSceneProxy->TrackSectionsCollisionData[SectionIdx];
				if (Section->bEnableCollision)
				{
					for (int32 BatchIdx = 0; BatchIdx < Section->BatchesInfo.Num(); BatchIdx++)
					{
						int32 NumFaces = Section->BatchesInfo[BatchIdx].NumTriangles;
						TotalFaceCount += NumFaces;

						if (FaceIndex < TotalFaceCount)
						{
							HitTrackInfo.GeometryCacheComponent = GeometryCacheStatus.GeometryCacheComponent;
							HitTrackInfo.TrackID = SectionIdx;
							HitTrackInfo.TrackName = GeometryCacheStatus.GeometryCacheComponent->GetGeometryCache()->Tracks[SectionIdx]->GetFName().ToString();
							HitTrackInfo.TrackBatchSectionID = BatchIdx;

							int32 MaterialIndex = Section->BatchesInfo[BatchIdx].MaterialIndex;
							// Grab the material
							HitTrackInfo.MaterialID = MaterialIndex;
							HitTrackInfo.Material = GeometryCacheStatus.GeometryCacheComponent->GetMaterial(MaterialIndex);

							return true;
						}
					}
				}
			}
		}
	}
	return false;
}

void UGeometryCacheCollisionComponent::UpdateCollisionManually()
{
	if (GeometryCacheStatus.GeometryCacheComponent && bRuntimeInited)
	{

		this->ResetGeometryCacheStatusWhenChanged(false);
		GeometryCacheStatus.bStatusReseted = false;
		this->AccumulateDeltaTime = 0.0f;

		// Update Collision
		{
			// Game thread update:
			// This mainly just updates the matrix and bounding boxes. All render state (meshes) is done on the render thread
			bool bUpdatedBoundsOrMatrix = false;
			for (int32 TrackIndex = 0; TrackIndex < TrackSections.Num(); ++TrackIndex)
			{
				bUpdatedBoundsOrMatrix |= UpdateTrackSection(TrackIndex);
			}

			if (bUpdatedBoundsOrMatrix)
			{
				UpdateLocalBounds();

				// Mark the transform as dirty, so the bounds are updated and sent to the render thread
				MarkRenderTransformDirty();
			}

			if (bUseComplexAsSimpleCollision)
			{
				if (UGeometryCacheCollisionSceneProxy* CastedProxy = static_cast<UGeometryCacheCollisionSceneProxy*>(SceneProxy))
				{
					UGeometryCacheCollisionSceneProxy* InSceneProxy = CastedProxy;

					ENQUEUE_RENDER_COMMAND(FGeometryCacheCollisionUpdateFrame)(
						[this, InSceneProxy](FRHICommandList& RHICmdList)
					{
						InSceneProxy->UpdateFrame();

						AsyncTask(ENamedThreads::GameThread, [this] {
							this->UpdateCollision();
							});
					}
					);
				}
			}
			else
			{
				//Update collision directly
				UpdateCollision();
			}
		}
	}
}

void UGeometryCacheCollisionComponent::SynchronizationCollisionSettings()
{
	if (GeometryCacheStatus.GeometryCacheComponent)
	{
		BodyInstance = GeometryCacheStatus.GeometryCacheComponent->BodyInstance;
	}
}

#undef LOCTEXT_NAMESPACE