// Copyright Qibo Pang 2023. All Rights Reserved.

#include "MovieSceneWidgetSubSequenceTrack.h"
#include "MovieSceneWidgetSubSequenceSection.h"
#include "MovieSceneWidgetSubSequenceTemplate.h"
#include "EntitySystem/BuiltInComponentTypes.h"
#include "Blueprint/UserWidget.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(MovieSceneWidgetSubSequenceTrack)

UMovieSceneWidgetSubSequenceTrack::UMovieSceneWidgetSubSequenceTrack( const FObjectInitializer& ObjectInitializer )
	: Super(ObjectInitializer)
{
	BuiltInTreePopulationMode = ETreePopulationMode::Blended;

#if WITH_EDITORONLY_DATA
	TrackTint = FColor(124, 15, 124, 65);
#endif

	SupportedBlendTypes.Add(EMovieSceneBlendType::Absolute);

	EvalOptions.bCanEvaluateNearestSection = true;
	EvalOptions.bEvaluateInPreroll = true;
}

/* UMovieSceneWidgetSubSequenceTrack interface
 *****************************************************************************/

UMovieSceneSection* UMovieSceneWidgetSubSequenceTrack::AddNewAnimation(FFrameNumber KeyTime, UUserWidget* UserWidget)
{
	UMovieSceneWidgetSubSequenceSection* NewSection = Cast<UMovieSceneWidgetSubSequenceSection>(CreateNewSection());
	{
		UWidgetBlueprintGeneratedClass* WidgetBPClass = Cast<UWidgetBlueprintGeneratedClass>(UserWidget->GetClass());
		if (WidgetBPClass && WidgetBPClass->Animations.Num() > 0)
		{
#if WITH_EDITOR
			NewSection->Params.AnimationName = WidgetBPClass->Animations[0]->GetDisplayName().ToString();
#else
			NewSection->Params.AnimationName = WidgetBPClass->Animations[0]->GetName();
#endif

			NewSection->Params.AnimationObjectName = WidgetBPClass->Animations[0]->GetName();
		}
		NewSection->Params.WidgetBPClass = WidgetBPClass;

		FFrameTime AnimationLength = NewSection->Params.GetValidWidgetAnimation()->GetEndTime() * GetTypedOuter<UMovieScene>()->GetTickResolution();
		int32 IFrameNumber = AnimationLength.FrameNumber.Value + (int)(AnimationLength.GetSubFrame() + 0.5f) + 1;
		NewSection->InitialPlacementOnRow(AnimationSections, KeyTime, IFrameNumber, INDEX_NONE);

	}

	AddSection(*NewSection);

	return NewSection;
}


TArray<UMovieSceneSection*> UMovieSceneWidgetSubSequenceTrack::GetAnimSectionsAtTime(FFrameNumber Time)
{
	TArray<UMovieSceneSection*> AnimSections;
	for (auto Section : AnimationSections)
	{
		if (Section->IsTimeWithinSection(Time))
		{
			AnimSections.Add(Section);
		}
	}

	return AnimSections;
}

FMovieSceneEvalTemplatePtr UMovieSceneWidgetSubSequenceTrack::CreateTemplateForSection(const UMovieSceneSection& InSection) const
{
	return FMovieSceneWidgetSubSequenceSectionTemplate(*CastChecked<UMovieSceneWidgetSubSequenceSection>(&InSection));
}

/* UMovieSceneTrack interface
 *****************************************************************************/


const TArray<UMovieSceneSection*>& UMovieSceneWidgetSubSequenceTrack::GetAllSections() const
{
	return AnimationSections;
}


bool UMovieSceneWidgetSubSequenceTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == UMovieSceneWidgetSubSequenceSection::StaticClass();
}

UMovieSceneSection* UMovieSceneWidgetSubSequenceTrack::CreateNewSection()
{
	return NewObject<UMovieSceneWidgetSubSequenceSection>(this, NAME_None, RF_Transactional);
}


void UMovieSceneWidgetSubSequenceTrack::RemoveAllAnimationData()
{
	AnimationSections.Empty();
}


bool UMovieSceneWidgetSubSequenceTrack::HasSection(const UMovieSceneSection& Section) const
{
	return AnimationSections.Contains(&Section);
}

void UMovieSceneWidgetSubSequenceTrack::AddSection(UMovieSceneSection& Section)
{
	AnimationSections.Add(&Section);
}

void UMovieSceneWidgetSubSequenceTrack::RemoveSection(UMovieSceneSection& Section)
{
	AnimationSections.Remove(&Section);
}

void UMovieSceneWidgetSubSequenceTrack::RemoveSectionAt(int32 SectionIndex)
{
	AnimationSections.RemoveAt(SectionIndex);
}


bool UMovieSceneWidgetSubSequenceTrack::IsEmpty() const
{
	return AnimationSections.Num() == 0;
}

void UMovieSceneWidgetSubSequenceTrack::ImportEntityImpl(UMovieSceneEntitySystemLinker* EntityLinker, const FEntityImportParams& Params, FImportedEntity* OutImportedEntity)
{
	// These tracks don't define any entities for themselves
	checkf(false, TEXT("This track should never have created entities for itself - this assertion indicates an error in the entity-component field"));
}

bool UMovieSceneWidgetSubSequenceTrack::PopulateEvaluationFieldImpl(const TRange<FFrameNumber>& EffectiveRange, const FMovieSceneEvaluationFieldEntityMetaData& InMetaData, FMovieSceneEntityComponentFieldBuilder* OutFieldBuilder)
{
	const FMovieSceneTrackEvaluationField& LocalEvaluationField = GetEvaluationField();

	// Define entities for every entry in our evaluation field
	for (const FMovieSceneTrackEvaluationFieldEntry& Entry : LocalEvaluationField.Entries)
	{
		UMovieSceneParameterSection* ParameterSection = Cast<UMovieSceneParameterSection>(Entry.Section);
		if (!ParameterSection || IsRowEvalDisabled(ParameterSection->GetRowIndex()))
		{
			continue;
		}

		TRange<FFrameNumber> SectionEffectiveRange = TRange<FFrameNumber>::Intersection(EffectiveRange, Entry.Range);
		if (!SectionEffectiveRange.IsEmpty())
		{
			FMovieSceneEvaluationFieldEntityMetaData SectionMetaData = InMetaData;
			SectionMetaData.Flags = Entry.Flags;

			ParameterSection->ExternalPopulateEvaluationField(SectionEffectiveRange, SectionMetaData, OutFieldBuilder);
		}
	}

	return true;
}


FName UMovieSceneWidgetSubSequenceTrack::GetTrackName() const
{ 
	return TrackName;
}


#if WITH_EDITORONLY_DATA
FText UMovieSceneWidgetSubSequenceTrack::GetDefaultDisplayName() const
{
	return FText::FromString(TEXT("SubSequence"));
}
#endif


void UMovieSceneWidgetSubSequenceTrack::SetBrushPropertyNamePath( TArray<FName> InBrushPropertyNamePath )
{
	BrushPropertyNamePath = InBrushPropertyNamePath;
	TrackName = TEXT("");
}

