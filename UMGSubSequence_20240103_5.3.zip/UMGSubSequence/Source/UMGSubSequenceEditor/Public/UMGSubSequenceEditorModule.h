// Copyright Qibo Pang 2023. All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Modules/ModuleManager.h"

DECLARE_LOG_CATEGORY_EXTERN(UMGSubSequenceEditor, Log, All);

class  FUMGSubSequenceEditorModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */


	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:

	FDelegateHandle TrackEditorBindingHandle;
};
