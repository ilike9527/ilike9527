// Copyright Qibo Pang 2024. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Layout/Visibility.h"
#include "Input/Reply.h"

#include "PolygonWidget.h"
#include "IDetailCustomization.h"

class IDetailLayoutBuilder;

//////////////////////////////////////////////////////////////////////////
// FUMGPolygonWidgetDetailsCustomization

class FUMGPolygonWidgetDetailsCustomization: public IDetailCustomization
{
public:
	// Makes a new instance of this detail layout class for a specific detail view requesting it
	static TSharedRef<IDetailCustomization> MakeInstance();

	// IDetailCustomization interface
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailLayout) override;
	// End of IDetailCustomization interface

	void OnPolygonInfoValueChanged(const FUMGPolygonInfo& NewPolygonInfo);

	FOptionalSize GetPolygonEditPanelHieght() const;

private:

	TWeakObjectPtr<UPolygonWidget> PolygonWidgetPtr;

	IDetailLayoutBuilder* MyDetailLayout;

	TSharedPtr<IPropertyHandle>     PropertyPolygonInfo;

};
