// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Layout/Visibility.h"
#include "Input/Reply.h"

#include "GeometryCacheCollisionComponent.h"
#include "IDetailCustomization.h"

class IDetailLayoutBuilder;

//////////////////////////////////////////////////////////////////////////
// FGeometryCacheCollisionWidgetDetailsCustomization

class FGeometryCacheCollisionWidgetDetailsCustomization: public IDetailCustomization
{
public:
	// Makes a new instance of this detail layout class for a specific detail view requesting it
	static TSharedRef<IDetailCustomization> MakeInstance();

	// IDetailCustomization interface
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailLayout) override;
	// End of IDetailCustomization interface

private:

	TWeakObjectPtr<UGeometryCacheCollisionComponent> GeometryCacheCollisionComponentPtr;

	IDetailLayoutBuilder* MyDetailLayout;

};
