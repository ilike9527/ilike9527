// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Components/PrimitiveComponent.h"
#include "PhysicsEngine/ConvexElem.h"
#include "Interfaces/Interface_CollisionDataProvider.h"
#include "GeometryCacheMeshData.h"
#include "PrimitiveSceneProxy.h"
#include "GeometryCacheCollisionComponent.generated.h"


class UGeometryCacheComponent;
class UGeometryCache;
class FGeomCacheTrackProxy;
class FGeometryCacheSceneProxy;

class FGeometryCacheCollisionProxySection;

/** Stores the RenderData for each individual track */
USTRUCT()
struct FTrackSectionRenderData
{
	GENERATED_USTRUCT_BODY()

	FTrackSectionRenderData() : Matrix(FMatrix::Identity), BoundingBox(EForceInit::ForceInitToZero), MatrixSampleIndex(INDEX_NONE), BoundsSampleIndex(INDEX_NONE) {}

	bool bEnableCollision = true;

	/** Transform matrix used to render this specific track.
		This goes from track local space to component local space.
	*/
	FMatrix Matrix;

	/** Bounding box of this specific track */
	FBox BoundingBox;

	/** Sample Id's of the values we currently have registered the component with. */
	int32 MatrixSampleIndex;
	int32 BoundsSampleIndex;

	void Clear()
	{
		BoundingBox.Init();
	}
};

/** Stores the Complex CollisionData for each individual track */
USTRUCT()
struct FTrackSectionCollisionData
{
	GENERATED_USTRUCT_BODY()

	FTrackSectionCollisionData() {}

	bool bEnableCollision = true;

	/** Position buffer for this track */
	TArray<FVector3f> PositionBuffer;

	/** UV buffer for this track */
	TArray<FVector2f> UVBuffer;

	/** Index buffer for this track */
	TArray<uint32> IndexBuffer;

	/** Array of per-batch info structs*/
	TArray<FGeometryCacheMeshBatchInfo> BatchesInfo;

	int32 FrameIndex = -1;

	void Clear()
	{
		IndexBuffer.Empty();

		PositionBuffer.Empty();

		UVBuffer.Empty();
	}

	void Prepare(int32 NumVertices)
	{
		if (NumVertices != PositionBuffer.Num())
		{
			// Clear entries but keep allocations.
			PositionBuffer.Reset();
			UVBuffer.Reset();

			// Make sure our capacity fits the requested vertex count
			PositionBuffer.Reserve(NumVertices);
			UVBuffer.Reserve(NumVertices);

			PositionBuffer.AddUninitialized(NumVertices);
			UVBuffer.AddUninitialized(NumVertices);
		}
	}

	void UpdateIndices(const TArray<uint32>& InIndexBuffer)
	{
		IndexBuffer = InIndexBuffer;
		return;
	}

	void UpdatePositions(const TArray<FVector3f>& InPositionBuffer)
	{
		PositionBuffer = InPositionBuffer;
		return;
	}

	void UpdateUVs(const TArray<FVector2f>& InUVBuffer)
	{
		UVBuffer = InUVBuffer;
		return;
	}
};

USTRUCT()
struct FGeometryCacheStatus
{
	GENERATED_USTRUCT_BODY()

	UGeometryCacheComponent* GeometryCacheComponent = nullptr;

	UGeometryCache* GeometryCache = nullptr;
	
	FGeometryCacheSceneProxy* GeometryCacheSceneProxy = nullptr;

	bool bStatusReseted = false;

	FGeometryCacheStatus() = default;

	FGeometryCacheStatus(UGeometryCacheComponent* InGeometryCacheComponent);

	bool IsValid()
	{
		return GeometryCacheComponent && GeometryCache && GeometryCacheSceneProxy;
	}

	bool ResetWhenChanged();

	void Clear()
	{
		GeometryCacheComponent = nullptr;
		GeometryCache = nullptr;
		GeometryCacheSceneProxy = nullptr;
		AnimationTime = -1.0f;
		bStatusReseted = true;
	}

	bool CheckStatusChanged();

	bool TracksInited();

private:

	float AnimationTime = -1.0f;
};

USTRUCT(BlueprintType)
struct FGeometryCacheHitTrackInfo
{
	GENERATED_USTRUCT_BODY()

	
	FGeometryCacheHitTrackInfo() = default;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "GeometryCacheCollision")
		UGeometryCacheComponent* GeometryCacheComponent;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "GeometryCacheCollision")
		int32 TrackID;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "GeometryCacheCollision")
		FString TrackName;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "GeometryCacheCollision")
		int32 TrackBatchSectionID;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "GeometryCacheCollision")
		int32 MaterialID;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "GeometryCacheCollision")
		UMaterialInterface* Material;
};

/** updating frame data from GeometryCache and  drawing collsion as wireframe */
class UGeometryCacheCollisionSceneProxy final : public FPrimitiveSceneProxy
{
public:
	SIZE_T GetTypeHash() const override
	{
		static size_t UniquePointer;
		return reinterpret_cast<size_t>(&UniquePointer);
	}

	UGeometryCacheCollisionSceneProxy(UGeometryCacheCollisionComponent* Component);

	virtual ~UGeometryCacheCollisionSceneProxy();

	virtual void GetDynamicMeshElements(const TArray<const FSceneView*>& Views, const FSceneViewFamily& ViewFamily, uint32 VisibilityMap, FMeshElementCollector& Collector) const override;

	virtual FPrimitiveViewRelevance GetViewRelevance(const FSceneView* View) const override;

	virtual uint32 GetMemoryFootprint(void) const override { return(sizeof(*this) + GetAllocatedSize()); }

	uint32 GetAllocatedSize(void) const { return(FPrimitiveSceneProxy::GetAllocatedSize()); }

	void UpdateFrame() const;

public:

	TArray<FTrackSectionCollisionData*> TrackSectionsCollisionData;

private:

	int32 NumSides;

	class UGeometryCacheCollisionComponent* GeometryCacheCollisionComponent;

	FGeometryCacheSceneProxy* GeometryCacheSceneProxy;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnGeometryCacheCollisionUpdated);

/** GeometryCache simple collision shape options. */
UENUM(BlueprintType)
enum class ESimpleCollisionShape : uint8
{
	
	Box UMETA(DisplayName = "Box"),
	
	Sphere UMETA(DisplayName = "Sphere")
};

/** An ActorComponent adding collision for GeometryCache */
UCLASS(ClassGroup = (GeometryCache), meta = (BlueprintSpawnableComponent))
class GEOMETRYCACHECOLLISION_API UGeometryCacheCollisionComponent : public UPrimitiveComponent, public IInterface_CollisionDataProvider
{
	GENERATED_UCLASS_BODY()

	friend class UGeometryCacheCollisionSceneProxy;

public:

	/**
	 *	Enable collision for geometry cache
	 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "GeometryCacheCollision")
		bool bEnableCollision = true;

	/**
	 *	Controls whether the complex (Per poly) geometry should be treated as 'simple' collision.
	 *	Should be set to false if this component is going to be given simple collision and simulated.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "GeometryCacheCollision")
		bool bUseComplexAsSimpleCollision = false;

	/**
	 *	Controls whether we should build simple collision for geometry cache.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheCollision", meta = (EditCondition = "!bUseComplexAsSimpleCollision"))
		bool bBuildSimpleCollision = true;
	
	/**
	 *	Controls simple collision shape.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheCollision", meta = (EditCondition = "!bUseComplexAsSimpleCollision"))
		ESimpleCollisionShape SimpleCollisionShape = ESimpleCollisionShape::Box;
	
	/**
	 *	Controls whether we should merge all enabled tracks simple collision to a large one.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheCollision", meta = (EditCondition = "!bUseComplexAsSimpleCollision"))
		bool bMergeSimpleCollision = false;

	/**
	* Controls whether the physics cooking should be done off the game thread. This should be used when collision geometry doesn't have to be immediately up to date (For example streaming in far away objects)
	*/
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "GeometryCacheCollision")
		bool bUseAsyncCooking;

	/**
	* Controls whether update collision manually. When enabled you can update collision by call Blueprint Function "UpdateCollisionManually"
	*/
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "GeometryCacheCollision")
		bool bManualUpdateCollision = false;

	/**
	*	Time interval for updating collision. When equal 0.0f, will update collision every frame.
	*/
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "GeometryCacheCollision", meta = (EditCondition = "!bManualUpdateCollision"))
		float UpdateCollisionInterval = 0.0f;

	/**
	 *	Only build collision for enabled geometry cache tracks.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "GeometryCacheCollision")
		bool bOnlyBuildCollisionForEnabledTracks = false;

	/**
	 *	Enabled geometry cache track id list.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "GeometryCacheCollision", meta = (EditCondition = "bOnlyBuildCollisionForEnabledTracks"))
		TArray<int32> EnabledTrackIDs;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Debug")
		bool bShowCollisionWireFrame = false;

public:

	/** Add simple collision convex to this component */
	UFUNCTION(BlueprintCallable, Category = "GeometryCacheCollision")
		void AddCollisionConvexMesh(TArray<FVector> ConvexVerts);

	/** Remove collision meshes from this component */
	UFUNCTION(BlueprintCallable, Category = "GeometryCacheCollision")
		void ClearCollisionConvexMeshes();

	/** Function to replace _all_ simple collision in one go */
	void SetCollisionConvexMeshes(const TArray< TArray<FVector> >& ConvexMeshes);

	/** Add simple collision convex to this component */
	UFUNCTION(BlueprintCallable, Category = "GeometryCacheCollision")
		bool GetHitTrackInfoFromCollisionFaceIndex(int32 FaceIndex, FGeometryCacheHitTrackInfo& HitTrackInfo) const;

	/** Synchronization collision settings from GeometryCacheComponent, use it when GeometryCacheComponent collision settings changed in plueprints*/
	UFUNCTION(BlueprintCallable, Category = "GeometryCacheCollision")
		void SynchronizationCollisionSettings();

	/** Update collision manually */
	UFUNCTION(BlueprintCallable, Category = "GeometryCacheCollision")
		void UpdateCollisionManually();

	UPROPERTY(BlueprintAssignable)
		FOnGeometryCacheCollisionUpdated OnCollisionUpdated;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

public:

	//~ Begin UActorComponent Interface.
	virtual void OnRegister() override;
	virtual void OnUnregister() override;
	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	//~ End UActorComponent Interface.

	//~ Begin Interface_CollisionDataProvider Interface
	virtual bool GetPhysicsTriMeshData(struct FTriMeshCollisionData* CollisionData, bool InUseAllTriData) override;
	virtual bool ContainsPhysicsTriMeshData(bool InUseAllTriData) const override;
	virtual bool WantsNegXTriMesh() override { return false; }
	//~ End Interface_CollisionDataProvider Interface

	//~ Begin UPrimitiveComponent Interface.
	virtual FPrimitiveSceneProxy* CreateSceneProxy() override;
	virtual class UBodySetup* GetBodySetup() override;
	virtual UMaterialInterface* GetMaterialFromCollisionFaceIndex(int32 FaceIndex, int32& SectionIndex) const override;
	//~ End UPrimitiveComponent Interface.

	UGeometryCacheComponent* GetGeometryCacheComponent() { return GeometryCacheStatus.GeometryCacheComponent; }

private:
	//~ Begin USceneComponent Interface.
	virtual FBoxSphereBounds CalcBounds(const FTransform& LocalToWorld) const override;
	//~ Begin USceneComponent Interface.


	/** Update LocalBounds member from the local box of each section */
	void UpdateLocalBounds();
	/** Ensure ProcMeshBodySetup is allocated and configured */
	void CreateGeometryCacheBodySetup();
	/** Mark collision data as dirty, and re-create on instance if necessary */
	void UpdateCollision();
	/** Once async physics cook is done, create needed state */
	void FinishPhysicsAsyncCook(bool bSuccess, UBodySetup* FinishedBodySetup);

	/** Helper to create new body setup objects */
	UBodySetup* CreateBodySetupHelper();

	bool ResetGeometryCacheStatusWhenChanged(bool bForceReset);

	void ClearGeometryCacheStatus();

	bool CheckTrackSectionCollisionEnabled(int32 TrackIndex);

	bool CheckHasCollisionDataInited() const;

	/**
	* Updates the game thread state of a track section
	*
	* @param TrackIndex - Index of the decal we want to update
	*/
	bool UpdateTrackSection(int32 TrackIndex);

	/**
	* CreateTrackSection, Create/replace a track section.
	*
	* @param TrackIndex - Index of the track to create (corresponds to an index on the geometry cache)
	*/
	void CreateTrackSection(int32 TrackIndex);

	/**
	* SetupTrackData
	* Call CreateTrackSection for all tracks in the GeometryCache assigned to this object.
	*/
	void SetupTrackData();

	/**
	* ClearTrackData
	* Clean up data that was required for playback of geometry cache tracks
	*/
	void ClearTrackData();

private:

	/** Collision data */
	UPROPERTY(Instanced)
		class UBodySetup* GeometryCacheBodySetup;

	UPROPERTY()
		FGeometryCacheStatus GeometryCacheStatus;

	UPROPERTY(VisibleAnywhere, Category = "GeometryCacheCollision")
		int32 NumTracks;

	/** Convex shapes used for simple collision */
	UPROPERTY()
		TArray<FKConvexElem> CollisionConvexElems;

	/** Local space bounds of mesh */
	UPROPERTY()
		FBoxSphereBounds LocalBounds;

	/** Queue for async body setups that are being cooked */
	UPROPERTY(transient)
		TArray<UBodySetup*> AsyncBodySetupQueue;

	/** Array containing the TrackData (used for collision) for each individual track*/
	TArray<FTrackSectionRenderData> TrackSections;

	float AccumulateDeltaTime = 0.0f;

	bool bRuntimeTicking = false;
	bool bRuntimeInited = false;

	bool bFrameUpdated = false;
};
