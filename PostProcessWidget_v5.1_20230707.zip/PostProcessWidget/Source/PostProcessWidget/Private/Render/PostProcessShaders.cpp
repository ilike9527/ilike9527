// Copyright Qibo Pang 2023. All Rights Reserved.

#include "PostProcessShaders.h"
#include "Rendering/RenderingCommon.h"
#include "PipelineStateCache.h"

IMPLEMENT_SHADER_TYPE(, FPostProcessCopysamplePS, TEXT("/Plugin/PostProcessWidget/Private/PostProcessPixelShader.usf"), TEXT("CopysampleMain"), SF_Pixel);
void FPostProcessCopysamplePS::ModifyCompilationEnvironment(const FGlobalShaderPermutationParameters& Parameters, FShaderCompilerEnvironment& OutEnvironment)
{
	static const auto CVar = IConsoleManager::Get().FindTConsoleVariableDataInt(TEXT("r.HDR.Display.OutputDevice"));
	OutEnvironment.SetDefine(TEXT("USE_709"), CVar ? (CVar->GetValueOnGameThread() == 1) : 1);
}
