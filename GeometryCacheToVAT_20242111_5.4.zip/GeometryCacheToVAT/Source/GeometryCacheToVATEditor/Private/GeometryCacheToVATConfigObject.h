// Copyright Qibo Pang 2023. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "GeometryCacheToVATTypes.h"
#include "GeometryCacheToVATConfigObject.generated.h"

UCLASS(BlueprintType)
class UGeometryCacheToVATConfigObject : public UObject
{
	GENERATED_BODY()

public:

	UGeometryCacheToVATConfigObject();

	UPROPERTY(EditAnywhere, Category = "GeometryCacheToVAT", meta = (AllowPrivateAccess = "true"))
		FGeometryCacheToVATInput Input;

	UPROPERTY(EditAnywhere, Category = "GeometryCacheToVAT", meta = (AllowPrivateAccess = "true"))
		FGeometryCacheToVATConfig Config;

	UPROPERTY(EditAnywhere, Category = "GeometryCacheToVAT", meta = (AllowPrivateAccess = "true"))
		FGeometryCacheToVATOutput Output;

public:

	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	void InitConfig();

};