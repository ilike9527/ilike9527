// Copyright Qibo Pang 2023. All Rights Reserved.


#include "GeometryCacheToVATEditorModule.h"
#include "IContentBrowserSingleton.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "AssetToolsModule.h"
#include "Modules/ModuleManager.h"
#include "GeometryCache.h"
#include "ContentBrowserModule.h"
#include "GeometryCacheToVATConfigPanel.h"

#define LOCTEXT_NAMESPACE "FGeometryCacheToVATEditorModule"

void FGeometryCacheToVATEditorModule::StartupModule()
{
    FContentBrowserModule& ContentBrowserModule = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
    TArray<FContentBrowserMenuExtender_SelectedAssets>& CBMenuExtenderDelegates = ContentBrowserModule.GetAllAssetViewContextMenuExtenders();
    CBMenuExtenderDelegates.Add(FContentBrowserMenuExtender_SelectedAssets::CreateRaw(this, &FGeometryCacheToVATEditorModule::OnExtendContentBrowserAssetSelectionMenu));


    RegisterCustomClassLayout("GeometryCacheToVATConfigObject", FOnGetDetailCustomizationInstance::CreateStatic(&FGeometryCacheToVATConfigDetailCustomization::MakeInstance));
}

void FGeometryCacheToVATEditorModule::ShutdownModule()
{
	if (!UObjectInitialized())
		return;

    if (FModuleManager::Get().IsModuleLoaded("ContentBrowser"))
    {
        FContentBrowserModule& ContentBrowserModule = FModuleManager::GetModuleChecked<FContentBrowserModule>("ContentBrowser");
        TArray<FContentBrowserMenuExtender_SelectedAssets>& CBMenuExtenderDelegates = ContentBrowserModule.GetAllAssetViewContextMenuExtenders();
        CBMenuExtenderDelegates.RemoveAll([this](const FContentBrowserMenuExtender_SelectedAssets& Delegate) {
            return Delegate.GetHandle() == ContentBrowserExtenderDelegateHandle;
            });
    }

    if (FModuleManager::Get().IsModuleLoaded("PropertyEditor"))
    {
        FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>("PropertyEditor");

        for (auto It = RegisteredClassNames.CreateConstIterator(); It; ++It)
        {
            if (It->IsValid())
            {
                PropertyModule.UnregisterCustomClassLayout(*It);
            }
        }

        PropertyModule.NotifyCustomizationModuleChanged();
    }
}

TSharedRef<FExtender> FGeometryCacheToVATEditorModule::OnExtendContentBrowserAssetSelectionMenu(const TArray<FAssetData>& SelectedAssets)
{
    TSharedRef<FExtender> Extender = MakeShareable(new FExtender);

    // Check UGeometryCache Type
    bool bContainsGeometryCache = false;
    for (const FAssetData& AssetData : SelectedAssets)
    {
        if (AssetData.AssetName == UGeometryCache::StaticClass()->GetFName()
            || AssetData.AssetClassPath == UGeometryCache::StaticClass()->GetClassPathName())
        {
            bContainsGeometryCache = true;
            break;
        }
    }

    if (bContainsGeometryCache)
    {
        Extender->AddMenuExtension(
            "GetAssetActions",
            EExtensionHook::After,
            nullptr,
            FMenuExtensionDelegate::CreateRaw(this, &FGeometryCacheToVATEditorModule::AddMenuEntry)
        );
    }

    return Extender;
}

void FGeometryCacheToVATEditorModule::AddMenuEntry(FMenuBuilder& MenuBuilder)
{
    MenuBuilder.AddMenuEntry(
        FText::FromString("Convert GeometryCache to Vertex Animation"),
        FText::FromString("Convert GeometryCache to Vertex Animation"),
        FSlateIcon(),
        FUIAction(FExecuteAction::CreateRaw(this, &FGeometryCacheToVATEditorModule::OnGeometryCacheToVATClicked))
    );
}

void FGeometryCacheToVATEditorModule::OnGeometryCacheToVATClicked()
{
    // Get the singleton instance of the content browser
    IContentBrowserSingleton& ContentBrowserSingleton = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser").Get();

    // Get the selected asset data
    TArray<FAssetData> SelectedAssets;
    ContentBrowserSingleton.Get().GetSelectedAssets(SelectedAssets);

    UGeometryCache* GeometryCache = nullptr;
    // Iterate through the selected asset data
    for (const FAssetData& AssetData : SelectedAssets)
    {
        // Check if the asset data is of type GeometryCache
        if (AssetData.AssetName == UGeometryCache::StaticClass()->GetFName()
            || AssetData.AssetClassPath == UGeometryCache::StaticClass()->GetClassPathName())
        {
            // Perform the corresponding operation, such as getting the selected GeometryCache object
            GeometryCache = Cast<UGeometryCache>(AssetData.GetAsset());
            if (GeometryCache)
            {
                break;
            }
        }
    }

    if (GeometryCache)
	{
        SGeometryCacheToVATConfigPanel::PopVertexAnimationConvertConfigWindow(GeometryCache);
	}
    
}

void FGeometryCacheToVATEditorModule::RegisterCustomClassLayout(FName ClassName, FOnGetDetailCustomizationInstance DetailLayoutDelegate)
{
    check(ClassName != NAME_None);

    RegisteredClassNames.Add(ClassName);

    FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>("PropertyEditor");
    PropertyModule.RegisterCustomClassLayout(ClassName, DetailLayoutDelegate);
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FGeometryCacheToVATEditorModule, GeometryCacheToVATEditor)
