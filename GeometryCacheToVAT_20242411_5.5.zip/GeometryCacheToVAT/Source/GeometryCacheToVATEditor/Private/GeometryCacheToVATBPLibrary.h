// Copyright Qibo Pang 2023. All Rights Reserved.

#pragma once

#include "GeometryCacheToVATTypes.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Materials/MaterialLayersFunctions.h"

#include "GeometryCacheToVATBPLibrary.generated.h"

class UStaticMesh;
class USkeletalMesh;
class UGeometryCache;

/**
* Converts Alembic geometry cache frames into a Vertex Animation Texture (VAT)
* 
* The texture can store Vertex positions and normals.
*/
UCLASS()
class UGeometryCacheToVATBPLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_UCLASS_BODY()

public:

#if WITH_EDITOR

	/**
	* Bakes Animation Data into Textures.
	*/
	UFUNCTION(BlueprintCallable, meta = (Category = "GeometryCacheToVAT"))
	static UPARAM(DisplayName="bSuccess") bool GeometryCacheToVertexAnimation(UGeometryCache* GeometryCache, UPARAM(Ref)FGeometryCacheToVATContext& Context);

	/**
	* Utility for converting GeometryCacheRenderMesh into a StaticMesh
	*/
	static UStaticMesh* ConvertGeometryCacheToStaticMesh(const FGeometryCacheRenderMesh& RenderMesh, const FString& PackagePath, const FString& PackageName, const int32 LODIndex = -1);

	/**
	* Utility for setting a StaticMesh LightMapIndex.
	*/
	UFUNCTION(BlueprintCallable, Category = "GeometryCacheToVAT")
	static UPARAM(DisplayName = "bSuccess") bool SetLightMapIndex(UStaticMesh* StaticMesh, const int32 LODIndex, const int32 LightmapIndex=1, bool bGenerateLightmapUVs=true);

	/**
	* Updates a material's parameters to match those of an GeometryCacheToVAT DataAsset
	*/
	UFUNCTION(BlueprintCallable, meta = (Category = "GeometryCacheToVAT"))
	static void UpdateMaterialInstanceFromDataAsset(UPARAM(Ref)FGeometryCacheToVATContext& Context, class UMaterialInstanceConstant* MaterialInstance,
		const EMaterialParameterAssociation MaterialParameterAssociation = EMaterialParameterAssociation::LayerParameter);

#endif // WITH_EDITOR

private:

	static void GenerateNaniteTexture(FGeometryCacheToVATContext& Context);

	// Runs some validations for the context
	// Returns false if there is any problems with the data, warnings will be printed in Log
	static bool CheckContextValid(const FGeometryCacheToVATContext& Context);

	// Get Vertex and Normals from Current Pose
	// The VertexDelta is returned from the RefPose
	static void GetVertexDeltasAndNormals(const TArray<FVector3f>& SourceVertices, const TArray<FVector3f>& DeformedVertices,
		const TArray<FPackedNormal>& DeformedNormals, const FTransform RootTransform, TArray<FVector3f>& OutVertexDeltas, TArray<FVector3f>& OutVertexNormals);

	// Normalizes Deltas and Normals between [0-1] with Bounding Box
	static void NormalizeVertexData(
		const TArray<FVector3f>& Deltas, const TArray<FVector3f>& Normals,
		FVector3f& OutMinBBox, FVector3f& OutSizeBBox,
		TArray<FVector3f>& OutNormalizedDeltas, TArray<FVector3f>& OutNormalizedNormals);


	/* Returns best resolution for the given data. 
	*  Returns false if data doesnt fit in the the max range */
	static bool FindBestResolution(const int32 NumFrames, const int32 NumElements,
								   int32& OutHeight, int32& OutWidth, int32& OutRowsPerFrame,
								   const int32 MaxHeight = 4096, const int32 MaxWidth = 4096, bool bEnforcePowerOfTwo = false);

	/* Sets Static Mesh FullPrecisionUVs Property*/
	static void SetFullPrecisionUVs(UStaticMesh* StaticMesh, const int32 LODIndex, bool bFullPrecision=true);

	/* Sets Static Mesh Bound Extensions */
	static void SetBoundsExtensions(UStaticMesh* StaticMesh, const FVector& MinBBox, const FVector& SizeBBox);

	static bool CreateUVChannel(FGeometryCacheRenderMesh& RenderMesh, const int32 UVChannelIndex,
		const int32 Height, const int32 Width);

	static void UpdateProgress(int32 Percentage, const TFunction<void(int32)> ProgressCallback = nullptr);

	static void RecordError(const FString& ErrorMessage, const TFunction<void(const FString&)> ErrorCallback = nullptr);
};
