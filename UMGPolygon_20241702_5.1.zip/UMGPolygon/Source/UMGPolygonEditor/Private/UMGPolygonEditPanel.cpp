// Copyright Qibo Pang. All Rights Reserved.


#include "UMGPolygonEditPanel.h"
#include "EditorStyleSet.h"
#include "Components/Widget.h"
#include "Widgets/Input/SSlider.h"
#include "UMGPolygonBuilder.h"
#include "UMGPolygonRenderBatch.h"
#include "UMGPolygonEditorSettings.h"
#include "Styling/ToolBarStyle.h"
#include "PolygonWidget.h"
#include "Layout/Geometry.h"

#define LOCTEXT_NAMESPACE "SUMGPolygonEditPanel"

const static FVector2D	CONST_KeySize = FVector2D(11, 11);
const static FVector2D	CONST_TangentSize = FVector2D(7, 7);
const static FVector2D	CONST_CurveSize = FVector2D(12, 12);

const static float		CONST_FitMargin = 0.25f;
const static float		CONST_MinViewRange = 100.0f;
const static float		CONST_DefaultZoomRange = 200.0f;
const static float      CONST_KeyTangentOffsetMin = 30.0f;
const static float      CONST_KeyTangentOffsetMax = 150.0f;
const static float      CONST_TangentMaxStrength = 2000.0f;
const static float      CONST_TangentSelectIconOffset = 15.0f;

const static float      CONST_PanelHeightMin = 200.0f;
const static float      CONST_PanelHeightMax = 1000.0f;

const static float      CONST_PolygonEdgeThicknessMin = 1.0f;
const static float      CONST_PolygonEdgeThicknessMax = 100.0f;
/*===========================================================================*\
|                                Construct                                    |
\*===========================================================================*/

void SUMGPolygonEditPanel::Construct(const FArguments& InArgs)
{
	// Arguments passed onto the slate widget
	PolygonInfo = InArgs._PolygonInfo;
	OwningPolygonWidget = InArgs._OwningPolygonWidget;

	OnPolygonInfoValueChanged = InArgs._OnPolygonInfoValueChanged;

	DragState = EDragState::None;
	DragThreshold = 4;

	SelectedPointIndex = 0;

	PoygonVertsCache = MakeShared<FPoygonVertsCache>();

	const FToolBarStyle& ToolBarStyle = FEditorStyle::Get().GetWidgetStyle<FToolBarStyle>("EditorViewportToolBar");

	ChildSlot
		[
			SNew(SHorizontalBox)

				+ SHorizontalBox::Slot()
				.FillWidth(1.0f)
				[
					SNew(SVerticalBox)

						+ SVerticalBox::Slot()
						.FillHeight(1.0f)
						[
							SNew(SHorizontalBox)

								+ SHorizontalBox::Slot()
								.AutoWidth()
								[
									SNew(SBorder)
										.VAlign(VAlign_Top)
										.HAlign(HAlign_Left)
										.BorderImage(FEditorStyle::GetBrush("NoBorder"))
										.DesiredSizeScale(FVector2D(256.0f, 32.0f))
										.Padding(FMargin(2, 2, 0, 0))
										[
											SNew(SHorizontalBox)
												+ SHorizontalBox::Slot()
												.AutoWidth()
												.VAlign(VAlign_Center)
												[
													SNew(SComboButton)
														.ButtonStyle(&ToolBarStyle.ButtonStyle)
														.OnGetMenuContent(this, &SUMGPolygonEditPanel::GetPanelHeightMenu)
														.ContentPadding(ToolBarStyle.ButtonPadding)
														.ButtonContent()
														[
															SNew(STextBlock)
																.Text(LOCTEXT("AdjustPanelHeight", "Panel Height"))
																.TextStyle(&ToolBarStyle.LabelStyle)
																.ColorAndOpacity(FSlateColor::UseForeground())
														]
												]

												+ SHorizontalBox::Slot()
												.AutoWidth()
												[
													SNew(SButton)
														.ButtonStyle(&ToolBarStyle.ButtonStyle)
														.ToolTipText(LOCTEXT("ZoomToFit", "Zoom To Fit"))
														.OnClicked(this, &SUMGPolygonEditPanel::ZoomToFitClicked)
														.ContentPadding(ToolBarStyle.ButtonPadding)
														.ContentPadding(1)
														[
															SNew(SImage)
																.Image(FEditorStyle::GetBrush("UMGEditor.ZoomToFit"))
																.ColorAndOpacity(FSlateColor::UseForeground())
														]
												]

												// Screen Fill Size Rule
												+ SHorizontalBox::Slot()
												.AutoWidth()
												.VAlign(VAlign_Center)
												[
													SNew(SComboButton)
														.ButtonStyle(&ToolBarStyle.ButtonStyle)
														.OnGetMenuContent(this, &SUMGPolygonEditPanel::GetEdgeThicknessFillMenu)
														.ContentPadding(ToolBarStyle.ButtonPadding)
														.ButtonContent()
														[
															SNew(STextBlock)
																.Text(LOCTEXT("EdgeThickness", "EdgeThickness"))
																.TextStyle(&ToolBarStyle.LabelStyle)
																.ColorAndOpacity(FSlateColor::UseForeground())
														]
												]
										]
								]
						]
				]
				// Help tips
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.Padding(FMargin(8.0f, 8.0f))
				.HAlign(HAlign_Right)
				.VAlign(VAlign_Top)
				[
					SAssignNew(HelpIconImage, SImage)
						.Image(FEditorStyle::GetBrush("Icons.Help"))
						.ToolTipText(this, &SUMGPolygonEditPanel::GetHelpText)
				]
		];
	DeferredZoomToFit();
}

/*===========================================================================*\
|                                Overrides                                    |
\*===========================================================================*/

FVector2D SUMGPolygonEditPanel::ComputeDesiredSize(float) const
{
	return FVector2D(300.0f, 310.0f);
}

void SUMGPolygonEditPanel::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	// Zoom to extents
	if (bDeferredZoomToFit)
	{
		bDeferredZoomToFit = false;
		
		RegisterActiveTimer(0.f, FWidgetActiveTimerDelegate::CreateSP(this, &SUMGPolygonEditPanel::HandleZoomToFit));
	}
}


FReply SUMGPolygonEditPanel::OnMouseButtonDown(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	const bool bLeftMouseButton = InMouseEvent.GetEffectingButton() == EKeys::LeftMouseButton;
	const bool bMiddleMouseButton = InMouseEvent.GetEffectingButton() == EKeys::MiddleMouseButton;
	const bool bRightMouseButton = InMouseEvent.GetEffectingButton() == EKeys::RightMouseButton;

	DragState = EDragState::PreDrag;

	if (bLeftMouseButton || bMiddleMouseButton || bRightMouseButton)
	{
		MouseDownLocation = InMyGeometry.AbsoluteToLocal(InMouseEvent.GetScreenSpacePosition());

		// Set keyboard focus to this so that selected text box doesn't try to apply to newly selected keys
		if (!HasKeyboardFocus())
		{
			FSlateApplication::Get().SetKeyboardFocus(SharedThis(this), EFocusCause::SetDirectly);
		}

		bEditPanelFocus = true;

		// Always capture mouse if we left or right click on the widget
		return FReply::Handled().CaptureMouse(SharedThis(this));
	}

	return FReply::Unhandled();
}

FReply SUMGPolygonEditPanel::OnMouseButtonUp(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	if (this->HasMouseCapture())
	{
		if (DragState == EDragState::PreDrag)
		{
			// If the user didn't start dragging, handle the mouse operation as a click.
			ProcessClick(InMyGeometry, InMouseEvent);
		}
		else
		{
			EndDrag(InMyGeometry, InMouseEvent);
		}
		return FReply::Handled().ReleaseMouseCapture();
	}

	return FReply::Unhandled();
}

FReply SUMGPolygonEditPanel::OnMouseMove(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	if (this->HasMouseCapture())
	{
		if (DragState == EDragState::PreDrag)
		{
			TryStartDrag(InMyGeometry, InMouseEvent);
		}
		if (DragState != EDragState::None)
		{
			ProcessDrag(InMyGeometry, InMouseEvent);
		}
		MouseMoveLocation = InMyGeometry.AbsoluteToLocal(InMouseEvent.GetScreenSpacePosition());
		return FReply::Handled();
	}

	return FReply::Unhandled();
}

void SUMGPolygonEditPanel::OnMouseCaptureLost(const FCaptureLostEvent& CaptureLostEvent)
{
	DragState = EDragState::None;
}


FReply SUMGPolygonEditPanel::OnMouseWheel(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (bEditPanelFocus/*HasKeyboardFocus()*/)
	{
		ZoomView(MyGeometry, MouseEvent);
		return FReply::Handled();
	}
	return FReply::Unhandled();
}

void SUMGPolygonEditPanel::OnMouseLeave(const FPointerEvent& MouseEvent)
{
	bEditPanelFocus = false;
}

void SUMGPolygonEditPanel::ZoomView(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	const float CONST_Scale_Min = 0.1f;
	const float CONST_Scale_Max = 10.0f;

	float Delta = MouseEvent.GetWheelDelta();
	float NewScale = TransformInfo.Scale + Delta * 0.1f;
	NewScale = FMath::Clamp(NewScale, CONST_Scale_Min, CONST_Scale_Max);
	
	// Mouse position is zoom center
	FVector2D MousePosition = MyGeometry.AbsoluteToLocal(MouseEvent.GetScreenSpacePosition());
	FVector2D InPosition = TransformInfo.LocalToInput(MousePosition);
	FVector2D NewOffset = InPosition - (MousePosition / NewScale);


	TransformInfo.Scale = NewScale;
	TransformInfo.Offset = NewOffset;
}


FReply SUMGPolygonEditPanel::OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	if (InKeyEvent.GetKey() == EKeys::Platform_Delete && SelectedPointIndex != -1)
	{
		DeleteSelectedPolygonPoint();
		return FReply::Handled();
	}
	
	return FReply::Unhandled();
}

int32 SUMGPolygonEditPanel::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	const ESlateDrawEffect DrawEffects = ShouldBeEnabled(bParentEnabled) ? ESlateDrawEffect::None : ESlateDrawEffect::DisabledEffect;
	
	int32 BackgroundLayerId = LayerId;

	// grid lines.
	int32 GridLineLayerId = BackgroundLayerId + 1;
	PaintGridLines(AllottedGeometry, OutDrawElements, GridLineLayerId, MyCullingRect, DrawEffects);
	
	int32 BackgroundMaterialLayerId = GridLineLayerId + 1;
	PaintBackgroundMaterial(PolygonInfo.Get(), AllottedGeometry, OutDrawElements, BackgroundMaterialLayerId, MyCullingRect, DrawEffects);

	int32 PolygonLayerId = BackgroundMaterialLayerId + 1;
	PaintPolygon_CustomVerts(PolygonInfo.Get(), AllottedGeometry, OutDrawElements, PolygonLayerId, MyCullingRect, DrawEffects, InWidgetStyle);

	int32 KeyLayerId = PolygonLayerId + 1;
	int32 SelectedKeyLayerId = KeyLayerId + 1;
	PaintPolygonPoints(PolygonInfo.Get(), OutDrawElements, KeyLayerId, SelectedKeyLayerId, AllottedGeometry, MyCullingRect, DrawEffects, InWidgetStyle);
	
	// Paint children
	int32 ChildrenLayerId = SelectedKeyLayerId + 1;
	int32 MarqueeLayerId = SCompoundWidget::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, ChildrenLayerId, InWidgetStyle, bParentEnabled);

	return ChildrenLayerId + 1;
}

/*===========================================================================*\
|                            Drag                                             |
\*===========================================================================*/

void SUMGPolygonEditPanel::TryStartDrag(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	const bool bLeftMouseButton = InMouseEvent.IsMouseButtonDown(EKeys::LeftMouseButton);
	const bool bMiddleMouseButton = InMouseEvent.IsMouseButtonDown(EKeys::MiddleMouseButton);
	const bool bRightMouseButton = InMouseEvent.IsMouseButtonDown(EKeys::RightMouseButton);
	const bool bControlDown = InMouseEvent.IsControlDown();
	const bool bShiftDown = InMouseEvent.IsShiftDown();
	const bool bAltDown = InMouseEvent.IsAltDown();

	FVector2D MousePosition = InMyGeometry.AbsoluteToLocal(InMouseEvent.GetScreenSpacePosition());
	FVector2D DragVector = MousePosition - MouseDownLocation;
	if (DragVector.SizeSquared() >= FMath::Square(DragThreshold))
	{
		if (bLeftMouseButton)
		{
			// Check if we should start dragging keys.
			int HitPointIndex = HitTestPolygonPoints(InMyGeometry, InMyGeometry.LocalToAbsolute(MouseDownLocation));
			if (HitPointIndex != -1)
			{
				SelectedPointIndex = HitPointIndex;
				DragState = EDragState::DragKey;
				DraggedPointIndex = HitPointIndex;
				PreDragPointLocations.Empty();
				PreDragPointLocations.Add(DraggedPointIndex, MousePosition);
			}
			else
			{
				// Check if we should start dragging a tangent.
				FSelectedPolygonTangent HitTangent = HitTestCubicTangents(InMyGeometry, InMyGeometry.LocalToAbsolute(MouseDownLocation));
				if (HitTangent.IsValid())
				{
					SelectedTangent = HitTangent;
					SelectedPointIndex = HitTangent.PointIndex;
					DragState = EDragState::DragTangent;
					PreDragTangents.Empty();
					PreDragTangents.Add(HitTangent.PointIndex, PolygonInfo.Get().Points[HitTangent.PointIndex].Direction);
				}
			}
		}
		else if (bRightMouseButton)
		{
			if (bAltDown)
			{
				DragState = EDragState::Zoom;
			}
			else
			{
				DragState = EDragState::Pan;
			}
		}
		else
		{
			DragState = EDragState::None;
		}
	}
}

void SUMGPolygonEditPanel::ProcessDrag(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	FVector2D ScreenDelta = InMouseEvent.GetCursorDelta();
	FVector2D InputDelta = ScreenDelta / TransformInfo.Scale;

	if (DragState == EDragState::DragKey)
	{
		FVector2D MousePosition = InMyGeometry.AbsoluteToLocal(InMouseEvent.GetScreenSpacePosition());
		FVector2D Delta = MousePosition - PreDragPointLocations[DraggedPointIndex];

		FUMGPolygonInfo NewPolygonInfo = PolygonInfo.Get();
		NewPolygonInfo.Points[DraggedPointIndex].Location = TransformInfo.LocalToInput(MousePosition); 
		OnPolygonInfoValueChanged.ExecuteIfBound(NewPolygonInfo);
	}
	else if (DragState == EDragState::DragTangent)
	{
		FVector2D MousePosition = InMyGeometry.AbsoluteToLocal(InMouseEvent.GetScreenSpacePosition());

		FVector2D KeyLocation = PolygonInfo.Get().Points[SelectedTangent.PointIndex].Location;
		FVector2D KeyLocalLocation = TransformInfo.InputToLocal(KeyLocation);
		
		float Distance = FVector2D::Distance(MousePosition, KeyLocalLocation);
		Distance = FMath::Max(CONST_KeyTangentOffsetMin, Distance);
		float Alpha = (Distance - CONST_KeyTangentOffsetMin) / (CONST_KeyTangentOffsetMax - CONST_KeyTangentOffsetMin);
		Alpha = FMath::Max(0.01f, Alpha);

		float Strength = (CONST_TangentMaxStrength * Alpha) / TransformInfo.Scale;

		FVector2D NewDirection = SelectedTangent.bIsArrial ? (KeyLocalLocation - MousePosition) : (MousePosition - KeyLocalLocation);
		NewDirection.Normalize();
		NewDirection = NewDirection * Strength;

		FUMGPolygonInfo NewPolygonInfo = PolygonInfo.Get();
		NewPolygonInfo.Points[SelectedTangent.PointIndex].Direction = NewDirection;
		OnPolygonInfoValueChanged.ExecuteIfBound(NewPolygonInfo);

	}
	else if (DragState == EDragState::Pan)
	{
		TransformInfo.Offset -= InputDelta;
	}
}

void SUMGPolygonEditPanel::EndDrag(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	DragState = EDragState::None;
}


int SUMGPolygonEditPanel::HitTestPolygonPoints(const FGeometry& InMyGeometry, const FVector2D& HitScreenPosition)
{
	const FVector2D HitPosition = InMyGeometry.AbsoluteToLocal(HitScreenPosition);

	const TArray<FUMGPolygonPoint>& Points = PolygonInfo.Get().GetPoints();

	// Iterate over each key
	for (int32 i = 0; i < Points.Num(); ++i)
	{
		FVector2D PointLocalLocation = TransformInfo.InputToLocal(Points[i].Location);

		if (HitPosition.X > (PointLocalLocation.X - (0.5f * CONST_KeySize.X)) &&
			HitPosition.X < (PointLocalLocation.X + (0.5f * CONST_KeySize.X)) &&
			HitPosition.Y >(PointLocalLocation.Y - (0.5f * CONST_KeySize.Y)) &&
			HitPosition.Y < (PointLocalLocation.Y + (0.5f * CONST_KeySize.Y)))
		{
			return i;
		}
	}


	return -1;
}

FSelectedPolygonTangent SUMGPolygonEditPanel::HitTestCubicTangents(const FGeometry& InMyGeometry, const FVector2D& HitScreenPosition)
{
	FSelectedPolygonTangent HitTangent;

	const FVector2D HitPosition = InMyGeometry.AbsoluteToLocal(HitScreenPosition);

	const TArray<FUMGPolygonPoint>& Points = PolygonInfo.Get().GetPoints();

	// Iterate over each key
	for (int32 i = 0; i < Points.Num(); ++i)
	{
		FVector2D LocalLocation = TransformInfo.InputToLocal(Points[i].Location);
		FVector2D LocalDir = Points[i].Direction * TransformInfo.Scale;
		FVector2D Arrive, Leave;
		GetTangentPoints(LocalLocation, LocalDir, Arrive, Leave);

		if (HitPosition.Y > (Arrive.Y - (0.5f * CONST_CurveSize.Y)) &&
			HitPosition.Y < (Arrive.Y + (0.5f * CONST_CurveSize.Y)) &&
			HitPosition.X >(Arrive.X - (0.5f * CONST_TangentSize.X)) &&
			HitPosition.X < (Arrive.X + (0.5f * CONST_TangentSize.X)))
		{
			HitTangent.PointIndex = i;
			HitTangent.bIsArrial = true;
			break;
		}
		if (HitPosition.Y > (Leave.Y - (0.5f * CONST_CurveSize.Y)) &&
			HitPosition.Y < (Leave.Y + (0.5f * CONST_CurveSize.Y)) &&
			HitPosition.X >(Leave.X - (0.5f * CONST_TangentSize.X)) &&
			HitPosition.X < (Leave.X + (0.5f * CONST_TangentSize.X)))
		{
			HitTangent.PointIndex = i;
			HitTangent.bIsArrial = false;
			break;
		}
	}

	return HitTangent;
}
	
/*===========================================================================*\
|                                Paint functions                              |
\*===========================================================================*/

void SUMGPolygonEditPanel::PaintPolygon_CustomVerts(const FUMGPolygonInfo& InPolygonInfo, const FGeometry& AllottedGeometry, FSlateWindowElementList& OutDrawElements,
	int32 LayerId, const FSlateRect& MyCullingRect, ESlateDrawEffect DrawEffects, const FWidgetStyle& InWidgetStyle)const
{
	if (InPolygonInfo.GetPointNum() > 1)
	{
		if (!PoygonVertsCache->PolygonInfoInUse.IsMatch(InPolygonInfo)
			|| PoygonVertsCache->DrawScale != AllottedGeometry.ToPaintGeometry().DrawScale
			|| PoygonVertsCache->DrawPosition != AllottedGeometry.ToPaintGeometry().DrawPosition
			|| PoygonVertsCache->TransformOffset != TransformInfo.Offset
			|| PoygonVertsCache->TransformScale != TransformInfo.Scale)
		{
			PoygonVertsCache->TransformOffset = TransformInfo.Offset;
			PoygonVertsCache->TransformScale = TransformInfo.Scale;
			PoygonVertsCache->DrawScale = AllottedGeometry.ToPaintGeometry().DrawScale;
			PoygonVertsCache->DrawPosition = AllottedGeometry.ToPaintGeometry().DrawPosition;
			PoygonVertsCache->PolygonInfoInUse = InPolygonInfo;
			PoygonVertsCache->Clear();
			const TArray<FUMGPolygonPoint>& Points = InPolygonInfo.GetPoints();

			// 1 is the minimum thickness we support for generating geometry.
			// The shader takes care of sub-pixel line widths.
			// EdgeThickness is given in screenspace, so convert it to local space before proceeding.
			FSlateLayoutTransform LayoutTransform = FSlateLayoutTransform(AllottedGeometry.ToPaintGeometry().DrawScale, AllottedGeometry.ToPaintGeometry().DrawPosition);
			float InEdgeThickness = InPolygonInfo.EdgeThickness;// FMath::Max(1.0f, Inverse(LayoutTransform).GetScale() * InPolygonInfo.EdgeThickness);

			static const float TwoRootTwo = 2 * FMath::Sqrt(2);
			// Compute the actual size of the line we need based on thickness.
			// Each line segment will be a bit thicker than the line to account
			// for the size of the filter.
			const float LineEdgeThickness = (TwoRootTwo + InEdgeThickness);

			// Width of the filter size to use for anti-aliasing.
			// Increasing this value will increase the fuzziness of line edges.
			const float FilterScale = 1.0f;
			const float HalfEdgeThickness = (LineEdgeThickness * 0.5f + FilterScale);// *TransformInfo.Scale;

			FLinearColor InColor = InWidgetStyle.GetColorAndOpacityTint() * InPolygonInfo.PolygonTintColor;
			FColor TintColor = InColor.ToFColor(true);
			FVector2D StartPosition = TransformInfo.InputToLocal(Points[0].Location);
			float CustomVertsVCoordScale = 1.0f / TransformInfo.Scale;
			FVector2D WidgetSize = OwningPolygonWidget ? OwningPolygonWidget->GetCachedGeometry().GetLocalSize() : FVector2D(100.0f, 100.0f);
			FUMGPolygonBuilder PolygonBuilder = FUMGPolygonBuilder(
				StartPosition,
				FilterScale,
				CustomVertsVCoordScale,
				AllottedGeometry.ToPaintGeometry().GetAccumulatedRenderTransform(),
				TransformInfo.InputToLocal(FVector2D(0.0f, 0.0f)),
				WidgetSize * TransformInfo.Scale);

			for (int32 i = 0; i < Points.Num() - 1; ++i)
			{
				FVector2D LocalStart = TransformInfo.InputToLocal(Points[i].Location);
				FVector2D StartDir = InPolygonInfo.PolygonType == EUMGPolygonType::LinearEdge ? FVector2D::ZeroVector : Points[i].Direction;
				StartDir = StartDir * TransformInfo.Scale;

				FVector2D LocalEnd = TransformInfo.InputToLocal(Points[i + 1].Location);
				FVector2D EndDir = InPolygonInfo.PolygonType == EUMGPolygonType::LinearEdge ? FVector2D::ZeroVector : Points[i + 1].Direction;
				EndDir = EndDir * TransformInfo.Scale;

				bool bAllValuesValid = (LocalStart.X != -FLT_MAX) && (LocalStart.Y != -FLT_MAX) && (LocalEnd.X != -FLT_MAX) && (LocalEnd.Y != -FLT_MAX);

				if (bAllValuesValid)
				{
					FVector2D P1 = LocalStart + StartDir / 3.0f;
					FVector2D P2 = LocalEnd - EndDir / 3.0f;
					PolygonBuilder.AppendBezierCurve(LocalStart, P1, P2, LocalEnd);
				}

			}

			// ClosedLoop
			{
				FVector2D LocalStart = TransformInfo.InputToLocal(Points.Last().Location);
				FVector2D StartDir = InPolygonInfo.PolygonType == EUMGPolygonType::LinearEdge ? FVector2D::ZeroVector : Points.Last().Direction;
				StartDir = StartDir * TransformInfo.Scale;

				FVector2D LocalEnd = TransformInfo.InputToLocal(Points[0].Location);
				FVector2D EndDir = InPolygonInfo.PolygonType == EUMGPolygonType::LinearEdge ? FVector2D::ZeroVector : Points[0].Direction;
				EndDir = EndDir * TransformInfo.Scale;

				bool bAllValuesValid = (LocalStart.X != -FLT_MAX) && (LocalStart.Y != -FLT_MAX) && (LocalEnd.X != -FLT_MAX) && (LocalEnd.Y != -FLT_MAX);

				if (bAllValuesValid)
				{
					FVector2D P1 = LocalStart + StartDir / 3.0f;
					FVector2D P2 = LocalEnd - EndDir / 3.0f;
					PolygonBuilder.AppendBezierCurve(LocalStart, P1, P2, LocalEnd);
				}
			}

			FUMGPolygonRenderBatch PolygonRenderBatch = FUMGPolygonRenderBatch(&PoygonVertsCache->PolygonSlateVerts, &PoygonVertsCache->PolygonIndexes);
			PolygonBuilder.BuildPolygonGeometry(PolygonRenderBatch, TintColor);

			if (InPolygonInfo.bCustomEdge)
			{
				FUMGPolygonRenderBatch EdgeRenderBatch = FUMGPolygonRenderBatch(&PoygonVertsCache->EdgeSlateVerts, &PoygonVertsCache->EdgeIndexes);
				PolygonBuilder.BuildEdgeGeometry(EdgeRenderBatch, InPolygonInfo.EdgeTintColor.ToFColor(true), HalfEdgeThickness, InPolygonInfo.EdgeThickness);
			}
		}

		// Get Ploygon brush
		FSlateResourceHandle PolygonHandle = FSlateApplication::Get().GetRenderer()->GetResourceHandle(InPolygonInfo.PolygonBrush);

		// Draw Ploygon
		FSlateDrawElement::MakeCustomVerts(OutDrawElements, LayerId, PolygonHandle, PoygonVertsCache->PolygonSlateVerts, PoygonVertsCache->PolygonIndexes, nullptr, 0, 0);

		if (InPolygonInfo.bCustomEdge)
		{
			// Get Edge brush
			FSlateResourceHandle EdgeHandle = FSlateApplication::Get().GetRenderer()->GetResourceHandle(InPolygonInfo.EdgeBrush);

			// Draw Edge
			FSlateDrawElement::MakeCustomVerts(OutDrawElements, LayerId, EdgeHandle, PoygonVertsCache->EdgeSlateVerts, PoygonVertsCache->EdgeIndexes, nullptr, 0, 0);
		}
	}
}

void SUMGPolygonEditPanel::PaintPolygonPoints(const FUMGPolygonInfo& InPolygonInfo, FSlateWindowElementList& OutDrawElements, int32 LayerId, int32 SelectedLayerId, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, ESlateDrawEffect DrawEffects, const FWidgetStyle& InWidgetStyle) const
{
	const FSlateBrush* KeyBrush = FEditorStyle::GetBrush("CurveEd.CurveKey");
	const FLinearColor KeyColor = FEditorStyle::GetColor("CurveEd.TangentColor");
	const FLinearColor KeySelectionColor = FEditorStyle::GetBrush("CurveEd.CurveKeySelected")->GetTint(InWidgetStyle); 

	const TArray<FUMGPolygonPoint>& Points = InPolygonInfo.GetPoints();

	// Iterate over each key
	for (int32 i = 0; i < Points.Num(); ++i)
	{

		// Work out where it is
		FVector2D KeyLocation = TransformInfo.InputToLocal(Points[i].Location);
		FVector2D KeyIconLocation = KeyLocation - (CONST_KeySize / 2);

		// Get brush
		bool IsSelected = IsPolygonPointSelected(i);
		
		int32 LayerToUse = IsSelected ? SelectedLayerId : LayerId;

		// Fade out keys that are not selected and whose curve is not selected as well.
		FLinearColor TintColor = IsSelected ? KeySelectionColor : KeyColor;

		FSlateDrawElement::MakeBox(
			OutDrawElements,
			LayerToUse,
			AllottedGeometry.ToPaintGeometry(KeyIconLocation, CONST_KeySize),
			KeyBrush,
			DrawEffects,
			TintColor
		);

		if ((IsSelected || !HideUnselectedTangents) && InPolygonInfo.PolygonType == EUMGPolygonType::CurveEdge)
		{
			PaintTangent(Points[i], OutDrawElements, LayerId, AllottedGeometry, MyCullingRect, DrawEffects, LayerToUse, InWidgetStyle, IsSelected);
		}
	}
}


void SUMGPolygonEditPanel::PaintTangent(const FUMGPolygonPoint& PolygonPoint, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, ESlateDrawEffect DrawEffects, int32 LayerToUse, const FWidgetStyle& InWidgetStyle, bool bTangentSelected) const
{
	FVector2D KeyIconLocation = TransformInfo.InputToLocal(PolygonPoint.Location);
	FVector2D LocalDir = PolygonPoint.Direction * TransformInfo.Scale;

	FVector2D ArriveTangentLocation, LeaveTangentLocation;
	GetTangentPoints(KeyIconLocation, LocalDir, ArriveTangentLocation, LeaveTangentLocation);

	FVector2D ArriveTangentIconLocation = ArriveTangentLocation - (CONST_TangentSize / 2);
	FVector2D LeaveTangentIconLocation = LeaveTangentLocation - (CONST_TangentSize / 2);

	const FSlateBrush* TangentBrush = FEditorStyle::GetBrush("CurveEd.Tangent");
	const FSlateBrush* TangentBrushSelected = FEditorStyle::GetBrush("CurveEd.TangentSelected");
	const FSlateBrush* ArrowImage = FEditorStyle::GetBrush(TEXT("Graph.Arrow"));
	const FLinearColor TangentColor = FEditorStyle::GetColor("CurveEd.TangentColor");
	const FLinearColor TangentColorSelected = FEditorStyle::GetColor("CurveEd.TangentColorSelected");

	bool LeaveTangentSelected = bTangentSelected;
	bool ArriveTangentSelected = bTangentSelected;

	//Add lines from tangent control point to 'key'
	TArray<FVector2D> LinePoints;
	LinePoints.Add(KeyIconLocation);
	LinePoints.Add(ArriveTangentLocation);
	FSlateDrawElement::MakeLines(
		OutDrawElements,
		LayerId,
		AllottedGeometry.ToPaintGeometry(),
		LinePoints,
		DrawEffects,
		ArriveTangentSelected ? TangentColorSelected : TangentColor
	);

	LinePoints.Empty();
	LinePoints.Add(KeyIconLocation);
	LinePoints.Add(LeaveTangentLocation);
	FSlateDrawElement::MakeLines(
		OutDrawElements,
		LayerId,
		AllottedGeometry.ToPaintGeometry(),
		LinePoints,
		DrawEffects,
		LeaveTangentSelected ? TangentColorSelected : TangentColor
	);

	//Arrive tangent control
	FSlateDrawElement::MakeBox(
		OutDrawElements,
		LayerToUse,
		AllottedGeometry.ToPaintGeometry(ArriveTangentIconLocation, CONST_TangentSize),
		ArriveTangentSelected ? TangentBrushSelected : TangentBrush,
		DrawEffects,
		ArriveTangentSelected ? TangentBrushSelected->GetTint(InWidgetStyle) : TangentBrush->GetTint(InWidgetStyle) * InWidgetStyle.GetColorAndOpacityTint()
	);


	//Leave tangent control arrow
	const FVector2D DirectionUnnormalized = LeaveTangentLocation - ArriveTangentLocation;
	const float AngleInRadians = DirectionUnnormalized.IsNearlyZero() ? 0.0f : FMath::Atan2(DirectionUnnormalized.Y, DirectionUnnormalized.X);
	const float ZoomFactor = 1.3 * CONST_TangentSize.X / ArrowImage->ImageSize.X;
	const FVector2D ArrowRadius = ArrowImage->ImageSize * ZoomFactor * 0.5f;
	const FVector2D ArrowDrawLocation = LeaveTangentLocation - ArrowRadius;

	FSlateDrawElement::MakeRotatedBox(
		OutDrawElements,
		LayerToUse,
		AllottedGeometry.ToPaintGeometry(ArrowDrawLocation, ArrowImage->ImageSize * ZoomFactor),
		ArrowImage,
		DrawEffects,
		AngleInRadians,
		TOptional<FVector2D>(),
		FSlateDrawElement::RelativeToElement,
		LeaveTangentSelected ? TangentBrushSelected->GetTint(InWidgetStyle) : TangentBrush->GetTint(InWidgetStyle) * InWidgetStyle.GetColorAndOpacityTint()
	);

	/*
	if (bTangentSelected)
	{
		LocalDir.Normalize();

		const FLinearColor TangentColorStrength = FLinearColor(0.0f, 0.0f, 0.5f, 1.0f);

		// Strength Icon
		FVector2D  TangentStrengthLocation = ArriveTangentLocation - CONST_TangentSelectIconOffset * LocalDir;
		FVector2D TangentStrengthIconLocation  = TangentStrengthLocation - (CONST_TangentSize / 2);
		FSlateDrawElement::MakeBox(
			OutDrawElements,
			LayerToUse,
			AllottedGeometry.ToPaintGeometry(TangentStrengthIconLocation, CONST_TangentSize),
			ArriveTangentSelected ? TangentBrushSelected : TangentBrush,
			DrawEffects,
			TangentColorStrength * InWidgetStyle.GetColorAndOpacityTint()
		);

		LinePoints.Empty();
		LinePoints.Add(ArriveTangentLocation);
		LinePoints.Add(TangentStrengthLocation);
		FSlateDrawElement::MakeLines(
			OutDrawElements,
			LayerId,
			AllottedGeometry.ToPaintGeometry(),
			LinePoints,
			DrawEffects,
			TangentColorStrength
		);

		// Angle Icon Up

		const FLinearColor TangentColorAngle = FLinearColor(0.5f, 0.0f, 0.0f, 1.0f);
		FVector2D UpDir = FVector2D(LocalDir.Y, -LocalDir.X);
		FVector2D  TangentAngleLocation = ArriveTangentLocation + CONST_TangentSelectIconOffset * UpDir;
		FVector2D  TangentAngleIconLocation = TangentAngleLocation - (CONST_TangentSize / 2);

		FSlateDrawElement::MakeBox(
			OutDrawElements,
			LayerToUse,
			AllottedGeometry.ToPaintGeometry(TangentAngleIconLocation, CONST_TangentSize),
			ArriveTangentSelected ? TangentBrushSelected : TangentBrush,
			DrawEffects,
			TangentColorAngle * InWidgetStyle.GetColorAndOpacityTint()
		);

		LinePoints.Empty();
		LinePoints.Add(ArriveTangentLocation);
		LinePoints.Add(TangentAngleLocation);
		FSlateDrawElement::MakeLines(
			OutDrawElements,
			LayerId,
			AllottedGeometry.ToPaintGeometry(),
			LinePoints,
			DrawEffects,
			TangentColorAngle
		);

		// Angle Icon Down
		TangentAngleLocation = ArriveTangentLocation - CONST_TangentSelectIconOffset * UpDir;
		TangentAngleIconLocation = TangentAngleLocation - (CONST_TangentSize / 2);

		FSlateDrawElement::MakeBox(
			OutDrawElements,
			LayerToUse,
			AllottedGeometry.ToPaintGeometry(TangentAngleIconLocation, CONST_TangentSize),
			ArriveTangentSelected ? TangentBrushSelected : TangentBrush,
			DrawEffects,
			TangentColorAngle * InWidgetStyle.GetColorAndOpacityTint()
		);

		LinePoints.Empty();
		LinePoints.Add(ArriveTangentLocation);
		LinePoints.Add(TangentAngleLocation);
		FSlateDrawElement::MakeLines(
			OutDrawElements,
			LayerId,
			AllottedGeometry.ToPaintGeometry(),
			LinePoints,
			DrawEffects,
			TangentColorAngle
		);
	}*/
}

void SUMGPolygonEditPanel::PaintBackgroundMaterial(const FUMGPolygonInfo& InPolygonInfo, const FGeometry& AllottedGeometry, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FSlateRect& MyCullingRect, ESlateDrawEffect DrawEffects) const
{
	if (OwningPolygonWidget)
	{
		const FLinearColor BackgroundTintColor(1.0f, 1.0f, 1.0f, 0.3f);

		FVector2D WidgetSize = OwningPolygonWidget->GetCachedGeometry().GetLocalSize();
		// UE_LOG(LogTemp, Warning, TEXT("WidgetSize %s"), *(WidgetSize.ToString()));
		FVector2D LeftTop = TransformInfo.InputToLocal(FVector2D(0.0f, 0.0f));
		FVector2D RightBottom = TransformInfo.InputToLocal(WidgetSize);

		FVector2D Center = LeftTop;
		FVector2D Size = RightBottom - LeftTop;
		FSlateDrawElement::MakeBox(
			OutDrawElements,
			LayerId,
			AllottedGeometry.ToPaintGeometry(Center, Size),
			&InPolygonInfo.PolygonBrush,
			DrawEffects,
			BackgroundTintColor);

		FString FrameString = TEXT("Widget Covered Region");
		const FSlateFontInfo SmallLayoutFont = FCoreStyle::GetDefaultFontStyle("Regular", 8);
		const FLinearColor FontTintColor(1.0f, 1.0f, 1.0f, 0.5f);

		FSlateDrawElement::MakeText(
			OutDrawElements,
			LayerId,
			AllottedGeometry.ToPaintGeometry(Center - FVector2D(0.0f, 13.0f), AllottedGeometry.Size),
			FrameString,
			SmallLayoutFont,
			DrawEffects,
			FontTintColor
		);
	}
}

float SUMGPolygonEditPanel::CalculateGridPixelSpacing() const 
{
	const float MinGridPixelSpacing = 10.0f;
	const float MaxGridPixelSpacing = 20.0f;

	const float ScaleStep = 0.20f;
	float Alpha = FMath::Frac(TransformInfo.Scale / ScaleStep);
	return FMath::Lerp(MinGridPixelSpacing, MaxGridPixelSpacing, Alpha);
}

void SUMGPolygonEditPanel::PaintGridLines(const FGeometry& AllottedGeometry, FSlateWindowElementList& OutDrawElements,
	int32 LayerId, const FSlateRect& MyCullingRect, ESlateDrawEffect DrawEffects) const
{
	float GridPixelSpacing = CalculateGridPixelSpacing();

	const FLinearColor GridColor(0.35f, 0.35f, 0.35f, 0.2f);
	const FLinearColor BoarderColor(0.35f, 0.35f, 0.35f, 1.0f);

	//Vertical grid
	{
		TArray<FVector2D> LinePoints;

		//draw vertical grid lines
		float StartOffset = FMath::Fmod(-TransformInfo.Offset.X, GridPixelSpacing);
		for (float X = StartOffset; X < AllottedGeometry.GetLocalSize().X; X += GridPixelSpacing)
		{
			if (SMALL_NUMBER < FMath::Abs(X)) //don't show at 0 to avoid overlapping with center axis 
			{
				LinePoints.Add(FVector2D(X, 0.0));
				LinePoints.Add(FVector2D(X, AllottedGeometry.GetLocalSize().Y));
				FSlateDrawElement::MakeLines(
					OutDrawElements,
					LayerId,
					AllottedGeometry.ToPaintGeometry(),
					LinePoints,
					DrawEffects,
					GridColor,
					false);

				LinePoints.Empty();
			}
		}
	}

	//Horizontal grid
	{
		TArray<FVector2D> LinePoints;

		float StartOffset = FMath::Fmod(-TransformInfo.Offset.Y, GridPixelSpacing);;

		for (float Y = StartOffset; Y < AllottedGeometry.GetLocalSize().Y; Y += GridPixelSpacing)
		{
			if (SMALL_NUMBER < FMath::Abs(Y)) //don't show at 0 to avoid overlapping with center axis 
			{
				LinePoints.Add(FVector2D(0.0f, Y));
				LinePoints.Add(FVector2D(AllottedGeometry.GetLocalSize().X, Y));
				FSlateDrawElement::MakeLines(
					OutDrawElements,
					LayerId,
					AllottedGeometry.ToPaintGeometry(),
					LinePoints,
					DrawEffects,
					GridColor,
					false);

				LinePoints.Empty();
			}
		}
	}

	// Boarder
	{
		TArray<FVector2D> LinePoints;
		LinePoints.Add(FVector2D(1.0f, 1.0f));
		LinePoints.Add(FVector2D(AllottedGeometry.GetLocalSize().X - 1.0f, 1.0f));
		LinePoints.Add(FVector2D(AllottedGeometry.GetLocalSize().X - 1.0f, AllottedGeometry.GetLocalSize().Y - 1.0f));
		LinePoints.Add(FVector2D(1.0f, AllottedGeometry.GetLocalSize().Y - 1.0f));
		LinePoints.Add(FVector2D(1.0f, 1.0f));

		FSlateDrawElement::MakeLines(
			OutDrawElements,
			LayerId,
			AllottedGeometry.ToPaintGeometry(),
			LinePoints,
			DrawEffects,
			BoarderColor,
			false);
	}
}

bool SUMGPolygonEditPanel::IsPolygonPointSelected(int PointIndex) const
{
	return PointIndex == SelectedPointIndex;
}

void SUMGPolygonEditPanel::GetTangentPoints(const FVector2D& Location, const FVector2D& Direction, FVector2D& Arrive, FVector2D& Leave) const
{
	FVector2D ArriveDirection = Direction;
	ArriveDirection.Normalize();

	FVector2D LeaveDirection = Direction;
	LeaveDirection.Normalize();

	float Alpha = FVector2D::Distance(Direction, FVector2D::ZeroVector) / CONST_TangentMaxStrength;
	Alpha = FMath::Clamp(Alpha, 0.01f, 1.0f);

	float KeyTangentOffset = FMath::Lerp(CONST_KeyTangentOffsetMin, CONST_KeyTangentOffsetMax, Alpha);
	Arrive = -ArriveDirection * KeyTangentOffset + Location;

	Leave = LeaveDirection * KeyTangentOffset + Location;
}

/*===========================================================================*\
|                                Click                                        |
\*===========================================================================*/

void SUMGPolygonEditPanel::ProcessClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	const bool bLeftMouseButton = InMouseEvent.GetEffectingButton() == EKeys::LeftMouseButton;
	const bool bRightMouseButton = InMouseEvent.GetEffectingButton() == EKeys::RightMouseButton;

	int HitPointIndex = HitTestPolygonPoints(InMyGeometry, InMouseEvent.GetScreenSpacePosition());
	FSelectedPolygonTangent HitTangent = HitTestCubicTangents(InMyGeometry, InMouseEvent.GetScreenSpacePosition());

	if (bLeftMouseButton)
	{
		// If the user left clicked a key, update selection based on modifier key state.
		if (HitPointIndex != -1)
		{
			SelectedPointIndex = HitPointIndex;
		}
		else if (HitTangent.IsValid())
		{
			SelectedTangent = HitTangent;
			SelectedPointIndex = HitTangent.PointIndex;
		}
	}
	else if (bRightMouseButton)
	{
		bool bShowAddNewPolygonPoint = true;

		// If the user right clicked, handle opening context menus.
		if (HitPointIndex != -1)
		{
			SelectedPointIndex = HitPointIndex;
			bShowAddNewPolygonPoint = false;
		}
		/*else if (HitTangent.IsValid())
		{
			SelectedTangent = HitTangent;
			SelectedPointIndex = HitTangent.PointIndex;
		}*/

		CreateContextMenu(InMyGeometry, InMouseEvent, bShowAddNewPolygonPoint);
	}
}

void SUMGPolygonEditPanel::CreateContextMenu(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent, bool bShowAddNewPolygonPoint)
{
	const FVector2D& ScreenPosition = InMouseEvent.GetScreenSpacePosition();

	const bool CloseAfterSelection = true;
	FMenuBuilder MenuBuilder(CloseAfterSelection, NULL);

	MenuBuilder.BeginSection("EditUMGPolygonActions", LOCTEXT("Actions", "Actions"));
	{
		if (bShowAddNewPolygonPoint)
		{
			FText MenuItemLabel = LOCTEXT("AddPointToPolygonLabel", "Add edge point to polygon");
			FText MenuItemToolTip = LOCTEXT("AddPointToPolygonToolTip", "Add a new polygon edge point at the hovered place to the polygon.");

			FVector2D Position = InMouseEvent.GetScreenSpacePosition();

			FUIAction Action = FUIAction(FExecuteAction::CreateSP(this, &SUMGPolygonEditPanel::AddNewPolygonPoint, InMyGeometry, Position));
			MenuBuilder.AddMenuEntry(MenuItemLabel, MenuItemToolTip, FSlateIcon(), Action);
		}
		
		if (SelectedPointIndex != -1)
		{
			FText MenuItemLabel = LOCTEXT("DeleteSelectedPointFromPolygonLabel", "Delete selected edge point from polygon");
			FText MenuItemToolTip = LOCTEXT("DeleteSelectedPointFromPolygonToolTip", "Delete selected edge point from the polygon.");

			FVector2D Position = InMouseEvent.GetScreenSpacePosition();

			FUIAction Action = FUIAction(FExecuteAction::CreateSP(this, &SUMGPolygonEditPanel::DeleteSelectedPolygonPoint));
			MenuBuilder.AddMenuEntry(MenuItemLabel, MenuItemToolTip, FSlateIcon(), Action);
		}
	}
	MenuBuilder.EndSection();

	FWidgetPath WidgetPath = InMouseEvent.GetEventPath() != nullptr ? *InMouseEvent.GetEventPath() : FWidgetPath();
	FSlateApplication::Get().PushMenu(SharedThis(this), WidgetPath, MenuBuilder.MakeWidget(), FSlateApplication::Get().GetCursorPos(), FPopupTransitionEffect(FPopupTransitionEffect::ContextMenu));
}

void SUMGPolygonEditPanel::AddNewPolygonPoint(FGeometry InMyGeometry, FVector2D ScreenPosition)
{
	const FScopedTransaction Transaction(LOCTEXT("EditUMGPolygon_AddNewPolygonPoint", "Add New Polygon Point"));

	const FVector2D MousePosition = InMyGeometry.AbsoluteToLocal(ScreenPosition);

	FUMGPolygonPoint NewPoint;
	NewPoint.Location = TransformInfo.LocalToInput(MousePosition);
	NewPoint.Direction = FVector2D(1.0f, 0.0f);

	FUMGPolygonInfo NewPolygonInfo = PolygonInfo.Get();
	NewPolygonInfo.AddPoint(NewPoint);
	OnPolygonInfoValueChanged.ExecuteIfBound(NewPolygonInfo);

	SelectedPointIndex = NewPolygonInfo.Points.Num() - 1;
}

void SUMGPolygonEditPanel::DeleteSelectedPolygonPoint()
{
	const FScopedTransaction Transaction(LOCTEXT("EditUMGPolygon_RemovePolygonPoint", "Delete Polygon Point"));
	
	if (SelectedPointIndex != -1 && PolygonInfo.Get().Points.Num() > SelectedPointIndex)
	{
		FUMGPolygonInfo NewPolygonInfo = PolygonInfo.Get();
		NewPolygonInfo.DeletePoint(SelectedPointIndex);
		OnPolygonInfoValueChanged.ExecuteIfBound(NewPolygonInfo);

		SelectedPointIndex = -1;
	}
}

/*===========================================================================*\
|                                Zoom to fit                                  |
\*===========================================================================*/

void SUMGPolygonEditPanel::DeferredZoomToFit()
{
	bDeferredZoomToFit = true;
}

EActiveTimerReturnType SUMGPolygonEditPanel::HandleZoomToFit(double InCurrentTime, float InDeltaTime)
{
	bool bDoneZooming = ZoomToFit(true, true);

	if (bDoneZooming)
	{
		return EActiveTimerReturnType::Stop;
	}

	return EActiveTimerReturnType::Continue;
}

bool SUMGPolygonEditPanel::ZoomToFit(bool bFitHorizontal, bool bFitVertical)
{
	float InMinX = FLT_MAX;
	float InMaxX = -FLT_MAX;
	float InMinY = FLT_MAX;
	float InMaxY = -FLT_MAX;

	const TArray<FUMGPolygonPoint>& Points = PolygonInfo.Get().GetPoints();

	// Iterate over each key
	for (int32 i = 0; i < Points.Num(); ++i)
	{
		InMinX = FMath::Min(Points[i].Location.X, InMinX);
		InMaxX = FMath::Max(Points[i].Location.X, InMaxX);
		InMinY = FMath::Min(Points[i].Location.Y, InMinY);
		InMaxY = FMath::Max(Points[i].Location.Y, InMaxY);
	}

	//if (bFitHorizontal)
	{
		if (Points.Num() > 0)
		{
			// Clamp the minimum size
			float SizeX = InMaxX - InMinX;
			if (SizeX < CONST_MinViewRange)
			{
				InMinX -= (0.5f * CONST_MinViewRange);
				InMaxX += (0.5f * CONST_MinViewRange);
				SizeX = InMaxX - InMinX;
			}

			// add margin
			InMinX -= CONST_FitMargin * SizeX;
			InMaxX += CONST_FitMargin * SizeX;
		}
		else
		{
			InMinX = -CONST_FitMargin * 2.0f;
			InMaxX = (CONST_DefaultZoomRange + CONST_FitMargin) * 2.0;
		}
	}
	
	//if (bFitVertical)
	{
		if (Points.Num() > 0)
		{
			// Clamp the minimum size
			float SizeY = InMaxY - InMinY;
			if (SizeY < CONST_MinViewRange)
			{
				InMinY -= (0.5f * CONST_MinViewRange);
				InMaxY += (0.5f * CONST_MinViewRange);
				SizeY = InMaxY - InMinY;
			}

			// add margin
			InMinY -= CONST_FitMargin * SizeY;
			InMaxY += CONST_FitMargin * SizeY;
		}  
		else
		{
			InMinY = -CONST_FitMargin * 2.0f;
			InMaxY = (CONST_DefaultZoomRange + CONST_FitMargin) * 2.0;
		}
	}

	FVector2D LocalSize = GetCachedGeometry().GetLocalSize();
	if (LocalSize == FVector2D::ZeroVector)
	{
		return false;
	}

	if (bFitHorizontal && bFitVertical)
	{
		float ScaleX = LocalSize.X / (InMaxX - InMinX);
		float ScaleY = LocalSize.Y / (InMaxY - InMinY);
		float Scale = FMath::Min(ScaleX, ScaleY);

		FVector2D LocalCenter = LocalSize / 2;
		FVector2D InputCenter = FVector2D(InMaxX + InMinX, InMaxY + InMinY) / 2;
		FVector2D Offset = InputCenter - LocalCenter / Scale;

		TransformInfo.Scale = Scale;
		TransformInfo.Offset = Offset;
	}
	else if (bFitHorizontal)
	{
		float Scale = LocalSize.X / (InMaxX - InMinX);
		
		FVector2D LocalCenter = LocalSize / 2;
		FVector2D InputCenter = FVector2D(InMaxX + InMinX, InMaxY + InMinY) / 2;
		FVector2D Offset = InputCenter - LocalCenter / Scale;

		TransformInfo.Scale = Scale;
		TransformInfo.Offset = Offset;
	}
	else if (bFitVertical)
	{
		float Scale = LocalSize.Y / (InMaxY - InMinY);

		FVector2D LocalCenter = LocalSize / 2;
		FVector2D InputCenter = FVector2D(InMaxX + InMinX, InMaxY + InMinY) / 2;
		FVector2D Offset = InputCenter - LocalCenter / Scale;

		TransformInfo.Scale = Scale;
		TransformInfo.Offset = Offset;
	}

	return true;
}

FReply SUMGPolygonEditPanel::ZoomToFitClicked()
{
	ZoomToFit(true, true);
	return FReply::Handled();
}

/*===========================================================================*\
|                                Adjust panel height                          |
\*===========================================================================*/

TSharedRef<SWidget> SUMGPolygonEditPanel::GetPanelHeightMenu()
{
	TSharedRef<SWidget> FillWidget = SNew(SBorder)
		.BorderImage(FEditorStyle::GetBrush(TEXT("Menu.Background")))
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(FMargin(8.0f, 2.0f, 60.0f, 2.0f))
			.HAlign(HAlign_Left)
			[
				SNew(STextBlock)
				.Text(LOCTEXT("UMGPolygonEditPanelHeight", "Panel Height"))
				.Font(FEditorStyle::GetFontStyle(TEXT("MenuItem.Font")))
			]
			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(FMargin(8.0f, 4.0f))
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.FillWidth(1)
				.Padding(FMargin(0.0f, 2.0f))
				[
					SNew(SSlider)
					.Value(this, &SUMGPolygonEditPanel::GetPanelHeightSliderPosition)
					.OnValueChanged(this, &SUMGPolygonEditPanel::OnSetPanelHeight)
				]
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.Padding(8.0f, 2.0f, 0.0f, 2.0f)
				[
					SNew(STextBlock)
					.Text(this, &SUMGPolygonEditPanel::GetPanelHeightLabel)
					.Font(FEditorStyle::GetFontStyle(TEXT("MenuItem.Font")))
				]
			]

		];

	return FillWidget;
}

FText SUMGPolygonEditPanel::GetPanelHeightLabel() const
{
	FNumberFormattingOptions Options;
	Options.SetMaximumFractionalDigits(0);
	return FText::AsNumber(UUMGPolygonEditorSettings::GetPanelHeight(), &Options);
}


float SUMGPolygonEditPanel::GetPanelHeightSliderPosition() const
{
	float Value = (UUMGPolygonEditorSettings::GetPanelHeight() - CONST_PanelHeightMin) / (CONST_PanelHeightMax - CONST_PanelHeightMin);
	return Value;
}


void SUMGPolygonEditPanel::OnSetPanelHeight(float NewValue)
{
	float DesiredHeight = FMath::Lerp(CONST_PanelHeightMin, CONST_PanelHeightMax, NewValue);
	UUMGPolygonEditorSettings::SetPanelHeight(DesiredHeight);
}

/*===========================================================================*\
|                                Adjust polygon edge thickness                      |
\*===========================================================================*/

TSharedRef<SWidget>  SUMGPolygonEditPanel::GetEdgeThicknessFillMenu()
{
	TSharedRef<SWidget> FillWidget = SNew(SBorder)
		.BorderImage(FEditorStyle::GetBrush(TEXT("Menu.Background")))
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(FMargin(8.0f, 2.0f, 60.0f, 2.0f))
				.HAlign(HAlign_Left)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("PolygonEditPolygonEdgeThickness", "Polygon EdgeThickness"))
					.Font(FEditorStyle::GetFontStyle(TEXT("MenuItem.Font")))
				]
			+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(FMargin(8.0f, 4.0f))
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot()
						.FillWidth(1)
						.Padding(FMargin(0.0f, 2.0f))
						[
							SNew(SSlider)
							.Value(this, &SUMGPolygonEditPanel::GetPolygonEdgeThicknessSliderPosition)
							.OnValueChanged(this, &SUMGPolygonEditPanel::OnSetPolygonEdgeThickness)
						]
					+ SHorizontalBox::Slot()
						.AutoWidth()
						.Padding(8.0f, 2.0f, 0.0f, 2.0f)
						[
							SNew(STextBlock)
							.Text(this, &SUMGPolygonEditPanel::GetPolygonEdgeThicknessLabel)
							.Font(FEditorStyle::GetFontStyle(TEXT("MenuItem.Font")))
						]
				] 
	
		];

	return FillWidget;
}

FText SUMGPolygonEditPanel::GetPolygonEdgeThicknessLabel() const
{
	FNumberFormattingOptions Options;
	Options.SetMaximumFractionalDigits(0);
	return FText::AsNumber(PolygonInfo.Get().EdgeThickness, &Options);
}


float SUMGPolygonEditPanel::GetPolygonEdgeThicknessSliderPosition() const
{
	float Value = (PolygonInfo.Get().EdgeThickness - CONST_PolygonEdgeThicknessMin) / (CONST_PolygonEdgeThicknessMax - CONST_PolygonEdgeThicknessMin);
	return Value;
}


void SUMGPolygonEditPanel::OnSetPolygonEdgeThickness(float NewValue)
{
	float NewEdgeThickness = FMath::Lerp(CONST_PolygonEdgeThicknessMin, CONST_PolygonEdgeThicknessMax, NewValue);

	FUMGPolygonInfo NewPolygonInfo = PolygonInfo.Get();
	NewPolygonInfo.EdgeThickness = NewEdgeThickness;
	OnPolygonInfoValueChanged.ExecuteIfBound(NewPolygonInfo);
}


/*===========================================================================*\
|                                Help text                                    |
\*===========================================================================*/

const FSlateBrush* SUMGPolygonEditPanel::GetHelpImage() const
{
	/*
	if (HelpIconImage->IsHovered())
	{
		return Hovered;
	}
	*/
	return Hovered;
}

FText SUMGPolygonEditPanel::GetHelpText() const
{
	FText HelpText = LOCTEXT("PolygonEditHelpText", "\
How to edit a polygon?\n\n\
Left mouse click:\n   Pick a polygon edge point or tangent.\n\n\
Right mouse click:\n   Add a polygon edge point at mouse location or delete selected polygon edge point.\n\n\
Mouse wheel:\n   Zoom the editor view. Before zooming you need to click on the edit panel to focus on it.\n\n\
Left mouse drag:\n   Adjust polygon edge point location, or adjust polygon edge tangent direction and strength.\n\n\
Right mouse drag:\n   Pan the editor view.");

	return HelpText;
}

#undef LOCTEXT_NAMESPACE