// Copyright Qibo Pang 2023. All Rights Reserved.

#pragma once

#include "Containers/Array.h"
#include "CoreMinimal.h"
#include "CoreTypes.h"
#include "EntitySystem/IMovieSceneEntityProvider.h"
#include "Internationalization/Text.h"
#include "Sections/MovieSceneParameterSection.h"
#include "MovieSceneNameableTrack.h"
#include "UObject/NameTypes.h"
#include "UObject/ObjectMacros.h"
#include "UObject/UObjectGlobals.h"
#include "Compilation/IMovieSceneTrackTemplateProducer.h"

#include "MovieSceneWidgetSubSequenceTrack.generated.h"

class UMovieSceneEntitySystemLinker;
class UMovieSceneSection;
class UObject;
class UUserWidget;
struct FFrameNumber;
struct FMovieSceneEntityComponentFieldBuilder;
struct FMovieSceneEvaluationFieldEntityMetaData;
template <typename ElementType> class TRange;

/**
 * A material track which is specialized for materials which are owned by widget brushes.
 */
UCLASS(MinimalAPI)
class UMovieSceneWidgetSubSequenceTrack
	: public UMovieSceneNameableTrack
	, public IMovieSceneEntityProvider
	, public IMovieSceneTrackTemplateProducer
	, public IMovieSceneParameterSectionExtender
{
	GENERATED_UCLASS_BODY()

public:

	/** Adds a new animation to this track */
	virtual UMovieSceneSection* AddNewAnimation(FFrameNumber KeyTime, UUserWidget* UserWidget);

	/** Gets the animation sections at a certain time */
	TArray<UMovieSceneSection*> GetAnimSectionsAtTime(FFrameNumber Time);

public:

	// UMovieSceneTrack interface
	virtual FName GetTrackName() const override;

	// UMovieSceneTrack interface
	virtual void RemoveAllAnimationData() override;
	virtual bool HasSection(const UMovieSceneSection& Section) const override;
	virtual void AddSection(UMovieSceneSection& Section) override;
	virtual void RemoveSection(UMovieSceneSection& Section) override;
	virtual void RemoveSectionAt(int32 SectionIndex) override;
	virtual bool IsEmpty() const override;
	virtual const TArray<UMovieSceneSection*>& GetAllSections() const override;
	virtual bool SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const override;
	virtual UMovieSceneSection* CreateNewSection() override;

	/*~ IMovieSceneEntityProvider */
	virtual void ImportEntityImpl(UMovieSceneEntitySystemLinker* EntityLinker, const FEntityImportParams& Params, FImportedEntity* OutImportedEntity) override;
	virtual bool PopulateEvaluationFieldImpl(const TRange<FFrameNumber>& EffectiveRange, const FMovieSceneEvaluationFieldEntityMetaData& InMetaData, FMovieSceneEntityComponentFieldBuilder* OutFieldBuilder) override;

	/*~ IMovieSceneParameterSectionExtender */
	virtual FMovieSceneEvalTemplatePtr CreateTemplateForSection(const UMovieSceneSection& InSection) const override;
	virtual void ExtendEntityImpl(UMovieSceneEntitySystemLinker* EntityLinker, const UE::MovieScene::FEntityImportParams& Params, UE::MovieScene::FImportedEntity* OutImportedEntity) override;

#if WITH_EDITORONLY_DATA
	virtual FText GetDefaultDisplayName() const override;
#endif

public:

	const TArray<FName>& GetBrushPropertyNamePath() const { return BrushPropertyNamePath; }

	UMGSUBSEQUENCE_API void SetBrushPropertyNamePath( TArray<FName> InBrushPropertyNamePath );

private:

	/** The name of the brush property which will be animated by this track. */
	UPROPERTY()
	TArray<FName> BrushPropertyNamePath;

	/** The name of this track, generated from the property name path. */
	UPROPERTY()
	FName TrackName;

	/** List of all animation sections */
	UPROPERTY()
		TArray<UMovieSceneSection*> AnimationSections;
};
