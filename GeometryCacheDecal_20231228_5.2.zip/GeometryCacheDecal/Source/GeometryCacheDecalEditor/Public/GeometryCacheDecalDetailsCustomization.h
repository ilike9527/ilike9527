// Copyright Qibo Pang 2023. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Layout/Visibility.h"
#include "Input/Reply.h"

#include "GeometryCacheDecalComponent.h"
#include "IDetailCustomization.h"

class IDetailLayoutBuilder;

//////////////////////////////////////////////////////////////////////////
// FGeometryCacheDecalDetailsCustomization

class FGeometryCacheDecalDetailsCustomization: public IDetailCustomization
{
public:
	// Makes a new instance of this detail layout class for a specific detail view requesting it
	static TSharedRef<IDetailCustomization> MakeInstance();

	// IDetailCustomization interface
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailLayout) override;
	// End of IDetailCustomization interface

private:

	EVisibility VisibilityForDecalType(EGeometryCacheDecalType DecalType) const;
	EVisibility VisibilityForDecalTypeUVRegion() const { return VisibilityForDecalType(EGeometryCacheDecalType::UVRegion); }
	EVisibility VisibilityForDecalTypeBoxRegion() const { return VisibilityForDecalType(EGeometryCacheDecalType::BoxRegion); }

private:

	TWeakObjectPtr<UGeometryCacheDecalComponent> GeometryCacheDecalComponentPtr;

	IDetailLayoutBuilder* MyDetailLayout;

	TSharedPtr<IPropertyHandle> DecalTypeHandle;
};
