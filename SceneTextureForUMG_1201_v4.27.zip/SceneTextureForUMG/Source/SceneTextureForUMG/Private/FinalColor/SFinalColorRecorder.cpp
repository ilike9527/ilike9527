// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SFinalColorRecorder.h"
#include "FinalColorDrawer.h"

SFinalColorRecorder::SFinalColorRecorder()
	: FinalColorDrawer(new FFinalColorDrawer())
{
	;
}

SFinalColorRecorder::~SFinalColorRecorder()
{
	// for thread safe, drawer must be deleted in render thread
	ENQUEUE_RENDER_COMMAND(SafeDeleteFinalColorDrawer)(
		[FinalColorDrawer = FinalColorDrawer](FRHICommandListImmediate& RHICmdList) mutable
		{
			FinalColorDrawer.Reset();
		}
	);
	//FinalColorDrawer = nullptr;
}

void SFinalColorRecorder::Construct(const FArguments& InArgs)
{
	SetCanTick(false);
}

int32 SFinalColorRecorder::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	
	int32 OutLayerId = LayerId;
	if (AllottedGeometry.GetLocalSize() > FVector2D::ZeroVector)
	{
		FSlateRect RenderBoundingRect = AllottedGeometry.GetRenderBoundingRect();
		FPaintGeometry PaintGeometry(RenderBoundingRect.GetTopLeft(), RenderBoundingRect.GetSize(), 1.0f);

		int32 RenderTargetWidth = FMath::RoundToInt(RenderBoundingRect.GetSize().X);
		int32 RenderTargetHeight = FMath::RoundToInt(RenderBoundingRect.GetSize().Y);

		if (RenderTargetWidth > 0 && RenderTargetHeight > 0)
		{
			OutDrawElements.PushClip(FSlateClippingZone(AllottedGeometry));

			if (FinalColorDrawer->InitializeSceneTextureForTextParams(OutDrawElements, LayerId, PaintGeometry))
			{
				FSlateDrawElement::MakeCustom(OutDrawElements, LayerId, FinalColorDrawer);
			}

			OutDrawElements.PopClip();
		}

		++OutLayerId;
	}

	return SCompoundWidget::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, OutLayerId, InWidgetStyle, bParentEnabled);
}