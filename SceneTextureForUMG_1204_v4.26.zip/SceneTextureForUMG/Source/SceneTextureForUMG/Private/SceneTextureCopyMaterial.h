// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "UObject/ConstructorHelpers.h"
#include "RHI.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Materials/MaterialInterface.h"
#include "Materials/Material.h"
#include "Runtime/RHI/Public/RHIStaticStates.h"
#include "Runtime/RenderCore/Public/ShaderParameterUtils.h"
#include "Runtime/RenderCore/Public/RenderResource.h"
#include "Runtime/Renderer/Public/MaterialShader.h"
#include "Runtime/RenderCore/Public/RenderGraphResources.h"
#include "Runtime/RenderCore/Public/RenderGraphResources.h"
#include "Runtime/Renderer/Private/ScreenPass.h"
#include "Runtime/Renderer/Private/SceneTextureParameters.h"

#include "RenderResource.h"
#include "ShaderParameters.h"
#include "Shader.h"
#include "GlobalShader.h"
#include "ShaderParameterUtils.h"
#include "Rendering/RenderingCommon.h"
#include "RHIStaticStates.h"
#include "ShaderPermutation.h"

// The vertex shader used by DrawScreenPass to draw a rectangle.
class FSceneTextureCopyScreenPassVS : public FGlobalShader
{
public:
	DECLARE_GLOBAL_SHADER(FSceneTextureCopyScreenPassVS);

	static bool ShouldCompilePermutation(const FGlobalShaderPermutationParameters&)
	{
		return true;
	}

	FSceneTextureCopyScreenPassVS() = default;
	FSceneTextureCopyScreenPassVS(const ShaderMetaType::CompiledShaderInitializerType& Initializer)
		: FGlobalShader(Initializer)
	{}
};

// A simple shader that copy texture
class FCopyTexturePS : public FGlobalShader
{
	DECLARE_GLOBAL_SHADER(FCopyTexturePS);
	SHADER_USE_PARAMETER_STRUCT(FCopyTexturePS, FGlobalShader);

	class FCopySceneColor : SHADER_PERMUTATION_BOOL("COPY_SCENECOLOR");
	class FCopySceneDepth : SHADER_PERMUTATION_BOOL("COPY_SCENEDEPTH");
	class FCopyCustomDepth : SHADER_PERMUTATION_BOOL("COPY_CUSTOMDEPTH");
	using FPermutationDomain = TShaderPermutationDomain<FCopySceneColor, FCopySceneDepth, FCopyCustomDepth>;

	BEGIN_SHADER_PARAMETER_STRUCT(FParameters, )
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, SceneColorCopyTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, SceneColorCopySampler)
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, SceneDepthCopyTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, SceneDepthCopySampler)
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, CustomDepthCopyTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, CustomDepthCopySampler)
		RENDER_TARGET_BINDING_SLOTS()
		END_SHADER_PARAMETER_STRUCT()

	static bool ShouldCompilePermutation(const FGlobalShaderPermutationParameters& Parameters)
	{
		return true;// IsFeatureLevelSupported(Parameters.Platform, ERHIFeatureLevel::SM5);
	}

	static void ModifyCompilationEnvironment(const FGlobalShaderPermutationParameters& Parameters, FShaderCompilerEnvironment& OutEnvironment)
	{
		FGlobalShader::ModifyCompilationEnvironment(Parameters, OutEnvironment);
	}
};


class FFinalColorCopyPS : public FGlobalShader
{
	DECLARE_SHADER_TYPE(FFinalColorCopyPS, Global);

public:
	/** Indicates that this shader should be cached */
	static bool ShouldCompilePermutation(const FGlobalShaderPermutationParameters& Parameters)
	{
		return true;
	}

	FFinalColorCopyPS()
	{
	}

	/** Constructor.  Binds all parameters used by the shader */
	FFinalColorCopyPS(const ShaderMetaType::CompiledShaderInitializerType& Initializer)
		: FGlobalShader(Initializer)
	{
		TextureParameter.Bind(Initializer.ParameterMap, TEXT("ElementTexture"));
		TextureParameterSampler.Bind(Initializer.ParameterMap, TEXT("ElementTextureSampler"));
		ShaderParams.Bind(Initializer.ParameterMap, TEXT("ShaderParams"));
		GammaAndAlphaValues.Bind(Initializer.ParameterMap, TEXT("GammaAndAlphaValues"));
	}

	static void ModifyCompilationEnvironment(const FGlobalShaderPermutationParameters& Parameters, FShaderCompilerEnvironment& OutEnvironment);

	/**
	 * Sets the element texture used by this shader
	 *
	 * @param Texture	Texture resource to use when this pixel shader is bound
	 * @param SamplerState	Sampler state to use when sampling this texture
	 */
	void SetTexture(FRHICommandList& RHICmdList, FRHITexture* InTexture, const FSamplerStateRHIRef SamplerState)
	{
		SetTextureParameter(RHICmdList, RHICmdList.GetBoundPixelShader(), TextureParameter, TextureParameterSampler, SamplerState, InTexture);
	}

	/**
	 * Sets shader params used by the shader
	 *
	 * @param InShaderParams Shader params to use
	 */
	void SetShaderParams(FRHICommandList& RHICmdList, const FVector4& InShaderParams)
	{
		SetShaderValue(RHICmdList, RHICmdList.GetBoundPixelShader(), ShaderParams, InShaderParams);
	}

	/**
	 * Sets the display gamma.
	 *
	 * @param DisplayGamma The display gamma to use
	 */
	void SetDisplayGammaAndInvertAlphaAndContrast(FRHICommandList& RHICmdList, float InDisplayGamma, float bInvertAlpha, float InContrast)
	{
		FVector4 Values(2.2f / InDisplayGamma, 1.0f / InDisplayGamma, bInvertAlpha, InContrast);

		SetShaderValue(RHICmdList, RHICmdList.GetBoundPixelShader(), GammaAndAlphaValues, Values);
	}

private:

	/** Texture parameter used by the shader */
	LAYOUT_FIELD(FShaderResourceParameter, TextureParameter);
	LAYOUT_FIELD(FShaderResourceParameter, TextureParameterSampler);
	LAYOUT_FIELD(FShaderParameter, ShaderParams);
	LAYOUT_FIELD(FShaderParameter, GammaAndAlphaValues);
};