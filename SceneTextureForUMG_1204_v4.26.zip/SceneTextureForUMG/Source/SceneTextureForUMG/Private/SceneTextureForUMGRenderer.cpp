// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SceneTextureForUMGRenderer.h"
#include "RenderUtils.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Materials/MaterialInterface.h"
#include "Blueprint/SlateBlueprintLibrary.h"
#include "FinalColor/FinalColorCopyProcessor.h"
#include "FinalColor/FinalColorRecorder.h"
#include "Async/Async.h"

FSceneTextureForUMGRenderer::FSceneTextureForUMGRenderer()
{
	;
}

FSceneTextureForUMGRenderer::~FSceneTextureForUMGRenderer()
{
	
}

void FSceneTextureForUMGRenderer::InitRenderResources()
{
	check(IsInGameThread());

	if (!RT_SceneColor)
	{
		//RT_SceneColor = NewObject<UTextureRenderTarget2D>();
		//RT_SceneColor->AddToRoot();
		//RT_SceneColor->ClearColor = FLinearColor::Transparent;
		//RT_SceneColor->TargetGamma = 0.0f;// 2.2f;
		//RT_SceneColor->SRGB = false;
		//RT_SceneColor->InitCustomFormat(RenderTargetSize.X, RenderTargetSize.Y, EPixelFormat::PF_B8G8R8A8, false);
		RT_SceneColor = LoadObject<UTextureRenderTarget2D>(nullptr, TEXT("/SceneTextureForUMG/SceneTextureForUMG/Textures/RT_SceneColor.RT_SceneColor"), nullptr, LOAD_None, nullptr);
		//RT_SceneColor->AddToRoot();
	}

	if (!RT_SceneDepth)
	{
		//RT_SceneDepth = NewObject<UTextureRenderTarget2D>();
		//RT_SceneDepth->AddToRoot();
		//RT_SceneDepth->ClearColor = FLinearColor::Transparent;
		//RT_SceneDepth->TargetGamma = 0.0f;// 2.2f;
		//RT_SceneDepth->SRGB = false;
		//RT_SceneDepth->InitCustomFormat(RenderTargetSize.X, RenderTargetSize.Y, EPixelFormat::PF_R32_FLOAT, false);
		RT_SceneDepth = LoadObject<UTextureRenderTarget2D>(nullptr, TEXT("/SceneTextureForUMG/SceneTextureForUMG/Textures/RT_SceneDepth.RT_SceneDepth"), nullptr, LOAD_None, nullptr);
		//RT_SceneDepth->AddToRoot();
	}

	if (!RT_CustomDepth)
	{
		//RT_CustomDepth = NewObject<UTextureRenderTarget2D>();
		//RT_CustomDepth->AddToRoot();
		//RT_CustomDepth->ClearColor = FLinearColor::Transparent;
		//RT_CustomDepth->TargetGamma = 0.0f;// 2.2f;
		//RT_CustomDepth->SRGB = false;
		//RT_CustomDepth->InitCustomFormat(RenderTargetSize.X, RenderTargetSize.Y, EPixelFormat::PF_R32_FLOAT, false);
		RT_CustomDepth = LoadObject<UTextureRenderTarget2D>(nullptr, TEXT("/SceneTextureForUMG/SceneTextureForUMG/Textures/RT_CustomDepth.RT_CustomDepth"), nullptr, LOAD_None, nullptr);
		//RT_CustomDepth->AddToRoot();
	}

	if (!RT_FinalColor)
	{
		//RT_FinalColor = NewObject<UTextureRenderTarget2D>();
		//RT_FinalColor->AddToRoot();
		//RT_FinalColor->ClearColor = FLinearColor::Transparent;
		//RT_FinalColor->TargetGamma = 0.0f;// 2.2f;
		//RT_FinalColor->SRGB = false;
		//RT_FinalColor->InitCustomFormat(RenderTargetSize.X, RenderTargetSize.Y, EPixelFormat::PF_B8G8R8A8, false);
		RT_FinalColor = LoadObject<UTextureRenderTarget2D>(nullptr, TEXT("/SceneTextureForUMG/SceneTextureForUMG/Textures/RT_FinalColor.RT_FinalColor"), nullptr, LOAD_None, nullptr);
		//RT_FinalColor->AddToRoot();
	}

	if (!FinalColorCopyProcessor)
	{
		FinalColorCopyProcessor = MakeShareable(new FFinalColorCopyProcessor);
		FinalColorCopyProcessor->SetRenderTarget(RT_FinalColor);
	}
}

void FSceneTextureForUMGRenderer::ReleaseRenderResources()
{
	check(IsInGameThread());
	
	auto ReleaseRenderTarget = [](UTextureRenderTarget2D* RenderTarget)
	{
		if (RenderTarget)
		{
			RenderTarget->ReleaseResource();
			//RenderTarget->RemoveFromRoot();
		}
	};

	ReleaseRenderTarget(RT_FinalColor);
	ReleaseRenderTarget(RT_SceneColor);
	ReleaseRenderTarget(RT_SceneDepth);
	ReleaseRenderTarget(RT_CustomDepth);

	RT_FinalColor = nullptr;
	RT_SceneColor = nullptr;
	RT_SceneDepth = nullptr;
	RT_CustomDepth = nullptr;

	FinalColorCopyProcessor = nullptr;
}

FSceneTextureForUMGRenderer& FSceneTextureForUMGRenderer::Get()
{
	static FSceneTextureForUMGRenderer Renderer;
	return Renderer;
}

static FVector2D GetViewportSize(UObject* WorldContextObject)
{
	UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);
	if (World && World->IsGameWorld())
	{
		if (UGameViewportClient* ViewportClient = World->GetGameViewport())
		{
			TSharedPtr<IGameLayerManager> GameLayerManager = ViewportClient->GetGameLayerManager();
			if (GameLayerManager.IsValid())
			{
				FVector2D ViewportSize;
				ViewportClient->GetViewportSize(ViewportSize);
				return ViewportSize;
			}
		}
	}
	return FVector2D::ZeroVector;
}

//void FSceneTextureForUMGRenderer::UpdateSceneTextureToMID()
//{
//	if (UIMaterialsUsedSceneTexture.Num() == 0 || !FinalColorRecorder)
//	{
//		return;
//	}
//
//	UTexture* SceneTexture = FinalColorCopyProcessor->GetSceneTexture();
//	FVector4 Viewport_Transform = FinalColorCopyProcessor->GetViewportTransform();
//
//	for (auto MID : UIMaterialsUsedSceneTexture)
//	{
//		if (MID)
//		{
//			if (bEnableTextureCopyPass)
//			{
//				MID->SetTextureParameterValue(TEXT("FinalColor_UMG"), RT_FinalColor);
//			}
//			
//			if (bEnableFinalColorCopy)
//			{
//				MID->SetTextureParameterValue(TEXT("SceneColor_UMG"), RT_SceneColor);
//				MID->SetTextureParameterValue(TEXT("SceneDepth_UMG"), RT_SceneDepth);
//				MID->SetTextureParameterValue(TEXT("CustomDepth_UMG"), RT_CustomDepth);
//			}
//			
//			MID->SetVectorParameterValue(TEXT("Viewport_Transform"), FLinearColor(Viewport_Transform));
//		}
//	}
//}

void FSceneTextureForUMGRenderer::UpdateRenderTargetSize(const FIntPoint& InRenderTargetSize)
{
	if (RenderTargetSize != InRenderTargetSize)
	{
		RenderTargetSize = InRenderTargetSize;

		if (RT_SceneColor)
		{
			RT_SceneColor->ResizeTarget(RenderTargetSize.X, RenderTargetSize.Y);
		}

		if (RT_SceneDepth)
		{
			RT_SceneDepth->ResizeTarget(RenderTargetSize.X, RenderTargetSize.Y);
		}

		if (RT_CustomDepth)
		{
			RT_CustomDepth->ResizeTarget(RenderTargetSize.X, RenderTargetSize.Y);
		}

		if (RT_FinalColor)
		{
			RT_FinalColor->ResizeTarget(RenderTargetSize.X, RenderTargetSize.Y);
		}
	}
}

void FSceneTextureForUMGRenderer::UpdateRenderTargetSize_GameThread(const FIntPoint& InRenderTargetSize)
{
	//if (IsInGameThread())
	//{
	//	UpdateRenderTargetSize(InRenderTargetSize);
	//}
	//else
	{
		AsyncTask(ENamedThreads::GameThread, [InRenderTargetSize]
			{
				FSceneTextureForUMGRenderer::Get().UpdateRenderTargetSize(InRenderTargetSize);
			});
	}
}

void FSceneTextureForUMGRenderer::InitFinalColorRecorder(UWorld* World)
{
	if (!FinalColorRecorder)
	{
		FinalColorRecorder = CreateWidget<UFinalColorRecorder>(World, UFinalColorRecorder::StaticClass());
		if (FinalColorRecorder)
		{
			FinalColorRecorder->DestructEvent.AddLambda([this]() {
				FinalColorRecorder = nullptr;
				});
			/*FinalColorRecorder->TickEvent.AddLambda([this]() {
				UpdateSceneTextureToMID();
				});*/

			// Keep this widget under all other widgets
			const int32 Recorder_Zorder = -999999;
			FinalColorRecorder->AddToViewport(Recorder_Zorder);
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("Failed to create Final Color Recorder Widget."));
		}
	}
}

void FSceneTextureForUMGRenderer::InitFinalColorRecorder_GameThread(UWorld* World)
{
	AsyncTask(ENamedThreads::GameThread, [World]
		{
			FSceneTextureForUMGRenderer::Get().InitFinalColorRecorder(World);
		});
}

void FSceneTextureForUMGRenderer::ReleaseFinalColorRecorder()
{
	if (FinalColorRecorder)
	{
		FinalColorRecorder->RemoveFromViewport();
		FinalColorRecorder = nullptr;
	}
}