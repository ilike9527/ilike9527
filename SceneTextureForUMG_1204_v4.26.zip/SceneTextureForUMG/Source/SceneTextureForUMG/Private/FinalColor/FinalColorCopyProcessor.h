// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "RHI.h"
#include "Layout/SlateRect.h"

class UTexture;
class UTextureRenderTarget2D;
class IRendererModule;

struct FCopyRectParams
{
	FTexture2DRHIRef SourceTexture;
	FSlateRect SourceRect;
	FSlateRect DestRect;
	FIntPoint SourceTextureSize;
	TFunction<void(FRHICommandListImmediate&, FGraphicsPipelineStateInitializer&)> RestoreStateFunc;
	TFunction<void()> RestoreStateFuncPostPipelineState;
};

class FFinalColorCopyProcessor
{
public:
	FFinalColorCopyProcessor();
	~FFinalColorCopyProcessor();

	void CopyRect(FRHICommandListImmediate& RHICmdList, IRendererModule& RendererModule, const FCopyRectParams& RectParams);

	void SetRenderTarget(UTextureRenderTarget2D* InRenderTarget) { RenderTarget = InRenderTarget; }
	
	UTexture* GetSceneTexture();

	FVector4 GetViewportTransform() { return Viewport_Transform; }

private:

	UTextureRenderTarget2D* RenderTarget;

	FIntPoint RenderTargetSize = FIntPoint(100, 100);

	FVector4 Viewport_Transform;
};