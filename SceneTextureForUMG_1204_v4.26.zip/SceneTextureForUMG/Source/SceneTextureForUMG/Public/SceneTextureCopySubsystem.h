// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "UObject/UObjectGlobals.h"
#include "UObject/Object.h"
#include "Subsystems/EngineSubsystem.h"
#include "Engine/EngineBaseTypes.h"
#include "SceneTextureCopySceneViewExtension.h"
#include "Tickable.h"

#include "SceneTextureCopySubsystem.generated.h"



/**
 * USceneTextureCopySubsystem
 */
UCLASS()
class USceneTextureCopySubsystem : public UWorldSubsystem, public FTickableGameObject
{
	GENERATED_BODY()
public:

	//~ Begin  Subsystem Init/Deinit
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;
	//~ End Subsystem Init/Deinit

	//~ Begin FTickableGameObject Interface
	virtual void Tick(float DeltaTime) override;
	virtual bool IsTickable() const override;
	virtual TStatId GetStatId() const override;
	//~ End FTickableGameObject Interface

	TSharedPtr< class FSceneTextureCopySceneViewExtension, ESPMode::ThreadSafe > PostProcessSceneViewExtension;
public:
	friend class FSceneTextureCopySceneViewExtension;

private:
	bool bFinalColorRecorderInited = false;
};
