// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SeeThroughTextWidgets.h"
#include "Engine/Font.h"
#include "Widgets/Input/SEditableText.h"
#include "Engine/DataTable.h"
#include "UObject/UObjectGlobals.h"
#include "UObject/Package.h"
#include "UObject/UnrealType.h"

#define LOCTEXT_NAMESPACE "SEETHROUGHTEXT_WIDGETS"

/////////////////////////////////////////////////////

static FEditableTextStyle* DefaultEditableTextStyle = nullptr;

UEditableText_ForSeeThrough::UEditableText_ForSeeThrough(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	
}
//void UEditableText_ForSeeThrough::SetFont(const FSlateFontInfo& InNewFont)
//{
//	if (MyEditableText)
//	{
//		MyEditableText->SetFont(InNewFont);
//	}
//}

#if WITH_EDITOR

const FText UEditableText_ForSeeThrough::GetPaletteCategory()
{
	return LOCTEXT("SeeThroughText", "See Through Text");
}

#endif

/////////////////////////////////////////////////////

URichTextBlock_ForSeeThrough::URichTextBlock_ForSeeThrough(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}
void URichTextBlock_ForSeeThrough::ForceSetTextStyleSet(UDataTable* NewTextStyleSet)
{
	if (NewTextStyleSet)
	{
		TextStyleSet = nullptr;
		SetTextStyleSet(NewTextStyleSet);
	}
}

void URichTextBlock_ForSeeThrough::ChangeTextStyleSetRow(const FString& RowName, const FTextBlockStyle& NewTextStyle)
{
	if (TextStyleSet && TextStyleSet->GetRowStruct()->IsChildOf(FRichTextStyleRow::StaticStruct()))
	{
		UDataTable* NewTextStyleSet = NewObject<UDataTable>(GetTransientPackage(), FName(TEXT("TempDataTable")));
		NewTextStyleSet->RowStruct = FRichTextStyleRow::StaticStruct();

		for (const auto& Entry : TextStyleSet->GetRowMap())
		{
			FString SubStyleName = Entry.Key.ToString();
			FRichTextStyleRow* RichTextStyle = (FRichTextStyleRow*)Entry.Value;

			FRichTextStyleRow Row = *RichTextStyle;

			if (SubStyleName == RowName)
			{
				Row.TextStyle = NewTextStyle;
			}
			NewTextStyleSet->AddRow(Entry.Key, Row);
		}

		ForceSetTextStyleSet(NewTextStyleSet);
	}
}

#if WITH_EDITOR

const FText URichTextBlock_ForSeeThrough::GetPaletteCategory()
{
	return LOCTEXT("SeeThroughText", "See Through Text");
}

/////////////////////////////////////////////////////

#endif

#undef LOCTEXT_NAMESPACE
