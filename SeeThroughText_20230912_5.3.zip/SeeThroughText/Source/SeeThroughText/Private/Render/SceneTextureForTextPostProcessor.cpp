// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SceneTextureForTextPostProcessor.h"
#include "Engine/TextureRenderTarget2D.h"
#include "SceneTextureForTextShaders.h"
#include "ScreenRendering.h"
#include "SceneUtils.h"
#include "RendererInterface.h"
#include "StaticBoundShaderState.h"
#include "PipelineStateCache.h"
#include "CommonRenderResources.h"
#include "TextureResource.h"

FSceneTextureForTextPostProcessor::FSceneTextureForTextPostProcessor()
{
	RenderTarget = NewObject<UTextureRenderTarget2D>();
	RenderTarget->AddToRoot();
	RenderTarget->ClearColor = FLinearColor::Transparent;
	RenderTarget->TargetGamma = 0.0f;// 2.2f;
	RenderTarget->SRGB = false;
	RenderTarget->InitCustomFormat(RenderTargetSize.X, RenderTargetSize.Y, EPixelFormat::PF_B8G8R8A8, false);
	//RenderTarget = LoadObject<UTextureRenderTarget2D>(nullptr, TEXT("/SeeThroughText/Textures/RT_SceneTexture.RT_SceneTexture"), nullptr, LOAD_None, nullptr);
	if (RenderTarget)
	{
		RenderTarget->AddToRoot();
		//RenderTarget->ClearColor = FLinearColor::Transparent;
	}
}

FSceneTextureForTextPostProcessor::~FSceneTextureForTextPostProcessor()
{
	RenderTarget->ReleaseResource();
	RenderTarget->RemoveFromRoot();
}

void FSceneTextureForTextPostProcessor::CopyRect(FRHICommandListImmediate& RHICmdList, IRendererModule& RendererModule, const FCopyRectParams& RectParams)
{
	check(RHICmdList.IsOutsideRenderPass());

	FIntPoint SourceRectSize = RectParams.SourceRect.GetSize().IntPoint();
	FIntPoint DestRectSize = RectParams.DestRect.GetSize().IntPoint();
	FIntPoint RequiredSize = DestRectSize;

	// The max size can get ridiculous with large scale values.  Clamp to size of the backbuffer
	RequiredSize.X = FMath::Min(RequiredSize.X, RectParams.SourceTextureSize.X);
	RequiredSize.Y = FMath::Min(RequiredSize.Y, RectParams.SourceTextureSize.Y);
	
	if (RenderTargetSize != DestRectSize)
	{
		RenderTargetSize = DestRectSize;
		RenderTarget->ResizeTarget(RenderTargetSize.X, RenderTargetSize.Y);
	}
	
	Viewport_Transform.X = RectParams.DestRect.Left / SourceRectSize.X;
	Viewport_Transform.Y = RectParams.DestRect.Top / SourceRectSize.Y;
	Viewport_Transform.Z = RectParams.DestRect.Right / SourceRectSize.X;
	Viewport_Transform.W = RectParams.DestRect.Bottom / SourceRectSize.Y;

	// Source is the viewport.  This is the width and height of the viewport backbuffer
	const int32 SrcTextureWidth = RectParams.SourceTextureSize.X;
	const int32 SrcTextureHeight = RectParams.SourceTextureSize.Y;

	// Dest is the destination quad for the downsample
	const int32 DestTextureWidth = RenderTargetSize.X;
	const int32 DestTextureHeight = RenderTargetSize.Y;

	// Rect of the viewport
	const FSlateRect& SourceRect = RectParams.SourceRect;

	// Rect of the final destination post process effect (not downsample rect).  This is the area we sample from
	const FSlateRect& DestRect = RectParams.DestRect;

	FGlobalShaderMap* ShaderMap = GetGlobalShaderMap(GMaxRHIFeatureLevel);
	TShaderMapRef<FScreenVS> VertexShader(ShaderMap);

	FSamplerStateRHIRef BilinearClamp = TStaticSamplerState<SF_Bilinear, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();

	FTexture2DRHIRef DestTexture = RenderTarget->GetRenderTargetResource()->GetRenderTargetTexture();

	// Copysample and store in intermediate texture
	{
		TShaderMapRef<FSceneTextureForTextCopyPS> PixelShader(ShaderMap);

		RHICmdList.Transition(FRHITransitionInfo(RectParams.SourceTexture, ERHIAccess::Unknown, ERHIAccess::SRVGraphics));
		RHICmdList.Transition(FRHITransitionInfo(DestTexture, ERHIAccess::Unknown, ERHIAccess::RTV));

		const FVector2D InvSrcTetureSize(1.f / SrcTextureWidth, 1.f / SrcTextureHeight);

		const FVector2D UVStart = FVector2D(DestRect.Left, DestRect.Top) * InvSrcTetureSize;
		const FVector2D UVEnd = FVector2D(DestRect.Right, DestRect.Bottom) * InvSrcTetureSize;
		const FVector2D SizeUV = UVEnd - UVStart;

		RHICmdList.SetViewport(0, 0, 0, DestTextureWidth, DestTextureHeight, 0.0f);
		RHICmdList.SetScissorRect(false, 0, 0, 0, 0);

		FRHIRenderPassInfo RPInfo(DestTexture, ERenderTargetActions::Load_Store);
		RHICmdList.BeginRenderPass(RPInfo, TEXT("CopysampleRect"));
		{
			FGraphicsPipelineStateInitializer GraphicsPSOInit;
			RHICmdList.ApplyCachedRenderTargets(GraphicsPSOInit);
			GraphicsPSOInit.BlendState = TStaticBlendState<>::GetRHI();
			GraphicsPSOInit.RasterizerState = TStaticRasterizerState<>::GetRHI();
			GraphicsPSOInit.DepthStencilState = TStaticDepthStencilState<false, CF_Always>::GetRHI();

			GraphicsPSOInit.BoundShaderState.VertexDeclarationRHI = GFilterVertexDeclaration.VertexDeclarationRHI;
			GraphicsPSOInit.BoundShaderState.VertexShaderRHI = VertexShader.GetVertexShader();
			GraphicsPSOInit.BoundShaderState.PixelShaderRHI = PixelShader.GetPixelShader();
			GraphicsPSOInit.PrimitiveType = PT_TriangleList;
			SetGraphicsPipelineState(RHICmdList, GraphicsPSOInit);

			PixelShader->SetTexture(RHICmdList, RectParams.SourceTexture, BilinearClamp);

			RendererModule.DrawRectangle(
				RHICmdList,
				0, 0,
				DestRectSize.X, DestRectSize.Y,
				UVStart.X, UVStart.Y,
				SizeUV.X, SizeUV.Y,
				FIntPoint(DestTextureWidth, DestTextureHeight),
				FIntPoint(1, 1),
				VertexShader,
				EDRF_Default);
		}
		RHICmdList.EndRenderPass();
	}
}

UTexture* FSceneTextureForTextPostProcessor::GetSceneTexture()
{
	return RenderTarget;
}