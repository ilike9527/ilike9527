// Copyright Qibo Pang 2023. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "GeometryCacheToVATTypes.h"
#include "IDetailCustomization.h"

class IPropertyHandle;
class SGeometryCacheToVATConfigPanel : public SCompoundWidget
{

public:

	SLATE_BEGIN_ARGS(SGeometryCacheToVATConfigPanel) {}

	SLATE_ATTRIBUTE(class UGeometryCacheToVATConfigObject*, ConfigObject)

	SLATE_END_ARGS()

	~SGeometryCacheToVATConfigPanel();

	void Construct(const FArguments& InArgs);

	static TSharedPtr<SWindow> PopVertexAnimationConvertConfigWindow(class UGeometryCache* GeometryCache);

	void SetWindow(TSharedPtr<SWindow> Window)
	{
		GeometryCacheWindow = Window;
	}

	FReply OnConvertButtonClicked();
	FReply OnCancelButtonClicked();

private:

	TSharedPtr<class IDetailsView> ConfigPanel;

	TAttribute<class UGeometryCacheToVATConfigObject*> ConfigObject;

	TSharedPtr<SWindow> GeometryCacheWindow;
};

class FGeometryCacheToVATConfigDetailCustomization : public IDetailCustomization
{
public:

	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;

	static TSharedRef<IDetailCustomization> MakeInstance();

};