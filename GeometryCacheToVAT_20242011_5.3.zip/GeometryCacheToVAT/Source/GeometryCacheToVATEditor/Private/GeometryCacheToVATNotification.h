// Copyright Qibo Pang 2023. All Rights Reserved.
#pragma once

// UE Header
#include "CoreMinimal.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Framework/Notifications/NotificationManager.h"

class FGeometryCacheToVATNotification
{
public:

	static void PopConfirm(TSharedPtr<SNotificationItem>& NotificationItem, const FText& NotificationMessage, TFunction<void()> ConfirmCallback, TFunction<void()> CancelCallback);

	static void PopOnce(const FText& Notification, SNotificationItem::ECompletionState State = SNotificationItem::ECompletionState::CS_Success, float ExpireDuration = 1.0f);

	static void PopPending(TSharedPtr<SNotificationItem>& NotificationItem, const FText& Notification, SNotificationItem::ECompletionState State = SNotificationItem::ECompletionState::CS_Pending);
	static void PendingNotificationFadeout(TSharedPtr<SNotificationItem>& NotificationItem, float ExpireDuration = 1.0f, float FadeOutDuration = 1.0f);

	static void PopPending(const FText& Notification, SNotificationItem::ECompletionState State = SNotificationItem::ECompletionState::CS_Pending);
	static void PendingNotificationFadeout(float ExpireDuration = 0.0f);

private:

	static TSharedPtr<SNotificationItem> GeometryCacheToVATNotification;

	static TSharedPtr<SNotificationItem> GetValidNotification();

};