// Copyright Qibo Pang 2023. All Rights Reserved.


#include "GeometryCacheAttachmentEditorModule.h"
#include "GeometryCacheAttachmentDetailsCustomization.h"


#define LOCTEXT_NAMESPACE "FGeometryCacheAttachmentEditorModule"

void FGeometryCacheAttachmentEditorModule::StartupModule()
{
	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.RegisterCustomClassLayout(UGeometryCacheAttachmentComponent::StaticClass()->GetFName(), FOnGetDetailCustomizationInstance::CreateStatic(&FGeometryCacheAttachmentDetailsCustomization::MakeInstance));
}

void FGeometryCacheAttachmentEditorModule::ShutdownModule()
{
	if (!UObjectInitialized())
		return;

	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.UnregisterCustomClassLayout(UGeometryCacheAttachmentComponent::StaticClass()->GetFName());

}


#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FGeometryCacheAttachmentEditorModule, GeometryCacheAttachmentEditor)
