// Copyright Qibo Pang 2023. All Rights Reserved.

#include "GeometryCacheAttachmentDetailsCustomization.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "EditorModeManager.h"

#include "PropertyHandle.h"
#include "DetailLayoutBuilder.h"
#include "DetailWidgetRow.h"
#include "IDetailPropertyRow.h"
#include "DetailCategoryBuilder.h"

#define LOCTEXT_NAMESPACE "GeometryCacheAttachment"

//////////////////////////////////////////////////////////////////////////
// FGeometryCacheAttachmentDetailsCustomization

TSharedRef<IDetailCustomization> FGeometryCacheAttachmentDetailsCustomization::MakeInstance()
{
	return MakeShareable(new FGeometryCacheAttachmentDetailsCustomization);
}

void FGeometryCacheAttachmentDetailsCustomization::CustomizeDetails(IDetailLayoutBuilder& DetailLayout)
{
	const TArray< TWeakObjectPtr<UObject> >& SelectedObjects = DetailLayout.GetSelectedObjects();
	if (SelectedObjects.Num() != 1)
	{
		return;
	}
	
	UGeometryCacheAttachmentComponent* GeometryCacheAttachmentComponent = nullptr;
	for (int32 ObjectIndex = 0; ObjectIndex < SelectedObjects.Num(); ++ObjectIndex)
	{
		UObject* TestObject = SelectedObjects[ObjectIndex].Get();
		if (UGeometryCacheAttachmentComponent* TestGeometryCacheAttachmentComponent = Cast<UGeometryCacheAttachmentComponent>(TestObject))
		{
			GeometryCacheAttachmentComponent = TestGeometryCacheAttachmentComponent;
			break;
		}
	}

	if (!GeometryCacheAttachmentComponent)
	{
		return;
	}

	GeometryCacheAttachmentComponentPtr = GeometryCacheAttachmentComponent;

	//DetailLayout.HideCategory(TEXT("Transform"));
	DetailLayout.HideCategory(TEXT("Collision"));
	DetailLayout.HideCategory(TEXT("Physics"));
	DetailLayout.HideCategory(TEXT("Lighting"));
	DetailLayout.HideCategory(TEXT("Rendering"));
	DetailLayout.HideCategory(TEXT("Navigation"));
	DetailLayout.HideCategory(TEXT("Tags"));
	DetailLayout.HideCategory(TEXT("Activation"));
	DetailLayout.HideCategory(TEXT("Cooking"));
	DetailLayout.HideCategory(TEXT("HLOD"));
	DetailLayout.HideCategory(TEXT("LOD"));
	DetailLayout.HideCategory(TEXT("Mobile"));
	DetailLayout.HideCategory(TEXT("AssetUserData"));

	MyDetailLayout = &DetailLayout;

	// Customize buttons in Style3D category
	IDetailCategoryBuilder& DetailCategoryBuilderInstance = DetailLayout.EditCategory(TEXT("GeometryCacheAttachment"));
	DetailCategoryBuilderInstance
		.AddCustomRow(LOCTEXT("GeometryCacheAttachBtn", "Attach"))
		.WholeRowContent().HAlign(HAlign_Left)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot().HAlign(HAlign_Left).VAlign(VAlign_Fill).AutoWidth()
			[
				SNew(SButton)
				.OnPressed(this, &FGeometryCacheAttachmentDetailsCustomization::OnAttachButtonClicked)
				[
					SNew(SEditableText)
					.RenderTransformPivot(FVector2D(0.5f, 0.5f))
					.RenderTransform(FSlateRenderTransform(FScale2D(1.f, 1.f)))
					.Text(FText::FromString("Attach")).Visibility(EVisibility::HitTestInvisible)
					//.Font(FSlateFontInfo("Regular", 10))
				]
			]
			+ SHorizontalBox::Slot().HAlign(HAlign_Left).VAlign(VAlign_Fill).AutoWidth()
			[
				SNew(SButton)
				.OnPressed(this, &FGeometryCacheAttachmentDetailsCustomization::OnRemoveButtonClicked)
				[	
					SNew(SEditableText)
					.RenderTransformPivot(FVector2D(0.5f, 0.5f))
					.RenderTransform(FSlateRenderTransform(FScale2D(1.f, 1.f)))
					.Text(FText::FromString("Unattach")).Visibility(EVisibility::HitTestInvisible)
					//.Font(FSlateFontInfo("Regular", 10))
				]
			]
		];
}

void FGeometryCacheAttachmentDetailsCustomization::OnAttachButtonClicked()
{
	if (GeometryCacheAttachmentComponentPtr.IsValid())
	{
		GeometryCacheAttachmentComponentPtr->AttachAllElements();
	}
}

void FGeometryCacheAttachmentDetailsCustomization::OnRemoveButtonClicked()
{
	if (GeometryCacheAttachmentComponentPtr.IsValid())
	{
		GeometryCacheAttachmentComponentPtr->RemoveAllAttachedComponents(false);
	}
}

//////////////////////////////////////////////////////////////////////////

#undef LOCTEXT_NAMESPACE
