// Copyright Qibo Pang 2023. All Rights Reserved.


#include "GeometryCacheAttachmentModule.h"

#define LOCTEXT_NAMESPACE "FGeometryCacheAttachmentModule"

void FGeometryCacheAttachmentModule::StartupModule()
{
	
}

void FGeometryCacheAttachmentModule::ShutdownModule()
{
	
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FGeometryCacheAttachmentModule, GeometryCacheAttachment)