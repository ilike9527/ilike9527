// Copyright Qibo Pang 2023. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "MovieSceneSection.h"
#include "Channels/MovieSceneFloatChannel.h"
#include "UObject/SoftObjectPath.h"
#include "MovieSceneWidgetSubSequenceSection.generated.h"

class UWidgetAnimation;

USTRUCT()
 struct UMGSUBSEQUENCE_API FMovieSceneWidgetSubSequenceParams
{
	GENERATED_BODY()

	FMovieSceneWidgetSubSequenceParams();

	/** Gets the animation sequence length, not modified by play rate */
	float GetSequenceLength() const;
	
	UPROPERTY(EditAnywhere, Category = "WidgetSubSequence")
		FString AnimationName;

	/** The offset for the first loop of the animation clip */
	UPROPERTY(EditAnywhere, Category = "WidgetSubSequence")
		FFrameNumber FirstLoopStartFrameOffset;

	/** The offset into the beginning of the animation clip */
	UPROPERTY(EditAnywhere, Category = "WidgetSubSequence")
		FFrameNumber StartFrameOffset;

	/** The offset into the end of the animation clip */
	UPROPERTY(EditAnywhere, Category = "WidgetSubSequence")
		FFrameNumber EndFrameOffset;

	/** The playback rate of the animation clip */
	UPROPERTY(EditAnywhere, Category = "WidgetSubSequence")
		float PlayRate;

	UWidgetAnimation* GetValidWidgetAnimation() const;

	UPROPERTY()
		class UWidgetBlueprintGeneratedClass* WidgetBPClass = nullptr;

	UPROPERTY()
		FString AnimationObjectName;
};

/**
 * Movie scene section that control garment cache playback
 */
UCLASS(MinimalAPI)
class UMovieSceneWidgetSubSequenceSection
	: public UMovieSceneSection
{
	GENERATED_UCLASS_BODY()

public:

	UPROPERTY(EditAnywhere, Category = "Animation", meta = (ShowOnlyInnerProperties))
	FMovieSceneWidgetSubSequenceParams Params;

	/** Get Frame Time as Animation Time*/
	virtual float MapTimeToAnimation(float ComponentDuration, FFrameTime InPosition, FFrameRate InFrameRate) const;

protected:
	//~ UMovieSceneSection interface
	virtual TOptional<TRange<FFrameNumber> > GetAutoSizeRange() const override;
	virtual void TrimSection(FQualifiedFrameTime TrimTime, bool bTrimLeft, bool bDeleteKeys) override;
	virtual UMovieSceneSection* SplitSection(FQualifiedFrameTime SplitTime, bool bDeleteKeys) override;
	virtual void GetSnapTimes(TArray<FFrameNumber>& OutSnapTimes, bool bGetSectionBorders) const override;
	virtual TOptional<FFrameTime> GetOffsetTime() const override;

	/** ~UObject interface */
	virtual void PostLoad() override;
	virtual void Serialize(FArchive& Ar) override;

private:

	//~ UObject interface

#if WITH_EDITOR

	virtual void PreEditChange(FProperty* PropertyAboutToChange) override;
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
public:
	float PreviousPlayRate;
	FString PreviousAnimationName;
#endif

};
