// Copyright Qibo Pang 2023. All Rights Reserved.


#include "GeometryCacheDecalEditorModule.h"
#include "GeometryCacheDecalDetailsCustomization.h"


#define LOCTEXT_NAMESPACE "FGeometryCacheDecalEditorModule"

void FGeometryCacheDecalEditorModule::StartupModule()
{
	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.RegisterCustomClassLayout(UGeometryCacheDecalComponent::StaticClass()->GetFName(), FOnGetDetailCustomizationInstance::CreateStatic(&FGeometryCacheDecalDetailsCustomization::MakeInstance));
}

void FGeometryCacheDecalEditorModule::ShutdownModule()
{
	if (!UObjectInitialized())
		return;

	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.UnregisterCustomClassLayout(UGeometryCacheDecalComponent::StaticClass()->GetFName());

}


#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FGeometryCacheDecalEditorModule, GeometryCacheDecalEditor)
