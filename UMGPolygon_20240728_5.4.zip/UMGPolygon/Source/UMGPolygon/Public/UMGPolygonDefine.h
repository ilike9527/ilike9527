// Copyright Qibo Pang 2024. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Dom/JsonObject.h"	// Json
#include "UMGPolygonDefine.generated.h"

/** Enumerates extrapolation options. */
UENUM(BlueprintType)
enum class EUMGPolygonType : uint8
{
    /** Use a linearly increasing value for extrapolation.*/
    LinearEdge UMETA(DisplayName = "Linear"),
    /** Use a bezier increasing value for extrapolation */
    CurveEdge UMETA(DisplayName = "Curve")
};

/** */
USTRUCT(BlueprintType)
struct UMGPOLYGON_API FUMGPolygonPoint
{
    GENERATED_BODY()

    FUMGPolygonPoint() { }
    FUMGPolygonPoint(FVector2D InLocation, FVector2D InDirection):
        Location(InLocation),
        Direction(InDirection)
    { }

public:

    /**  */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UMGPolygon")
        FVector2D Location;

    /**  */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UMGPolygon")
        FVector2D Direction;
};

/** */
USTRUCT(BlueprintType)
struct UMGPOLYGON_API FUMGPolygonInfo
{
    GENERATED_BODY()

    FUMGPolygonInfo() { }

    FUMGPolygonInfo(bool Init);

public:

    /**
      */
    void AddPoint(const FUMGPolygonPoint& PolygonPoint)
    {
        Points.Add(PolygonPoint);
    }
    

    /**
      */
    void AddPolygonPointAtIndex(const FUMGPolygonPoint& PolygonPoint, int32 Index)
    {
        if (Index >= 0 && Index < Points.Num()) {
            Points.Insert(PolygonPoint, Index);
        }
    }

    void ChangePolygonPointAtIndex(const FUMGPolygonPoint& PolygonPoint, int32 Index)
    {
        if (Index >= 0 && Index < Points.Num()) {
            Points[Index] = PolygonPoint;
        }
    }

    /**
     *  Remove the specified key from the curve.
     *
     * @param Index The Index of the Points.
     */
    void DeletePoint(int Index)
    {
        if (Points.IsValidIndex(Index))
        {
            Points.RemoveAt(Index);
        }
    }


    /** Finds a key a the specified time */
    FUMGPolygonPoint FindPoint(int Index) const
    {
        if (Points.IsValidIndex(Index))
        {
            return Points[Index];
        }
        return FUMGPolygonPoint();
    }

    int GetPointNum() const { return Points.Num(); }

    const TArray<FUMGPolygonPoint>& GetPoints() const { return Points; }

    bool IsMatch(const FUMGPolygonInfo& B)
    {
        if (PolygonType != B.PolygonType
            || bCustomEdge != B.bCustomEdge
            || bCustomEdge != B.bCustomEdge
            || EdgeThickness != B.EdgeThickness
            || PolygonTintColor != B.PolygonTintColor
            || EdgeTintColor != B.EdgeTintColor
            || Points.Num() != B.Points.Num())
        {
            return false;
        }

        for (int32 i = 0; i < Points.Num(); i++)
        {
            if (Points[i].Location != B.Points[i].Location
                || Points[i].Direction != B.Points[i].Direction)
            {
                return false;
            }
        }

        return true;
    }

public:

    /** 
    * PolygonType = EUMGPolygonType::CurveEdge, draw bezier curve edges.
    * PolygonType = EUMGPolygonType::LinearEdge, draw straight line edges.
    */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UMGPolygon")
        EUMGPolygonType PolygonType = EUMGPolygonType::CurveEdge;

    /** Edge Points of the polygon */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UMGPolygon")
        TArray<FUMGPolygonPoint> Points;

    /** Tint color for the polygon */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UMGPolygon")
        FLinearColor PolygonTintColor = FLinearColor(1.0f, 1.0f, 1.0f, 1.0f);

    /** The image/material used for the polygon geometry*/
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UMGPolygon", meta = (EditCondition = "BuildCustomVerts"))
        FSlateBrush PolygonBrush;

    /** Enable custom edge */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UMGPolygon")
        bool bCustomEdge = false;

    /** Line thickness for the edge */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UMGPolygon")
        float EdgeThickness = 1.0f;

    /** Tint color for the edge */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UMGPolygon")
        FLinearColor EdgeTintColor = FLinearColor(1.0f, 1.0f, 1.0f, 1.0f);

    /** The image/material used for  the edge geometry*/
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UMGPolygon", meta = (EditCondition = "BuildCustomVerts"))
        FSlateBrush EdgeBrush;
};

class FPoygonVertsCache : public TSharedFromThis<FPoygonVertsCache>
{

public:

    TArray<FSlateVertex> EdgeSlateVerts;
    TArray<SlateIndex> EdgeIndexes;

    TArray<FSlateVertex> PolygonSlateVerts;
    TArray<SlateIndex> PolygonIndexes;

    TArray<FVector2D> EdgePoints;

    FUMGPolygonInfo PolygonInfoInUse;
    float DrawScale;
    FVector2f DrawPosition;

    FVector2D  TransformOffset;
    float      TransformScale;

    void Clear()
    {
        EdgeSlateVerts.Empty();
        EdgeIndexes.Empty();

        PolygonSlateVerts.Empty();
        PolygonIndexes.Empty();

        EdgePoints.Empty();
    }
};

/** Notification for FUMGPolygonInfo value change */
DECLARE_DELEGATE_OneParam(FOnPolygonInfoValueChanged, const FUMGPolygonInfo&)
