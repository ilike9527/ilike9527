// Copyright Qibo Pang 2024. All Rights Reserved.


#include "UMGPolygonEditorModule.h"
#include "UMGPolygonWidgetDetailsCustomization.h"


#define LOCTEXT_NAMESPACE "FUMGPolygonEditorModule"

void FUMGPolygonEditorModule::StartupModule()
{
	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.RegisterCustomClassLayout(UPolygonWidget::StaticClass()->GetFName(), FOnGetDetailCustomizationInstance::CreateStatic(&FUMGPolygonWidgetDetailsCustomization::MakeInstance));
}

void FUMGPolygonEditorModule::ShutdownModule()
{
	if (!UObjectInitialized())
		return;

	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.UnregisterCustomClassLayout(UPolygonWidget::StaticClass()->GetFName());

}


#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FUMGPolygonEditorModule, UMGPolygonEditor)
