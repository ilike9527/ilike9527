// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Components/EditableText.h"
#include "Components/RichTextBlock.h"
#include "SeeThroughTextWidgets.generated.h"

class SEditableText;
class USlateBrushAsset;
class USlateWidgetStyleAsset;

/**
 * Editable text widget for see through text
 */
UCLASS()
class SEETHROUGHTEXT_API UEditableText_ForSeeThrough : public UEditableText
{
	GENERATED_UCLASS_BODY()

public:

	/**
	 * Set the widget font
	 */
	UFUNCTION(BlueprintCallable, Category = "Widget")
	void SetFont(const FSlateFontInfo& InNewFont);

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override;
#endif

};

/**
 * Rich text widget for see through text
 */
UCLASS()
class SEETHROUGHTEXT_API URichTextBlock_ForSeeThrough : public URichTextBlock
{
	GENERATED_UCLASS_BODY()

public:

	UFUNCTION(BlueprintCallable, Category = "Widget")
		void ForceSetTextStyleSet(class UDataTable* NewTextStyleSet);

	UFUNCTION(BlueprintCallable, Category = "Widget")
		void ChangeTextStyleSetRow(const FString& RowName, const FTextBlockStyle& NewTextStyle);

#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override;
#endif

};
