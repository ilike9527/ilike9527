// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

class FSceneTextureForTextDrawer;
class FSceneTextureForTextPostProcessor;

class UWidget;
class UMaterialInstanceDynamic;

struct FSeeThroughTextWidgetInfo
{
	UWidget* Widget;
	FSlateFontInfo* FontInfo;

	UMaterialInstanceDynamic* MID_Font = nullptr;
	UMaterialInstanceDynamic* MID_Outline = nullptr;
};

/**
 * SceneTexture For Text renderer
 */
class FSceneTextureForTextRenderer
{
public:
	FSceneTextureForTextRenderer();
	~FSceneTextureForTextRenderer();

	TSharedRef<FSceneTextureForTextPostProcessor> GetPostProcessor() { return PostProcessor; }

	void AddMaterialForSeeThroughText(UMaterialInstanceDynamic* MaterialInstanceDynamic, const UObject* WorldContextObject);

	void RemoveMaterialForSeeThroughText(UMaterialInstanceDynamic* MaterialInstanceDynamic);

	void UpdateSceneTextureToMID();

	static FSceneTextureForTextRenderer& Get();

private:

	/** Handles post process effects for slate */
	TSharedRef<FSceneTextureForTextPostProcessor> PostProcessor;

	class USceneTextureRecorder* SceneTextureRecorder = nullptr;

	TArray<UMaterialInstanceDynamic*> MaterialsForSeeThroughText;
};

