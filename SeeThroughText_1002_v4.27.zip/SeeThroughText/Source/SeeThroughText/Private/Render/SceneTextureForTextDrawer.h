// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "RenderResource.h"
#include "RendererInterface.h"
#include "Rendering/RenderingCommon.h"
#include "CanvasTypes.h"
#include "Widgets/SLeafWidget.h"

class FRHICommandListImmediate;

struct FSceneTextureForTextRenderParams
{
	FVector4 QuadPositionData;

	const FSlateClippingState* ClippingState;

	FVector2D ViewportSize;

	FSceneTextureForTextRenderParams()
	{
		ClippingState = nullptr;
	}
};


/**
 * Custom Slate drawer to render a SceneTextureForText with mask
 */
class FSceneTextureForTextDrawer : public ICustomSlateElement
{
public:
	FSceneTextureForTextDrawer();
	~FSceneTextureForTextDrawer();

	bool InitializeSceneTextureForTextParams(FSlateWindowElementList& ElementList, uint32 InLayer, const FPaintGeometry& PaintGeometry);

private:
	/**
	 * ICustomSlateElement interface 
	 */
	virtual void DrawRenderThread(FRHICommandListImmediate& RHICmdList, const void* InWindowBackBuffer) override;

	const FSlateClippingState* ResolveClippingState(FSlateWindowElementList& ElementList) const;

private:
	
	//FSlateStencilClipVertexBuffer StencilVertexBuffer;
	FSceneTextureForTextRenderParams RenderParams;
	
};
