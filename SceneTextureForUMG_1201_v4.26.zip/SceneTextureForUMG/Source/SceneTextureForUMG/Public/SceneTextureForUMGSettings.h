﻿// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Engine/DeveloperSettings.h"
#include "SceneTextureForUMGSettings.generated.h"


/**
 * 
 */
UCLASS(config = Game, defaultconfig)
class SCENETEXTUREFORUMG_API USceneTextureForUMGSettings : public UDeveloperSettings
{
	GENERATED_BODY()

	USceneTextureForUMGSettings();

public:

	/* Color before postprocessing*/
	UPROPERTY(config, EditAnywhere, BlueprintReadWrite, Category = "SceneTextureForUMG")
		bool EnableSceneColor;

	UPROPERTY(config, EditAnywhere, BlueprintReadWrite, Category = "SceneTextureForUMG")
		bool EnableSceneDepth;

	UPROPERTY(config, EditAnywhere, BlueprintReadWrite, Category = "SceneTextureForUMG")
		bool EnableCustomDepth;

	/* Color after postprocessing*/
	UPROPERTY(config, EditAnywhere, BlueprintReadWrite, Category = "SceneTextureForUMG")
		bool EnableFinalColor;

	static const USceneTextureForUMGSettings* GetInstance();
	static USceneTextureForUMGSettings* GetMutableInstance();

	// Begin UDeveloperSettings Interface
	virtual FName GetCategoryName() const override;
#if WITH_EDITOR
	virtual FText GetSectionText() const override;
#endif
	// END UDeveloperSettings Interface

};
