// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Materials/MaterialExpression.h"
#include "MaterialSceneTextureId.h"
#include "MaterialExpressionIO.h"
#include "SceneTextureForUMGMaterialExpression.generated.h"


#ifndef STORE_ONLY_ACTIVE_SHADERMAPS
#define STORE_ONLY_ACTIVE_SHADERMAPS 0
#endif

UENUM()
enum ESceneTextureForUMGId
{
	/** Scene color, normal post process passes should use PostProcessInput0 */
	UMG_SceneColor UMETA(DisplayName = "SceneColor"),
	/** Scene depth, single channel, contains the linear depth of the opaque objects */
	UMG_SceneDepth UMETA(DisplayName = "SceneDepth"),
	/** Scene depth, single channel, contains the linear depth of the opaque objects rendered with CustomDepth (mesh property) */
	UMG_CustomDepth UMETA(DisplayName = "CustomDepth"),
	/** Scene depth, single channel, contains the linear depth of the opaque objects rendered with CustomDepth (mesh property) */
	UMG_FinalColor UMETA(DisplayName = "FinalColor"),
};


UCLASS(collapsecategories, hidecategories = Object)
class UMaterialExpressionSceneTextureForUMG : public UMaterialExpression
{
	GENERATED_UCLASS_BODY()

	/** UV in 0..1 range */
	UPROPERTY(meta = (RequiredInput = "false", ToolTip = "Ignored if not specified"))
	FExpressionInput Coordinates;

	/** Only used if Coordinates is not hooked up */
	UPROPERTY(EditAnywhere, Category = UMaterialExpressionARKitPassthroughCamera)
		uint32 ConstCoordinate;

	/** Which scene texture (screen aligned texture) we want to make a lookup into */
	UPROPERTY(EditAnywhere, Category = UMaterialExpressionSceneTexture, meta = (DisplayName = "Scene Texture Id"))
		TEnumAsByte<ESceneTextureForUMGId> SceneTextureId;

	//~ Begin UMaterialExpression Interface
#if WITH_EDITOR
	virtual int32 Compile(class FMaterialCompiler* Compiler, int32 OutputIndex) override;
	virtual void GetCaption(TArray<FString>& OutCaptions) const override;
#endif

	virtual UObject* GetReferencedTexture() const override;
	virtual bool CanReferenceTexture() const { return true; }
	//~ End UMaterialExpression Interface

private:

	UTexture* GetSceneTextureById() const;
};

