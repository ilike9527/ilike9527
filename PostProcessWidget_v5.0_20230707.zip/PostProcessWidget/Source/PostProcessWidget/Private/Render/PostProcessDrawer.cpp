// Copyright Qibo Pang 2023. All Rights Reserved.

#include "PostProcessDrawer.h"
#include "RenderingThread.h"
#include "UnrealClient.h"
#include "Engine/Engine.h"
#include "EngineModule.h"
#include "Framework/Application/SlateApplication.h"
#include "PostProcessShaders.h"
#include "ScreenRendering.h"
#include "CommonRenderResources.h"
#include "Engine/TextureRenderTarget2D.h"

#define INVALID_LAYER_ID UINT_MAX

static const FName RendererModuleName("Renderer");

FPostProcessDrawer::FPostProcessDrawer()
	: LayerID(INVALID_LAYER_ID)
{
	
}

FPostProcessDrawer::~FPostProcessDrawer()
{
	
}

static bool ShouldCullWidget(const FSlateWindowElementList& ElementList)
{
	const FSlateClippingManager& ClippingManager = ElementList.GetClippingManager();
	const int32 CurrentIndex = ClippingManager.GetClippingIndex();
	if (CurrentIndex != INDEX_NONE)
	{
		const FSlateClippingState& ClippingState = ClippingManager.GetClippingStates()[CurrentIndex];
		return ClippingState.HasZeroArea();
	}

	return false;
}

bool FPostProcessDrawer::InitializePostProcessParams(FSlateWindowElementList& ElementList, uint32 InLayer, const FPaintGeometry& PaintGeometry, UTextureRenderTarget2D* InRenderTarget)
{
	PaintGeometry.CommitTransformsIfUsingLegacyConstructor();

	if (ShouldCullWidget(ElementList))
	{
		return false;
	}

	const FSlateRenderTransform& RenderTransform = PaintGeometry.GetAccumulatedRenderTransform();
	const FVector2D& LocalSize = PaintGeometry.GetLocalSize();

	//@todo doesn't work with rotated or skewed objects yet
	const FVector2D& Position = FVector2D(PaintGeometry.DrawPosition);

	const int32 Layer = InLayer;

	// Determine the four corners of the quad
	FVector2D TopLeft = FVector2D::ZeroVector;
	FVector2D TopRight = FVector2D(LocalSize.X, 0);
	FVector2D BotLeft = FVector2D(0, LocalSize.Y);
	FVector2D BotRight = FVector2D(LocalSize.X, LocalSize.Y);

	FVector2D WorldTopLeft = TransformPoint(RenderTransform, TopLeft).RoundToVector();
	FVector2D WorldBotRight = TransformPoint(RenderTransform, BotRight).RoundToVector();

	FVector2D WindowSize = ElementList.GetPaintWindow()->GetViewportSize();;
	FVector2D SizeUV = (WorldBotRight - WorldTopLeft) / WindowSize;

	const FSlateClippingState* ClipState = ResolveClippingState(ElementList);

	RenderTarget = InRenderTarget;

	// These could be negative with rotation or negative scales.  This is not supported yet
	if (SizeUV.X > 0 && SizeUV.Y > 0)
	{
		ClippingState = ClipState;
		QuadPositionData = FVector4(WorldTopLeft, WorldBotRight);

		return true;
	}

	return false;
}

const FSlateClippingState* FPostProcessDrawer::ResolveClippingState(FSlateWindowElementList& ElementList) const
{
	FClipStateHandle ClipHandle;
	ClipHandle.SetPreCachedClipIndex(ElementList.GetClippingIndex());

	const TArray<FSlateClippingState>* PrecachedClippingStates = &ElementList.GetClippingManager().GetClippingStates();

	// Do cached first
	if (ClipHandle.GetCachedClipState())
	{
		// We should be working with cached elements if we have a cached clip state
		//check(ElementList);
		return ClipHandle.GetCachedClipState();
	}
	else if (PrecachedClippingStates->IsValidIndex(ClipHandle.GetPrecachedClipIndex()))
	{
		// Store the clipping state so we can use it later for rendering.
		return &(*PrecachedClippingStates)[ClipHandle.GetPrecachedClipIndex()];
	}

	return nullptr;
}

static bool IsMemorylessTexture(const FTexture2DRHIRef& Tex)
{
	if (Tex)
	{
		return EnumHasAnyFlags(Tex->GetFlags(), TexCreate_Memoryless);
	}
	return false;
}

static bool UpdateScissorRect(
	FRHICommandList& RHICmdList,
	FIntPoint& BackBufferSize,
	const FSlateClippingState* ClippingState,
	FTexture2DRHIRef& ColorTarget,
	const FVector2D& ViewTranslation2D,
	bool bSwitchVerticalAxis,
	FGraphicsPipelineStateInitializer& InGraphicsPSOInit,
	bool bForceStateChange)
{
	check(RHICmdList.IsInsideRenderPass());
	bool bDidRestartRenderpass = false;

	if (ClippingState != nullptr || bForceStateChange)
	{
		QUICK_SCOPE_CYCLE_COUNTER(STAT_Slate_UpdateScissorRect);

		if (ClippingState)
		{
			const FSlateClippingState& ClipState = *ClippingState;
			if (ClipState.GetClippingMethod() == EClippingMethod::Scissor)
			{
				const FSlateClippingZone& ScissorRect = ClipState.ScissorRect.GetValue();

				const FIntPoint SizeXY = BackBufferSize;
				const FVector2D ViewSize((float)SizeXY.X, (float)SizeXY.Y);

				// Clamp scissor rect to BackBuffer size
				const FVector2D TopLeft = FMath::Min(FMath::Max(FVector2D(ScissorRect.TopLeft) + ViewTranslation2D, FVector2D(0.0f, 0.0f)), ViewSize);
				const FVector2D BottomRight = FMath::Min(FMath::Max(FVector2D(ScissorRect.BottomRight) + ViewTranslation2D, FVector2D(0.0f, 0.0f)), ViewSize);

				if (bSwitchVerticalAxis)
				{
					const int32 MinY = (ViewSize.Y - BottomRight.Y);
					const int32 MaxY = (ViewSize.Y - TopLeft.Y);
					ensure(TopLeft.X <= BottomRight.X && MinY <= MaxY);
					if (TopLeft.X <= BottomRight.X && TopLeft.Y <= BottomRight.Y)
					{
						RHICmdList.SetScissorRect(true, TopLeft.X, MinY, BottomRight.X, MaxY);
					}
					else
					{
						RHICmdList.SetScissorRect(false, 0, 0, 0, 0);
					}
				}
				else
				{
					if (TopLeft.X <= BottomRight.X && TopLeft.Y <= BottomRight.Y)
					{
						RHICmdList.SetScissorRect(true, TopLeft.X, TopLeft.Y, BottomRight.X, BottomRight.Y);
					}
					else
					{
						RHICmdList.SetScissorRect(false, 0, 0, 0, 0);
					}
				}

				// Disable depth/stencil testing by default
				InGraphicsPSOInit.DepthStencilState = TStaticDepthStencilState<false, CF_Always>::GetRHI();
			}
			

			RHICmdList.ApplyCachedRenderTargets(InGraphicsPSOInit);
		}
		else
		{
			RHICmdList.SetScissorRect(false, 0, 0, 0, 0);

			// Disable depth/stencil testing
			InGraphicsPSOInit.DepthStencilState = TStaticDepthStencilState<false, CF_Always>::GetRHI();
		}
	}

	return bDidRestartRenderpass;
}


void FPostProcessDrawer::DrawRenderThread(FRHICommandListImmediate& RHICmdList, const void* InWindowBackBuffer)
{
	
	IRendererModule& RendererModule = FModuleManager::GetModuleChecked<IRendererModule>(RendererModuleName);

	// This is the stenciling ref variable we set any time we draw, so that any stencil comparisons use the right mask id.
	{
		//SLATE_DRAW_EVENT(RHICmdList, PostProcess);
		//RHICmdList.EndRenderPass();

		FTexture2DRHIRef PostProcessTexture = *(FTexture2DRHIRef*)(InWindowBackBuffer);
		FTexture2DRHIRef ColorTarget = *(FTexture2DRHIRef*)(InWindowBackBuffer);

		FIntPoint BackBufferSize = PostProcessTexture->GetSizeXY();

		const FSlateClippingState* LastClippingState = nullptr;

		// Currently, PostProcess for 3D widget is not supported.
		FVector2D ViewTranslation2D = FVector2D::ZeroVector;
		bool bSwitchVerticalAxis = RHINeedsToSwitchVerticalAxis(GShaderPlatformForFeatureLevel[GMaxRHIFeatureLevel]);

		FPostProcessRectParams RectParams;
		RectParams.SourceTexture = PostProcessTexture->GetTexture2D();
		RectParams.TargetTexture = RenderTarget->GetRenderTargetResource()->GetRenderTargetTexture();;
		RectParams.SourceRect = FSlateRect(0, 0, PostProcessTexture->GetSizeX(), PostProcessTexture->GetSizeY());
		RectParams.DestRect = FSlateRect(QuadPositionData.X, QuadPositionData.Y, QuadPositionData.Z, QuadPositionData.W);
		RectParams.SourceTextureSize = PostProcessTexture->GetSizeXY();

		RectParams.RestoreStateFunc = [&](FRHICommandListImmediate& InRHICmdList, FGraphicsPipelineStateInitializer& InGraphicsPSOInit) {
			return UpdateScissorRect(
				InRHICmdList,
				BackBufferSize,
				ClippingState,
				ColorTarget,
				ViewTranslation2D,
				bSwitchVerticalAxis,
				InGraphicsPSOInit,
				true);
		};

		RectParams.RestoreStateFuncPostPipelineState = [&]() {
			RHICmdList.SetStencilRef(0);
		};

		CopysampleRect(RHICmdList, RendererModule, RectParams);

		check(RHICmdList.IsOutsideRenderPass());
		// Render pass for slate elements will be restarted on a next loop iteration if any
	}

}

void FPostProcessDrawer::CopysampleRect(FRHICommandListImmediate& RHICmdList, IRendererModule& RendererModule, const FPostProcessRectParams& Params)
{
	// Source is the viewport.  This is the width and height of the viewport backbuffer
	const int32 SrcTextureWidth = Params.SourceTextureSize.X;
	const int32 SrcTextureHeight = Params.SourceTextureSize.Y;

	// Dest is the destination quad for the downsample
	const int32 DestTextureWidth = RenderTarget->GetSurfaceWidth();
	const int32 DestTextureHeight = RenderTarget->GetSurfaceHeight();

	// Rect of the viewport
	const FSlateRect& SourceRect = Params.SourceRect;

	// Rect of the final destination post process effect (not downsample rect).  This is the area we sample from
	const FSlateRect& DestRect = Params.DestRect;

	const FIntPoint DestRectSize = Params.DestRect.GetSize().IntPoint();

	FGlobalShaderMap* ShaderMap = GetGlobalShaderMap(GMaxRHIFeatureLevel);
	TShaderMapRef<FScreenVS> VertexShader(ShaderMap);

	FSamplerStateRHIRef BilinearClamp = TStaticSamplerState<SF_Bilinear, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();

	FTexture2DRHIRef DestTexture = Params.TargetTexture;// IntermediateTargets->GetRenderTarget(2);

	// Copysample and store in intermediate texture
	{
		TShaderMapRef<FPostProcessCopysamplePS> PixelShader(ShaderMap);

		RHICmdList.Transition(FRHITransitionInfo(Params.SourceTexture, ERHIAccess::Unknown, ERHIAccess::SRVGraphics));
		RHICmdList.Transition(FRHITransitionInfo(DestTexture, ERHIAccess::Unknown, ERHIAccess::RTV));

		const FVector2D InvSrcTetureSize(1.f / SrcTextureWidth, 1.f / SrcTextureHeight);

		const FVector2D UVStart = FVector2D(DestRect.Left, DestRect.Top) * InvSrcTetureSize;
		const FVector2D UVEnd = FVector2D(DestRect.Right, DestRect.Bottom) * InvSrcTetureSize;
		const FVector2D SizeUV = UVEnd - UVStart;

		RHICmdList.SetViewport(0, 0, 0, DestTextureWidth, DestTextureHeight, 0.0f);
		RHICmdList.SetScissorRect(false, 0, 0, 0, 0);

		FRHIRenderPassInfo RPInfo(DestTexture, ERenderTargetActions::Load_Store);
		RHICmdList.BeginRenderPass(RPInfo, TEXT("CopysampleRect"));
		{
			FGraphicsPipelineStateInitializer GraphicsPSOInit;
			RHICmdList.ApplyCachedRenderTargets(GraphicsPSOInit);
			GraphicsPSOInit.BlendState = TStaticBlendState<>::GetRHI();
			GraphicsPSOInit.RasterizerState = TStaticRasterizerState<>::GetRHI();
			GraphicsPSOInit.DepthStencilState = TStaticDepthStencilState<false, CF_Always>::GetRHI();

			GraphicsPSOInit.BoundShaderState.VertexDeclarationRHI = GFilterVertexDeclaration.VertexDeclarationRHI;
			GraphicsPSOInit.BoundShaderState.VertexShaderRHI = VertexShader.GetVertexShader();
			GraphicsPSOInit.BoundShaderState.PixelShaderRHI = PixelShader.GetPixelShader();
			GraphicsPSOInit.PrimitiveType = PT_TriangleList;
			SetGraphicsPipelineState(RHICmdList, GraphicsPSOInit);

			PixelShader->SetTexture(RHICmdList, Params.SourceTexture, BilinearClamp);

			RendererModule.DrawRectangle(
				RHICmdList,
				0, 0,
				DestRectSize.X, DestRectSize.Y,
				UVStart.X, UVStart.Y,
				SizeUV.X, SizeUV.Y,
				FIntPoint(DestTextureWidth, DestTextureHeight),
				FIntPoint(1, 1),
				VertexShader,
				EDRF_Default);
		}
		RHICmdList.EndRenderPass();

		RHICmdList.Transition(FRHITransitionInfo(DestTexture, ERHIAccess::Unknown, ERHIAccess::SRVGraphics));
	}
}



