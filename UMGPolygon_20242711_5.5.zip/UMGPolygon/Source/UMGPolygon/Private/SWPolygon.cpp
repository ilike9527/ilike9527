// Copyright Qibo Pang 2024. All Rights Reserved.

#include "SWPolygon.h"
#include "UMGPolygonBuilder.h"
#include "UMGPolygonRenderBatch.h"

/*===========================================================================*\
|                                Construct                                    |
\*===========================================================================*/

void SWPolygon::Construct(const FArguments& InArgs)
{
	// Arguments passed onto the slate widget
	PolygonInfo = InArgs._PolygonInfo;

	OnValueChanged = InArgs._OnValueChanged;

	PoygonVertsCache = MakeShared<FPoygonVertsCache>();

}

/*===========================================================================*\
|                                Overrides                                    |
\*===========================================================================*/

FVector2D SWPolygon::ComputeDesiredSize(float) const
{
	return FVector2D(200.0f, 200.0f);
}


int32 SWPolygon::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	const ESlateDrawEffect DrawEffects = ShouldBeEnabled(bParentEnabled) ? ESlateDrawEffect::None : ESlateDrawEffect::DisabledEffect;
	
	PaintPolygon_CustomVerts(PolygonInfo.Get(), AllottedGeometry, OutDrawElements, LayerId + 1, MyCullingRect, DrawEffects, InWidgetStyle);

	return LayerId + 1;
}

void SWPolygon::PaintPolygon_CustomVerts(const FUMGPolygonInfo& InPolygonInfo, const FGeometry& AllottedGeometry, FSlateWindowElementList& OutDrawElements,
	int32 LayerId, const FSlateRect& MyCullingRect, ESlateDrawEffect DrawEffects, const FWidgetStyle& InWidgetStyle)const
{
	if (InPolygonInfo.GetPointNum() > 1)
	{
		
		//
		if (!PoygonVertsCache->PolygonInfoInUse.IsMatch(InPolygonInfo)
			|| PoygonVertsCache->DrawScale != AllottedGeometry.ToPaintGeometry().DrawScale
			|| PoygonVertsCache->DrawPosition != AllottedGeometry.ToPaintGeometry().DrawPosition)
		{
			PoygonVertsCache->DrawScale = AllottedGeometry.ToPaintGeometry().DrawScale;
			PoygonVertsCache->DrawPosition = AllottedGeometry.ToPaintGeometry().DrawPosition;
			PoygonVertsCache->PolygonInfoInUse = InPolygonInfo;
			PoygonVertsCache->Clear();

			const TArray<FUMGPolygonPoint>& Points = InPolygonInfo.GetPoints();

			// 1 is the minimum thickness we support for generating geometry.
			// The shader takes care of sub-pixel line widths.
			// EdgeThickness is given in screenspace, so convert it to local space before proceeding.
			FSlateLayoutTransform LayoutTransform = FSlateLayoutTransform(AllottedGeometry.ToPaintGeometry().DrawScale, AllottedGeometry.ToPaintGeometry().DrawPosition);
			float InEdgeThickness = FMath::Max(1.0f, Inverse(LayoutTransform).GetScale() * InPolygonInfo.EdgeThickness);

			static const float TwoRootTwo = 2 * FMath::Sqrt(2.0f);
			// Compute the actual size of the line we need based on thickness.
			// Each line segment will be a bit thicker than the line to account
			// for the size of the filter.
			const float LineEdgeThickness = (TwoRootTwo + InEdgeThickness);

			// Width of the filter size to use for anti-aliasing.
			// Increasing this value will increase the fuzziness of line edges.
			const float FilterScale = 1.0f;
			const float HalfEdgeThickness = LineEdgeThickness * 0.5f + FilterScale;

			FLinearColor InColor = InWidgetStyle.GetColorAndOpacityTint() * InPolygonInfo.PolygonTintColor;
			FColor TintColor = InColor.ToFColor(true);
			FUMGPolygonBuilder PolygonBuilder = FUMGPolygonBuilder(
				Points[0].Location,
				FilterScale,
				1.0f, //InPolygonInfo.CustomVertsVCoordScale, 
				AllottedGeometry.ToPaintGeometry().GetAccumulatedRenderTransform(),
				FVector2D(0.0f, 0.0f),
				AllottedGeometry.GetLocalSize());

			for (int32 i = 0; i < Points.Num() - 1; ++i)
			{
				FVector2D LocalStart = Points[i].Location;
				FVector2D StartDir = InPolygonInfo.PolygonType == EUMGPolygonType::LinearEdge ? FVector2D::ZeroVector : Points[i].Direction;

				FVector2D LocalEnd = Points[i + 1].Location;
				FVector2D EndDir = InPolygonInfo.PolygonType == EUMGPolygonType::LinearEdge ? FVector2D::ZeroVector : Points[i + 1].Direction;

				bool bAllValuesValid = (LocalStart.X != -FLT_MAX) && (LocalStart.Y != -FLT_MAX) && (LocalEnd.X != -FLT_MAX) && (LocalEnd.Y != -FLT_MAX);

				if (bAllValuesValid)
				{
					FVector2D P1 = LocalStart + StartDir / 3.0f;
					FVector2D P2 = LocalEnd - EndDir / 3.0f;
					PolygonBuilder.AppendBezierCurve(LocalStart, P1, P2, LocalEnd);
				}

			}

			// Closed Loop
			{
				FVector2D LocalStart = Points.Last().Location;
				FVector2D StartDir = InPolygonInfo.PolygonType == EUMGPolygonType::LinearEdge ? FVector2D::ZeroVector : Points.Last().Direction;

				FVector2D LocalEnd = Points[0].Location;
				FVector2D EndDir = InPolygonInfo.PolygonType == EUMGPolygonType::LinearEdge ? FVector2D::ZeroVector : Points[0].Direction;

				bool bAllValuesValid = (LocalStart.X != -FLT_MAX) && (LocalStart.Y != -FLT_MAX) && (LocalEnd.X != -FLT_MAX) && (LocalEnd.Y != -FLT_MAX);

				if (bAllValuesValid)
				{
					FVector2D P1 = LocalStart + StartDir / 3.0f;
					FVector2D P2 = LocalEnd - EndDir / 3.0f;
					PolygonBuilder.AppendBezierCurve(LocalStart, P1, P2, LocalEnd);
				}
			}

			FUMGPolygonRenderBatch PolygonRenderBatch = FUMGPolygonRenderBatch(&PoygonVertsCache->PolygonSlateVerts, &PoygonVertsCache->PolygonIndexes);
			PolygonBuilder.BuildPolygonGeometry(PolygonRenderBatch, TintColor);

			PoygonVertsCache->EdgePoints = PolygonBuilder.GetEdgePoints();

			if (InPolygonInfo.bCustomEdge)
			{
				FUMGPolygonRenderBatch EdgeRenderBatch = FUMGPolygonRenderBatch(&PoygonVertsCache->EdgeSlateVerts, &PoygonVertsCache->EdgeIndexes);
				PolygonBuilder.BuildEdgeGeometry(EdgeRenderBatch, InPolygonInfo.EdgeTintColor.ToFColor(true), HalfEdgeThickness, InPolygonInfo.EdgeThickness);
			}
			
		}

		// Get Ploygon brush
		FSlateResourceHandle PolygonHandle = FSlateApplication::Get().GetRenderer()->GetResourceHandle(InPolygonInfo.PolygonBrush);

		// Draw Ploygon
		FSlateDrawElement::MakeCustomVerts(OutDrawElements, LayerId, PolygonHandle, PoygonVertsCache->PolygonSlateVerts, PoygonVertsCache->PolygonIndexes, nullptr, 0, 0);

		if (InPolygonInfo.bCustomEdge)
		{
			// Get Edge brush
			FSlateResourceHandle EdgeHandle = FSlateApplication::Get().GetRenderer()->GetResourceHandle(InPolygonInfo.EdgeBrush);

			// Draw Edge
			FSlateDrawElement::MakeCustomVerts(OutDrawElements, LayerId, EdgeHandle, PoygonVertsCache->EdgeSlateVerts, PoygonVertsCache->EdgeIndexes, nullptr, 0, 0);
		}
	}
}

bool SWPolygon::CheckPointInPolygon(const FVector2D& Point) const
{
	if (PoygonVertsCache && PoygonVertsCache->EdgePoints.Num() > 0)
	{
		//algorithm from https://stackoverflow.com/questions/217578/how-can-i-determine-whether-a-2d-point-is-within-a-polygon
		const TArray<FVector2D>& EdgePoints = PoygonVertsCache->EdgePoints;
		FVector2D Min = EdgePoints[0];
		FVector2D Max = EdgePoints[0];
		for (int i = 1; i < EdgePoints.Num(); i++)
		{
			const FVector2D& P = EdgePoints[i];
			Min.X = FMath::Min(P.X, Min.X);
			Max.X = FMath::Max(P.X, Max.X);
			Min.Y = FMath::Min(P.Y, Min.Y);
			Max.Y = FMath::Max(P.Y, Max.Y);
		}

		if (Point.X < Min.X || Point.X > Max.X || Point.Y < Min.Y || Point.Y > Max.Y)
		{
			return false;
		}

		bool bIsInPolygon = false;
		for (int32 i = 0, j = EdgePoints.Num() - 1; i < EdgePoints.Num(); j = i++)
		{
			if (((EdgePoints[i].Y > Point.Y) != (EdgePoints[j].Y > Point.Y)) &&
				(Point.X < (EdgePoints[j].X - EdgePoints[i].X) * (Point.Y - EdgePoints[i].Y) / (EdgePoints[j].Y - EdgePoints[i].Y) + EdgePoints[i].X))
			{
				bIsInPolygon = !bIsInPolygon;
			}
		}

		return bIsInPolygon;
	}

	return false;
}