// Copyright Qibo Pang 2023. All Rights Reserved.

#include "MovieSceneWidgetSubSequenceTemplate.h"
#include "Compilation/MovieSceneCompilerRules.h"
#include "Evaluation/MovieSceneEvaluation.h"
#include "IMovieScenePlayer.h"
#include "UObject/ObjectKey.h"
#include "Async/Async.h"
#include "Blueprint/UserWidget.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"
#include "Animation/UMGSequencePlayer.h"
#include "Animation/WidgetAnimation.h"

DECLARE_CYCLE_STAT(TEXT("Widget SubSequence Evaluate"), MovieSceneEval_WidgetSubSequence_Evaluate, STATGROUP_MovieSceneEval);
DECLARE_CYCLE_STAT(TEXT("Widget SubSequence Token Execute"), MovieSceneEval_WidgetSubSequence_TokenExecute, STATGROUP_MovieSceneEval);

/** Used to set Manual Tick back to previous when outside section */
struct FPreAnimatedWidgetSubSequenceTokenProducer : IMovieScenePreAnimatedTokenProducer
{
	virtual IMovieScenePreAnimatedTokenPtr CacheExistingState(UObject& Object) const
	{
		struct FToken : IMovieScenePreAnimatedToken
		{
			FToken(UUserWidget* InUserWidget)
			{
				// Cache this object's current update flag and animation mode
				bInManualTick = true;
			}

			virtual void RestoreState(UObject& Object, const UE::MovieScene::FRestoreStateParams& Params)
			{
				UUserWidget* UserWidget = CastChecked<UUserWidget>(&Object);
			}
			bool bInManualTick;
		};

		return FToken(CastChecked<UUserWidget>(&Object));
	}
	static FMovieSceneAnimTypeID GetAnimTypeID()
	{
		return TMovieSceneAnimTypeID<FPreAnimatedWidgetSubSequenceTokenProducer>();
	}
};


/** A movie scene execution token that executes a Widget SubSequence*/
struct FWidgetSubSequenceExecutionToken
	: IMovieSceneExecutionToken

{
	FWidgetSubSequenceExecutionToken(const FMovieSceneWidgetSubSequenceSectionTemplateParameters &InParams) :
		Params(InParams)
	{}

	static UUserWidget* UserWidgetFromObject(UObject* BoundObject)
	{
		if (UUserWidget* UserWidget = Cast<UUserWidget>(BoundObject))
		{
			return UserWidget;
		}
		return nullptr;
	}

	/** Execute this token, operating on all objects referenced by 'Operand' */
	virtual void Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) override
	{
		MOVIESCENE_DETAILED_SCOPE_CYCLE_COUNTER(MovieSceneEval_WidgetSubSequence_TokenExecute)
		if (Operand.ObjectBindingID.IsValid())
		{
			for (TWeakObjectPtr<> WeakObj : Player.FindBoundObjects(Operand))
			{
				if (UObject* Obj = WeakObj.Get())
				{
					UUserWidget* UserWidget = UserWidgetFromObject(Obj);
					if (UserWidget /*&& UserWidget->IsRegistered()*/)
					{
						ExecuteSubSequencePlay(UserWidget, Context, Player);
					}
				}
			}
		}
	}

	void ExecuteSubSequencePlay(UUserWidget* UserWidget, const FMovieSceneContext& Context, IMovieScenePlayer& Player)
	{
		UE_LOG(LogTemp, Log, TEXT("Execute SubSequence Play"));

		UWidgetAnimation* WidgetAnimation = nullptr;
		UWidgetBlueprintGeneratedClass* WidgetBPClass = Cast<UWidgetBlueprintGeneratedClass>(UserWidget->GetClass());
		for (int32 Index = 0; Index < WidgetBPClass->Animations.Num(); Index++)
		{
			if (WidgetBPClass->Animations[Index] == Params.GetValidWidgetAnimation())
			{
				WidgetAnimation = WidgetBPClass->Animations[Index];
			}
		}

		if (WidgetAnimation)
		{
			// calculate the time at which to evaluate the animation
			const float AnimPlayRate = 1.0f;
			//float EvalTime = FFrameTime::FromDecimal((Context.GetTime() - Params.SectionStartTime).AsDecimal() * AnimPlayRate) / Context.GetFrameRate();
			float DeltaTime = Context.GetDelta() / Context.GetFrameRate();
			
			float EvalTime = Params.MapTimeToAnimation(WidgetAnimation->GetEndTime(), Context.GetTime(), Context.GetFrameRate());

			UUMGSequencePlayer* SequencePlayer = nullptr;
			for (int32 Index = 0; Index < UserWidget->ActiveSequencePlayers.Num(); Index++)
			{
				if (UserWidget->ActiveSequencePlayers[Index]->GetAnimation() == WidgetAnimation)
				{
					SequencePlayer = UserWidget->ActiveSequencePlayers[Index];
					break;
				}
			}
			if (!UserWidget->IsPlayingAnimation() 
				|| !SequencePlayer 
				|| SequencePlayer->IsStopping()
				|| SequencePlayer->GetPlaybackStatus() != EMovieScenePlayerStatus::Playing)
			{
				SequencePlayer = UserWidget->PlayAnimation(WidgetAnimation, EvalTime);
			}
			else /*if (DeltaTime == 0.0f)*/
			{
				SequencePlayer->SetCurrentTime(EvalTime);
				//SequencePlayer->Tick(0.0f);
			}

			FFrameTime CurrentPosition = FMath::Clamp(Context.GetTime(), FFrameTime(Params.SectionStartTime), FFrameTime(Params.SectionEndTime));
			bool bLastFrame = (FMath::Abs(CurrentPosition.GetFrame().Value + Context.GetDelta() - Params.SectionEndTime.Value) < 2
				|| CurrentPosition.GetFrame().Value + Context.GetDelta() >= Params.SectionEndTime.Value);
			if (bLastFrame)
			{
				SequencePlayer->Pause();
			}
		}
	}

	FMovieSceneWidgetSubSequenceSectionTemplateParameters Params;
};

FMovieSceneWidgetSubSequenceSectionTemplate::FMovieSceneWidgetSubSequenceSectionTemplate(const UMovieSceneWidgetSubSequenceSection& InSection)
	: Params(const_cast<FMovieSceneWidgetSubSequenceParams&> (InSection.Params), InSection.GetInclusiveStartFrame(), InSection.GetExclusiveEndFrame())
{
}

//We use a token here so we can set the manual tick state back to what it was previously when outside this section.
//This is similar to how Skeletal Animation evaluation also works.
void FMovieSceneWidgetSubSequenceSectionTemplate::Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const
{
	MOVIESCENE_DETAILED_SCOPE_CYCLE_COUNTER(MovieSceneEval_WidgetSubSequence_Evaluate)
		ExecutionTokens.Add(FWidgetSubSequenceExecutionToken(Params));
}

float FMovieSceneWidgetSubSequenceSectionTemplateParameters::MapTimeToAnimation(float ComponentDuration, FFrameTime InPosition, FFrameRate InFrameRate) const
{
	const float SequenceLength = ComponentDuration;
	const FFrameTime AnimationLength = SequenceLength * InFrameRate;
	const int32 LengthInFrames = AnimationLength.FrameNumber.Value + (int)(AnimationLength.GetSubFrame() + 0.5f) + 1;
	//we only play end if we are not looping, and assuming we are looping if Length is greater than default length;
	const bool bLooping = (SectionEndTime.Value - SectionStartTime.Value + StartFrameOffset + EndFrameOffset) > LengthInFrames;

	InPosition = FMath::Clamp(InPosition, FFrameTime(SectionStartTime), FFrameTime(SectionEndTime - 1));

	const float SectionPlayRate = PlayRate;
	const float AnimPlayRate = FMath::IsNearlyZero(SectionPlayRate) ? 1.0f : SectionPlayRate;

	const float FirstLoopSeqLength = SequenceLength - InFrameRate.AsSeconds(FirstLoopStartFrameOffset + StartFrameOffset + EndFrameOffset);
	const float SeqLength = SequenceLength - InFrameRate.AsSeconds(StartFrameOffset + EndFrameOffset);

	float AnimPosition = FFrameTime::FromDecimal((InPosition - SectionStartTime).AsDecimal() * AnimPlayRate) / InFrameRate;
	AnimPosition += InFrameRate.AsSeconds(FirstLoopStartFrameOffset);
	if (SeqLength > 0.f && (bLooping || !FMath::IsNearlyEqual(AnimPosition, SeqLength, 1e-4f)))
	{
		AnimPosition = FMath::Fmod(AnimPosition, SeqLength);
	}
	AnimPosition += InFrameRate.AsSeconds(StartFrameOffset);

	return AnimPosition;
}
