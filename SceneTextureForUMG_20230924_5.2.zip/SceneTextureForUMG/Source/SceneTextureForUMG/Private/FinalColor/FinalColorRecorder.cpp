// Copyright Qibo Pang 2022. All Rights Reserved.


#include "FinalColorRecorder.h"
#include "ObjectEditorUtils.h"

#define LOCTEXT_NAMESPACE "FinalColorRecorder"

UFinalColorRecorder::UFinalColorRecorder(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bIsVariable = false;
	Visibility = ESlateVisibility::SelfHitTestInvisible;
}

void UFinalColorRecorder::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);

	MyFinalColorRecorder.Reset();
}

void UFinalColorRecorder::NativeDestruct()
{
	Super::NativeDestruct();

	DestructEvent.Broadcast();
}

void UFinalColorRecorder::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	TickEvent.Broadcast();
}

TSharedRef<SWidget> UFinalColorRecorder::RebuildWidget()
{
	MyFinalColorRecorder = SNew(SFinalColorRecorder);

	return MyFinalColorRecorder.ToSharedRef();
}


#undef LOCTEXT_NAMESPACE


