// Copyright Qibo Pang 2023. All Rights Reserved.

#include "GeometryCacheToVATUtils.h"

namespace GeometryCacheToVAT_Private
{

TSoftObjectPtr<UTexture2D> CreateTexture(const FGeometryCacheToVATContext& Context, TSoftObjectPtr<UTexture2D>& InTexture, const FString InName, const FIntPoint InSize, const TArray<FVector4u16>& Data)
{
	InTexture.LoadSynchronous();
	InTexture = TSoftObjectPtr<UTexture2D>(CreateTexture(Context, InTexture.Get(), InName, InSize, Data));

	return InTexture;
}

TSoftObjectPtr<UTexture2D> CreateTexture(const FGeometryCacheToVATContext& Context, TSoftObjectPtr<UTexture2D>& InTexture, const FString InName, const FIntPoint InSize, const TArray<FColor>& Data)
{
	InTexture.LoadSynchronous();
	InTexture = TSoftObjectPtr<UTexture2D>(CreateTexture(Context, InTexture.Get(), InName, InSize, Data));

	return InTexture;
}

UTexture2D* InitializeTexture(const FGeometryCacheToVATContext& Context, UTexture2D* InTexture, const FString InName, const FIntPoint InSize, const ETextureSourceFormat SrcFormat)
{
	UTexture2D* NewTexture;

	if (IsValid(InTexture))
	{
		// Use existing texture
		const EObjectFlags InObjectFlags = /*Context->GetMaskedFlags() |*/ RF_Public | RF_Standalone;
		NewTexture = NewObject<UTexture2D>(InTexture->GetOuter(), InTexture->GetFName(), InObjectFlags);
	}
	else
	{
		// New texture
		const FString Name = Context.GetPackageNamespace() + "_" + InName;
		const FString PackagePath = Context.GetOutputPath();
		const FString SubFolder = FString("Textures");
		const FString AssetName = TEXT("T_") + InName;

		// Create texture asset
		NewTexture = CreateAsset<UTexture2D>(PackagePath, SubFolder, AssetName);
	}

	NewTexture->Source.Init(InSize.X, InSize.Y, 1, 1, SrcFormat);

	NewTexture->Filter = TextureFilter::TF_Nearest;
	NewTexture->NeverStream = true;
	NewTexture->SRGB = false;
	NewTexture->MipGenSettings = TextureMipGenSettings::TMGS_NoMipmaps;

	return NewTexture;
}

void WriteTextureData(UTexture2D* InTexture, const void* DataPtr)
{
	uint32* TextureData = (uint32*)InTexture->Source.LockMip(0);
	const int32 TextureDataSize = InTexture->Source.CalcMipSize(0);
	FMemory::Memcpy(TextureData, DataPtr, TextureDataSize);
	InTexture->Source.UnlockMip(0);
}

void FinalizeTexture(UTexture2D* InTexture)
{
	InTexture->Modify();
	InTexture->MarkPackageDirty();
	InTexture->PostEditChange();
	InTexture->UpdateResource();
}

UTexture2D* CreateTexture(const FGeometryCacheToVATContext& Context, UTexture2D* InTexture, const FString InName, const FIntPoint InSize, const TArray<FVector4u16>& Data)
{
	UTexture2D* NewTexture = InitializeTexture(Context, InTexture, InName, InSize, TSF_RGBA16F);

	NewTexture->CompressionSettings = TextureCompressionSettings::TC_HDR;

	WriteTextureData(NewTexture, Data.GetData());
	FinalizeTexture(NewTexture);
	InTexture = NewTexture;

	return NewTexture;
}

UTexture2D* CreateTexture(const FGeometryCacheToVATContext& Context, UTexture2D* InTexture, const FString InName, const FIntPoint InSize, const TArray<FColor>& Data)
{
	UTexture2D* NewTexture = InitializeTexture(Context, InTexture, InName, InSize, TSF_BGRA8);

	NewTexture->CompressionSettings = TextureCompressionSettings::TC_VectorDisplacementmap;

	/*WriteTextureData(NewTexture, Data.GetData());
	FinalizeTexture(NewTexture);*/
	InTexture = NewTexture;

	return NewTexture;
}

void ChangeTextureCompressionSettings(UTexture2D* InTexture, TextureCompressionSettings InTSC)
{
	if (IsValid(InTexture))
	{
		InTexture->CompressionSettings = InTSC;
		FinalizeTexture(InTexture);
	}
}


} // end namespace GeometryCacheToVAT_Private