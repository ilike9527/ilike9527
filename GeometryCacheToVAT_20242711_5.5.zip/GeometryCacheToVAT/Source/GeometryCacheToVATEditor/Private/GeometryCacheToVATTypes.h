// Copyright Qibo Pang 2023. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Containers/StaticArray.h"
#include "GPUSkinPublicDefs.h" 

#include "GeometryCacheToVATTypes.generated.h"

DECLARE_LOG_CATEGORY_EXTERN(LogGeometryCacheToVAT, Log, All);

class UMaterialInstance;
class UStaticMesh;
class UTexture2D;
class UGeometryCache;

namespace GeometryCacheToVAT_Private
{
	template <uint16 NumInfluences>
	struct TVertexSkinWeight
	{
		TStaticArray<uint16, NumInfluences> MeshBoneIndices;
		TStaticArray<uint8, NumInfluences>  BoneWeights;
	};

	using VertexSkinWeightMax = TVertexSkinWeight<MAX_TOTAL_INFLUENCES>;
	using VertexSkinWeightFour = TVertexSkinWeight<4>;

} // namespace GeometryCacheToVAT_Private

namespace GeometryCacheToVATParamNames
{
	static const FName Frame = TEXT("Frame");
	static const FName AutoPlay = TEXT("AutoPlay");
	static const FName StartFrame = TEXT("StartFrame");
	static const FName EndFrame = TEXT("EndFrame");
	static const FName SampleRate = TEXT("SampleRate");
	static const FName NumFrames = TEXT("NumFrames");
	static const FName MinBBox = TEXT("MinBBox");
	static const FName SizeBBox = TEXT("SizeBBox");
	static const FName NumBones = TEXT("NumBones");
	static const FName RowsPerFrame = TEXT("RowsPerFrame");
	static const FName BoneWeightRowsPerFrame = TEXT("BoneWeightsRowsPerFrame");
	static const FName VertexPositionTexture = TEXT("PositionTexture");
	static const FName VertexNormalTexture = TEXT("NormalTexture");
	static const FName BonePositionTexture = TEXT("BonePositionTexture");
	static const FName BoneRotationTexture = TEXT("BoneRotationTexture");
	static const FName BoneWeightsTexture = TEXT("BoneWeightsTexture");
	static const FName UseUV0 = TEXT("UseUV0");
	static const FName UseUV1 = TEXT("UseUV1");
	static const FName UseUV2 = TEXT("UseUV2");
	static const FName UseUV3 = TEXT("UseUV3");
	static const FName UseTwoInfluences = TEXT("UseTwoInfluences");
	static const FName UseFourInfluences = TEXT("UseFourInfluences");
}

USTRUCT(BlueprintType)
struct FGeometryCacheToVATInput
{
	GENERATED_BODY()
public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheToVAT", meta = (AllowPrivateAccess = "true"))
	UGeometryCache* GeometryCache = nullptr;

};


UENUM(Blueprintable)
enum class EGeometryCacheToVATPrecision : uint8
{
	/* 8 bits */
	EightBits,
	/* 16 bits */
	SixteenBits,
};

USTRUCT(BlueprintType)
struct FGeometryCacheToVATConfig
{
	GENERATED_BODY()

public:
	
	/**
	* StaticMesh LOD to bake to.
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "StaticMesh", Meta = (DisplayName = "LODIndex"))
	int32 StaticLODIndex = 0;

	/**
	* StaticMesh UVChannel Index for storing vertex information.
	* Make sure this index does not conflict with the Lightmap UV Index.
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "StaticMesh")
	int32 UVChannel = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "StaticMesh|Mapping")
	int32 MaxExportFrames = -1;

	//UPROPERTY(EditAnywhere, Category = "StaticMesh")
	bool bNaniteSupport = false;

	//UPROPERTY(EditAnywhere, Category = "StaticMesh")
	int32 NaniteTextureSize = 1024;

	// ------------------------------------------------------
	// Texture
	/**
	* Max resolution of the texture.
	* A smaller size will be used if the data fits.
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Texture")
	int32 MaxHeight = 4096;

	/**
	* Max resolution of the texture.
	* A smaller size will be used if the data fits.
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Texture")
	int32 MaxWidth = 4096;

	/**
	* Enforce Power Of Two on texture resolutions.
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Texture")
	bool bEnforcePowerOfTwo = false;

	/**
	* Texture Precision
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Texture")
	EGeometryCacheToVATPrecision Precision = EGeometryCacheToVATPrecision::SixteenBits;


	// ------------------------------------------------------
	// Animation

	/**
	* Adds transformation to baked textures.
	* This can be used for adding an offset to the animation.
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	FTransform RootTransform;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	float SampleRate = 30.0f;

	// ------------------------------------------------------
	// Material Layer Static Switches

	/**
	* AutoPlay will use Engine Time for driving the animation.
	* This will be used by UpdateMaterialInstanceFromDataAsset and AssetActions for setting MaterialInstance static switches
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Material")
	bool bAutoPlay = true;

	/**
	* Frame to play
	* When not using AutoPlay, user is responsible of setting the frame.
	* This will be used by UpdateMaterialInstanceFromDataAsset and AssetActions for setting MaterialInstance static switches
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Material", meta = (EditCondition = "!bAutoPlay"))
	int32 Frame = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Material")
	TArray<UMaterialInstance*> MaterialInstancesToUpdate;

	// If we weren't in a plugin, we could unify this in a base class
	template<typename AssetType>
	static AssetType* GetAsset(const TSoftObjectPtr<AssetType>& AssetPointer)
	{
		AssetType* ReturnVal = nullptr;
		if (AssetPointer.ToSoftObjectPath().IsValid())
		{
			ReturnVal = AssetPointer.Get();
			if (!ReturnVal)
			{
				AssetType* LoadedAsset = Cast<AssetType>(AssetPointer.ToSoftObjectPath().TryLoad());
				if (ensureMsgf(LoadedAsset, TEXT("Failed to load asset pointer %s"), *AssetPointer.ToString()))
				{
					ReturnVal = LoadedAsset;
				}
			}
		}
		return ReturnVal;
	}

};

USTRUCT(BlueprintType)
struct FGeometryCacheToVATOutput
{
	GENERATED_BODY()
public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheToVAT", meta = (RelativeToGameContentDir, LongPackageName))
		FDirectoryPath OutputFilePath;
};

USTRUCT(BlueprintType)
struct FGeometryCacheToVATContext
{
	GENERATED_BODY()

public:

	UPROPERTY(EditAnywhere, Category = "GeometryCacheToVAT", meta = (AllowPrivateAccess = "true"))
	FGeometryCacheToVATInput Input;

	UPROPERTY(EditAnywhere, Category = "GeometryCacheToVAT", meta = (AllowPrivateAccess = "true"))
	FGeometryCacheToVATConfig Config;

	UPROPERTY(EditAnywhere, Category = "GeometryCacheToVAT", meta = (AllowPrivateAccess = "true"))
	FGeometryCacheToVATOutput Output;

	/**
	* StaticMesh to bake to.
	*/
	TSoftObjectPtr<UStaticMesh> StaticMesh;

	/**
	* Texture for storing vertex positions
	* This is only used on Vertex Mode
	*/
	TSoftObjectPtr<UTexture2D> VertexPositionTexture;

	/**
	* Texture for storing vertex normals
	* This is only used on Vertex Mode
	*/
	TSoftObjectPtr<UTexture2D> VertexNormalTexture;


	TSoftObjectPtr<UTexture2D> Nanite = nullptr;

	// ------------------------------------------------------
	// Info
	/* Total Number of Frames in all animations */
	int32 NumFrames = 0;
	int32 VertexRowsPerFrame = 1;

	int32 TextureHeight;
	int32 TextureWidth;

	FVector3f VertexMinBBox;

	FVector3f VertexSizeBBox;

	UGeometryCache* GeometryCache = nullptr;
	TFunction<void(const FString&)> ErrorCallback = nullptr;
	TFunction<void(int32)> ProgressCallback = nullptr;
	FString CacheSubDirectoryName;

public:

	FString GetPackageNamespace() const
	{
		return TEXT("/Game/GeometryCache");
	}

	FString GetOutputPath() const
	{
		return FPaths::Combine(Output.OutputFilePath.Path, CacheSubDirectoryName);
	}

};

struct FGeometryCacheRenderMeshSection
{
	TArray<FVector3f> Positions;

	TArray<FPackedNormal> Normals;

	TArray<FColor> Colors;

	TArray<FVector2f> Uvs;
	TArray<FVector2f> UV1;
	TArray<FVector2f> UV2;
	TArray<FVector2f> UV3;

	TArray<uint32> Indices;

	UMaterialInterface* MaterialInterface = nullptr;

	FString SectionName = "NONE";
	FString MaterialName = "NONE";
};

struct FGeometryCacheRenderMesh
{
	TArray<FGeometryCacheRenderMeshSection> Sections;

	int32 GetTotalVertexCount() const
	{
		int32 TotalVertexCount = 0;
		for (const FGeometryCacheRenderMeshSection& Section : Sections)
		{
			TotalVertexCount += Section.Positions.Num();
		}
		return TotalVertexCount;
	}
};