// Copyright Qibo Pang 2023. All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Modules/ModuleManager.h"

DECLARE_LOG_CATEGORY_EXTERN(GeometryCacheToVATEditor, Log, All);

class  FGeometryCacheToVATEditorModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */


	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:


	TSharedRef<FExtender> OnExtendContentBrowserAssetSelectionMenu(const TArray<FAssetData>& SelectedAssets);
	FDelegateHandle ContentBrowserExtenderDelegateHandle;

	void AddMenuEntry(FMenuBuilder& MenuBuilder);
	void OnGeometryCacheToVATClicked();

	void RegisterCustomClassLayout(FName ClassName, FOnGetDetailCustomizationInstance DetailLayoutDelegate);
	TSet< FName > RegisteredClassNames;
};
