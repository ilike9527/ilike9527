// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SceneTextureForTextRenderer.h"
#include "RenderUtils.h"
#include "SceneTextureRecorder.h"
#include "SceneTextureForTextPostProcessor.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Materials/MaterialInterface.h"
#include "Blueprint/SlateBlueprintLibrary.h"
#include "Slate/SGameLayerManager.h"
#include "Engine/GameViewportClient.h"

FSceneTextureForTextRenderer::FSceneTextureForTextRenderer()
	: PostProcessor(new FSceneTextureForTextPostProcessor)
{
	;
}

FSceneTextureForTextRenderer::~FSceneTextureForTextRenderer()
{
	;
}

FSceneTextureForTextRenderer& FSceneTextureForTextRenderer::Get()
{
	static FSceneTextureForTextRenderer Renderer;
	return Renderer;
}

void FSceneTextureForTextRenderer::AddMaterialForSeeThroughText(UMaterialInstanceDynamic* MaterialInstanceDynamic, const UObject* WorldContextObject)
{
	if (MaterialInstanceDynamic)
	{
		MaterialsForSeeThroughText.Add(MaterialInstanceDynamic);
		
		if (!SceneTextureRecorder)
		{
			SceneTextureRecorder = CreateWidget<USceneTextureRecorder>(WorldContextObject->GetWorld(), USceneTextureRecorder::StaticClass());
			if (SceneTextureRecorder)
			{
				SceneTextureRecorder->DestructEvent.AddLambda([this]() {
					MaterialsForSeeThroughText.Empty();
					SceneTextureRecorder = nullptr;
					});
				SceneTextureRecorder->TickEvent.AddLambda([this]() {
					UpdateSceneTextureToMID();
					});

				// Keep this widget under all other widgets
				const int32 Recorder_Zorder = -999999;
				SceneTextureRecorder->AddToViewport(Recorder_Zorder);
			}
			else
			{
				UE_LOG(LogTemp, Warning, TEXT("Failed to create SceneCreate Texture Recorder Widget."));
			}
		}

		UpdateSceneTextureToMID();
	}
}

void FSceneTextureForTextRenderer::RemoveMaterialForSeeThroughText(UMaterialInstanceDynamic* MaterialInstanceDynamic)
{
	if (MaterialInstanceDynamic)
	{
		MaterialsForSeeThroughText.Remove(MaterialInstanceDynamic);
	}
}

static FVector2D GetViewportSize(UObject* WorldContextObject)
{
	UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);
	if (World && World->IsGameWorld())
	{
		if (UGameViewportClient* ViewportClient = World->GetGameViewport())
		{
			TSharedPtr<IGameLayerManager> GameLayerManager = ViewportClient->GetGameLayerManager();
			if (GameLayerManager.IsValid())
			{
				FVector2D ViewportSize;
				ViewportClient->GetViewportSize(ViewportSize);
				return ViewportSize;
			}
		}
	}
	return FVector2D::ZeroVector;
}

void FSceneTextureForTextRenderer::UpdateSceneTextureToMID()
{
	if (MaterialsForSeeThroughText.Num() == 0 || !SceneTextureRecorder)
	{
		return;
	}

	UTexture* SceneTexture = PostProcessor->GetSceneTexture();
	FVector4 Viewport_Transform = PostProcessor->GetViewportTransform();

	for (auto MID : MaterialsForSeeThroughText)
	{
		if (MID)
		{
			MID->SetTextureParameterValue(TEXT("SceneTexture_UMG"), SceneTexture);
			MID->SetVectorParameterValue(TEXT("Viewport_Transform"), FLinearColor(Viewport_Transform));
		}
	}
}