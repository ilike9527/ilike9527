// Copyright Qibo Pang 2023. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Components/MeshComponent.h"
#include "PhysicsEngine/ConvexElem.h"
#include "Interfaces/Interface_CollisionDataProvider.h"
#include "GeometryCacheMeshData.h"
#include "GeometryCacheSceneProxy.h"
#include "PrimitiveSceneProxy.h"
#include "Materials/MaterialInterface.h"

#include "DynamicMesh/DynamicMesh3.h"
#include "DynamicMesh/DynamicMeshAABBTree3.h"

#include "GeometryCacheDecalComponent.generated.h"

class UGeometryCacheComponent;
class UGeometryCache;
class FGeomCacheTrackProxy;
class FGeometryCacheSceneProxy;

DECLARE_DYNAMIC_DELEGATE_TwoParams(FLineTraceAttachDecalFinishedEvent, bool, bSuccess, const FString&, Message);

UENUM(BlueprintType)
enum class EGeometryCacheDecalType : uint8
{
	BoxRegion UMETA(DisplayName = "BoxRegion"),

	UVRegion UMETA(DisplayName = "UVRegion"),

};

USTRUCT()
struct FGeometryCacheOriginStatus
{
	GENERATED_USTRUCT_BODY()

	UGeometryCacheComponent* GeometryCacheComponent = nullptr;

	UGeometryCache* GeometryCache = nullptr;
	
	FGeometryCacheSceneProxy* GeometryCacheSceneProxy = nullptr;

	class UGeometryCacheDecalComponent* GeometryCacheDecalComponent = nullptr;

	bool bStatusReseted = false;

	FGeometryCacheOriginStatus() = default;

	FGeometryCacheOriginStatus(UGeometryCacheComponent* InGeometryCacheComponent, UGeometryCacheDecalComponent* InGeometryCacheDecalComponent);

	bool IsValid()
	{
		return GeometryCacheComponent && GeometryCache && GeometryCacheSceneProxy;
	}

	bool ResetWhenChanged();

	void Clear()
	{
		GeometryCacheComponent = nullptr;
		GeometryCacheDecalComponent = nullptr;
		GeometryCache = nullptr;
		GeometryCacheSceneProxy = nullptr;
		AnimationTime = -1.0f;
		bStatusReseted = true;
	}

	bool CheckStatusChanged();

	bool TracksInited();

private:

	float AnimationTime = -1.0f;
};

USTRUCT(BlueprintType)
struct FGeometryCacheDecalLocation
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		int32 TrackIndex = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		int32 TriangleIndex = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		FVector BaryCentric;
};


USTRUCT(BlueprintType)
struct FGeometryCacheLineHitResult
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		int32 TrackIndex = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		int32 TriangleIndex = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		FVector BaryCentric;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		float NearestDistance = 0.0f;
};

USTRUCT()
struct FGeometryCacheDecaledTriangle
{
	GENERATED_USTRUCT_BODY()

	FGeometryCacheDecaledTriangle() {}

	FGeometryCacheDecalLocation AttachLocation;

	FVector3f AttachPosition;

	FVector3f AttachNormal;

	FTransform AttachTransform;

	FVector2f AttachUV;

	int32 FrameIndex = -1;
	float InterpolationFactor = -1.0f;

	bool bFrameUpdated = false;
};

USTRUCT(BlueprintType)
struct FGeometryCacheDecalUVInfo
{
	GENERATED_USTRUCT_BODY()

	FGeometryCacheDecalUVInfo() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		FVector2D DecalRegion = FVector2D(1.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		FVector2D DecalUVCenter = FVector2D(0.5f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		float DecalRotation = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		bool bGenerateDecalUV = true;
};

UENUM(BlueprintType)
enum class EGeometryCacheDecalBoxUVToward : uint8
{
	UVTowardXAxis UMETA(DisplayName = "UVTowardXAxis"),

	UVTowardYAxis UMETA(DisplayName = "UVTowardYAxis"),

	UVTowardZAxis UMETA(DisplayName = "UVTowardZAxis"),
};

USTRUCT(BlueprintType)
struct FGeometryCacheDecalBoxInfo
{
	GENERATED_USTRUCT_BODY()

	FGeometryCacheDecalBoxInfo() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		FVector DecalRegion = FVector(100.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		FVector DecalCenter = FVector(0.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		FVector DecalRotation = FVector(0.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		bool bGenerateDecalUV = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		int32 RematchDimensions = 500;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		EGeometryCacheDecalBoxUVToward UVToward = EGeometryCacheDecalBoxUVToward::UVTowardZAxis;
};

USTRUCT(BlueprintType)
struct FGeometryCacheDecalInfo
{
	GENERATED_USTRUCT_BODY()

	FGeometryCacheDecalInfo() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		EGeometryCacheDecalType DecalType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		FGeometryCacheDecalUVInfo DecalUVInfo;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		FGeometryCacheDecalBoxInfo DecalBoxInfo;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		UMaterialInterface* DecalMaterial = nullptr;

};

/** Stores the BVH tree info for each individual track */
USTRUCT()
struct FGeometryCacheTrackDecalData
{
	GENERATED_USTRUCT_BODY()

	FGeometryCacheTrackDecalData() {}

	/** Position buffer for this track */
	TArray<FVector3f> PositionBuffer;

	/** UV buffer for this track */
	TArray<FVector2f> UVBuffer;

	/** Index buffer for this track */
	TArray<uint32> IndexBuffer;

	TArray<FPackedNormal> TangentsX;
	TArray<FPackedNormal> TangentsZ;

	TArray<int32> OriginVerticeIndex;

	/** Array of per-batch info structs*/
	TArray<FGeometryCacheMeshBatchInfo> BatchesInfo;

	bool TopologyCompatible = false;
	bool bNewGeneratedDecal = false;

	int32 FrameIndex = -1;
	int32 DecalGenerateFrameIndex = -1;

	TArray< TArray<FVector> > RematchMap;
	FVector2D OriginUVMin;
	FVector2D OriginUVMax;
	FVector2D RematchStepSize;

	/** Transform matrix used to render this specific track.
		This goes from track local space to component local space.
	*/
	FMatrix Matrix;

	/** Bounding box of this specific track */
	FBox BoundingBox;

	/** Sample Id's of the values we currently have registered the component with. */
	int32 MatrixSampleIndex;
	int32 BoundsSampleIndex;

	void Clear()
	{
		IndexBuffer.Empty();

		PositionBuffer.Empty();

		UVBuffer.Empty();

		TangentsX.Empty();
		TangentsZ.Empty();

		FrameIndex = -1;
		TopologyCompatible = false;
		BatchesInfo.Empty();

		BoundingBox.Init();
	}

	void Prepare(int32 NumVertices)
	{
		if (NumVertices != PositionBuffer.Num())
		{
			// Clear entries but keep allocations.
			PositionBuffer.Reset();
			TangentsX.Reset();
			TangentsZ.Reset();
			UVBuffer.Reset();

			// Make sure our capacity fits the requested vertex count
			PositionBuffer.Reserve(NumVertices);
			TangentsX.Reserve(NumVertices);
			TangentsZ.Reserve(NumVertices);
			UVBuffer.Reserve(NumVertices);

			PositionBuffer.AddUninitialized(NumVertices);
			TangentsX.AddUninitialized(NumVertices);
			TangentsZ.AddUninitialized(NumVertices);
			UVBuffer.AddUninitialized(NumVertices);
		}
	}

	void UpdateIndices(const TArray<uint32>& InIndexBuffer)
	{
		IndexBuffer = InIndexBuffer;
	}

	void UpdatePositions(const TArray<FVector3f>& InPositionBuffer)
	{
		PositionBuffer = InPositionBuffer;
	}

	void UpdateUVs(const TArray<FVector2f>& InUVBuffer)
	{
		UVBuffer = InUVBuffer;
	}
};

/** updating frame data from GeometryCache and  drawing decal */
class UGeometryCacheDecalSceneProxy final : public FPrimitiveSceneProxy
{
public:
	SIZE_T GetTypeHash() const override
	{
		static size_t UniquePointer;
		return reinterpret_cast<size_t>(&UniquePointer);
	}

	UGeometryCacheDecalSceneProxy(UGeometryCacheDecalComponent* Component);

	virtual ~UGeometryCacheDecalSceneProxy();

	virtual void GetDynamicMeshElements(const TArray<const FSceneView*>& Views, const FSceneViewFamily& ViewFamily, uint32 VisibilityMap, FMeshElementCollector& Collector) const override;

	virtual FPrimitiveViewRelevance GetViewRelevance(const FSceneView* View) const override;

	virtual bool CanBeOccluded() const override;
	virtual bool IsUsingDistanceCullFade() const override;
	virtual uint32 GetMemoryFootprint(void) const;
	uint32 GetAllocatedSize(void) const;

	void UpdateDecalFrame() const;

	bool GenerateDecalMesh(bool bNextFrame = false) const;
	bool GenerateDecalMeshInUVRegion(FGeomCacheTrackProxy* TrackProxy, const FGeometryCacheDecalUVInfo& DecalInfo, bool bNextFrame = false) const;
	bool GenerateDecalMeshInBoxRegion(FGeomCacheTrackProxy* TrackProxy, const FGeometryCacheDecalBoxInfo& DecalBoxInfo, bool bNextFrame = false) const;

#if RHI_RAYTRACING
	virtual bool IsRayTracingRelevant() const override { return true; }
	virtual bool HasRayTracingRepresentation() const override { return true; }

	virtual void GetDynamicRayTracingInstances(FRayTracingMaterialGatheringContext& Context, TArray<FRayTracingInstance>& OutRayTracingInstances) override final;

#endif


public:

	FGeometryCacheTrackDecalData* DecalGeometryData = nullptr;

	FGeometryCacheSceneProxy* GeometryCacheSceneProxy = nullptr;

private:

	class FDecalGeometryCacheVertexFactoryUserDataWrapper : public FOneFrameResource
	{
	public:
		FGeometryCacheVertexFactoryUserData Data;
	};
	
	void CreateMeshBatch(
		const FGeomCacheTrackProxy* TrackProxy,
		const FGeometryCacheTrackDecalData* GeometryData,
		const FGeometryCacheMeshBatchInfo& BatchInfo,
		FDecalGeometryCacheVertexFactoryUserDataWrapper& UserDataWrapper,
		FDynamicPrimitiveUniformBuffer& DynamicPrimitiveUniformBuffer,
		FMeshBatch& Mesh) const;

	void SubmitSectionBuffer_RenderThread() const;

private:

	FMaterialRelevance MaterialRelevance;

	int32 NumSides;

	uint32 UpdatedFrameNum;

	class UGeometryCacheDecalComponent* GeometryCacheDecalComponent = nullptr;

	FGeomCacheTrackProxy* DecalTrackProxy = nullptr;

	float PreTime = -1.0f;

#if WITH_EDITOR
	TArray<FHitProxyId> HitProxyIds;
#endif

};

/** An ActorComponent adding collision for GeometryCache */
UCLASS(ClassGroup = (GeometryCache), meta = (BlueprintSpawnableComponent))
class GEOMETRYCACHEDECAL_API UGeometryCacheDecalComponent : public UMeshComponent
{
	GENERATED_UCLASS_BODY()

	friend class UGeometryCacheDecalSceneProxy;

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		int32 DecalTrackIndex = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		EGeometryCacheDecalType DecalType = EGeometryCacheDecalType::BoxRegion;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		FGeometryCacheDecalUVInfo DecalUVInfo;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		FGeometryCacheDecalBoxInfo DecalBoxInfo;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheDecal")
		UMaterialInterface* DecalMaterial = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Debug")
		bool bShowDecalWireFrame = false;

public:

	/** Trace a ray to GeometryCache, and attach element to the hit surface */
	UFUNCTION(BlueprintCallable, Category = "GeometryCacheDecal")
		void LineTraceAttachDecal(const FVector& WorldStart, const FVector& WorldEnd, const FGeometryCacheDecalInfo& InDecalInfo, const FLineTraceAttachDecalFinishedEvent& FinishedEvent);

	/** Attach component at target location */
	UFUNCTION(BlueprintCallable, Category = "GeometryCacheDecal")
		bool AttachDecalAtLocation(const FGeometryCacheDecalLocation& AttachLocation, const FGeometryCacheDecalInfo& InDecalInfo, const FTransform& ElementTransform);

	
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

public:

	//~ Begin USceneComponent Interface.
	virtual FBoxSphereBounds CalcBounds(const FTransform& LocalToWorld) const override;
	//~ Begin USceneComponent Interface.

	//~ Begin UActorComponent Interface.
	virtual void OnRegister() override;
	virtual void OnUnregister() override;
	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	//~ End UActorComponent Interface.

	//~ Begin UPrimitiveComponent Interface.
	virtual FPrimitiveSceneProxy* CreateSceneProxy() override;
	virtual void GetUsedMaterials(TArray<UMaterialInterface*>& OutMaterials, bool bGetDebugMaterials = false) const override;
	//~ End UPrimitiveComponent Interface.

	//~ Begin UMeshComponent Interface.
	virtual int32 GetNumMaterials() const override { return 1; }
	virtual UMaterialInterface* GetMaterial(int32 ElementIndex) const override { return DecalMaterial; }
	virtual void SetMaterial(int32 ElementIndex, UMaterialInterface* InMaterial) override;
	//~ End UMeshComponent Interface.

	UGeometryCacheComponent* GetGeometryCacheComponent() { return GeometryCacheStatus.GeometryCacheComponent; }

	bool LineTraceGeometryCache(const FVector& WorldStart, const FVector& WorldEnd, FGeometryCacheLineHitResult& Result);

	bool UpdateFrameData();

private:
	
	bool ResetGeometryCacheStatusWhenChanged(bool bForceReset);

	void ClearGeometryCacheStatus();

	void CreateTrackData();
	void ClearTrackData();

	void BuildGeometryCacheMeshBVH();

	bool UpdateTrackSection(int32 TrackIndex);

	void UpdateLocalBounds();

	int FindNearestTriangle(const FVector3d& P, double& NearestDistSqr, int32& NearestTrackIndex) const;

	bool CalculateVerticeInfoAtAttachedLocation(const FGeometryCacheDecalLocation& AttachLocation, FTransform& Transform, FVector2f& UV);

	bool RematchAttachLocation(FGeometryCacheDecaledTriangle& AttachedTriangle, FGeometryCacheMeshData* MeshDataToUse);

private:

	UPROPERTY()
		FGeometryCacheOriginStatus GeometryCacheStatus;

	//UPROPERTY(VisibleAnywhere, Category = "GeometryCacheDecal")
		int32 NumTracks;

	/** Local space bounds of mesh */
	UPROPERTY()
		FBoxSphereBounds LocalBounds;

	TArray<FGeometryCacheTrackDecalData*> TrackSections;

	TArray<TUniquePtr<UE::Geometry::FDynamicMesh3>> TrackMeshs;
	TArray<TUniquePtr<UE::Geometry::FDynamicMeshAABBTree3>> TrackMeshSpatials;

	float PreviousTime = 0.0f;

	float AccumulateDeltaTime = 0.0f;

	bool bRuntimeTicking = false;
	bool bRuntimeInited = false;

	bool bFrameUpdated = false;
};
