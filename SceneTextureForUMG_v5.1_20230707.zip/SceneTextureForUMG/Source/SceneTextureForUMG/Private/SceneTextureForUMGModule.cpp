// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SceneTextureForUMGModule.h"
#include "Interfaces/IPluginManager.h"
#include "Misc/Paths.h"
#include "ShaderCore.h"
#include "SceneTextureForUMGRenderer.h"
#include "SceneTextureForUMGSettings.h"

#if WITH_EDITOR
#include "ISettingsModule.h"	// Settings
#include "ISettingsSection.h"	// Settings
#include "ISettingsContainer.h"	// Settings

const char* const ConfigCantainer = "Project";
const char* const ConfigSection = "SceneTextureForUMG Settings";

#endif

#define LOCTEXT_NAMESPACE "FSceneTextureForUMGModule"

void FSceneTextureForUMGModule::StartupModule()
{
	FString PluginShaderDir = FPaths::Combine(IPluginManager::Get().FindPlugin(TEXT("SceneTextureForUMG"))->GetBaseDir(), TEXT("Shaders"));
	AddShaderSourceDirectoryMapping(TEXT("/Plugin/SceneTextureForUMG"), PluginShaderDir);

	RegisterSettings();
}

void FSceneTextureForUMGModule::ShutdownModule()
{
#if WITH_EDITOR
	//FSceneTextureForUMGRenderer::Get().ReleaseRenderResources();
#endif
	UnregisterSettings();
}

void FSceneTextureForUMGModule::RegisterSettings()
{
	return;
#if WITH_EDITOR
	//-- register settings
	ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings");
	if (SettingsModule && !bSettingRegistered) {

		bSettingRegistered = true;

		FName ContainerName(ConfigCantainer);
		FName SectionName(ConfigSection);

		// create new category for MVM
		ISettingsContainerPtr SettingsContainer = SettingsModule->GetContainer(ContainerName);

		ISettingsSectionPtr SettingsSection = SettingsModule->RegisterSettings(ContainerName,
			"Project",
			SectionName,
			FText::FromString(TEXT("SceneTextureForUMG")),
			FText::FromString(TEXT("SceneTextureForUMG Settings")),
			GetMutableDefault<USceneTextureForUMGSettings>()
		);

	}// end of if
#endif
}

void FSceneTextureForUMGModule::UnregisterSettings()
{
	if (!UObjectInitialized() || !bSettingRegistered)
		return;

#if WITH_EDITOR
	//-- unregister settings
	ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings");
	if (SettingsModule) {
		SettingsModule->UnregisterSettings(
			ConfigCantainer,
			"Project",
			ConfigSection
		);
	}
#endif
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FSceneTextureForUMGModule, SceneTextureForUMG)