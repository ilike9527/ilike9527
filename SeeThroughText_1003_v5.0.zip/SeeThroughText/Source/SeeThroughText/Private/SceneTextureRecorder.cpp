// Copyright Qibo Pang 2022. All Rights Reserved.


#include "SceneTextureRecorder.h"
#include "ObjectEditorUtils.h"

#define LOCTEXT_NAMESPACE "SceneTextureRecorder"

USceneTextureRecorder::USceneTextureRecorder(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bIsVariable = false;
	Visibility = ESlateVisibility::SelfHitTestInvisible;
}

void USceneTextureRecorder::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);

	MySceneTextureRecorder.Reset();
}

void USceneTextureRecorder::NativeDestruct()
{
	Super::NativeDestruct();

	DestructEvent.Broadcast();
}

void USceneTextureRecorder::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	TickEvent.Broadcast();
}

TSharedRef<SWidget> USceneTextureRecorder::RebuildWidget()
{
	MySceneTextureRecorder = SNew(SSceneTextureRecorder);

	return MySceneTextureRecorder.ToSharedRef();
}


#undef LOCTEXT_NAMESPACE


