// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SceneTextureForTextShaders.h"
#include "Rendering/RenderingCommon.h"
#include "PipelineStateCache.h"

//IMPLEMENT_TYPE_LAYOUT(FSceneTextureForTextCopyPS);

IMPLEMENT_SHADER_TYPE(, FSceneTextureForTextCopyPS,         TEXT("/Plugin/SeeThroughText/Private/SeeThroughTextPixelShader.usf"), TEXT("CopysampleMain"), SF_Pixel);

void FSceneTextureForTextCopyPS::ModifyCompilationEnvironment(const FGlobalShaderPermutationParameters& Parameters, FShaderCompilerEnvironment& OutEnvironment)
{
	static const auto CVar = IConsoleManager::Get().FindTConsoleVariableDataInt(TEXT("r.HDR.Display.OutputDevice"));
	OutEnvironment.SetDefine(TEXT("USE_709"), CVar ? (CVar->GetValueOnGameThread() == 1) : 1);
}
