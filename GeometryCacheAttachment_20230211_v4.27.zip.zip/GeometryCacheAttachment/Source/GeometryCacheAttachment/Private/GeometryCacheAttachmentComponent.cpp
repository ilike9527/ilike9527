// Copyright Qibo Pang 2023. All Rights Reserved.

#include "GeometryCacheAttachmentComponent.h"
#include "GeometryCacheComponent.h"
#include "GeometryCache.h"
#include "GeometryCacheSceneProxy.h"
#include "GeometryCacheTrack.h"

#include "Engine.h"
#include "Async/Async.h"
#include "PhysicsEngine/BodySetup.h"
#include "MaterialShared.h"
#include "Materials/Material.h"
#include "PhysicsEngine/PhysicsSettings.h"

#define LOCTEXT_NAMESPACE "GeometryCacheAttachmentComponent"

//////////////////////////////////////////////////////////////////////////

FGeometryCacheParentStatus::FGeometryCacheParentStatus(UGeometryCacheComponent* InGeometryCacheComponent)
	: GeometryCacheComponent(InGeometryCacheComponent)
{
	if (InGeometryCacheComponent)
	{
		GeometryCache = InGeometryCacheComponent->GetGeometryCache();
		if (FGeometryCacheSceneProxy* SceneProxy = static_cast<FGeometryCacheSceneProxy*>(InGeometryCacheComponent->SceneProxy))
		{
			GeometryCacheSceneProxy = SceneProxy;
		}
		AnimationTime = GeometryCacheComponent->GetAnimationTime();
	}
}

bool FGeometryCacheParentStatus::ResetWhenChanged()
{
	if (GeometryCacheComponent)
	{
		if (GeometryCacheComponent->GetGeometryCache() != GeometryCache
			|| GeometryCacheComponent->SceneProxy != GeometryCacheSceneProxy)
		{
			if (FGeometryCacheSceneProxy* SceneProxy = static_cast<FGeometryCacheSceneProxy*>(GeometryCacheComponent->SceneProxy))
			{
				const TArray<FGeomCacheTrackProxy*>& Tracks = SceneProxy->GetTracks();
				bool bAllTrackInited = Tracks.Num() > 0;
				for (FGeomCacheTrackProxy* Track: Tracks)
				{
					if (Track->FrameIndex == -1 && Track->NextFrameIndex == -1)
					{
						bAllTrackInited = false;
						break;
					}
				}

				if (bAllTrackInited)
				{
					GeometryCache = GeometryCacheComponent->GetGeometryCache();
					GeometryCacheSceneProxy = SceneProxy;
				
					AnimationTime = GeometryCacheComponent->GetAnimationTime();
					return true;
				}
			}
		}
	}

	return false;
}

bool FGeometryCacheParentStatus::TracksInited()
{
	if (GeometryCacheSceneProxy)
	{
		const TArray<FGeomCacheTrackProxy*>& Tracks = GeometryCacheSceneProxy->GetTracks();
		bool bAllTrackInited = Tracks.Num() > 0;
		for (FGeomCacheTrackProxy* Track : Tracks)
		{
			if (!Track || (Track->FrameIndex == -1 && Track->NextFrameIndex == -1))
			{
				bAllTrackInited = false;
				break;
			}
		}

		return bAllTrackInited;
	}
	return false;
}

bool FGeometryCacheParentStatus::CheckStatusChanged()
{
	if (GeometryCacheComponent && !FMath::IsNearlyEqual(GeometryCacheComponent->GetAnimationTime(), AnimationTime))
	{
		AnimationTime = GeometryCacheComponent->GetAnimationTime();
		return true;
	}
	return false;
}

//////////////////////////////////////////////////////////////////////////


UGeometryCacheAttachmentComponent::UGeometryCacheAttachmentComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bStartWithTickEnabled = true;
	PrimaryComponentTick.bCanEverTick = true;
	bTickInEditor = true;
}

void UGeometryCacheAttachmentComponent::BeginPlay()
{
	Super::BeginPlay();
	
	if (GeometryCacheStatus.GeometryCacheComponent == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("UGeometryCacheAttachmentComponent: Failed to find geometry cache component. (%s)"), *(GetOwner()->GetName()));
	}

	bRuntimeTicking = true;
	bRuntimeInited = false;
}

void UGeometryCacheAttachmentComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	bRuntimeTicking = false;
	bRuntimeInited = false;
}

void UGeometryCacheAttachmentComponent::OnRegister()
{
	ResetGeometryCacheStatusWhenChanged(true);

	Super::OnRegister();
}

void UGeometryCacheAttachmentComponent::OnUnregister()
{
	Super::OnUnregister();
	
	ClearGeometryCacheStatus();
}

void UGeometryCacheAttachmentComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	auto NeedUpdate = [this, DeltaTime]()
	{
		if (AttachedElements.Num() == 0)
		{
			return false;
		}

		ResetGeometryCacheStatusWhenChanged(false);
		if (GeometryCacheStatus.bStatusReseted)
		{
			GeometryCacheStatus.bStatusReseted = false;
			return true;
		}

		if (!this->bRuntimeTicking)
		{
			return GeometryCacheStatus.CheckStatusChanged();
		}

		if (!bRuntimeInited)
		{
			if (GeometryCacheStatus.TracksInited())
			{
				bRuntimeInited = true;
				return true;
			}
		}
		else
		{
			return true;// GeometryCacheStatus.GeometryCacheComponent->IsPlaying();
		}

		return false;
	};

	if (NeedUpdate())
	{

		ENQUEUE_RENDER_COMMAND(FGeometryCacheAttachAllUpdate)(
			[this](FRHICommandList& RHICmdList)
			{
				if (this->UpdateAttachedTriangles())
				{
					AsyncTask(ENamedThreads::GameThread, [this] {
						UpdateAttachedElements();
					});
				}
				else
				{
					UE_LOG(LogTemp, Warning, TEXT("UGeometryCacheAttachmentComponent: Failed to UpdateFrameData. (%s)"), *(GetOwner()->GetName()));
				}
			}
		);
	}
}

bool UGeometryCacheAttachmentComponent::ResetGeometryCacheStatusWhenChanged(bool bForceReset)
{
	if (bForceReset)
	{
		UGeometryCacheComponent* GeometryCacheComponent = Cast<UGeometryCacheComponent>(GetOwner()->GetComponentByClass(UGeometryCacheComponent::StaticClass()));
		GeometryCacheStatus = FGeometryCacheParentStatus(GeometryCacheComponent);
	}

	if (bForceReset || GeometryCacheStatus.ResetWhenChanged())
	{
		if (GeometryCacheStatus.GeometryCacheComponent)
		{
			FVector ToWorldScale3D = GetRelativeScale3D() * GeometryCacheStatus.GeometryCacheComponent->GetRelativeScale3D();
			if ((ToWorldScale3D - FVector::OneVector).IsNearlyZero()
				&& GetRelativeLocation() == FVector::ZeroVector
				&& GetRelativeRotation() == FRotator::ZeroRotator)
			{
				ResetRelativeTransform();
			}
		}

		//SynchronizationCollisionSettings();
		
		GeometryCacheStatus.bStatusReseted = true;
		return true;
	}

	return false;
}

void UGeometryCacheAttachmentComponent::ClearGeometryCacheStatus()
{
	GeometryCacheStatus.Clear();

	ClearTrackData();
}

void UGeometryCacheAttachmentComponent::CreateTrackData()
{
	FGeometryCacheSceneProxy* GeometryCacheSceneProxy = static_cast<FGeometryCacheSceneProxy*>(GetGeometryCacheComponent()->SceneProxy);
	if (GeometryCacheSceneProxy)
	{
		const TArray<FGeomCacheTrackProxy*>& Tracks = GeometryCacheSceneProxy->GetTracks();
		for (int Index = 0; Index < Tracks.Num(); Index++)
		{
			FGeometryCacheSectionData* SectionData = new FGeometryCacheSectionData();
			TrackSections.Add(SectionData);
		}
	}
}

void UGeometryCacheAttachmentComponent::ClearTrackData()
{
	NumTracks = 0;

	for (int Index = 0; Index < TrackSections.Num(); Index++)
	{
		delete TrackSections[Index];
	}
	TrackSections.Empty();
}

bool UGeometryCacheAttachmentComponent::LineTraceGeometryCache(const FVector& WorldStart, const FVector& WorldEnd, FGeometryCacheLineTraceResult& Result)
{
	Result.TriangleIndex = -1;
	Result.TrackIndex = -1;
	Result.NearestDistance = BIG_NUMBER;

	FVector  NearestIntersectPoint;
	FVector LocalStart = GetComponentTransform().InverseTransformPosition(WorldStart);
	FVector LocalEnd = GetComponentTransform().InverseTransformPosition(WorldEnd);
	
	FVector IntersectPoint, TriangleNormal;
	for (int32 SectionIndex = 0; SectionIndex < TrackSections.Num(); ++SectionIndex)
	{
		FGeometryCacheSectionData* SectionData = TrackSections[SectionIndex];
		TArray<FVector>& PositionBuffer = SectionData->PositionBuffer;
		TArray<FVector2D>& UVBuffer = SectionData->UVBuffer;
		TArray<uint32>& IndexBuffer = SectionData->IndexBuffer;
		for (int32 i = 0; i + 2 < IndexBuffer.Num(); i += 3)
		{
			const FVector& v0 = PositionBuffer[IndexBuffer[i]];
			const FVector& v1 = PositionBuffer[IndexBuffer[i + 1]];
			const FVector& v2 = PositionBuffer[IndexBuffer[i + 2]];
			if (FMath::SegmentTriangleIntersection(LocalStart, LocalEnd, v0, v1, v2, IntersectPoint, TriangleNormal))
			{
				float Dist = (IntersectPoint - LocalStart).Size();
				if (Dist < Result.NearestDistance)
				{
					NearestIntersectPoint = IntersectPoint;
					Result.NearestDistance = Dist;
					SectionIndex = SectionIndex;
					Result.TrackIndex = SectionIndex;
					Result.TriangleIndex = i / 3;
					Result.BaryCentric = FMath::ComputeBaryCentric2D(NearestIntersectPoint, v0, v1, v2);
				}
			}
		}
	}
	if (Result.TriangleIndex >= 0 && Result.TrackIndex >= 0)
	{
		return true;
	}
		
	return false;
}

//////////////////////////////////////////////////////////////////////////

inline FVector ComputeTriangleNormal(const FVector& InVertexA, const FVector& InVertexB, const FVector& InVertexC)
{
	return FVector::CrossProduct(InVertexC - InVertexA, InVertexB - InVertexA).GetSafeNormal();
}

bool UGeometryCacheAttachmentComponent::RematchAttachLocation(FGeometryCacheAttachedTriangle& AttachedTriangle, FGeometryCacheMeshData* MeshDataToUse)
{
	check(IsInRenderingThread());

	if (!MeshDataToUse || MeshDataToUse->TextureCoordinates.Num() == 0)
	{
		return false;
	}

	auto VectorSign = [](const FVector2D& Vec, const FVector2D& A, const FVector2D& B)
	{
		return FMath::Sign((B.X - A.X) * (Vec.Y - A.Y) - (B.Y - A.Y) * (Vec.X - A.X));
	};

	auto IsPointInTriangle = [VectorSign](const FVector2D& TestPoint, const FVector2D& A, const FVector2D& B, const FVector2D& C)
	{
		float BA = VectorSign(B, A, TestPoint);
		float CB = VectorSign(C, B, TestPoint);
		float AC = VectorSign(A, C, TestPoint);

		// point is in the same direction of all 3 tri edge lines
		// must be inside, regardless of tri winding
		return BA == CB && CB == AC;
	};

	bool RematchSuccess = false;

	FVector2D AttachUV = AttachedTriangle.AttachUV;
	TArray<uint32>& Indices = MeshDataToUse->Indices;
	TArray<FVector2D>& TextureCoordinates = MeshDataToUse->TextureCoordinates;
	for (int32 TriIndex = 0; TriIndex < Indices.Num(); TriIndex += 3)
	{
		const FVector2D& uv0 = TextureCoordinates[Indices[TriIndex]];
		const FVector2D& uv1 = TextureCoordinates[Indices[TriIndex + 1]];
		const FVector2D& uv2 = TextureCoordinates[Indices[TriIndex + 2]];

		if (uv0.X < AttachUV.X && uv1.X < AttachUV.X && uv2.X < AttachUV.X
			|| uv0.X > AttachUV.X && uv1.X > AttachUV.X && uv2.X > AttachUV.X
			|| uv0.Y < AttachUV.Y && uv1.Y < AttachUV.Y && uv2.Y < AttachUV.Y
			|| uv0.Y > AttachUV.Y && uv1.Y > AttachUV.Y && uv2.Y > AttachUV.Y)
		{
			continue;
		}

		if (IsPointInTriangle(AttachUV, uv0, uv1, uv2))
		{
			AttachedTriangle.AttachLocation.TriangleIndex = (TriIndex / 3);
			RematchSuccess = true;
			break;
		}
	}

	return RematchSuccess;
}

bool UGeometryCacheAttachmentComponent::UpdateAttachedTriangles()
{
	check(IsInRenderingThread());

	if (!GetGeometryCacheComponent() || !GetGeometryCacheComponent()->SceneProxy)
	{
		return false;
	}

	FGeometryCacheSceneProxy* GeometryCacheSceneProxy = static_cast<FGeometryCacheSceneProxy*>(GetGeometryCacheComponent()->SceneProxy);
	if (!GeometryCacheSceneProxy)
	{
		return false;
	}

	if (AttachedTriangles.Num() != AttachedElements.Num())
	{
		AttachedTriangles.Empty();
		for (int Index = 0; Index < AttachedElements.Num(); Index++)
		{
			FGeometryCacheAttachedTriangle AttachedTriangle;
			AttachedTriangle.AttachLocation = AttachedElements[Index].AttachLocation;
			AttachedTriangles.Add(AttachedTriangle);
		}
	}
	

	const TArray<FGeomCacheTrackProxy*>& Tracks = GeometryCacheSceneProxy->GetTracks();
	UGeometryCacheComponent* GeometryCacheComponent = GetGeometryCacheComponent();

	float Time = GeometryCacheComponent->GetAnimationTime();
	bool bLooping = GeometryCacheComponent->IsLooping();
	bool bExtrapolateFrames = GeometryCacheComponent->IsExtrapolatingFrames();

	for (int32 AttachIndex = 0; AttachIndex < AttachedElements.Num(); AttachIndex++)
	{
		FGeometryCacheAttachedTriangle& AttachedTriangle = AttachedTriangles[AttachIndex];
		FGeometryCacheAttachLocation& AttachLocation = AttachedElements[AttachIndex].AttachLocation;
		int32 TrackIndex = AttachLocation.TrackIndex;
		FGeomCacheTrackProxy* TrackProxy = Tracks[TrackIndex];
		if (TrackProxy != nullptr)
		{
			const FVisibilitySample& VisibilitySample = TrackProxy->GetVisibilitySample(Time, bLooping);
			if (!VisibilitySample.bVisibilityState)
			{
				continue;
			}

			// Check if we can interpolate between the two frames we have available
			const bool bCanInterpolate = (TrackProxy->FrameIndex != TrackProxy->NextFrameIndex) && TrackProxy->IsTopologyCompatible(TrackProxy->FrameIndex, TrackProxy->NextFrameIndex);
			float InterpolationFactor = TrackProxy->InterpolationFactor;
			const bool bFrameIndicesChanged = TrackProxy->FrameIndex != AttachedTriangle.FrameIndex;
			const bool bDifferentRoundedInterpolationFactor = FMath::RoundToInt(InterpolationFactor) != FMath::RoundToInt(TrackProxy->PreviousInterpolationFactor);
			const bool bDifferentInterpolationFactor = !FMath::IsNearlyEqual(InterpolationFactor, TrackProxy->PreviousInterpolationFactor);
			
			if (AttachedTriangle.FrameIndex == TrackProxy->FrameIndex
				&& AttachedTriangle.InterpolationFactor == InterpolationFactor)
			{
				AttachedTriangle.bFrameUpdated = false;
				continue;
			}
			else
			{
				AttachedTriangle.bFrameUpdated = true;
			}

			AttachedTriangle.FrameIndex = TrackProxy->FrameIndex;
			AttachedTriangle.InterpolationFactor = InterpolationFactor;

			// Check if we have explicit motion vectors
			const bool bHasMotionVectors = (
				TrackProxy->MeshData->VertexInfo.bHasMotionVectors &&
				TrackProxy->NextFrameMeshData->VertexInfo.bHasMotionVectors &&
				TrackProxy->MeshData->Positions.Num() == TrackProxy->MeshData->MotionVectors.Num())
				&& (TrackProxy->NextFrameMeshData->Positions.Num() == TrackProxy->NextFrameMeshData->MotionVectors.Num());
			
			// Can we interpolate the vertex data?
			if (bCanInterpolate/* && bDifferentInterpolationFactor*/)
			{
				int32 TriangleIndex = AttachLocation.TriangleIndex * 3;

				const float OneMinusInterp = 1.0 - InterpolationFactor;
				const int32 InterpFixed = (int32)(InterpolationFactor * 255.0f);
				const int32 OneMinusInterpFixed = 255 - InterpFixed;
				const VectorRegister WeightA = VectorSetFloat1(OneMinusInterp);
				const VectorRegister WeightB = VectorSetFloat1(InterpolationFactor);
				const VectorRegister Half = VectorSetFloat1(0.5f);

				const int32 NumVerts = TrackProxy->MeshData->Positions.Num();
				
				const uint32* IndicesPtr = TrackProxy->MeshData->Indices.GetData();
				const FVector& W = AttachLocation.BaryCentric;

				// Position
				{
					check(TrackProxy->MeshData->Positions.Num() >= NumVerts);
					check(TrackProxy->NextFrameMeshData->Positions.Num() >= NumVerts);
					
					const FVector* PositionAPtr = TrackProxy->MeshData->Positions.GetData();
					const FVector* PositionBPtr = TrackProxy->NextFrameMeshData->Positions.GetData();

					const FVector& v0 = PositionAPtr[IndicesPtr[TriangleIndex]] * OneMinusInterp + PositionBPtr[IndicesPtr[TriangleIndex]] * InterpolationFactor;
					const FVector& v1 = PositionAPtr[IndicesPtr[TriangleIndex + 1]] * OneMinusInterp + PositionBPtr[IndicesPtr[TriangleIndex + 1]] * InterpolationFactor;
					const FVector& v2 = PositionAPtr[IndicesPtr[TriangleIndex + 2]] * OneMinusInterp + PositionBPtr[IndicesPtr[TriangleIndex + 2]] * InterpolationFactor;

					AttachedTriangle.AttachPosition = v0 * W.X + v1 * W.Y + v2 * W.Z;
					AttachedTriangle.AttachNormal = ComputeTriangleNormal(v0, v1, v2);

					FRotator Rotator = FRotationMatrix::MakeFromYZ((AttachedTriangle.AttachPosition - v0).GetSafeNormal(), AttachedTriangle.AttachNormal).Rotator();
					AttachedTriangle.AttachTransform = FTransform(Rotator, AttachedTriangle.AttachPosition);
				}

				if (TrackProxy->MeshData->VertexInfo.bHasUV0)
				{
					check(TrackProxy->MeshData->TextureCoordinates.Num() >= NumVerts);
					check(TrackProxy->NextFrameMeshData->TextureCoordinates.Num() >= NumVerts);

					const FVector2D* UVAPtr = TrackProxy->MeshData->TextureCoordinates.GetData();
					const FVector2D* UVBPtr = TrackProxy->NextFrameMeshData->TextureCoordinates.GetData();

					const FVector2D& uv0 = UVAPtr[IndicesPtr[TriangleIndex]] * OneMinusInterp + UVBPtr[IndicesPtr[TriangleIndex]] * InterpolationFactor;
					const FVector2D& uv1 = UVAPtr[IndicesPtr[TriangleIndex + 1]] * OneMinusInterp + UVBPtr[IndicesPtr[TriangleIndex + 1]] * InterpolationFactor;
					const FVector2D& uv2 = UVAPtr[IndicesPtr[TriangleIndex + 2]] * OneMinusInterp + UVBPtr[IndicesPtr[TriangleIndex + 2]] * InterpolationFactor;

					AttachedTriangle.AttachUV = uv0 * W.X + uv1 * W.Y + uv2 * W.Z;
				}
			}
			else
			{
				//if (bFrameIndicesChanged || bDifferentRoundedInterpolationFactor || (bDifferentInterpolationFactor && bExtrapolateFrames))
				{
					const bool bNextFrame = !!FMath::RoundToInt(InterpolationFactor) && TrackProxy->NextFrameMeshData->Positions.Num() > 0; // use next frame only if it's valid
					const uint32 FrameIndexToUse = bNextFrame ? TrackProxy->NextFrameIndex : TrackProxy->FrameIndex;
					FGeometryCacheMeshData* MeshDataToUse = bNextFrame ? TrackProxy->NextFrameMeshData : TrackProxy->MeshData;
					
					if (!bCanInterpolate && (TrackProxy->FrameIndex != TrackProxy->NextFrameIndex))
					{
						RematchAttachLocation(AttachedTriangle, MeshDataToUse);
					}
					int32 TriangleIndex = AttachLocation.TriangleIndex * 3;

					const uint32* IndicesPtr = MeshDataToUse->Indices.GetData();
					const FVector& W = AttachLocation.BaryCentric;

					if (TriangleIndex + 2 < MeshDataToUse->Indices.Num())
					{
						const FVector& v0 = MeshDataToUse->Positions[IndicesPtr[TriangleIndex]];
						const FVector& v1 = MeshDataToUse->Positions[IndicesPtr[TriangleIndex + 1]];
						const FVector& v2 = MeshDataToUse->Positions[IndicesPtr[TriangleIndex + 2]];

						AttachedTriangle.AttachPosition = v0 * W.X + v1 * W.Y + v2 * W.Z;
						AttachedTriangle.AttachNormal = ComputeTriangleNormal(v0, v1, v2);

						FRotator Rotator = FRotationMatrix::MakeFromYZ((AttachedTriangle.AttachPosition - v0).GetSafeNormal(), AttachedTriangle.AttachNormal).Rotator();
						AttachedTriangle.AttachTransform = FTransform(Rotator, AttachedTriangle.AttachPosition);
					
						if (TrackProxy->MeshData->VertexInfo.bHasUV0)
						{
							const FVector2D* UVAPtr = MeshDataToUse->TextureCoordinates.GetData();
							const FVector2D* UVBPtr = TrackProxy->NextFrameMeshData->TextureCoordinates.GetData();

							const FVector2D& uv0 = MeshDataToUse->TextureCoordinates[IndicesPtr[TriangleIndex]];
							const FVector2D& uv1 = MeshDataToUse->TextureCoordinates[IndicesPtr[TriangleIndex + 1]];
							const FVector2D& uv2 = MeshDataToUse->TextureCoordinates[IndicesPtr[TriangleIndex + 2]];

							AttachedTriangle.AttachUV = uv0 * W.X + uv1 * W.Y + uv2 * W.Z;
						}
					}
				}
			}
		}
	}

	return true;
}

bool UGeometryCacheAttachmentComponent::UpdateFrameData()
{
	check(IsInRenderingThread());

	if (!GetGeometryCacheComponent() || !GetGeometryCacheComponent()->SceneProxy)
	{
		return false;
	}

	FGeometryCacheSceneProxy* GeometryCacheSceneProxy = static_cast<FGeometryCacheSceneProxy*>(GetGeometryCacheComponent()->SceneProxy);
	if (!GeometryCacheSceneProxy)
	{
		return false;
	}

	const TArray<FGeomCacheTrackProxy*>& Tracks = GeometryCacheSceneProxy->GetTracks();
	if (TrackSections.Num() != Tracks.Num())
	{
		if (TrackSections.Num() > 0)
		{
			ClearTrackData();
		}

		CreateTrackData();
	}

	UGeometryCacheComponent* GeometryCacheComponent = GetGeometryCacheComponent();

	float Time = GeometryCacheComponent->GetAnimationTime();
	bool bLooping = GeometryCacheComponent->IsLooping();
	bool bExtrapolateFrames = GeometryCacheComponent->IsExtrapolatingFrames();

	for (int32 SectionIndex = 0; SectionIndex < Tracks.Num(); SectionIndex++)
	{
		FGeomCacheTrackProxy* TrackProxy = Tracks[SectionIndex];
		FGeometryCacheSectionData* SectionData = TrackSections[SectionIndex];

		// Render out stored TrackProxy's
		if (TrackProxy != nullptr)
		{
			const FVisibilitySample& VisibilitySample = TrackProxy->GetVisibilitySample(Time, bLooping);
			if (!VisibilitySample.bVisibilityState)
			{
				continue;
			}

			// Check if we can interpolate between the two frames we have available
			const bool bCanInterpolate = (TrackProxy->FrameIndex != TrackProxy->NextFrameIndex) && TrackProxy->IsTopologyCompatible(TrackProxy->FrameIndex, TrackProxy->NextFrameIndex);
			float InterpolationFactor = TrackProxy->InterpolationFactor;
			const bool bFrameIndicesChanged = TrackProxy->FrameIndex != SectionData->FrameIndex;
			const bool bDifferentRoundedInterpolationFactor = FMath::RoundToInt(InterpolationFactor) != FMath::RoundToInt(TrackProxy->PreviousInterpolationFactor);
			const bool bDifferentInterpolationFactor = !FMath::IsNearlyEqual(InterpolationFactor, TrackProxy->PreviousInterpolationFactor);

			SectionData->FrameIndex = TrackProxy->FrameIndex;

			// Check if we have explicit motion vectors
			const bool bHasMotionVectors = (
				TrackProxy->MeshData->VertexInfo.bHasMotionVectors &&
				TrackProxy->NextFrameMeshData->VertexInfo.bHasMotionVectors &&
				TrackProxy->MeshData->Positions.Num() == TrackProxy->MeshData->MotionVectors.Num())
				&& (TrackProxy->NextFrameMeshData->Positions.Num() == TrackProxy->NextFrameMeshData->MotionVectors.Num());

			// Can we interpolate the vertex data?
			if (bCanInterpolate/* && (bDifferentInterpolationFactor || bFrameIndicesChanged)*/)
			{

				const float OneMinusInterp = 1.0 - InterpolationFactor;
				const int32 InterpFixed = (int32)(InterpolationFactor * 255.0f);
				const int32 OneMinusInterpFixed = 255 - InterpFixed;
				const VectorRegister WeightA = VectorSetFloat1(OneMinusInterp);
				const VectorRegister WeightB = VectorSetFloat1(InterpolationFactor);
				const VectorRegister Half = VectorSetFloat1(0.5f);

				const int32 NumVerts = TrackProxy->MeshData->Positions.Num();
				SectionData->Prepare(NumVerts);

				{
					check(TrackProxy->MeshData->Positions.Num() >= NumVerts);
					check(TrackProxy->NextFrameMeshData->Positions.Num() >= NumVerts);
					check(SectionData->PositionBuffer.Num() >= NumVerts);
					const FVector* PositionAPtr = TrackProxy->MeshData->Positions.GetData();
					const FVector* PositionBPtr = TrackProxy->NextFrameMeshData->Positions.GetData();
					FVector* InterpolatedPositionsPtr = SectionData->PositionBuffer.GetData();

					// Unroll 4 times so we can do 4 wide SIMD
					{
						const FVector4* PositionAPtr4 = (const FVector4*)PositionAPtr;
						const FVector4* PositionBPtr4 = (const FVector4*)PositionBPtr;
						FVector4* InterpolatedPositionsPtr4 = (FVector4*)InterpolatedPositionsPtr;

						int32 Index = 0;
						for (; Index + 3 < NumVerts; Index += 4)
						{
							VectorRegister Pos0xyz_Pos1x = VectorMultiplyAdd(VectorLoad(PositionAPtr4 + 0), WeightA, VectorMultiply(VectorLoad(PositionBPtr4 + 0), WeightB));
							VectorRegister Pos1yz_Pos2xy = VectorMultiplyAdd(VectorLoad(PositionAPtr4 + 1), WeightA, VectorMultiply(VectorLoad(PositionBPtr4 + 1), WeightB));
							VectorRegister Pos2z_Pos3xyz = VectorMultiplyAdd(VectorLoad(PositionAPtr4 + 2), WeightA, VectorMultiply(VectorLoad(PositionBPtr4 + 2), WeightB));
							VectorStore(Pos0xyz_Pos1x, InterpolatedPositionsPtr4 + 0);
							VectorStore(Pos1yz_Pos2xy, InterpolatedPositionsPtr4 + 1);
							VectorStore(Pos2z_Pos3xyz, InterpolatedPositionsPtr4 + 2);
							PositionAPtr4 += 3;
							PositionBPtr4 += 3;
							InterpolatedPositionsPtr4 += 3;
						}

						for (; Index < NumVerts; Index++)
						{
							InterpolatedPositionsPtr[Index] = PositionAPtr[Index] * OneMinusInterp + PositionBPtr[Index] * InterpolationFactor;
						}
					}
				}

				if (TrackProxy->MeshData->VertexInfo.bHasUV0 )
				{
					check(TrackProxy->MeshData->TextureCoordinates.Num() >= NumVerts);
					check(TrackProxy->NextFrameMeshData->TextureCoordinates.Num() >= NumVerts);
					check(SectionData->UVBuffer.Num() >= NumVerts);
					const FVector2D* UVAPtr = TrackProxy->MeshData->TextureCoordinates.GetData();
					const FVector2D* UVBPtr = TrackProxy->NextFrameMeshData->TextureCoordinates.GetData();
					FVector2D* InterpolatedUVsPtr = SectionData->UVBuffer.GetData();

					// Unroll 2x so we can use 4 wide ops. OOP will hopefully take care of the rest.
					{
						int32 Index = 0;
						for (; Index + 1 < NumVerts; Index += 2)
						{
							VectorRegister InterpolatedUVx2 = VectorMultiplyAdd(VectorLoad(&UVAPtr[Index]), WeightA,
								VectorMultiply(VectorLoad(&UVBPtr[Index]), WeightB));
							VectorStore(InterpolatedUVx2, &InterpolatedUVsPtr[Index]);
						}

						if (Index < NumVerts)
						{
							InterpolatedUVsPtr[Index] = UVAPtr[Index] * OneMinusInterp + UVBPtr[Index] * InterpolationFactor;
						}
					}
				}

				SectionData->IndexBuffer = TrackProxy->MeshData->Indices; //.UpdateIndices(TrackProxy->MeshData->Indices);
				check(TrackProxy->MeshData->Indices.Num() % 3 == 0);

				SectionData->BatchesInfo = TrackProxy->MeshData->BatchesInfo;

			}
			else
			{
				// We just don't interpolate between frames if we got GPU to burn we could someday render twice and stipple fade between it :-D like with lods

				// Only bother uploading if anything changed or when the we failed to decode anything make sure update the gpu buffers regardless
				if (bFrameIndicesChanged || bDifferentRoundedInterpolationFactor || (bDifferentInterpolationFactor && bExtrapolateFrames))
				{
					const bool bNextFrame = !!FMath::RoundToInt(InterpolationFactor) && TrackProxy->NextFrameMeshData->Positions.Num() > 0; // use next frame only if it's valid
					const uint32 FrameIndexToUse = bNextFrame ? TrackProxy->NextFrameIndex : TrackProxy->FrameIndex;
					FGeometryCacheMeshData* MeshDataToUse = bNextFrame ? TrackProxy->NextFrameMeshData : TrackProxy->MeshData;

					SectionData->UpdateIndices(MeshDataToUse->Indices);
					SectionData->UpdatePositions(MeshDataToUse->Positions);
					SectionData->UpdateUVs(MeshDataToUse->TextureCoordinates);

					SectionData->BatchesInfo = MeshDataToUse->BatchesInfo;
				}
			}
		}
	}

	return true;
}

void UGeometryCacheAttachmentComponent::BuildGeometryCacheMeshBVH()
{
	int32 TrackNum = TrackSections.Num();

	TrackMeshSpatials.Empty();
	TrackMeshSpatials.SetNum(TrackNum);
	TrackMeshs.Empty();
	TrackMeshs.SetNum(TrackNum);

	ParallelFor(TrackNum, [&](int32 TrackIndex)
		{
			FGeometryCacheSectionData* SectionData = TrackSections[TrackIndex];
			// Transform vertice
			TArray<FVector>& PositionBuffer = SectionData->PositionBuffer;
			TArray<uint32>& IndexBuffer = SectionData->IndexBuffer;

			int32 NumPieceV = PositionBuffer.Num();

			// Build mesh tree
			TArray<int32> TrackTriMap;
			TrackMeshs[TrackIndex] = MakeUnique<FDynamicMesh3>();
			
			for (int32 i = 0, NumV = PositionBuffer.Num(); i < NumV; ++i)
			{
				const auto& p = PositionBuffer[i];
				TrackMeshs[TrackIndex]->AppendVertex(p);
			}
			for (int32 i = 0, NumT = IndexBuffer.Num() / 3; i < NumT; ++i)
			{
				TrackMeshs[TrackIndex]->AppendTriangle(IndexBuffer[3 * i + 0], IndexBuffer[3 * i + 1], IndexBuffer[3 * i + 2]);
				TrackTriMap.Add(i);
			}
			
			TrackMeshSpatials[TrackIndex] = MakeUnique<FDynamicMeshAABBTree3>(TrackMeshs[TrackIndex].Get(), true);
		}
	);
}

int UGeometryCacheAttachmentComponent::FindNearestTriangle(const FVector3d& P, double& NearestDistSqr, int32& NearestTrackIndex) const
{
	NearestDistSqr = TNumericLimits<double>::Max();
	NearestTrackIndex = -1;
	
	int32 NearestTriangleIndex = -1;

	for (int32 Index = 0; Index < TrackMeshSpatials.Num(); Index++)
	{
		double DistanceSqr = 0;
		int32 TriangleIndex = TrackMeshSpatials[Index]->FindNearestTriangle(P, DistanceSqr);
		if (TriangleIndex < 0 || DistanceSqr > NearestDistSqr)
		{
			continue;
		}

		NearestDistSqr = DistanceSqr;
		NearestTrackIndex = Index;
		NearestTriangleIndex = TriangleIndex;
	}

	return NearestTriangleIndex;
}

void UGeometryCacheAttachmentComponent::LineTraceAttachElement(const FVector& WorldStart, const FVector& WorldEnd, USceneComponent* ElementComponent, const FTransform& ElementTransform, const FLineTraceAttachFinishedEvent& FinishedEvent)
{
	if (!ElementComponent)
	{
		FinishedEvent.ExecuteIfBound(true, TEXT("Invalid Element Component!"));
		return;
	}

	auto UpdateFinishedCallback = [this, WorldStart, WorldEnd, ElementComponent, ElementTransform, FinishedEvent]()
	{
		FGeometryCacheLineTraceResult Result;
		if (LineTraceGeometryCache(WorldStart, WorldEnd, Result))
		{
			FGeometryCacheAttachedElement AttachedElement;
			AttachedElement.AttachLocation.TrackIndex = Result.TrackIndex;
			AttachedElement.AttachLocation.TriangleIndex = Result.TriangleIndex;
			AttachedElement.AttachLocation.BaryCentric = FVector(1.0f/3.0f);//Result.BaryCentric;
			CalculateVerticeInfoAtAttachedLocation(AttachedElement.AttachLocation, AttachedElement.OrgAttachTransform, AttachedElement.OrgAttachUV);

			ElementComponent->SetRelativeScale3D(ElementTransform.GetScale3D());
			FTransform AttachedTransform = AttachedElement.OrgAttachTransform;
			AttachedElement.RelativePosition = ElementTransform.GetTranslation();// AttachedTransform.InverseTransformPosition(ElementComponent->GetRelativeLocation());
			AttachedElement.RelativeQuat = ElementTransform.GetRotation();// AttachedTransform.InverseTransformRotation(ElementComponent->GetRelativeRotation().Quaternion());
			AttachedElement.RelativeTransform = ElementTransform;// FTransform(AttachedElement.RelativeQuat, AttachedElement.RelativePosition);

			AttachedElement.ElementComponent = ElementComponent;

			AttachedElements.Add(AttachedElement);

			FinishedEvent.ExecuteIfBound(true, TEXT("LineTrace Attach Success"));
		}
		else
		{
			FinishedEvent.ExecuteIfBound(false, TEXT("LineTrace Failed!"));
		}
	};

	ENQUEUE_RENDER_COMMAND(FGeometryCacheAttachAllUpdate)(
		[this, UpdateFinishedCallback](FRHICommandList& RHICmdList)
		{
			this->UpdateFrameData();

			AsyncTask(ENamedThreads::GameThread, [this, UpdateFinishedCallback] {
				UpdateFinishedCallback();
				});
		}
	);
}

bool UGeometryCacheAttachmentComponent::AttachElementAtLocation(const FGeometryCacheAttachLocation& AttachLocation, USceneComponent* ElementComponent, const FTransform& ElementTransform)
{
	if (ElementComponent)
	{
		FGeometryCacheAttachedElement AttachedElement;
		AttachedElement.AttachLocation = AttachLocation;
		if (CalculateVerticeInfoAtAttachedLocation(AttachedElement.AttachLocation, AttachedElement.OrgAttachTransform, AttachedElement.OrgAttachUV))
		{
			FTransform AttachedTransform = AttachedElement.OrgAttachTransform;

			AttachedElement.RelativePosition = AttachedTransform.InverseTransformPosition(ElementComponent->GetRelativeLocation());
			AttachedElement.RelativeQuat = AttachedTransform.InverseTransformRotation(ElementComponent->GetRelativeRotation().Quaternion());
			AttachedElement.RelativeTransform = FTransform(AttachedElement.RelativeQuat, AttachedElement.RelativePosition);

			AttachedElement.ElementComponent = ElementComponent;
			AttachedElements.Add(AttachedElement);

			return true;
		}
	}

	return false;
}

void UGeometryCacheAttachmentComponent::RemoveAllAttachedComponents(bool bDestroyAfterRemove)
{
	for (int32 AttachIndex = 0; AttachIndex < AttachedElements.Num(); AttachIndex++)
	{
		if (bDestroyAfterRemove)
		{
			AttachedElements[AttachIndex].ElementComponent->DestroyComponent();
		}
	}

	AttachedElements.Empty();
}

bool UGeometryCacheAttachmentComponent::RemoveAttachedComponent(USceneComponent* AttachedComponent, bool bDestroyAfterRemove)
{
	if (AttachedComponent)
	{
		for (int32 AttachIndex = 0; AttachIndex < AttachedElements.Num(); AttachIndex++)
		{
			if (AttachedElements[AttachIndex].ElementComponent == AttachedComponent)
			{
				AttachedElements.RemoveAt(AttachIndex);

				if (bDestroyAfterRemove)
				{
					AttachedComponent->DestroyComponent();
				}
				return true;
			}
		}
	}
	
	return false;
}

bool UGeometryCacheAttachmentComponent::ReplaceAttachedComponent(USceneComponent* OldAttachedComponent, USceneComponent* NewAttachedComponent, bool bDestroyOldAfterReplace)
{
	if (OldAttachedComponent && NewAttachedComponent)
	{
		for (int32 AttachIndex = 0; AttachIndex < AttachedElements.Num(); AttachIndex++)
		{
			if (AttachedElements[AttachIndex].ElementComponent == OldAttachedComponent)
			{
				AttachedElements[AttachIndex].ElementComponent = NewAttachedComponent;

				if (bDestroyOldAfterReplace)
				{
					OldAttachedComponent->DestroyComponent();
				}
				return true;
			}
		}
	}

	return false;
}

void UGeometryCacheAttachmentComponent::AttachAllElements()
{
	AttachedElements.Empty();

	auto UpdateFinishedCallback = [this]()
	{
		if (AttachType == EGeometryCacheAttachType::AttachToNearestDistance)
		{
			BuildGeometryCacheMeshBVH();

			const FTransform RelativeTransform = GetRelativeTransform();
			const TArray<USceneComponent*>& AttachedComponents = GetAttachChildren();
			for (int32 AttachIndex = 0; AttachIndex < AttachedComponents.Num(); AttachIndex++)
			{
				USceneComponent* AttachComponent = AttachedComponents[AttachIndex];
				FVector Location = RelativeTransform.TransformPositionNoScale(AttachComponent->GetRelativeLocation());
				
				double NearestDistSqr = 0;
				int32 NearestTrackIndex = -1;
				int32 NearestTriangleIndex = FindNearestTriangle(Location, NearestDistSqr, NearestTrackIndex);

				if (NearestTriangleIndex >= 0 && NearestTrackIndex >= 0)
				{
					FGeometryCacheAttachedElement AttachedElement;
					AttachedElement.AttachLocation.TrackIndex = NearestTrackIndex;
					AttachedElement.AttachLocation.TriangleIndex = NearestTriangleIndex;
					AttachedElement.AttachLocation.BaryCentric = FVector(0.33f);
					CalculateVerticeInfoAtAttachedLocation(AttachedElement.AttachLocation, AttachedElement.OrgAttachTransform, AttachedElement.OrgAttachUV);

					FTransform AttachedTransform = AttachedElement.OrgAttachTransform;
				
					AttachedElement.RelativePosition = AttachedTransform.InverseTransformPosition(AttachComponent->GetRelativeLocation());
					AttachedElement.RelativeQuat = AttachedTransform.InverseTransformRotation(AttachComponent->GetRelativeRotation().Quaternion());
					AttachedElement.RelativeTransform = FTransform(AttachedElement.RelativeQuat, AttachedElement.RelativePosition, AttachComponent->GetRelativeScale3D());

					AttachedElement.ElementComponent = AttachComponent;
					AttachedElements.Add(AttachedElement);
				}
			}
		}
		else
		{
			const TArray<USceneComponent*>& AttachedComponents = GetAttachChildren();
			for (int32 AttachIndex = 0; AttachIndex < AttachedComponents.Num(); AttachIndex++)
			{
				USceneComponent* AttachComponent = AttachedComponents[AttachIndex];
				
				FVector WorldStart;
				FVector WorldEnd;
				FGeometryCacheLineTraceResult Result;
				if (LineTraceGeometryCache(WorldStart, WorldEnd, Result))
				{
					FGeometryCacheAttachedElement AttachedElement;
					AttachedElement.AttachLocation.TrackIndex = Result.TrackIndex;
					AttachedElement.AttachLocation.TriangleIndex = Result.TriangleIndex;
					AttachedElement.AttachLocation.BaryCentric = Result.BaryCentric;
					CalculateVerticeInfoAtAttachedLocation(AttachedElement.AttachLocation, AttachedElement.OrgAttachTransform, AttachedElement.OrgAttachUV);

					FTransform AttachedTransform = AttachedElement.OrgAttachTransform;
					AttachedElement.RelativePosition = AttachedTransform.InverseTransformPosition(AttachComponent->GetRelativeLocation());
					AttachedElement.RelativeQuat = AttachedTransform.InverseTransformRotation(AttachComponent->GetRelativeRotation().Quaternion());
					AttachedElement.RelativeTransform = FTransform(AttachedElement.RelativeQuat, AttachedElement.RelativePosition);

					AttachedElement.ElementComponent = AttachComponent;
					
					AttachedElements.Add(AttachedElement);
				}
			}
		}

	};
	
	ENQUEUE_RENDER_COMMAND(FGeometryCacheAttachAllUpdate)(
		[this, UpdateFinishedCallback](FRHICommandList& RHICmdList)
		{
			this->UpdateFrameData();

			AsyncTask(ENamedThreads::GameThread, [this, UpdateFinishedCallback] {
				UpdateFinishedCallback();
				});
		}
	);
}

void UGeometryCacheAttachmentComponent::UpdateAttachedElements()
{
	if (AttachedElements.Num() == AttachedTriangles.Num() && GeometryCacheStatus.GeometryCacheComponent)
	{
		auto IsComponentValid = [this](USceneComponent* Component)
		{
			const TArray<USceneComponent*>& AttachedComponents = GetAttachChildren();
			return AttachedComponents.Contains(Component);
		};
		
		float Time = GeometryCacheStatus.GeometryCacheComponent->GetAnimationTime();
		bool IsPlaying = GeometryCacheStatus.GeometryCacheComponent->IsPlaying();

		FTransform InvTransform = GetRelativeTransform().Inverse();
		for (int32 AttachIndex = 0; AttachIndex < AttachedElements.Num(); AttachIndex++)
		{
			FGeometryCacheAttachedElement& AttachedElement = AttachedElements[AttachIndex];
			FGeometryCacheAttachedTriangle& AttachedTriangle = AttachedTriangles[AttachIndex];

			if (IsComponentValid(AttachedElement.ElementComponent))
			{
				if (IsPlaying && PreviousTime != Time && !AttachedTriangle.bFrameUpdated)
				{
					if (this->bRuntimeTicking)
					{
						AttachedElement.ElementComponent->SetVisibility(false, true);
					}
				}
				else
				{
					AttachedElement.FrameIndex = AttachedTriangle.FrameIndex;

					FVector Position = AttachedTriangle.AttachPosition;
					FVector Normal = AttachedTriangle.AttachNormal;

					FTransform AttachmentTransform = AttachedTriangle.AttachTransform;

					FVector RelativePosition = AttachmentTransform.TransformPosition(AttachedElement.RelativePosition);
					FQuat RelativeQuat = AttachmentTransform.TransformRotation(AttachedElement.RelativeQuat);
					AttachedElement.ElementComponent->SetRelativeLocationAndRotation(RelativePosition,
						RelativeQuat);

					//AttachedElement.ElementComponent->SetRelativeTransform(AttachedElement.RelativeTransform * AttachmentTransform, true);
					if (!AttachedElement.ElementComponent->IsUnreachable())
					{
						AttachedElement.ElementComponent->DoDeferredRenderUpdates_Concurrent();
					}

					AttachedElement.ElementComponent->SetVisibility(true, true);
				}
			}
			else
			{
				UE_LOG(LogTemp, Warning, TEXT("UGeometryCacheAttachmentComponent: Failed to update Attached Element. (%s)"), *(GetOwner()->GetName()));
			}
		}
	}
}

bool UGeometryCacheAttachmentComponent::CalculateVerticeInfoAtAttachedLocation(const FGeometryCacheAttachLocation& AttachLocation, FTransform& Transform, FVector2D& UV)
{
	check(AttachLocation.TrackIndex < TrackSections.Num());

	FGeometryCacheSectionData* SectionData = TrackSections[AttachLocation.TrackIndex];
	if (SectionData && SectionData->PositionBuffer.Num() > 0)
	{
		TArray<FVector>& PositionBuffer = SectionData->PositionBuffer;
		TArray<FVector2D>& UVBuffer = SectionData->UVBuffer;
		TArray<uint32>& IndexBuffer = SectionData->IndexBuffer;

		int32 TriangleIndex = AttachLocation.TriangleIndex * 3;
		if (TriangleIndex + 2 < IndexBuffer.Num())
		{
			const FVector& v0 = PositionBuffer[IndexBuffer[TriangleIndex]];
			const FVector& v1 = PositionBuffer[IndexBuffer[TriangleIndex + 1]];
			const FVector& v2 = PositionBuffer[IndexBuffer[TriangleIndex + 2]];

			const FVector& W = AttachLocation.BaryCentric;
			FVector Position = v0 * W.X + v1 * W.Y + v2 * W.Z;
			FVector Normal = ComputeTriangleNormal(v0, v1, v2);

			FRotator Rotator = FRotationMatrix::MakeFromYZ((Position - v0).GetSafeNormal(), Normal).Rotator();
			Transform = FTransform(Rotator, Position);

			if (UVBuffer.Num() > 0)
			{
				const FVector2D& uv0 = UVBuffer[IndexBuffer[TriangleIndex]];
				const FVector2D& uv1 = UVBuffer[IndexBuffer[TriangleIndex + 1]];
				const FVector2D& uv2 = UVBuffer[IndexBuffer[TriangleIndex + 2]];

				UV = uv0 * W.X + uv1 * W.Y + uv2 * W.Z;
			}
			
			return true;
		}
	}

	return false;
}

#undef LOCTEXT_NAMESPACE