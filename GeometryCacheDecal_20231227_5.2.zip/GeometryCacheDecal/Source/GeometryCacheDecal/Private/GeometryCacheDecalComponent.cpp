// Copyright Qibo Pang 2023. All Rights Reserved.

#include "GeometryCacheDecalComponent.h"
#include "GeometryCacheComponent.h"
#include "GeometryCache.h"
#include "GeometryCacheTrack.h"

#include "Engine.h"
#include "Async/Async.h"
#include "PhysicsEngine/BodySetup.h"
#include "MaterialShared.h"
#include "Materials/Material.h"
#include "PhysicsEngine/PhysicsSettings.h"

#include "RayTracingDefinitions.h"
#include "RayTracingInstance.h"

#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 2
#include "Materials/MaterialRenderProxy.h"
#include "MaterialDomain.h"
#endif

#define LOCTEXT_NAMESPACE "GeometryCacheDecalComponent"

//////////////////////////////////////////////////////////////////////////

FGeometryCacheOriginStatus::FGeometryCacheOriginStatus(UGeometryCacheComponent* InGeometryCacheComponent, UGeometryCacheDecalComponent* InGeometryCacheDecalComponent)
	: GeometryCacheComponent(InGeometryCacheComponent), GeometryCacheDecalComponent(InGeometryCacheDecalComponent)
{
	if (InGeometryCacheComponent)
	{
		GeometryCache = InGeometryCacheComponent->GetGeometryCache();
		if (FGeometryCacheSceneProxy* SceneProxy = static_cast<FGeometryCacheSceneProxy*>(InGeometryCacheComponent->SceneProxy))
		{
			GeometryCacheSceneProxy = SceneProxy;
		}
		AnimationTime = GeometryCacheComponent->GetAnimationTime();
	}
}

bool FGeometryCacheOriginStatus::ResetWhenChanged()
{
	if (GeometryCacheComponent)
	{
		if (GeometryCacheComponent->GetGeometryCache() != GeometryCache
			|| GeometryCacheComponent->SceneProxy != GeometryCacheSceneProxy)
		{
			if (FGeometryCacheSceneProxy* SceneProxy = static_cast<FGeometryCacheSceneProxy*>(GeometryCacheComponent->SceneProxy))
			{
				const TArray<FGeomCacheTrackProxy*>& Tracks = SceneProxy->GetTracks();
				bool bAllTrackInited = Tracks.Num() > 0;
				for (FGeomCacheTrackProxy* Track: Tracks)
				{
					if (Track->FrameIndex == -1 && Track->NextFrameIndex == -1)
					{
						bAllTrackInited = false;
						break;
					}
				}

				if (bAllTrackInited)
				{
					GeometryCache = GeometryCacheComponent->GetGeometryCache();
					GeometryCacheSceneProxy = SceneProxy;
				
					AnimationTime = GeometryCacheComponent->GetAnimationTime();
					return true;
				}
			}
		}

		if (UGeometryCacheDecalSceneProxy* SceneProxy = static_cast<UGeometryCacheDecalSceneProxy*>(GeometryCacheDecalComponent->SceneProxy))
		{
			if (SceneProxy->GeometryCacheSceneProxy != GeometryCacheSceneProxy)
			{
				return true;
			}
		}
	}

	return false;
}

bool FGeometryCacheOriginStatus::TracksInited()
{
	if (GeometryCacheSceneProxy)
	{
		const TArray<FGeomCacheTrackProxy*>& Tracks = GeometryCacheSceneProxy->GetTracks();
		bool bAllTrackInited = Tracks.Num() > 0;
		for (FGeomCacheTrackProxy* Track : Tracks)
		{
			if (!Track || (Track->FrameIndex == -1 && Track->NextFrameIndex == -1))
			{
				bAllTrackInited = false;
				break;
			}
		}

		return bAllTrackInited;
	}
	return false;
}

bool FGeometryCacheOriginStatus::CheckStatusChanged()
{
	if (GeometryCacheComponent && !FMath::IsNearlyEqual(GeometryCacheComponent->GetAnimationTime(), AnimationTime))
	{
		AnimationTime = GeometryCacheComponent->GetAnimationTime();
		return true;
	}
	return false;
}

//////////////////////////////////////////////////////////////////////////

class FDecalGeomCacheTrackProxy : public FGeomCacheTrackProxy
{
public:
	FDecalGeomCacheTrackProxy(ERHIFeatureLevel::Type InFeatureLevel)
		: FGeomCacheTrackProxy(InFeatureLevel)
	{}

	//~ Begin FGeomCacheTrackProxy Interface
	virtual bool UpdateMeshData(float Time, bool bLooping, int32& InOutMeshSampleIndex, FGeometryCacheMeshData& OutMeshData) override
	{
		return false;
	}

	virtual bool GetMeshData(int32 SampleIndex, FGeometryCacheMeshData& OutMeshData) override
	{
		return false;
	}

	virtual bool IsTopologyCompatible(int32 SampleIndexA, int32 SampleIndexB) override
	{
		return false;
	}
	virtual const FVisibilitySample& GetVisibilitySample(float Time, const bool bLooping) const override
	{
		// Assume the track is visible for its whole duration
		return FVisibilitySample::VisibleSample;
	}

	virtual void FindSampleIndexesFromTime(float Time, bool bLooping, bool bIsPlayingBackwards, int32& OutFrameIndex, int32& OutNextFrameIndex, float& TheInterpolationFactor) override
	{
		return;
	}
	//~ End FGeomCacheTrackProxy Interface
};

//////////////////////////////////////////////////////////////////////////

UGeometryCacheDecalSceneProxy::UGeometryCacheDecalSceneProxy(UGeometryCacheDecalComponent* Component)
	: FPrimitiveSceneProxy(Component)
{
	bAlwaysHasVelocity = true;
	bVerifyUsedMaterials = false;

	EnableGPUSceneSupportFlags();
	bCanSkipRedundantTransformUpdates = false;

	GeometryCacheDecalComponent = Component;
	if (Component && Component->GetGeometryCacheComponent())
	{
		MaterialRelevance = Component->GetMaterialRelevance(GetScene().GetFeatureLevel());
		if (FGeometryCacheSceneProxy* SceneProxy = static_cast<FGeometryCacheSceneProxy*>(Component->GetGeometryCacheComponent()->SceneProxy))
		{
			GeometryCacheSceneProxy = SceneProxy;

			const TArray<FGeomCacheTrackProxy*>& Tracks = GeometryCacheSceneProxy->GetTracks();
			check(Component->TrackSections.Num() == Tracks.Num());
			// Init DecalGeometryData
			{
				DecalGeometryData = new FGeometryCacheTrackDecalData();

				/** Array of per-batch info structs*/
				FGeometryCacheMeshBatchInfo BatchInfo;
				BatchInfo.StartIndex = 0;
				BatchInfo.NumTriangles = 1;
				BatchInfo.MaterialIndex = 0;
				DecalGeometryData->BatchesInfo.Empty();
				DecalGeometryData->BatchesInfo.Add(BatchInfo);
			}
			
			// Init DecalTrackProxy
			{
				DecalTrackProxy = new FDecalGeomCacheTrackProxy(GetScene().GetFeatureLevel());

				DecalTrackProxy->Track = nullptr;
				DecalTrackProxy->FrameIndex = -1;
				DecalTrackProxy->UploadedSampleIndex = -1;
				DecalTrackProxy->NextFrameIndex = -1;
				DecalTrackProxy->PreviousFrameIndex = -1;
				DecalTrackProxy->InterpolationFactor = 0.f;
				DecalTrackProxy->PreviousInterpolationFactor = 0.f;
				DecalTrackProxy->SubframeInterpolationFactor = 1.f;
				DecalTrackProxy->NextFrameMeshData = nullptr;
				DecalTrackProxy->bResourcesInitialized = false;

				// Grab materials
				int32 Dummy = -1;
				
				DecalTrackProxy->bNextFrameMeshDataSelected = false;

				// Grab material
				UMaterialInterface* Material = Component->GetMaterial(0);
				if (Material == NULL)
				{
					Material = UMaterial::GetDefaultMaterial(MD_Surface);
				}
				DecalTrackProxy->Materials.Add(Material);
			}

			UGeometryCacheDecalSceneProxy* DecalSceneProxy = this;
			ENQUEUE_RENDER_COMMAND(FGeometryCacheDecalUpdateFrame)(
				[DecalSceneProxy](FRHICommandList& RHICmdList)
				{
					DecalSceneProxy->GenerateDecalMesh();
					DecalSceneProxy->UpdateDecalFrame();
				}
			);
		}
	}
}

UGeometryCacheDecalSceneProxy::~UGeometryCacheDecalSceneProxy()
{
	if (DecalTrackProxy)
	{
		DecalTrackProxy->TangentXBuffer.ReleaseResource();
		DecalTrackProxy->TangentZBuffer.ReleaseResource();
		DecalTrackProxy->TextureCoordinatesBuffer.ReleaseResource();
		DecalTrackProxy->ColorBuffer.ReleaseResource();
		DecalTrackProxy->IndexBuffer.ReleaseResource();
		DecalTrackProxy->VertexFactory.ReleaseResource();
		DecalTrackProxy->PositionBuffers[0].ReleaseResource();
		DecalTrackProxy->PositionBuffers[1].ReleaseResource();
#if RHI_RAYTRACING
		DecalTrackProxy->RayTracingGeometry.ReleaseResource();
#endif

		delete DecalGeometryData;
		delete DecalTrackProxy;

		DecalGeometryData = nullptr;
		DecalTrackProxy = nullptr;
	}
}

void UGeometryCacheDecalSceneProxy::CreateMeshBatch(
	const FGeomCacheTrackProxy* TrackProxy,
	const FGeometryCacheTrackDecalData* GeometryData, 
	const FGeometryCacheMeshBatchInfo& BatchInfo,
	FDecalGeometryCacheVertexFactoryUserDataWrapper& UserDataWrapper,
	FDynamicPrimitiveUniformBuffer& DynamicPrimitiveUniformBuffer,
	FMeshBatch& Mesh) const
{
	FGeometryCacheVertexFactoryUserData& UserData = UserDataWrapper.Data;

	UserData.MeshExtension = FVector3f::OneVector;
	UserData.MeshOrigin = FVector3f::ZeroVector;

	const float PreviousPositionScale = 1.0f;// (GFrameNumber <= UpdatedFrameNum) ? 1.f : 0.f;
	UserData.MotionBlurDataExtension = FVector3f::OneVector * PreviousPositionScale;
	UserData.MotionBlurDataOrigin = FVector3f::ZeroVector;
	UserData.MotionBlurPositionScale = 1.f - PreviousPositionScale;

	if (IsRayTracingEnabled())
	{
		// No vertex manipulation is allowed in the vertex shader
		// Otherwise we need an additional compute shader pass to execute the vertex shader and dump to a staging buffer
		check(UserData.MeshExtension == FVector3f::OneVector);
		check(UserData.MeshOrigin == FVector3f::ZeroVector);
	}

	UserData.PositionBuffer = &TrackProxy->PositionBuffers[(TrackProxy->CurrentPositionBufferIndex) % 2];
	UserData.MotionBlurDataBuffer = &TrackProxy->PositionBuffers[(TrackProxy->CurrentPositionBufferIndex + 1) % 2];

	FGeometryCacheVertexFactoryUniformBufferParameters UniformBufferParameters;

	UniformBufferParameters.MeshOrigin = UserData.MeshOrigin;
	UniformBufferParameters.MeshExtension = UserData.MeshExtension;
	UniformBufferParameters.MotionBlurDataOrigin = UserData.MotionBlurDataOrigin;
	UniformBufferParameters.MotionBlurDataExtension = UserData.MotionBlurDataExtension;
	UniformBufferParameters.MotionBlurPositionScale = UserData.MotionBlurPositionScale;

	UserData.UniformBuffer = FGeometryCacheVertexFactoryUniformBufferParametersRef::CreateUniformBufferImmediate(UniformBufferParameters, UniformBuffer_SingleFrame);
	TrackProxy->VertexFactory.CreateManualVertexFetchUniformBuffer(UserData.PositionBuffer, UserData.MotionBlurDataBuffer, UserData);

	// Draw the mesh.
	FMeshBatchElement& BatchElement = Mesh.Elements[0];
	BatchElement.IndexBuffer = &TrackProxy->IndexBuffer;
	Mesh.VertexFactory = &TrackProxy->VertexFactory;
	Mesh.SegmentIndex = 0;

	const FMatrix& LocalToWorldTransform = /*TrackProxy->WorldMatrix **/ GetLocalToWorld();

	bool bHasPrecomputedVolumetricLightmap;
	FMatrix PreviousLocalToWorld;
	int32 SingleCaptureIndex;
	bool bOutputVelocity;
	GetScene().GetPrimitiveUniformShaderParameters_RenderThread(GetPrimitiveSceneInfo(), bHasPrecomputedVolumetricLightmap, PreviousLocalToWorld, SingleCaptureIndex, bOutputVelocity);
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 2
	bOutputVelocity |= AlwaysHasVelocity();
#endif

	DynamicPrimitiveUniformBuffer.Set(LocalToWorldTransform, PreviousLocalToWorld, GetBounds(), GetLocalBounds(), true, false, DrawsVelocity(), bOutputVelocity);
	BatchElement.PrimitiveUniformBufferResource = &DynamicPrimitiveUniformBuffer.UniformBuffer;

	BatchElement.FirstIndex = BatchInfo.StartIndex;
	BatchElement.NumPrimitives = BatchInfo.NumTriangles;
	BatchElement.MinVertexIndex = 0;
	BatchElement.MaxVertexIndex = GeometryData->PositionBuffer.Num() - 1;
	BatchElement.VertexFactoryUserData = &UserDataWrapper.Data;
	Mesh.ReverseCulling = IsLocalToWorldDeterminantNegative();
	Mesh.Type = PT_TriangleList;
	Mesh.DepthPriorityGroup = SDPG_World;
	Mesh.bCanApplyViewModeOverrides = false;
}

void UGeometryCacheDecalSceneProxy::GetDynamicMeshElements(const TArray<const FSceneView*>& Views, const FSceneViewFamily& ViewFamily, uint32 VisibilityMap, FMeshElementCollector& Collector) const
{	
	if (!DecalGeometryData || DecalGeometryData->IndexBuffer.Num() == 0)
	{
		return;
	}

	const bool bVisible = [&Views, VisibilityMap]()
	{
		for (int32 ViewIndex = 0; ViewIndex < Views.Num(); ViewIndex++)
		{
			if (VisibilityMap & (1 << ViewIndex))
			{
				return true;
			}
		}
		return false;
	}();

	auto NeedUpdate = [this]()
	{
		if (GeometryCacheDecalComponent->bRuntimeTicking)
		{
			if (!GeometryCacheDecalComponent->bRuntimeInited)
			{
				return true;
			}
			/*else
			{
				if (!GeometryCacheDecalComponent->bManualUpdateCollision && GeometryCacheDecalComponent->AccumulateDeltaTime >= GeometryCacheDecalComponent->UpdateCollisionInterval)
				{
					if (GeometryCacheDecalComponent->GeometryCacheStatus.CheckStatusChanged())
					{
						return true;
					}
				}
			}*/
		}
		else
		{
			return true;
		}

		return true;
	};

	if (bVisible && NeedUpdate())
	{
		UpdateDecalFrame();
	}

	// Draw bounds
	bool bDrawWireframe = GeometryCacheDecalComponent->bShowDecalWireFrame;
	
	for (int32 ViewIndex = 0; ViewIndex < Views.Num(); ViewIndex++)
	{
		if (VisibilityMap & (1 << ViewIndex))
		{
			static FVector3f const PosX(1.f, 0, 0);
			static FVector3f const PosY(0, 1.f, 0);
			static FVector3f const PosZ(0, 0, 1.f);

			UMaterialInterface* MaterialToUse = UMaterial::GetDefaultMaterial(MD_Surface);
			FLinearColor DrawDecalColor = GetWireframeColor();
			FColoredMaterialRenderProxy* WireframeMaterialInstance = nullptr;
			if (bDrawWireframe)
			{
				if (GEngine->WireframeMaterial)
				{
					MaterialToUse = GEngine->WireframeMaterial;
					DrawDecalColor = FColor(0, 255, 255, 255);

					WireframeMaterialInstance = new FColoredMaterialRenderProxy(MaterialToUse->GetRenderProxy(), DrawDecalColor);
					Collector.RegisterOneFrameMaterialProxy(WireframeMaterialInstance);
				}
			}
			else
			{
				MaterialToUse = GeometryCacheDecalComponent->DecalMaterial;
			}

 			if (!MaterialToUse)
			{
				MaterialToUse = UMaterial::GetDefaultMaterial(EMaterialDomain::MD_Surface);
			}

			// Create colored proxy
			FMaterialRenderProxy* RenderProxy = WireframeMaterialInstance ? WireframeMaterialInstance : MaterialToUse->GetRenderProxy();
			
			// Iterate over sections
			{
				if (DecalGeometryData->IndexBuffer.Num() > 0)
				{
					const FSceneView* View = Views[ViewIndex];

					if (bDrawWireframe)
					{
						//this seems far from optimal in terms of perf, but it's for debugging
						FDynamicMeshBuilder MeshBuilder(View->GetFeatureLevel());

						// set up geometry
						for (int32 VertIdx = 0; VertIdx < DecalGeometryData->PositionBuffer.Num(); ++VertIdx)
						{
							MeshBuilder.AddVertex(DecalGeometryData->PositionBuffer[VertIdx], FVector2f::ZeroVector, PosX, PosY, PosZ, FColor::White);
						}

						for (int32 Idx = 0; Idx < DecalGeometryData->IndexBuffer.Num(); Idx += 3)
						{
							MeshBuilder.AddTriangle(DecalGeometryData->IndexBuffer[Idx], DecalGeometryData->IndexBuffer[Idx + 1], DecalGeometryData->IndexBuffer[Idx + 2]);
						}

						MeshBuilder.GetMesh(GetLocalToWorld(), RenderProxy, SDPG_World, false, false, ViewIndex, Collector);
					}
					else
					{
						int32 BatchIndex = 0;
						const FGeometryCacheMeshBatchInfo& BatchInfo = DecalGeometryData->BatchesInfo[BatchIndex];

						FMeshBatch& MeshBatch = Collector.AllocateMesh();

						FDecalGeometryCacheVertexFactoryUserDataWrapper& UserDataWrapper = Collector.AllocateOneFrameResource<FDecalGeometryCacheVertexFactoryUserDataWrapper>();
						FDynamicPrimitiveUniformBuffer& DynamicPrimitiveUniformBuffer = Collector.AllocateOneFrameResource<FDynamicPrimitiveUniformBuffer>();
						CreateMeshBatch(DecalTrackProxy, DecalGeometryData, BatchInfo, UserDataWrapper, DynamicPrimitiveUniformBuffer, MeshBatch);

#if WITH_EDITOR
						// It's possible the number of batches has changed since the initial frame so validate the BatchIndex
						if (HitProxyIds.IsValidIndex(BatchIndex))
						{
							MeshBatch.BatchHitProxyId = HitProxyIds[BatchIndex];
						}
#endif

						// Apply view mode material overrides
						MeshBatch.bWireframe = false; 
						MeshBatch.MaterialRenderProxy = RenderProxy;

						Collector.AddMesh(ViewIndex, MeshBatch);
					}
				}
			}

			if (GeometryCacheDecalComponent->DecalType == EGeometryCacheDecalType::UVRegion)
			{
				;
			}
			else if (GeometryCacheDecalComponent->DecalType == EGeometryCacheDecalType::BoxRegion 
				&& (!GeometryCacheDecalComponent->GetWorld()->IsGameWorld()
					/*|| bDrawWireframe*/))
			{
				const FGeometryCacheDecalBoxInfo& DecalBoxInfo = GeometryCacheDecalComponent->DecalBoxInfo;

				FKAggregateGeom Geom;
				FKBoxElem BoxElem;
				BoxElem.Center = FVector(0.0f);
				BoxElem.X = DecalBoxInfo.DecalRegion.X * 2.0f;
				BoxElem.Y = DecalBoxInfo.DecalRegion.Y * 2.0f;
				BoxElem.Z = DecalBoxInfo.DecalRegion.Z * 2.0f;
				Geom.BoxElems.Add(BoxElem);

				FTransform GeomCacheTransform(GeometryCacheSceneProxy->GetLocalToWorld());
				if (GeomCacheTransform.IsValid())
				{
					FTransform OriginDecalTransform = FTransform(FQuat::MakeFromEuler(DecalBoxInfo.DecalRotation), DecalBoxInfo.DecalCenter);

					Geom.GetAggGeom(OriginDecalTransform * GeomCacheTransform, FColor(255, 0, 0, 255), NULL, false, false, DrawsVelocity(), ViewIndex, Collector);
				}
			}

#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
			// Render bounds
			RenderBounds(Collector.GetPDI(ViewIndex), ViewFamily.EngineShowFlags, GetBounds(), IsSelected());
#endif
		}
	}
}

void UGeometryCacheDecalSceneProxy::SubmitSectionBuffer_RenderThread() const 
{
	//UpdatedFrameNum = GFrameNumber + 1;
	const uint32 FrameIndexToUse = GFrameNumber + 1;// UpdatedFrameNum;

	check(IsInRenderingThread());

	if (DecalGeometryData != nullptr)
	{
		//if (SectionData->bUpdateNormal || SectionData->bUpdateTangent)
		{
			DecalTrackProxy->TangentXBuffer.Update(DecalGeometryData->TangentsX);
			DecalTrackProxy->TangentZBuffer.Update(DecalGeometryData->TangentsZ);
		}

		if (DecalGeometryData->bNewGeneratedDecal)
		{
			DecalGeometryData->bNewGeneratedDecal = false;

			DecalTrackProxy->IndexBuffer.Update(DecalGeometryData->IndexBuffer);

			DecalTrackProxy->TextureCoordinatesBuffer.Update(DecalGeometryData->UVBuffer);

			TArray<FColor> Colors;
			Colors.SetNum(DecalGeometryData->UVBuffer.Num());
			for (FColor& Color : Colors)
			{
				Color = FColor::White;
			}
			DecalTrackProxy->ColorBuffer.Update(Colors);
		}
			
		// Initialize both buffers the first frame or when topology changed as we can't render
		// with a previous buffer referencing a buffer from another topology
		if (DecalTrackProxy->CurrentPositionBufferIndex == -1)
		{
			DecalTrackProxy->PositionBuffers[0].Update(DecalGeometryData->PositionBuffer);
			DecalTrackProxy->PositionBuffers[1].Update(DecalGeometryData->PositionBuffer);
			DecalTrackProxy->CurrentPositionBufferIndex = 0;
			DecalTrackProxy->PositionBufferFrameIndices[0] = FrameIndexToUse;
			DecalTrackProxy->PositionBufferFrameIndices[1] = FrameIndexToUse;
		}
		// We still use the previous frame's buffer as a motion blur previous position. As interpolation is switched
		// off the actual time of this previous frame depends on the geometry cache framerate and playback speed
		// so the motion blur vectors may not really be anything relevant. Do we want to just disable motion blur? 
		// But as an optimization skipping interpolation when the cache fps is near to the actual game fps this is obviously nice...
		else
		{
			DecalTrackProxy->CurrentPositionBufferIndex++;
			DecalTrackProxy->PositionBuffers[DecalTrackProxy->CurrentPositionBufferIndex % 2].Update(DecalGeometryData->PositionBuffer);
			//DecalTrackProxy->PositionBuffers[0].Update(MeshDataToUse->Positions);
			//DecalTrackProxy->PositionBuffers[1].Update(MeshDataToUse->Positions);
			DecalTrackProxy->PositionBufferFrameIndices[DecalTrackProxy->CurrentPositionBufferIndex % 2] = FrameIndexToUse; //TrackProxy->CurrentPositionBufferIndex; //
		}
			

#if RHI_RAYTRACING
		if (IsRayTracingEnabled())
		{
			if(DecalTrackProxy->RayTracingGeometry.Initializer.TotalPrimitiveCount == 0)
			{
				FRayTracingGeometryInitializer Initializer;
				Initializer.TotalPrimitiveCount = 0;
				Initializer.GeometryType = RTGT_Triangles;
				Initializer.bFastBuild = true;
				Initializer.bAllowUpdate = false;

				TArray<FRayTracingGeometrySegment> Segments;
				//const FGeometryCacheMeshData* MeshData = TrackProxy->MeshData;
				for (const FGeometryCacheMeshBatchInfo& BatchInfo : DecalGeometryData->BatchesInfo)
				{
					FRayTracingGeometrySegment Segment;
					Segment.FirstPrimitive = BatchInfo.StartIndex / 3;
					Segment.NumPrimitives = BatchInfo.NumTriangles;
					Segment.VertexBuffer = DecalTrackProxy->PositionBuffers[DecalTrackProxy->CurrentPositionBufferIndex % 2].VertexBufferRHI;
					Segment.MaxVertices = DecalTrackProxy->PositionBuffers[DecalTrackProxy->CurrentPositionBufferIndex % 2].GetSizeInBytes() / Segment.VertexBufferStride; // conservative estimate
					Segments.Add(Segment);
					Initializer.TotalPrimitiveCount += BatchInfo.NumTriangles;
				}

				Initializer.Segments = Segments;

				// The geometry is not considered valid for initialization unless it has any triangles
				if (Initializer.TotalPrimitiveCount > 0)
				{
					Initializer.IndexBuffer = DecalTrackProxy->IndexBuffer.IndexBufferRHI;
				}
				DecalTrackProxy->RayTracingGeometry.SetInitializer(Initializer);
				DecalTrackProxy->RayTracingGeometry.InitResource();

				DecalTrackProxy->RayTracingGeometry.UpdateRHI();
			}
			else
			{
				const uint32 IndexBufferNumTriangles = DecalTrackProxy->IndexBuffer.NumValidIndices / 3;

#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 3
				TArray<FRayTracingGeometrySegment>& Segments = DecalTrackProxy->RayTracingGeometry.Initializer.Segments;
#else
				TMemoryImageArray<FRayTracingGeometrySegment>& Segments = DecalTrackProxy->RayTracingGeometry.Initializer.Segments;
#endif
				Segments.Reset();

				uint32 TotalPrimitiveCount = 0;
				for (const FGeometryCacheMeshBatchInfo& BatchInfo : DecalGeometryData->BatchesInfo)
				{
					FRayTracingGeometrySegment Segment;
					Segment.FirstPrimitive = BatchInfo.StartIndex / 3;
					Segment.NumPrimitives = BatchInfo.NumTriangles;

					// Ensure that a geometry segment does not access the index buffer out of bounds
					if (!ensureMsgf(Segment.FirstPrimitive + Segment.NumPrimitives <= IndexBufferNumTriangles,
						TEXT("Ray tracing geometry index buffer is smaller than what's required by FGeometryCacheMeshBatchInfo. ")
						TEXT("Segment.FirstPrimitive=%d Segment.NumPrimitives=%d RequiredIndexBufferTriangles=%d IndexBufferNumTriangles=%d"),
						Segment.FirstPrimitive, Segment.NumPrimitives, Segment.FirstPrimitive + Segment.NumPrimitives, IndexBufferNumTriangles))
					{
						Segment.NumPrimitives = IndexBufferNumTriangles - FMath::Min<uint32>(Segment.FirstPrimitive, IndexBufferNumTriangles);
					}

					Segment.VertexBuffer = DecalTrackProxy->PositionBuffers[DecalTrackProxy->CurrentPositionBufferIndex % 2].VertexBufferRHI;
					Segment.MaxVertices = DecalTrackProxy->PositionBuffers[DecalTrackProxy->CurrentPositionBufferIndex % 2].GetSizeInBytes() / Segment.VertexBufferStride; // conservative estimate
					Segments.Add(Segment);
					TotalPrimitiveCount += BatchInfo.NumTriangles;
				}

				DecalTrackProxy->RayTracingGeometry.Initializer.IndexBuffer = DecalTrackProxy->IndexBuffer.IndexBufferRHI;
				DecalTrackProxy->RayTracingGeometry.Initializer.TotalPrimitiveCount = TotalPrimitiveCount;
				if (Segments.Num() > 0)
				{

					FRayTracingGeometryBuildParams BuildParams;
					BuildParams.Geometry = DecalTrackProxy->RayTracingGeometry.RayTracingGeometryRHI;
					BuildParams.BuildMode = EAccelerationStructureBuildMode::Build;
					BuildParams.Segments = DecalTrackProxy->RayTracingGeometry.Initializer.Segments;
					FRHICommandListExecutor::GetImmediateCommandList().BuildAccelerationStructures(MakeArrayView(&BuildParams, 1));
				}

			}
		}
#endif
	}
}

#if RHI_RAYTRACING

void UGeometryCacheDecalSceneProxy::GetDynamicRayTracingInstances(FRayTracingMaterialGatheringContext& Context, TArray<FRayTracingInstance>& OutRayTracingInstances)
{
	if (DecalGeometryData->IndexBuffer.Num() >= 0
		&& DecalTrackProxy->RayTracingGeometry.IsValid() 
		&& DecalTrackProxy->RayTracingGeometry.IsInitialized())
	{
		float Time = 0.0f;
		bool bLooping = true;

		const FVisibilitySample& VisibilitySample = DecalTrackProxy->GetVisibilitySample(Time, bLooping);
		if (!VisibilitySample.bVisibilityState)
		{
			return;
		}

		FRayTracingInstance RayTracingInstance;
		RayTracingInstance.Geometry = &DecalTrackProxy->RayTracingGeometry;
		RayTracingInstance.InstanceTransforms.Add(GetLocalToWorld());

		for (int32 SegmentIndex = 0; SegmentIndex < DecalGeometryData->BatchesInfo.Num(); ++SegmentIndex)
		{
			const FGeometryCacheMeshBatchInfo& BatchInfo = DecalGeometryData->BatchesInfo[SegmentIndex];
			FMeshBatch MeshBatch;

			FDecalGeometryCacheVertexFactoryUserDataWrapper& UserDataWrapper = Context.RayTracingMeshResourceCollector.AllocateOneFrameResource<FDecalGeometryCacheVertexFactoryUserDataWrapper>();
			FDynamicPrimitiveUniformBuffer& DynamicPrimitiveUniformBuffer = Context.RayTracingMeshResourceCollector.AllocateOneFrameResource<FDynamicPrimitiveUniformBuffer>();
			CreateMeshBatch(DecalTrackProxy, DecalGeometryData, BatchInfo, UserDataWrapper, DynamicPrimitiveUniformBuffer, MeshBatch);

			MeshBatch.MaterialRenderProxy = DecalTrackProxy->Materials[SegmentIndex]->GetRenderProxy();
			MeshBatch.CastRayTracedShadow = IsShadowCast(Context.ReferenceView);
			MeshBatch.SegmentIndex = SegmentIndex;

			RayTracingInstance.Materials.Add(MeshBatch);
		}

		if (RayTracingInstance.Materials.Num() > 0)
		{
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 2
#else
			RayTracingInstance.BuildInstanceMaskAndFlags(
				GetScene().GetFeatureLevel()
			);
#endif

			OutRayTracingInstances.Add(RayTracingInstance);
		}
	}
}

#endif

bool UGeometryCacheDecalSceneProxy::GenerateDecalMesh(bool bNextFrame) const
{
	if (!DecalGeometryData)
	{
		return false;
	}
	DecalGeometryData->Clear();

	const TArray<FGeomCacheTrackProxy*>& Tracks = GeometryCacheSceneProxy->GetTracks();
	if (!Tracks.IsValidIndex(GeometryCacheDecalComponent->DecalTrackIndex))
	{
		return false;
	}

	FGeomCacheTrackProxy* TrackProxy = Tracks[GeometryCacheDecalComponent->DecalTrackIndex];
	if (TrackProxy != nullptr)
	{
		if (GeometryCacheDecalComponent->DecalType == EGeometryCacheDecalType::UVRegion)
		{
			GenerateDecalMeshInUVRegion(TrackProxy, GeometryCacheDecalComponent->DecalUVInfo, bNextFrame);
		}
		else if (GeometryCacheDecalComponent->DecalType == EGeometryCacheDecalType::BoxRegion)
		{
			GenerateDecalMeshInBoxRegion(TrackProxy, GeometryCacheDecalComponent->DecalBoxInfo, bNextFrame);
		}
	}

	if (DecalGeometryData->IndexBuffer.Num() > 0 && DecalGeometryData->UVBuffer.Num() > 0 && !DecalTrackProxy->bResourcesInitialized)
	{
		DecalTrackProxy->InitRenderResources(DecalGeometryData->UVBuffer.Num(), DecalGeometryData->IndexBuffer.Num());
	}

	DecalGeometryData->DecalGenerateFrameIndex = bNextFrame ? TrackProxy->NextFrameIndex :TrackProxy->FrameIndex;
	DecalGeometryData->bNewGeneratedDecal = true;
	return true;
}

bool UGeometryCacheDecalSceneProxy::GenerateDecalMeshInUVRegion(FGeomCacheTrackProxy* TrackProxy, const FGeometryCacheDecalUVInfo& DecalInfo, bool bNextFrame) const
{
	if (TrackProxy != nullptr)
	{
		FGeometryCacheMeshData* MeshDataToUse = bNextFrame ? TrackProxy->NextFrameMeshData : TrackProxy->MeshData;
		if (MeshDataToUse->VertexInfo.bHasUV0)
		{
			auto CheckVerticeInUVRegion = [](const FTransform2f& DecalUVTransform, const FVector2f& DecalUVRegion, const FVector2f& UV)
			{
				FVector2f NewUV = DecalUVTransform.TransformPoint(UV);
				if (NewUV.X >= -DecalUVRegion.X && NewUV.X <= DecalUVRegion.X
					&& NewUV.Y >= -DecalUVRegion.Y && NewUV.Y <= DecalUVRegion.Y)
				{
					return true;
				}
				return false;
			};

			auto CheckTriangleInUVRegion = [CheckVerticeInUVRegion](const FTransform2f& DecalUVTransform, const FVector2f& DecalUVRegion, const FVector2f& UV0, const FVector2f& UV1, const FVector2f& UV2, bool& bAllInRegion)
			{
				bool bV0InRegion = CheckVerticeInUVRegion(DecalUVTransform, DecalUVRegion, UV0);
				bool bV1InRegion = CheckVerticeInUVRegion(DecalUVTransform, DecalUVRegion, UV1);
				bool bV2InRegion = CheckVerticeInUVRegion(DecalUVTransform, DecalUVRegion, UV2);

				bAllInRegion = bV0InRegion && bV1InRegion && bV2InRegion;
				
				return bV0InRegion || bV1InRegion || bV2InRegion;
			};

			TArray<FVector3f> DecalPositionBuffer;
			TArray<FVector2f> DecalUVBuffer;
			TArray<uint32> DecalIndexBuffer;
			TMap<int32, int32> DecalVerticeIndexMap;
			TArray<int32> OriginVerticeIndexes;
			int32 DecalVerticeNum = 0;

			auto AddDecalVertice = [&OriginVerticeIndexes, &DecalVerticeIndexMap,&DecalVerticeNum](int32 VerticeIndex)
			{
				int32 DecalVertIndex = -1;
				if (!DecalVerticeIndexMap.Contains(VerticeIndex))
				{
					DecalVertIndex = DecalVerticeNum;
					OriginVerticeIndexes.Add(VerticeIndex);
					DecalVerticeIndexMap.Add(VerticeIndex, DecalVerticeNum);
					DecalVerticeNum++;
				}
				else
				{
					DecalVertIndex = DecalVerticeIndexMap[VerticeIndex];
				}

				return DecalVertIndex;
			};

			FVector2f DecalUVCenter = FVector2f(DecalInfo.DecalUVCenter);
			FVector2f DecalUVRegion = FVector2f(DecalInfo.DecalRegion);
			FVector2f DecalLeftTop = DecalUVCenter - DecalUVRegion * 0.5f;
			FVector2f DecalRightBottom = DecalUVCenter + DecalUVRegion * 0.5f;

			FTransform2f  DecalUVTransform = FTransform2f(FQuat2D(FMath::DegreesToRadians(DecalInfo.DecalRotation)), DecalInfo.DecalUVCenter);
			DecalUVTransform = DecalUVTransform.Inverse();
	
			float DecalRotation = DecalInfo.DecalRotation;

			TArray<uint32>& Indices = MeshDataToUse->Indices;
			TArray<FVector2f>& TextureCoordinates = MeshDataToUse->TextureCoordinates;

			
			for (int32 Index = 0; Index < Indices.Num(); Index += 3)
			{
				FVector2f& UV0 = TextureCoordinates[Indices[Index]];
				FVector2f& UV1 = TextureCoordinates[Indices[Index + 1]];
				FVector2f& UV2 = TextureCoordinates[Indices[Index + 2]];
				bool bAllInRegion = false;
				if (CheckTriangleInUVRegion(DecalUVTransform, DecalUVRegion, UV0, UV1, UV2, bAllInRegion))
				{
					int32 DecalVertIndex0 = AddDecalVertice(Indices[Index]);
					int32 DecalVertIndex1 = AddDecalVertice(Indices[Index + 1]);
					int32 DecalVertIndex2 = AddDecalVertice(Indices[Index + 2]);

					DecalIndexBuffer.Add(DecalVertIndex0);
					DecalIndexBuffer.Add(DecalVertIndex1);
					DecalIndexBuffer.Add(DecalVertIndex2);
				}
			}

			DecalUVBuffer.SetNum(OriginVerticeIndexes.Num());
			for (int32 Index = 0; Index < OriginVerticeIndexes.Num(); Index++)
			{
				int32 VerticeIndex = OriginVerticeIndexes[Index];
				FVector2f& UV = TextureCoordinates[VerticeIndex];
				if (DecalInfo.bGenerateDecalUV)
				{
					FVector2f NewUV = DecalUVTransform.TransformPoint(UV);
					DecalUVBuffer[Index] = (NewUV + DecalUVRegion) / (DecalUVRegion * 2);
				}
				else
				{
					DecalUVBuffer[Index] = UV;
				}
			}

			DecalGeometryData->IndexBuffer = DecalIndexBuffer;
			DecalGeometryData->OriginVerticeIndex = OriginVerticeIndexes;
			DecalGeometryData->UVBuffer = DecalUVBuffer;
			DecalGeometryData->Prepare(OriginVerticeIndexes.Num());

			FGeometryCacheMeshBatchInfo BatchInfo;
			BatchInfo.StartIndex = 0;
			BatchInfo.NumTriangles = DecalIndexBuffer.Num() / 3;
			BatchInfo.MaterialIndex = 0;
			DecalGeometryData->BatchesInfo.Empty();
			DecalGeometryData->BatchesInfo.Add(BatchInfo);		

			if (DecalGeometryData->IndexBuffer.Num() > 0 && DecalGeometryData->UVBuffer.Num() > 0 && !DecalTrackProxy->bResourcesInitialized)
			{
				DecalTrackProxy->InitRenderResources(DecalGeometryData->UVBuffer.Num(), DecalGeometryData->IndexBuffer.Num());
			}
		}
	}

	return true;
}

bool UGeometryCacheDecalSceneProxy::GenerateDecalMeshInBoxRegion(FGeomCacheTrackProxy* TrackProxy, const FGeometryCacheDecalBoxInfo& DecalBoxInfo, bool bNextFrame) const
{
	if (TrackProxy != nullptr)
	{
		if (DecalGeometryData->RematchMap.Num() == 0)
		{
			auto CheckVerticeInBoxRegion = [](const FTransform3f& DecalTransform, const FVector3f& Region, const FVector3f& P)
				{
					FVector3f NewP = DecalTransform.TransformPosition(P);
					if (NewP.X >= -Region.X && NewP.X <= Region.X
						&& NewP.Y >= -Region.Y && NewP.Y <= Region.Y
						&& NewP.Z >= -Region.Y && NewP.Z <= Region.Z)
					{
						return true;
					}
					return false;
				};

			auto CheckTriangleInBoxRegion = [CheckVerticeInBoxRegion](const FTransform3f& DecalTransform, const FVector3f& Region, const FVector3f& P0, const FVector3f& P1, const FVector3f& P2, bool& bAllInRegion)
				{
					bool bV0InRegion = CheckVerticeInBoxRegion(DecalTransform, Region, P0);
					bool bV1InRegion = CheckVerticeInBoxRegion(DecalTransform, Region, P1);
					bool bV2InRegion = CheckVerticeInBoxRegion(DecalTransform, Region, P2);

					bAllInRegion = bV0InRegion && bV1InRegion && bV2InRegion;

					return bV0InRegion || bV1InRegion || bV2InRegion;
				};

			TArray<FVector3f> DecalPositionBuffer;
			TArray<FVector2f> DecalUVBuffer;
			TArray<uint32> DecalIndexBuffer;
			TMap<int32, int32> DecalVerticeIndexMap;
			TArray<int32> OriginVerticeIndexes;
			int32 DecalVerticeNum = 0;

			auto AddDecalVertice = [&OriginVerticeIndexes, &DecalVerticeIndexMap, &DecalVerticeNum](int32 VerticeIndex)
				{
					int32 DecalVertIndex = -1;
					if (!DecalVerticeIndexMap.Contains(VerticeIndex))
					{
						DecalVertIndex = DecalVerticeNum;
						OriginVerticeIndexes.Add(VerticeIndex);
						DecalVerticeIndexMap.Add(VerticeIndex, DecalVerticeNum);
						DecalVerticeNum++;
					}
					else
					{
						DecalVertIndex = DecalVerticeIndexMap[VerticeIndex];
					}

					return DecalVertIndex;
				};

			FVector3f DecalRegion = FVector3f(DecalBoxInfo.DecalRegion);
			FVector3f DecalCenter = FVector3f(DecalBoxInfo.DecalCenter);
			FVector3f DecalRotation = FVector3f(DecalBoxInfo.DecalRotation);
			FTransform OriginDecalTransform = FTransform(FQuat::MakeFromEuler(DecalBoxInfo.DecalRotation), DecalBoxInfo.DecalCenter);
			FTransform3f DecalTransform = FTransform3f(OriginDecalTransform);
			DecalTransform = DecalTransform.Inverse();

			FGeometryCacheMeshData* MeshDataToUse = bNextFrame ? TrackProxy->NextFrameMeshData : TrackProxy->MeshData;
			TArray<uint32>& Indices = MeshDataToUse->Indices;
			TArray<FVector3f>& Positions = MeshDataToUse->Positions;
			TArray<FVector2f>& TextureCoordinates = MeshDataToUse->TextureCoordinates;
			for (int32 Index = 0; Index < Indices.Num(); Index += 3)
			{
				FVector3f& P0 = Positions[Indices[Index]];
				FVector3f& P1 = Positions[Indices[Index + 1]];
				FVector3f& P2 = Positions[Indices[Index + 2]];
				bool bAllInRegion = false;
				if (CheckTriangleInBoxRegion(DecalTransform, DecalRegion, P0, P1, P2, bAllInRegion))
				{
					int32 DecalVertIndex0 = AddDecalVertice(Indices[Index]);
					int32 DecalVertIndex1 = AddDecalVertice(Indices[Index + 1]);
					int32 DecalVertIndex2 = AddDecalVertice(Indices[Index + 2]);

					DecalIndexBuffer.Add(DecalVertIndex0);
					DecalIndexBuffer.Add(DecalVertIndex1);
					DecalIndexBuffer.Add(DecalVertIndex2);
				}
			}

			FVector2D OriginUVMin = FVector2D(999);
			FVector2D OriginUVMax = FVector2D(0);
			DecalUVBuffer.SetNum(OriginVerticeIndexes.Num());
			for (int32 Index = 0; Index < OriginVerticeIndexes.Num(); Index++)
			{
				int32 VerticeIndex = OriginVerticeIndexes[Index];
				FVector2f& UV = TextureCoordinates[VerticeIndex];
				if (OriginUVMax.X < UV.X)
					OriginUVMax.X = UV.X;
				if (OriginUVMax.Y < UV.Y)
					OriginUVMax.Y = UV.Y;
				if (OriginUVMin.X > UV.X)
					OriginUVMin.X = UV.X;
				if (OriginUVMin.Y > UV.Y)
					OriginUVMin.Y = UV.Y;

				if (DecalBoxInfo.bGenerateDecalUV)
				{
					FVector3f& P = Positions[VerticeIndex];
					FVector3f NewP = DecalTransform.TransformPosition(P);
					FVector2f NewUV;
					switch (DecalBoxInfo.UVToward)
					{
					case EGeometryCacheDecalBoxUVToward::UVTowardXAxis:
						NewUV.X = (NewP.Z - (-DecalRegion.Z)) / (DecalRegion.Z * 2);
						NewUV.Y = (NewP.Y - (-DecalRegion.Y)) / (DecalRegion.Y * 2);
						break;
					case EGeometryCacheDecalBoxUVToward::UVTowardYAxis:
						NewUV.X = (NewP.Z - (-DecalRegion.Z)) / (DecalRegion.Z * 2);
						NewUV.Y = (NewP.X - (-DecalRegion.X)) / (DecalRegion.X * 2);
						break;
					case EGeometryCacheDecalBoxUVToward::UVTowardZAxis:
						NewUV.X = (NewP.X - (-DecalRegion.X)) / (DecalRegion.X * 2);
						NewUV.Y = (NewP.Y - (-DecalRegion.Y)) / (DecalRegion.Y * 2);
						break;
					}
					DecalUVBuffer[Index] = NewUV;
				}
				else
				{
					DecalUVBuffer[Index] = UV;
				}
			}

			if (OriginVerticeIndexes.Num() > 0
				/*&& OriginUVMin.X >= 0.0f && OriginUVMin.Y >= 0.0f
				&& OriginUVMax.X <= 1.0f && OriginUVMax.Y <= 1.0f*/)
			{
				double DisX = OriginUVMax.X - OriginUVMin.X;
				double DisY = OriginUVMax.Y - OriginUVMin.Y;

				int32 RematchSize = DecalBoxInfo.RematchDimensions;
				double StepDisX = DisX / RematchSize;
				double StepDisY = DisY / RematchSize;

				DecalGeometryData->OriginUVMin = OriginUVMin;
				DecalGeometryData->OriginUVMax = OriginUVMax;
				DecalGeometryData->RematchStepSize = FVector2D(StepDisX, StepDisY);
				TArray< TArray<FVector> >& RematchMap = DecalGeometryData->RematchMap;
				RematchMap.SetNum(RematchSize);
				for (int32 Index = 0; Index < RematchSize; Index++)
				{
					RematchMap[Index].SetNumZeroed(RematchSize);
				}

				auto GetMinMax = [](const FVector2f& UV, const FVector2f& NewUV, FVector2f& Min, FVector2f& Max, FVector2f& NewMin, FVector2f& NewMax) {
					if (Min.X > UV.X)
					{
						Min.X = UV.X;
						NewMin.X = NewUV.X;
					}
					if (Min.Y > UV.Y)
					{
						Min.Y = UV.Y;
						NewMin.Y = NewUV.Y;
					}
					if (Max.X < UV.X)
					{
						Max.X = UV.X;
						NewMax.X = NewUV.X;
					}
					if (Max.Y < UV.Y)
					{
						Max.Y = UV.Y;
						NewMax.Y = NewUV.Y;
					}
					};

				for (int32 Index = 0; Index < DecalIndexBuffer.Num(); Index += 3)
				{
					int32 DecalVertIndex0 = OriginVerticeIndexes[DecalIndexBuffer[Index]];
					int32 DecalVertIndex1 = OriginVerticeIndexes[DecalIndexBuffer[Index + 1]];
					int32 DecalVertIndex2 = OriginVerticeIndexes[DecalIndexBuffer[Index + 2]];

					FVector2f& UV0 = TextureCoordinates[DecalVertIndex0];
					FVector2f& UV1 = TextureCoordinates[DecalVertIndex1];
					FVector2f& UV2 = TextureCoordinates[DecalVertIndex2];
					FVector2f Min = UV0;
					FVector2f Max = UV0;

					FVector2f& NewUV0 = DecalUVBuffer[DecalIndexBuffer[Index]];
					FVector2f& NewUV1 = DecalUVBuffer[DecalIndexBuffer[Index + 1]];
					FVector2f& NewUV2 = DecalUVBuffer[DecalIndexBuffer[Index + 2]];
					FVector2f NewMin = NewUV0;
					FVector2f NewMax = NewUV0;

					GetMinMax(UV1, NewUV1, Min, Max, NewMin, NewMax);
					GetMinMax(UV2, NewUV2, Min, Max, NewMin, NewMax);

					int32 UStepStart = (Min.X - OriginUVMin.X) / StepDisX;
					int32 UStepEnd = (Max.X - OriginUVMin.X) / StepDisX + 1;
					int32 VStepStart = (Min.Y - OriginUVMin.Y) / StepDisY;
					int32 VStepEnd = (Max.Y - OriginUVMin.Y) / StepDisY + 1;

					UStepStart = FMath::Clamp(UStepStart, 0, RematchSize - 1);
					UStepEnd = FMath::Clamp(UStepEnd, 0, RematchSize - 1);
					VStepStart = FMath::Clamp(VStepStart, 0, RematchSize - 1);
					VStepEnd = FMath::Clamp(VStepEnd, 0, RematchSize - 1);

					for (int32 U = UStepStart; U < UStepEnd; U++)
					{
						for (int32 V = VStepStart; V < VStepEnd; V++)
						{
							float NewU = NewMin.X + (((OriginUVMin.X + U * StepDisX) - Min.X) / (Max.X - Min.X)) * (NewMax.X - NewMin.X);
							float NewV = NewMin.Y + (((OriginUVMin.Y + V * StepDisY) - Min.Y) / (Max.Y - Min.Y)) * (NewMax.Y - NewMin.Y);
							RematchMap[U][V] = FVector(NewU, NewV, 1);
						}
					}
				}
			}

			DecalGeometryData->IndexBuffer = DecalIndexBuffer;
			DecalGeometryData->OriginVerticeIndex = OriginVerticeIndexes;
			DecalGeometryData->UVBuffer = DecalUVBuffer;
			DecalGeometryData->Prepare(OriginVerticeIndexes.Num());

			FGeometryCacheMeshBatchInfo BatchInfo;
			BatchInfo.StartIndex = 0;
			BatchInfo.NumTriangles = DecalIndexBuffer.Num() / 3;
			BatchInfo.MaterialIndex = 0;
			DecalGeometryData->BatchesInfo.Empty();
			DecalGeometryData->BatchesInfo.Add(BatchInfo);
		}
		else
		{
			FVector2D& OriginUVMin = DecalGeometryData->OriginUVMin;
			FVector2D& OriginUVMax = DecalGeometryData->OriginUVMax;
			FVector2D& RematchStepSize = DecalGeometryData->RematchStepSize;
			TArray< TArray<FVector> >& RematchMap = DecalGeometryData->RematchMap;
			int32 RematchSize = RematchMap.Num();
			auto CheckVerticeInRematchMap = [&RematchMap, &OriginUVMin, &OriginUVMax, &RematchStepSize, &RematchSize](const FVector2f& UV)
				{
					int32 IndexU = (UV.X - OriginUVMin.X) / RematchStepSize.X;
					IndexU = FMath::Clamp(IndexU, 0, RematchSize - 1);
					int32 IndexV = (UV.Y - OriginUVMin.Y) / RematchStepSize.Y;
					IndexV = FMath::Clamp(IndexV, 0, RematchSize - 1);
					if (RematchMap[IndexU][IndexV].Z >= 0.9f)
					{
						return true;
					}
					return false;
				};

			auto CheckTriangleInRematchMap = [CheckVerticeInRematchMap](const FVector2f& UV0, const FVector2f& UV1, const FVector2f& UV2, bool& bAllInRegion)
				{
					bool bV0InRegion = CheckVerticeInRematchMap(UV0);
					bool bV1InRegion = CheckVerticeInRematchMap(UV1);
					bool bV2InRegion = CheckVerticeInRematchMap(UV2);

					bAllInRegion = bV0InRegion && bV1InRegion && bV2InRegion;

					return bV0InRegion || bV1InRegion || bV2InRegion;
				};

			TArray<FVector3f> DecalPositionBuffer;
			TArray<FVector2f> DecalUVBuffer;
			TArray<uint32> DecalIndexBuffer;
			TMap<int32, int32> DecalVerticeIndexMap;
			TArray<int32> OriginVerticeIndexes;
			int32 DecalVerticeNum = 0;

			auto AddDecalVertice = [&OriginVerticeIndexes, &DecalVerticeIndexMap, &DecalVerticeNum](int32 VerticeIndex)
				{
					int32 DecalVertIndex = -1;
					if (!DecalVerticeIndexMap.Contains(VerticeIndex))
					{
						DecalVertIndex = DecalVerticeNum;
						OriginVerticeIndexes.Add(VerticeIndex);
						DecalVerticeIndexMap.Add(VerticeIndex, DecalVerticeNum);
						DecalVerticeNum++;
					}
					else
					{
						DecalVertIndex = DecalVerticeIndexMap[VerticeIndex];
					}

					return DecalVertIndex;
				};

			FVector3f DecalRegion = FVector3f(DecalBoxInfo.DecalRegion);
			FVector3f DecalCenter = FVector3f(DecalBoxInfo.DecalCenter);
			FVector3f DecalRotation = FVector3f(DecalBoxInfo.DecalRotation);
			FTransform OriginDecalTransform = FTransform(FQuat::MakeFromEuler(DecalBoxInfo.DecalRotation), DecalBoxInfo.DecalCenter);
			FTransform3f DecalTransform = FTransform3f(OriginDecalTransform);
			DecalTransform = DecalTransform.Inverse();

			FGeometryCacheMeshData* MeshDataToUse = bNextFrame ? TrackProxy->NextFrameMeshData : TrackProxy->MeshData;
			TArray<uint32>& Indices = MeshDataToUse->Indices;
			TArray<FVector3f>& Positions = MeshDataToUse->Positions;
			TArray<FVector2f>& TextureCoordinates = MeshDataToUse->TextureCoordinates;
			for (int32 Index = 0; Index < Indices.Num(); Index += 3)
			{
				FVector2f& UV0 = TextureCoordinates[Indices[Index]];
				FVector2f& UV1 = TextureCoordinates[Indices[Index + 1]];
				FVector2f& UV2 = TextureCoordinates[Indices[Index + 2]];
				bool bAllInRegion = false;
				if (CheckTriangleInRematchMap(UV0, UV1, UV2, bAllInRegion))
				{
					if (bAllInRegion)
					{
						int32 DecalVertIndex0 = AddDecalVertice(Indices[Index]);
						int32 DecalVertIndex1 = AddDecalVertice(Indices[Index + 1]);
						int32 DecalVertIndex2 = AddDecalVertice(Indices[Index + 2]);

						DecalIndexBuffer.Add(DecalVertIndex0);
						DecalIndexBuffer.Add(DecalVertIndex1);
						DecalIndexBuffer.Add(DecalVertIndex2);
					}
				}
			}

			DecalUVBuffer.SetNum(OriginVerticeIndexes.Num());
			for (int32 Index = 0; Index < OriginVerticeIndexes.Num(); Index++)
			{
				int32 VerticeIndex = OriginVerticeIndexes[Index];
				FVector2f& UV = TextureCoordinates[VerticeIndex];

				if (DecalBoxInfo.bGenerateDecalUV)
				{
					int32 IndexU0 = (UV.X - OriginUVMin.X) / RematchStepSize.X;
					IndexU0 = FMath::Clamp(IndexU0, 0, RematchSize - 1);
					int32 IndexU1 = FMath::Clamp(IndexU0 + 1, 0, RematchSize - 1);
					float UAlpha = ((UV.X - OriginUVMin.X) - RematchStepSize.X * IndexU0) / RematchStepSize.X;

					int32 IndexV0 = (UV.Y - OriginUVMin.Y) / RematchStepSize.Y;
					IndexV0 = FMath::Clamp(IndexV0, 0, RematchSize - 1);
					int32 IndexV1 = FMath::Clamp(IndexV0 + 1, 0, RematchSize - 1);
					float VAlpha = ((UV.Y - OriginUVMin.Y) - RematchStepSize.Y * IndexV0) / RematchStepSize.Y;

					FVector2f RematchUV00 = /*RematchMap[IndexU0][IndexV0].Z == 0 ? FVector2f(1.1f, 1.1f) : */FVector2f(RematchMap[IndexU0][IndexV0].X, RematchMap[IndexU0][IndexV0].Y);
					FVector2f RematchUV01 = RematchMap[IndexU0][IndexV1].Z == 0 ? RematchUV00 : FVector2f(RematchMap[IndexU0][IndexV1].X, RematchMap[IndexU0][IndexV1].Y);
					FVector2f RematchUV10 = RematchMap[IndexU1][IndexV0].Z == 0 ? RematchUV00 : FVector2f(RematchMap[IndexU1][IndexV0].X, RematchMap[IndexU1][IndexV0].Y);
					FVector2f RematchUV11 = RematchMap[IndexU1][IndexV1].Z == 0 ? RematchUV10 : FVector2f(RematchMap[IndexU1][IndexV1].X, RematchMap[IndexU1][IndexV1].Y);

					FVector2f NewUV0 = RematchUV00 * (1 - UAlpha) + RematchUV10 * UAlpha;
					FVector2f NewUV1 = RematchUV01 * (1 - UAlpha) + RematchUV11 * UAlpha;
					
					FVector2f NewUV;
					NewUV = NewUV0 * (1 - VAlpha) + NewUV1 * VAlpha; // 

					DecalUVBuffer[Index] = NewUV;
				}
				else
				{
					DecalUVBuffer[Index] = UV;
				}
			}
			DecalGeometryData->IndexBuffer = DecalIndexBuffer;
			DecalGeometryData->OriginVerticeIndex = OriginVerticeIndexes;
			DecalGeometryData->UVBuffer = DecalUVBuffer;
			DecalGeometryData->Prepare(OriginVerticeIndexes.Num());

			FGeometryCacheMeshBatchInfo BatchInfo;
			BatchInfo.StartIndex = 0;
			BatchInfo.NumTriangles = DecalIndexBuffer.Num() / 3;
			BatchInfo.MaterialIndex = 0;
			DecalGeometryData->BatchesInfo.Empty();
			DecalGeometryData->BatchesInfo.Add(BatchInfo);
		}
	}

	return true;
}

FPrimitiveViewRelevance UGeometryCacheDecalSceneProxy::GetViewRelevance(const FSceneView* View) const
{
	FPrimitiveViewRelevance Result;
	Result.bDrawRelevance = IsShown(View);
	Result.bShadowRelevance = IsShadowCast(View);
	Result.bDynamicRelevance = true;
	Result.bRenderInMainPass = ShouldRenderInMainPass();
	Result.bUsesLightingChannels = GetLightingChannelMask() != GetDefaultLightingChannelMask();
	Result.bRenderCustomDepth = ShouldRenderCustomDepth();
	Result.bTranslucentSelfShadow = bCastVolumetricTranslucentShadow;
	MaterialRelevance.SetPrimitiveViewRelevance(Result);
	Result.bVelocityRelevance = DrawsVelocity() && Result.bOpaque && Result.bRenderInMainPass;
	return Result;
}


bool UGeometryCacheDecalSceneProxy::CanBeOccluded() const
{
	return !MaterialRelevance.bDisableDepthTest;
}

bool UGeometryCacheDecalSceneProxy::IsUsingDistanceCullFade() const
{
	return MaterialRelevance.bUsesDistanceCullFade;
}

uint32 UGeometryCacheDecalSceneProxy::GetMemoryFootprint(void) const
{
	return(sizeof(*this) + GetAllocatedSize());
}

uint32 UGeometryCacheDecalSceneProxy::GetAllocatedSize(void) const
{
	return(FPrimitiveSceneProxy::GetAllocatedSize());
}

// Avoid converting from 8 bit normalized to float and back again.
inline FPackedNormal InterpolateDecalPackedNormal(const FPackedNormal& A, const FPackedNormal& B, int32 ScaledFactor, int32 OneMinusScaledFactor)
{
	static float OneOver255 = 1.0f / 255.0f;

	FPackedNormal result;
	result.Vector.X = (A.Vector.X * OneMinusScaledFactor + B.Vector.X * ScaledFactor) * OneOver255;
	result.Vector.Y = (A.Vector.Y * OneMinusScaledFactor + B.Vector.Y * ScaledFactor) * OneOver255;
	result.Vector.Z = (A.Vector.Z * OneMinusScaledFactor + B.Vector.Z * ScaledFactor) * OneOver255;
	result.Vector.W = (A.Vector.W * OneMinusScaledFactor + B.Vector.W * ScaledFactor) * OneOver255;
	return result;
}

void UGeometryCacheDecalSceneProxy::UpdateDecalFrame() const
{
	if (!GeometryCacheSceneProxy || !DecalGeometryData || !GeometryCacheDecalComponent->GetGeometryCacheComponent()
		|| GeometryCacheDecalComponent->GetGeometryCacheComponent()->SceneProxy != GeometryCacheSceneProxy)
	{
		return;
	}

	int32 TrackIndex = GeometryCacheDecalComponent->DecalTrackIndex;
	const TArray<FGeomCacheTrackProxy*>& Tracks = GeometryCacheSceneProxy->GetTracks();
	if (!Tracks.IsValidIndex(TrackIndex))
	{
		return;
	}

	if (GeometryCacheDecalComponent->GetWorld()->IsGameWorld()
		&& GeometryCacheDecalComponent->bFrameUpdated)
	{
		return;
	}
	GeometryCacheDecalComponent->bFrameUpdated = true;

	UGeometryCacheComponent* GeometryCacheComponent = GeometryCacheDecalComponent->GetGeometryCacheComponent();

	float Time = GeometryCacheComponent->GetAnimationTime();
	bool bLooping = GeometryCacheComponent->IsLooping();
	bool bExtrapolateFrames = GeometryCacheComponent->IsExtrapolatingFrames();

	{
		FGeomCacheTrackProxy* TrackProxy = Tracks[TrackIndex];
		FGeometryCacheTrackDecalData* SectionData = DecalGeometryData;

		// Render out stored TrackProxy's
		if (TrackProxy != nullptr)
		{
			const FVisibilitySample& VisibilitySample = TrackProxy->GetVisibilitySample(Time, bLooping);
			if (!VisibilitySample.bVisibilityState)
			{
				return;
			}

			// Check if we can interpolate between the two frames we have available
			const bool bCanInterpolate = (TrackProxy->FrameIndex != TrackProxy->NextFrameIndex) && TrackProxy->IsTopologyCompatible(TrackProxy->FrameIndex, TrackProxy->NextFrameIndex);
			float InterpolationFactor = TrackProxy->InterpolationFactor;
			const bool bFrameIndicesChanged = TrackProxy->FrameIndex != SectionData->FrameIndex;
			const bool bDifferentRoundedInterpolationFactor = FMath::RoundToInt(InterpolationFactor) != FMath::RoundToInt(TrackProxy->PreviousInterpolationFactor);
			const bool bDifferentInterpolationFactor = !FMath::IsNearlyEqual(InterpolationFactor, TrackProxy->PreviousInterpolationFactor);

			SectionData->FrameIndex = TrackProxy->FrameIndex;

			// Check if we have explicit motion vectors
			const bool bHasMotionVectors = (
				TrackProxy->MeshData->VertexInfo.bHasMotionVectors &&
				TrackProxy->NextFrameMeshData->VertexInfo.bHasMotionVectors &&
				TrackProxy->MeshData->Positions.Num() == TrackProxy->MeshData->MotionVectors.Num())
				&& (TrackProxy->NextFrameMeshData->Positions.Num() == TrackProxy->NextFrameMeshData->MotionVectors.Num());
			
			// UE_LOG(LogTemp, Warning, TEXT("UGeometryCacheDecalSceneProxy::UpdateDecalFrame FrameIndex(%d) NextFrameIndex(%d)"), TrackProxy->FrameIndex, TrackProxy->NextFrameIndex);
			
			const bool bReGenerateDecal = TrackProxy->IsTopologyCompatible(TrackProxy->FrameIndex, DecalGeometryData->DecalGenerateFrameIndex) == false;
			if (bReGenerateDecal)
			{
				GenerateDecalMesh(false);
			}

			// Can we interpolate the vertex data?
			if (bCanInterpolate && (bDifferentInterpolationFactor || bFrameIndicesChanged))
			{
				const float OneMinusInterp = 1.0 - InterpolationFactor;
				const int32 InterpFixed = (int32)(InterpolationFactor * 255.0f);
				const int32 OneMinusInterpFixed = 255 - InterpFixed;
				const VectorRegister4Float WeightA = VectorSetFloat1(OneMinusInterp);
				const VectorRegister4Float WeightB = VectorSetFloat1(InterpolationFactor);
				const VectorRegister4Float Half = VectorSetFloat1(0.5f);

				const uint32* IndicesPtr = TrackProxy->MeshData->Indices.GetData();
				const int32 NumVerts = TrackProxy->MeshData->Positions.Num();

#define VALIDATE 0

				check(TrackProxy->MeshData->Positions.Num() >= NumVerts);
				check(TrackProxy->NextFrameMeshData->Positions.Num() >= NumVerts);

				const FVector3f* PositionAPtr = TrackProxy->MeshData->Positions.GetData();
				const FVector3f* PositionBPtr = TrackProxy->NextFrameMeshData->Positions.GetData();

				const FVector2f* UVAPtr = nullptr;
				const FVector2f* UVBPtr = nullptr;
				if (TrackProxy->MeshData->VertexInfo.bHasUV0)
				{
					check(TrackProxy->MeshData->TextureCoordinates.Num() >= NumVerts);
					check(TrackProxy->NextFrameMeshData->TextureCoordinates.Num() >= NumVerts);
					UVAPtr = TrackProxy->MeshData->TextureCoordinates.GetData();
					UVBPtr = TrackProxy->NextFrameMeshData->TextureCoordinates.GetData();
				}

				check(TrackProxy->MeshData->TangentsX.Num() >= NumVerts);
				check(TrackProxy->NextFrameMeshData->TangentsX.Num() >= NumVerts);
				check(TrackProxy->MeshData->TangentsZ.Num() >= NumVerts);
				check(TrackProxy->NextFrameMeshData->TangentsZ.Num() >= NumVerts);
				const FPackedNormal* TangentXAPtr = TrackProxy->MeshData->TangentsX.GetData();
				const FPackedNormal* TangentXBPtr = TrackProxy->NextFrameMeshData->TangentsX.GetData();
				const FPackedNormal* TangentZAPtr = TrackProxy->MeshData->TangentsZ.GetData();
				const FPackedNormal* TangentZBPtr = TrackProxy->NextFrameMeshData->TangentsZ.GetData();

				for (int32 Index = 0; Index < DecalGeometryData->OriginVerticeIndex.Num(); Index++)
				{
					int32 VerticeIndex = DecalGeometryData->OriginVerticeIndex[Index];
					
					// Position
					DecalGeometryData->PositionBuffer[Index] = PositionAPtr[VerticeIndex] *OneMinusInterp + PositionBPtr[VerticeIndex] * InterpolationFactor;

					// Tangent and Normal
					DecalGeometryData->TangentsX[Index] = InterpolateDecalPackedNormal(TangentXAPtr[VerticeIndex], TangentXBPtr[VerticeIndex], InterpFixed, OneMinusInterpFixed);
					DecalGeometryData->TangentsZ[Index] = InterpolateDecalPackedNormal(TangentZAPtr[VerticeIndex], TangentZBPtr[VerticeIndex], InterpFixed, OneMinusInterpFixed);
				}

#undef VALIDATE
			}
			else
			{
				// We just don't interpolate between frames if we got GPU to burn we could someday render twice and stipple fade between it :-D like with lods

				// Only bother uploading if anything changed or when the we failed to decode anything make sure update the gpu buffers regardless
				if (bFrameIndicesChanged || bDifferentRoundedInterpolationFactor || (bDifferentInterpolationFactor && bExtrapolateFrames))
				{
					const bool bNextFrame = !!FMath::RoundToInt(InterpolationFactor) && TrackProxy->NextFrameMeshData->Positions.Num() > 0; // use next frame only if it's valid
					if (/*TrackProxy->MeshData->Positions.Num() > 0
						&& */TrackProxy->NextFrameMeshData->Positions.Num() > 0
						&& !TrackProxy->IsTopologyCompatible(TrackProxy->FrameIndex, TrackProxy->NextFrameIndex)
						&& bNextFrame)
					{
						GenerateDecalMesh(true);
					}

					const uint32 FrameIndexToUse = bNextFrame ? TrackProxy->NextFrameIndex : TrackProxy->FrameIndex;
					FGeometryCacheMeshData* MeshDataToUse = bNextFrame ? TrackProxy->NextFrameMeshData : TrackProxy->MeshData;

					for (int32 Index = 0; Index < DecalGeometryData->OriginVerticeIndex.Num(); Index++)
					{
						int32 VerticeIndex = DecalGeometryData->OriginVerticeIndex[Index];

						// Position
						DecalGeometryData->PositionBuffer[Index] = MeshDataToUse->Positions[VerticeIndex];

						// Tangent and Normal
						DecalGeometryData->TangentsX[Index] = MeshDataToUse->TangentsX[VerticeIndex];
						DecalGeometryData->TangentsZ[Index] = MeshDataToUse->TangentsZ[VerticeIndex];
					}
				}
			}

			const int32 NumVerts = DecalGeometryData->PositionBuffer.Num();

			if (NumVerts == 0)
			{
				return;
			}
			else if (!DecalTrackProxy->bResourcesInitialized)
			{
				DecalTrackProxy->InitRenderResources(NumVerts, DecalGeometryData->IndexBuffer.Num());
			}

			SubmitSectionBuffer_RenderThread();
		}
	}
}


//////////////////////////////////////////////////////////////////////////


UGeometryCacheDecalComponent::UGeometryCacheDecalComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bStartWithTickEnabled = true;
	PrimaryComponentTick.bCanEverTick = true;
	bTickInEditor = true;

	DecalMaterial = LoadObject<UMaterialInterface>(nullptr, TEXT("/GeometryCacheDecal/GeometryCacheDecal/Materials/M_GeometryCacheDecalDefault"));
}

void UGeometryCacheDecalComponent::BeginPlay()
{
	Super::BeginPlay();
	
	if (GeometryCacheStatus.GeometryCacheComponent == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("UGeometryCacheDecalComponent: Failed to find geometry cache component. (%s)"), *(GetOwner()->GetName()));
	}

	bRuntimeTicking = true;
	bRuntimeInited = false;
}

void UGeometryCacheDecalComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	bRuntimeTicking = false;
	bRuntimeInited = false;
}

void UGeometryCacheDecalComponent::OnRegister()
{
	ResetGeometryCacheStatusWhenChanged(true);

	Super::OnRegister();
}

void UGeometryCacheDecalComponent::OnUnregister()
{
	Super::OnUnregister();
	
	ClearGeometryCacheStatus();
}

void UGeometryCacheDecalComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	auto NeedUpdate = [this, DeltaTime]()
	{
		ResetGeometryCacheStatusWhenChanged(false);
		if (GeometryCacheStatus.bStatusReseted)
		{
			GeometryCacheStatus.bStatusReseted = false;
			return true;
		}

		if (this->bRuntimeTicking)
		{
			if (!bRuntimeInited)
			{
				if (GeometryCacheStatus.TracksInited())
				{
					bRuntimeInited = true;
					return true;
				}
			}
			else
			{
				return true;// GeometryCacheStatus.GeometryCacheComponent->IsPlaying();
			}
		}

		return false;
	};

	if (NeedUpdate())
	{
		this->AccumulateDeltaTime = 0.0f;
		this->bFrameUpdated = false;


		// Game thread update:
		// This mainly just updates the matrix and bounding boxes. All render state (meshes) is done on the render thread
		bool bUpdatedBoundsOrMatrix = false;
		for (int32 TrackIndex = 0; TrackIndex < TrackSections.Num(); ++TrackIndex)
		{
			bUpdatedBoundsOrMatrix |= UpdateTrackSection(TrackIndex);
		}

		if (bUpdatedBoundsOrMatrix)
		{
			UpdateLocalBounds();

			// Mark the transform as dirty, so the bounds are updated and sent to the render thread
			MarkRenderTransformDirty();
		}
	}
}


bool UGeometryCacheDecalComponent::UpdateTrackSection(int32 TrackIndex)
{
	checkf(TrackIndex < TrackSections.Num(), TEXT("Invalid SectionIndex"));

	FGeometryCacheTrackDecalData* UpdateSection = TrackSections[TrackIndex];
	UGeometryCacheTrack* Track = GeometryCacheStatus.GeometryCacheComponent->GetGeometryCache()->Tracks[TrackIndex];

	FMatrix Matrix;
	FBox TrackBounds;
	const bool bUpdateMatrix = Track->UpdateMatrixData(GeometryCacheStatus.GeometryCacheComponent->GetAnimationTime(), GeometryCacheStatus.GeometryCacheComponent->IsLooping(), UpdateSection->MatrixSampleIndex, Matrix);
	const bool bUpdateBounds = Track->UpdateBoundsData(GeometryCacheStatus.GeometryCacheComponent->GetAnimationTime(), GeometryCacheStatus.GeometryCacheComponent->IsLooping(), (GeometryCacheStatus.GeometryCacheComponent->IsPlayingReversed()) ? true : false, UpdateSection->BoundsSampleIndex, TrackBounds);

	if (bUpdateBounds)
	{
		UpdateSection->BoundingBox = TrackBounds;
	}

	if (bUpdateMatrix)
	{
		UpdateSection->Matrix = Matrix;
	}

	// Update sections according what is required
	if (bUpdateMatrix || bUpdateBounds)
	{
		return true;
	}

	return false;
}

FBoxSphereBounds UGeometryCacheDecalComponent::CalcBounds(const FTransform& LocalToWorld) const
{
	FBoxSphereBounds Ret(LocalBounds.TransformBy(LocalToWorld));

	Ret.BoxExtent *= BoundsScale;
	Ret.SphereRadius *= BoundsScale;

	return Ret;
}

void UGeometryCacheDecalComponent::UpdateLocalBounds()
{
	FBox LocalBox(ForceInit);

	for (const FGeometryCacheTrackDecalData* Section : TrackSections)
	{
		//if (Section.bEnableCollision)
		{
			// Use World matrix per section for correct bounding box
			LocalBox += (Section->BoundingBox.TransformBy(Section->Matrix));
		}
	}

	LocalBounds = LocalBox.IsValid ? FBoxSphereBounds(LocalBox) : FBoxSphereBounds(FVector(0, 0, 0), FVector(0, 0, 0), 0); // fallback to reset box sphere bounds
	if (LocalBounds.ContainsNaN())
	{
		LocalBounds = FBoxSphereBounds(FVector(0, 0, 0), FVector(0, 0, 0), 0);
	}

	// Update global bounds
	UpdateBounds();
}


bool UGeometryCacheDecalComponent::ResetGeometryCacheStatusWhenChanged(bool bForceReset)
{
	if (bForceReset)
	{
		UGeometryCacheComponent* GeometryCacheComponent = Cast<UGeometryCacheComponent>(GetOwner()->GetComponentByClass(UGeometryCacheComponent::StaticClass()));
		GeometryCacheStatus = FGeometryCacheOriginStatus(GeometryCacheComponent, this);
	}

	if (bForceReset || GeometryCacheStatus.ResetWhenChanged())
	{
		ClearTrackData();
		CreateTrackData();

		if (GeometryCacheStatus.GeometryCacheComponent)
		{
			FVector ToWorldScale3D = GetRelativeScale3D() * GeometryCacheStatus.GeometryCacheComponent->GetRelativeScale3D();
			if ((ToWorldScale3D - FVector::OneVector).IsNearlyZero()
				&& GetRelativeLocation() == FVector::ZeroVector
				&& GetRelativeRotation() == FRotator::ZeroRotator)
			{
				ResetRelativeTransform();
			}
		}

		GeometryCacheStatus.bStatusReseted = true;
		return true;
	}

	return false;
}

void UGeometryCacheDecalComponent::ClearGeometryCacheStatus()
{
	GeometryCacheStatus.Clear();

	ClearTrackData();
}

void UGeometryCacheDecalComponent::CreateTrackData()
{
	FGeometryCacheSceneProxy* GeometryCacheSceneProxy = static_cast<FGeometryCacheSceneProxy*>(GetGeometryCacheComponent()->SceneProxy);
	if (GeometryCacheSceneProxy)
	{
		const TArray<FGeomCacheTrackProxy*>& Tracks = GeometryCacheSceneProxy->GetTracks();
		for (int Index = 0; Index < Tracks.Num(); Index++)
		{
			FGeometryCacheTrackDecalData* SectionData = new FGeometryCacheTrackDecalData();
			TrackSections.Add(SectionData);
			UpdateTrackSection(Index);
		}
	}

	MarkRenderStateDirty();
	UpdateLocalBounds();

	if (DecalType == EGeometryCacheDecalType::BoxRegion
		&& DecalBoxInfo.DecalRegion == FVector(100.0f)
		&& LocalBounds.GetBox().IsValid != 0)
	{
		DecalBoxInfo.DecalRegion = LocalBounds.GetBox().GetSize() * 0.5f;
		DecalBoxInfo.DecalCenter = LocalBounds.GetBox().GetCenter();
	}
}

void UGeometryCacheDecalComponent::ClearTrackData()
{
	NumTracks = 0;

	for (int Index = 0; Index < TrackSections.Num(); Index++)
	{
		delete TrackSections[Index];
	}
	TrackSections.Empty();
}

bool UGeometryCacheDecalComponent::LineTraceGeometryCache(const FVector& WorldStart, const FVector& WorldEnd, FGeometryCacheLineHitResult& Result)
{
	Result.TriangleIndex = -1;
	Result.TrackIndex = -1;
	Result.NearestDistance = BIG_NUMBER;

	FVector  NearestIntersectPoint;
	FVector LocalStart = GetComponentTransform().InverseTransformPosition(WorldStart);
	FVector LocalEnd = GetComponentTransform().InverseTransformPosition(WorldEnd);
	
	FVector IntersectPoint, TriangleNormal;
	for (int32 SectionIndex = 0; SectionIndex < TrackSections.Num(); ++SectionIndex)
	{
		FGeometryCacheTrackDecalData* SectionData = TrackSections[SectionIndex];
		TArray<FVector3f>& PositionBuffer = SectionData->PositionBuffer;
		TArray<FVector2f>& UVBuffer = SectionData->UVBuffer;
		TArray<uint32>& IndexBuffer = SectionData->IndexBuffer;
		for (int32 i = 0; i + 2 < IndexBuffer.Num(); i += 3)
		{
			const FVector3f& v0 = PositionBuffer[IndexBuffer[i]];
			const FVector3f& v1 = PositionBuffer[IndexBuffer[i + 1]];
			const FVector3f& v2 = PositionBuffer[IndexBuffer[i + 2]];
			if (FMath::SegmentTriangleIntersection(LocalStart, LocalEnd, FVector(v0), FVector(v1), FVector(v2), IntersectPoint, TriangleNormal))
			{
				float Dist = (IntersectPoint - LocalStart).Size();
				if (Dist < Result.NearestDistance)
				{
					NearestIntersectPoint = IntersectPoint;
					Result.NearestDistance = Dist;
					SectionIndex = SectionIndex;
					Result.TrackIndex = SectionIndex;
					Result.TriangleIndex = i / 3;
					Result.BaryCentric = FMath::ComputeBaryCentric2D(NearestIntersectPoint, FVector(v0), FVector(v1), FVector(v2));
				}
			}
		}
	}
	if (Result.TriangleIndex >= 0 && Result.TrackIndex >= 0)
	{
		return true;
	}
		
	return false;
}

//////////////////////////////////////////////////////////////////////////

inline FVector3f ComputeTriangleNormal(const FVector3f& InVertexA, const FVector3f& InVertexB, const FVector3f& InVertexC)
{
	return FVector3f::CrossProduct(InVertexC - InVertexA, InVertexB - InVertexA).GetSafeNormal();
}

bool UGeometryCacheDecalComponent::RematchAttachLocation(FGeometryCacheDecaledTriangle& AttachedTriangle, FGeometryCacheMeshData* MeshDataToUse)
{
	check(IsInRenderingThread());

	if (!MeshDataToUse || MeshDataToUse->TextureCoordinates.Num() == 0)
	{
		return false;
	}

	auto VectorSign = [](const FVector2f& Vec, const FVector2f& A, const FVector2f& B)
	{
		return FMath::Sign((B.X - A.X) * (Vec.Y - A.Y) - (B.Y - A.Y) * (Vec.X - A.X));
	};

	auto IsPointInTriangle = [VectorSign](const FVector2f& TestPoint, const FVector2f& A, const FVector2f& B, const FVector2f& C)
	{
		float BA = VectorSign(B, A, TestPoint);
		float CB = VectorSign(C, B, TestPoint);
		float AC = VectorSign(A, C, TestPoint);

		// point is in the same direction of all 3 tri edge lines
		// must be inside, regardless of tri winding
		return BA == CB && CB == AC;
	};

	bool RematchSuccess = false;

	FVector2f AttachUV = AttachedTriangle.AttachUV;
	TArray<uint32>& Indices = MeshDataToUse->Indices;
	TArray<FVector2f>& TextureCoordinates = MeshDataToUse->TextureCoordinates;
	for (int32 TriIndex = 0; TriIndex < Indices.Num(); TriIndex += 3)
	{
		const FVector2f& uv0 = TextureCoordinates[Indices[TriIndex]];
		const FVector2f& uv1 = TextureCoordinates[Indices[TriIndex + 1]];
		const FVector2f& uv2 = TextureCoordinates[Indices[TriIndex + 2]];

		if (uv0.X < AttachUV.X && uv1.X < AttachUV.X && uv2.X < AttachUV.X
			|| uv0.X > AttachUV.X && uv1.X > AttachUV.X && uv2.X > AttachUV.X
			|| uv0.Y < AttachUV.Y && uv1.Y < AttachUV.Y && uv2.Y < AttachUV.Y
			|| uv0.Y > AttachUV.Y && uv1.Y > AttachUV.Y && uv2.Y > AttachUV.Y)
		{
			continue;
		}

		if (IsPointInTriangle(AttachUV, uv0, uv1, uv2))
		{
			AttachedTriangle.AttachLocation.TriangleIndex = (TriIndex / 3);
			RematchSuccess = true;
			break;
		}
	}

	return RematchSuccess;
}

bool UGeometryCacheDecalComponent::UpdateFrameData()
{
	check(IsInRenderingThread());

	if (!GetGeometryCacheComponent() || !GetGeometryCacheComponent()->SceneProxy)
	{
		return false;
	}

	FGeometryCacheSceneProxy* GeometryCacheSceneProxy = static_cast<FGeometryCacheSceneProxy*>(GetGeometryCacheComponent()->SceneProxy);
	if (!GeometryCacheSceneProxy)
	{
		return false;
	}

	const TArray<FGeomCacheTrackProxy*>& Tracks = GeometryCacheSceneProxy->GetTracks();
	if (TrackSections.Num() != Tracks.Num())
	{
		if (TrackSections.Num() > 0)
		{
			ClearTrackData();
		}

		CreateTrackData();
	}

	UGeometryCacheComponent* GeometryCacheComponent = GetGeometryCacheComponent();

	float Time = GeometryCacheComponent->GetAnimationTime();
	bool bLooping = GeometryCacheComponent->IsLooping();
	bool bExtrapolateFrames = GeometryCacheComponent->IsExtrapolatingFrames();

	for (int32 SectionIndex = 0; SectionIndex < Tracks.Num(); SectionIndex++)
	{
		FGeomCacheTrackProxy* TrackProxy = Tracks[SectionIndex];
		FGeometryCacheTrackDecalData* SectionData = TrackSections[SectionIndex];

		// Render out stored TrackProxy's
		if (TrackProxy != nullptr)
		{
			const FVisibilitySample& VisibilitySample = TrackProxy->GetVisibilitySample(Time, bLooping);
			if (!VisibilitySample.bVisibilityState)
			{
				continue;
			}

			// Check if we can interpolate between the two frames we have available
			const bool bCanInterpolate = (TrackProxy->FrameIndex != TrackProxy->NextFrameIndex) && TrackProxy->IsTopologyCompatible(TrackProxy->FrameIndex, TrackProxy->NextFrameIndex);
			float InterpolationFactor = TrackProxy->InterpolationFactor;
			const bool bFrameIndicesChanged = TrackProxy->FrameIndex != SectionData->FrameIndex;
			const bool bDifferentRoundedInterpolationFactor = FMath::RoundToInt(InterpolationFactor) != FMath::RoundToInt(TrackProxy->PreviousInterpolationFactor);
			const bool bDifferentInterpolationFactor = !FMath::IsNearlyEqual(InterpolationFactor, TrackProxy->PreviousInterpolationFactor);

			SectionData->FrameIndex = TrackProxy->FrameIndex;

			// Check if we have explicit motion vectors
			const bool bHasMotionVectors = (
				TrackProxy->MeshData->VertexInfo.bHasMotionVectors &&
				TrackProxy->NextFrameMeshData->VertexInfo.bHasMotionVectors &&
				TrackProxy->MeshData->Positions.Num() == TrackProxy->MeshData->MotionVectors.Num())
				&& (TrackProxy->NextFrameMeshData->Positions.Num() == TrackProxy->NextFrameMeshData->MotionVectors.Num());

			// Can we interpolate the vertex data?
			if (bCanInterpolate/* && (bDifferentInterpolationFactor || bFrameIndicesChanged)*/)
			{

				const float OneMinusInterp = 1.0 - InterpolationFactor;
				const int32 InterpFixed = (int32)(InterpolationFactor * 255.0f);
				const int32 OneMinusInterpFixed = 255 - InterpFixed;
				const VectorRegister4Float WeightA = VectorSetFloat1(OneMinusInterp);
				const VectorRegister4Float WeightB = VectorSetFloat1(InterpolationFactor);
				const VectorRegister4Float Half = VectorSetFloat1(0.5f);

				const int32 NumVerts = TrackProxy->MeshData->Positions.Num();
				SectionData->Prepare(NumVerts);

				{
					check(TrackProxy->MeshData->Positions.Num() >= NumVerts);
					check(TrackProxy->NextFrameMeshData->Positions.Num() >= NumVerts);
					check(SectionData->PositionBuffer.Num() >= NumVerts);
					const FVector3f* PositionAPtr = TrackProxy->MeshData->Positions.GetData();
					const FVector3f* PositionBPtr = TrackProxy->NextFrameMeshData->Positions.GetData();
					FVector3f* InterpolatedPositionsPtr = SectionData->PositionBuffer.GetData();

					// Unroll 4 times so we can do 4 wide SIMD
					{
						const FVector4f* PositionAPtr4 = (const FVector4f*)PositionAPtr;
						const FVector4f* PositionBPtr4 = (const FVector4f*)PositionBPtr;
						FVector4f* InterpolatedPositionsPtr4 = (FVector4f*)InterpolatedPositionsPtr;

						int32 Index = 0;
						for (; Index + 3 < NumVerts; Index += 4)
						{
							VectorRegister4Float Pos0xyz_Pos1x = VectorMultiplyAdd(VectorLoad(PositionAPtr4 + 0), WeightA, VectorMultiply(VectorLoad(PositionBPtr4 + 0), WeightB));
							VectorRegister4Float Pos1yz_Pos2xy = VectorMultiplyAdd(VectorLoad(PositionAPtr4 + 1), WeightA, VectorMultiply(VectorLoad(PositionBPtr4 + 1), WeightB));
							VectorRegister4Float Pos2z_Pos3xyz = VectorMultiplyAdd(VectorLoad(PositionAPtr4 + 2), WeightA, VectorMultiply(VectorLoad(PositionBPtr4 + 2), WeightB));
							VectorStore(Pos0xyz_Pos1x, InterpolatedPositionsPtr4 + 0);
							VectorStore(Pos1yz_Pos2xy, InterpolatedPositionsPtr4 + 1);
							VectorStore(Pos2z_Pos3xyz, InterpolatedPositionsPtr4 + 2);
							PositionAPtr4 += 3;
							PositionBPtr4 += 3;
							InterpolatedPositionsPtr4 += 3;
						}

						for (; Index < NumVerts; Index++)
						{
							InterpolatedPositionsPtr[Index] = PositionAPtr[Index] * OneMinusInterp + PositionBPtr[Index] * InterpolationFactor;
						}
					}
				}

				if (TrackProxy->MeshData->VertexInfo.bHasUV0 )
				{
					check(TrackProxy->MeshData->TextureCoordinates.Num() >= NumVerts);
					check(TrackProxy->NextFrameMeshData->TextureCoordinates.Num() >= NumVerts);
					check(SectionData->UVBuffer.Num() >= NumVerts);
					const FVector2f* UVAPtr = TrackProxy->MeshData->TextureCoordinates.GetData();
					const FVector2f* UVBPtr = TrackProxy->NextFrameMeshData->TextureCoordinates.GetData();
					FVector2f* InterpolatedUVsPtr = SectionData->UVBuffer.GetData();

					// Unroll 2x so we can use 4 wide ops. OOP will hopefully take care of the rest.
					{
						int32 Index = 0;
						for (; Index + 1 < NumVerts; Index += 2)
						{
							VectorRegister4Float InterpolatedUVx2 = VectorMultiplyAdd(VectorLoad(&UVAPtr[Index].X),
								WeightA,
								VectorMultiply(VectorLoad(&UVBPtr[Index].X), WeightB));
							VectorStore(InterpolatedUVx2, &(InterpolatedUVsPtr[Index].X));
						}

						if (Index < NumVerts)
						{
							InterpolatedUVsPtr[Index] = UVAPtr[Index] * OneMinusInterp + UVBPtr[Index] * InterpolationFactor;
						}
					}
				}

				SectionData->IndexBuffer = TrackProxy->MeshData->Indices; //.UpdateIndices(TrackProxy->MeshData->Indices);
				check(TrackProxy->MeshData->Indices.Num() % 3 == 0);

				SectionData->BatchesInfo = TrackProxy->MeshData->BatchesInfo;

			}
			else
			{
				// We just don't interpolate between frames if we got GPU to burn we could someday render twice and stipple fade between it :-D like with lods

				// Only bother uploading if anything changed or when the we failed to decode anything make sure update the gpu buffers regardless
				if (bFrameIndicesChanged || bDifferentRoundedInterpolationFactor || (bDifferentInterpolationFactor && bExtrapolateFrames))
				{
					const bool bNextFrame = !!FMath::RoundToInt(InterpolationFactor) && TrackProxy->NextFrameMeshData->Positions.Num() > 0; // use next frame only if it's valid
					const uint32 FrameIndexToUse = bNextFrame ? TrackProxy->NextFrameIndex : TrackProxy->FrameIndex;
					FGeometryCacheMeshData* MeshDataToUse = bNextFrame ? TrackProxy->NextFrameMeshData : TrackProxy->MeshData;

					SectionData->UpdateIndices(MeshDataToUse->Indices);
					SectionData->UpdatePositions(MeshDataToUse->Positions);
					SectionData->UpdateUVs(MeshDataToUse->TextureCoordinates);

					SectionData->BatchesInfo = MeshDataToUse->BatchesInfo;
				}
			}
		}
	}

	return true;
}

void UGeometryCacheDecalComponent::BuildGeometryCacheMeshBVH()
{
	int32 TrackNum = TrackSections.Num();

	TrackMeshSpatials.Empty();
	TrackMeshSpatials.SetNum(TrackNum);
	TrackMeshs.Empty();
	TrackMeshs.SetNum(TrackNum);

	ParallelFor(TrackNum, [&](int32 TrackIndex)
		{
			FGeometryCacheTrackDecalData* SectionData = TrackSections[TrackIndex];
			// Transform vertice
			TArray<FVector3f>& PositionBuffer = SectionData->PositionBuffer;
			TArray<uint32>& IndexBuffer = SectionData->IndexBuffer;

			int32 NumPieceV = PositionBuffer.Num();

			// Build mesh tree
			TArray<int32> TrackTriMap;
			TrackMeshs[TrackIndex] = MakeUnique<UE::Geometry::FDynamicMesh3>();
			
			for (int32 i = 0, NumV = PositionBuffer.Num(); i < NumV; ++i)
			{
				const auto& p = PositionBuffer[i];
				TrackMeshs[TrackIndex]->AppendVertex(FVector(p));
			}
			for (int32 i = 0, NumT = IndexBuffer.Num() / 3; i < NumT; ++i)
			{
				TrackMeshs[TrackIndex]->AppendTriangle(IndexBuffer[3 * i + 0], IndexBuffer[3 * i + 1], IndexBuffer[3 * i + 2]);
				TrackTriMap.Add(i);
			}
			
			TrackMeshSpatials[TrackIndex] = MakeUnique<UE::Geometry::FDynamicMeshAABBTree3>(TrackMeshs[TrackIndex].Get(), true);
		}
	);
}

int UGeometryCacheDecalComponent::FindNearestTriangle(const FVector3d& P, double& NearestDistSqr, int32& NearestTrackIndex) const
{
	NearestDistSqr = TNumericLimits<double>::Max();
	NearestTrackIndex = -1;
	
	int32 NearestTriangleIndex = -1;

	for (int32 Index = 0; Index < TrackMeshSpatials.Num(); Index++)
	{
		double DistanceSqr = 0;
		int32 TriangleIndex = TrackMeshSpatials[Index]->FindNearestTriangle(P, DistanceSqr);
		if (TriangleIndex < 0 || DistanceSqr > NearestDistSqr)
		{
			continue;
		}

		NearestDistSqr = DistanceSqr;
		NearestTrackIndex = Index;
		NearestTriangleIndex = TriangleIndex;
	}

	return NearestTriangleIndex;
}

void UGeometryCacheDecalComponent::LineTraceAttachDecal(const FVector& WorldStart, const FVector& WorldEnd, const FGeometryCacheDecalInfo& InDecalInfo, const FLineTraceAttachDecalFinishedEvent& FinishedEvent)
{
	auto UpdateFinishedCallback = [this, WorldStart, WorldEnd, FinishedEvent, InDecalInfo]()
	{
		FGeometryCacheLineHitResult Result;
		if (LineTraceGeometryCache(WorldStart, WorldEnd, Result))
		{
			FGeometryCacheDecalLocation AttachLocation;
			AttachLocation.TrackIndex = Result.TrackIndex;
			AttachLocation.TriangleIndex = Result.TriangleIndex;
			AttachLocation.BaryCentric = Result.BaryCentric;

			FTransform ElementTransform;
			AttachDecalAtLocation(AttachLocation, InDecalInfo, ElementTransform);
			FinishedEvent.ExecuteIfBound(true, TEXT("LineTrace Attach Success"));
		}
		else
		{
			FinishedEvent.ExecuteIfBound(false, TEXT("LineTrace Failed!"));
		}
	};

	ENQUEUE_RENDER_COMMAND(FGeometryCacheDecalAllUpdate)(
		[this, UpdateFinishedCallback](FRHICommandList& RHICmdList)
		{
			this->UpdateFrameData();

			AsyncTask(ENamedThreads::GameThread, [this, UpdateFinishedCallback] {
				UpdateFinishedCallback();
				});
		}
	);
}

bool UGeometryCacheDecalComponent::AttachDecalAtLocation(const FGeometryCacheDecalLocation& AttachLocation, const FGeometryCacheDecalInfo& InDecalInfo, const FTransform& ElementTransform)
{
	DecalType = InDecalInfo.DecalType;
	DecalUVInfo = InDecalInfo.DecalUVInfo;
	DecalBoxInfo = InDecalInfo.DecalBoxInfo;
	DecalMaterial = InDecalInfo.DecalMaterial;

	FTransform Transform;
	FVector2f UV;
	CalculateVerticeInfoAtAttachedLocation(AttachLocation, Transform, UV);
	if (DecalType == EGeometryCacheDecalType::UVRegion)
	{
		DecalUVInfo.DecalUVCenter = FVector2D(UV);
	}
	else
	{
		DecalBoxInfo.DecalCenter = Transform.GetLocation();
		//DecalBoxInfo.DecalRotation = Transform.GetRotation().Euler();
	}

	MarkRenderStateDirty();

	return false;
}

bool UGeometryCacheDecalComponent::CalculateVerticeInfoAtAttachedLocation(const FGeometryCacheDecalLocation& AttachLocation, FTransform& Transform, FVector2f& UV)
{
	check(AttachLocation.TrackIndex < TrackSections.Num());

	FGeometryCacheTrackDecalData* SectionData = TrackSections[AttachLocation.TrackIndex];
	if (SectionData && SectionData->PositionBuffer.Num() > 0)
	{
		TArray<FVector3f>& PositionBuffer = SectionData->PositionBuffer;
		TArray<FVector2f>& UVBuffer = SectionData->UVBuffer;
		TArray<uint32>& IndexBuffer = SectionData->IndexBuffer;

		int32 TriangleIndex = AttachLocation.TriangleIndex * 3;
		if (TriangleIndex + 2 < IndexBuffer.Num())
		{
			const FVector3f& v0 = PositionBuffer[IndexBuffer[TriangleIndex]];
			const FVector3f& v1 = PositionBuffer[IndexBuffer[TriangleIndex + 1]];
			const FVector3f& v2 = PositionBuffer[IndexBuffer[TriangleIndex + 2]];

			const FVector& W = AttachLocation.BaryCentric;
			FVector3f Position = v0 * W.X + v1 * W.Y + v2 * W.Z;
			FVector3f Normal = ComputeTriangleNormal(v0, v1, v2);

			FRotator Rotator = FRotationMatrix::MakeFromYZ((FVector(Position - v0)).GetSafeNormal(), FVector(Normal)).Rotator();
			Transform = FTransform(Rotator, FVector(Position));

			if (UVBuffer.Num() > 0)
			{
				const FVector2f& uv0 = UVBuffer[IndexBuffer[TriangleIndex]];
				const FVector2f& uv1 = UVBuffer[IndexBuffer[TriangleIndex + 1]];
				const FVector2f& uv2 = UVBuffer[IndexBuffer[TriangleIndex + 2]];

				UV = uv0 * W.X + uv1 * W.Y + uv2 * W.Z;
			}

			return true;
		}
	}

	return false;
}

FPrimitiveSceneProxy* UGeometryCacheDecalComponent::CreateSceneProxy()
{
	return new UGeometryCacheDecalSceneProxy(this);
}

void UGeometryCacheDecalComponent::SetMaterial(int32 ElementIndex, UMaterialInterface* InMaterial)
{
	DecalMaterial = InMaterial;
}

void UGeometryCacheDecalComponent::GetUsedMaterials(TArray<UMaterialInterface*>& OutMaterials, bool bGetDebugMaterials) const
{
	/*if (DecalMaterial)
	{
		OutMaterials.AddUnique(DecalMaterial);
	}*/
	return Super::GetUsedMaterials(OutMaterials, bGetDebugMaterials);
}

#undef LOCTEXT_NAMESPACE