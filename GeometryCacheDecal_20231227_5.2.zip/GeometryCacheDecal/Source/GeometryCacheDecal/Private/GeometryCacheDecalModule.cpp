// Copyright Qibo Pang 2023. All Rights Reserved.


#include "GeometryCacheDecalModule.h"

#define LOCTEXT_NAMESPACE "FGeometryCacheDecalModule"

void FGeometryCacheDecalModule::StartupModule()
{
	
}

void FGeometryCacheDecalModule::ShutdownModule()
{
	
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FGeometryCacheDecalModule, GeometryCacheDecal)