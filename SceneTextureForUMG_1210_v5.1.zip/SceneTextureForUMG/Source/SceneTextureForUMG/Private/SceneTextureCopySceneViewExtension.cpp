// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SceneTextureCopySceneViewExtension.h"
#include "RHI.h"
#include "SceneView.h"
#include "PostProcess/PostProcessing.h"
#include "ScreenPass.h"
#include "CommonRenderResources.h"
#include "Containers/DynamicRHIResourceArray.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "SceneRendering.h"
#include "Engine/TextureRenderTarget2D.h"
#include "DynamicResolutionState.h"

#include "SceneTextureForUMGRenderer.h"
#include "SceneTextureCopySubsystem.h"
#include "SceneTextureCopyMaterial.h"
#include "SceneTextureForUMGSettings.h"

namespace
{
	template<typename TSetupFunction>
	void DrawScreenPass(
		FRHICommandListImmediate& RHICmdList,
		const FSceneView& View,
		const FScreenPassTextureViewport& OutputViewport,
		const FScreenPassTextureViewport& InputViewport,
		const FScreenPassPipelineState& PipelineState,
		TSetupFunction SetupFunction)
	{
		PipelineState.Validate();

		const FIntRect InputRect = InputViewport.Rect;
		const FIntPoint InputSize = InputViewport.Extent;
		const FIntRect OutputRect = OutputViewport.Rect;
		const FIntPoint OutputSize = OutputRect.Size();

		RHICmdList.SetViewport(OutputRect.Min.X, OutputRect.Min.Y, 0.0f, OutputRect.Max.X, OutputRect.Max.Y, 1.0f);

		SetScreenPassPipelineState(RHICmdList, PipelineState);

		// Setting up buffers.
		SetupFunction(RHICmdList);

		FIntPoint LocalOutputPos(FIntPoint::ZeroValue);
		FIntPoint LocalOutputSize(OutputSize);
		EDrawRectangleFlags DrawRectangleFlags = EDRF_UseTriangleOptimization;

		DrawPostProcessPass(
			RHICmdList,
			LocalOutputPos.X, LocalOutputPos.Y, LocalOutputSize.X, LocalOutputSize.Y,
			InputRect.Min.X, InputRect.Min.Y, InputRect.Width(), InputRect.Height(),
			OutputSize,
			InputSize,
			PipelineState.VertexShader,
			View.StereoViewIndex,
			false,
			DrawRectangleFlags);
	}

	FVector4 Clamp(const FVector4 & VectorToClamp, float Min, float Max)
	{
		return FVector4(FMath::Clamp(VectorToClamp.X, Min, Max),
						FMath::Clamp(VectorToClamp.Y, Min, Max),
						FMath::Clamp(VectorToClamp.Z, Min, Max),
						FMath::Clamp(VectorToClamp.W, Min, Max));
	}
}

FSceneTextureCopySceneViewExtension::FSceneTextureCopySceneViewExtension(const FAutoRegister& AutoRegister, USceneTextureCopySubsystem* InWorldSubsystem) :
	FSceneViewExtensionBase(AutoRegister), WorldSubsystem(InWorldSubsystem)
{
}

void FSceneTextureCopySceneViewExtension::PrePostProcessPass_RenderThread(FRDGBuilder& GraphBuilder, const FSceneView& View, const FPostProcessingInputs& Inputs)
{
	if (!WorldSubsystem)
	{
		return;
	}

	bool EnableSceneColor = USceneTextureForUMGSettings::GetInstance()->EnableSceneColor;
	bool EnableSceneDepth = USceneTextureForUMGSettings::GetInstance()->EnableSceneDepth;
	bool EnableCustomDepth = USceneTextureForUMGSettings::GetInstance()->EnableCustomDepth;
	if (!EnableSceneColor && !EnableSceneDepth && !EnableCustomDepth)
	{
		return;
	}

	Inputs.Validate();

	const FSceneViewFamily& ViewFamily = *View.Family;
	DynamicRenderScaling::TMap<float> UpperBounds = ViewFamily.GetScreenPercentageInterface()->GetResolutionFractionsUpperBound();
	const auto FeatureLevel = View.GetFeatureLevel();
	const float ScreenPercentage = UpperBounds[GDynamicPrimaryResolutionFraction] * ViewFamily.SecondaryViewFraction;

	checkSlow(View.bIsViewInfo); // can't do dynamic_cast because FViewInfo doesn't have any virtual functions.
	const FIntRect PrimaryViewRect = static_cast<const FViewInfo&>(View).ViewRect;
	
	// Scene Textures
	FScreenPassTexture SceneColor((*Inputs.SceneTextures)->SceneColorTexture, PrimaryViewRect);
	FScreenPassTexture SceneDepth((*Inputs.SceneTextures)->SceneDepthTexture, PrimaryViewRect);
	FScreenPassTexture CustomDepth((*Inputs.SceneTextures)->CustomDepthTexture, PrimaryViewRect);

	if (!SceneColor.IsValid() || !SceneDepth.IsValid() || !CustomDepth.IsValid())
	{
		return;
	}

	// Get ViewportSize
	const FScreenPassTextureViewport RegionViewport(SceneColor);
	FIntPoint ViewportSize = RegionViewport.Rect.Size();
	if (ViewportSize != FSceneTextureForUMGRenderer::Get().GetRenderTargetSize())
	{
		ReleasePooledTextures();
		FSceneTextureForUMGRenderer::Get().UpdateRenderTargetSize_GameThread(ViewportSize);
		return;
	}

	InitPooledTextures();
	if (SceneColorPooledTexture && SceneDepthPooledTexture && CustomDepthPooledTexture)
	{
		FGlobalShaderMap* GlobalShaderMap = GetGlobalShaderMap(GMaxRHIFeatureLevel);
	
		// Get BlendState
		FRHIBlendState* DefaultBlendState = FScreenPassPipelineState::FDefaultBlendState::GetRHI();
		//FRHISamplerState* PointClampSampler = TStaticSamplerState<SF_Point, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();

#pragma region COPY
		
		//Create Copy PS Shader Parameters
		FCopyTexturePS::FParameters* Parameters = GraphBuilder.AllocParameters<FCopyTexturePS::FParameters>();

		TShaderMapRef<FSceneTextureCopyScreenPassVS> ScreenPassVS(GlobalShaderMap);
		//TShaderMapRef<FCopyTexturePS> CopyPixelShader(GlobalShaderMap);

		FCopyTexturePS::FPermutationDomain PermutationVector;
		PermutationVector.Set<FCopyTexturePS::FCopySceneColor>(EnableSceneColor);
		PermutationVector.Set<FCopyTexturePS::FCopySceneDepth>(EnableSceneDepth);
		PermutationVector.Set<FCopyTexturePS::FCopyCustomDepth>(EnableCustomDepth);
		auto CopyPixelShader = GlobalShaderMap->GetShader<FCopyTexturePS>(PermutationVector);

		if (EnableSceneColor)
		{
			Parameters->SceneColorCopyTexture = SceneColor.Texture;
			Parameters->SceneColorCopySampler = TStaticSamplerState</*SF_Bilinear*/SF_Point, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();
			
		}
		
		if (EnableSceneDepth)
		{
			Parameters->SceneDepthCopyTexture = SceneDepth.Texture;
			Parameters->SceneDepthCopySampler = TStaticSamplerState</*SF_Bilinear*/SF_Point, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();
			
		}

		if (EnableCustomDepth)
		{
			Parameters->CustomDepthCopyTexture = CustomDepth.Texture;
			Parameters->CustomDepthCopySampler = TStaticSamplerState</*SF_Bilinear*/SF_Point, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();
			
		}
		FRDGTextureRef RDGSceneColorTexture = GraphBuilder.RegisterExternalTexture(SceneColorPooledTexture);
		FRDGTextureRef RDGSceneDepthTexture = GraphBuilder.RegisterExternalTexture(SceneDepthPooledTexture);
		FRDGTextureRef RDGCustomDepthTexture = GraphBuilder.RegisterExternalTexture(CustomDepthPooledTexture);

		Parameters->RenderTargets[0] = FRenderTargetBinding(RDGSceneDepthTexture, ERenderTargetLoadAction::EClear);
		Parameters->RenderTargets[1] = FRenderTargetBinding(RDGCustomDepthTexture, ERenderTargetLoadAction::EClear);
		Parameters->RenderTargets[2] = FRenderTargetBinding(RDGSceneColorTexture, ERenderTargetLoadAction::EClear);

		GraphBuilder.AddPass(
			RDG_EVENT_NAME("CopySceneTextures"),
			Parameters,
			ERDGPassFlags::Raster,
			[&View, ScreenPassVS, CopyPixelShader, RegionViewport, Parameters, DefaultBlendState](FRHICommandListImmediate& RHICmdList)
			{
				DrawScreenPass(
					RHICmdList,
					View,
					RegionViewport,
					RegionViewport,
					FScreenPassPipelineState(ScreenPassVS, CopyPixelShader, DefaultBlendState),
					[&](FRHICommandListImmediate&)
					{
						SetShaderParameters(RHICmdList, CopyPixelShader, CopyPixelShader.GetPixelShader(), *Parameters);
					});
			});
#pragma endregion
	}
}

void FSceneTextureCopySceneViewExtension::InitPooledTextures()
{
	if (!SceneColorPooledTexture)
	{
		UTextureRenderTarget2D* RT_SceneColor = FSceneTextureForUMGRenderer::Get().GetSceneColor();
		FTexture2DRHIRef RHISceneColorTexture = RT_SceneColor->GetRenderTargetResource()->GetRenderTargetTexture();
		SceneColorPooledTexture = CreateRenderTarget(RHISceneColorTexture, TEXT("SceneColorForUMG"));
	}

	if (!SceneDepthPooledTexture)
	{
		UTextureRenderTarget2D* RT_SceneDepth = FSceneTextureForUMGRenderer::Get().GetSceneDepth();
		FTexture2DRHIRef RHISceneDepthTexture = RT_SceneDepth->GetRenderTargetResource()->GetRenderTargetTexture();
		SceneDepthPooledTexture = CreateRenderTarget(RHISceneDepthTexture, TEXT("SceneDepthForUMG"));
	}

	if (!CustomDepthPooledTexture)
	{
		UTextureRenderTarget2D* RT_CustomDepth = FSceneTextureForUMGRenderer::Get().GetCustomDepth();
		FTexture2DRHIRef RHICustomDepthTexture = RT_CustomDepth->GetRenderTargetResource()->GetRenderTargetTexture();
		CustomDepthPooledTexture = CreateRenderTarget(RHICustomDepthTexture, TEXT("CustomDepthForUMG"));
	}
}

void FSceneTextureCopySceneViewExtension::ReleasePooledTextures()
{
	if (SceneColorPooledTexture)
	{
		SceneColorPooledTexture.SafeRelease();
		SceneColorPooledTexture = nullptr;
	}

	if (SceneDepthPooledTexture)
	{
		SceneDepthPooledTexture.SafeRelease();
		SceneDepthPooledTexture = nullptr;
	}

	if (CustomDepthPooledTexture)
	{
		CustomDepthPooledTexture.SafeRelease();
		CustomDepthPooledTexture = nullptr;
	}
}

