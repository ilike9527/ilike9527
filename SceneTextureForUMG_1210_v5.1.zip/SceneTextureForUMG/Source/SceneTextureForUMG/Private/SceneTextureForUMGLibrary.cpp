// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SceneTextureForUMGLibrary.h"
#include "SceneTextureForUMGRenderer.h"
#include "Components/Widget.h"
#include "SceneTextureForUMGSettings.h"

void USceneTextureForUMGLibrary::EnableSceneTexturesForUMG(const FSceneTextureEnableSettings& Settings, const UObject* WorldContextObject)
{
	USceneTextureForUMGSettings::GetMutableInstance()->EnableSceneColor = Settings.EnableSceneColor;
	USceneTextureForUMGSettings::GetMutableInstance()->EnableSceneDepth = Settings.EnableSceneDepth;
	USceneTextureForUMGSettings::GetMutableInstance()->EnableCustomDepth = Settings.EnableCustomDepth;
	USceneTextureForUMGSettings::GetMutableInstance()->EnableFinalColor = Settings.EnableFinalColor;
	USceneTextureForUMGSettings::GetMutableInstance()->SaveConfig();

	if (USceneTextureForUMGSettings::GetInstance()->EnableFinalColor)
	{
		FSceneTextureForUMGRenderer::Get().InitFinalColorRecorder(WorldContextObject->GetWorld());
	}
	else
	{
		FSceneTextureForUMGRenderer::Get().ReleaseFinalColorRecorder();
	}
}