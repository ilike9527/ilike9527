// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SeeThroughTextLibrary.h"
#include "Render/SceneTextureForTextRenderer.h"
#include "Components/Widget.h"

void USeeThroughTextLibrary::AddMaterialForSeeThroughText(UMaterialInstanceDynamic* MaterialInstanceDynamic, const UObject* WorldContextObject)
{
	FSceneTextureForTextRenderer::Get().AddMaterialForSeeThroughText(MaterialInstanceDynamic, WorldContextObject);
}

void USeeThroughTextLibrary::RemoveMaterialForSeeThroughText(UMaterialInstanceDynamic* MaterialInstanceDynamic)
{
	FSceneTextureForTextRenderer::Get().RemoveMaterialForSeeThroughText(MaterialInstanceDynamic);
}

void USeeThroughTextLibrary::GetStyleFromRichTextStyleRow(const FRichTextStyleRow& Row, FTextBlockStyle& OutStyle)
{
	OutStyle = Row.TextStyle;
}