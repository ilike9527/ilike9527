// Copyright Qibo Pang 2022. All Rights Reserved.


#include "GeometryCacheCollisionEditorModule.h"
#include "GeometryCacheCollisionDetailsCustomization.h"


#define LOCTEXT_NAMESPACE "FGeometryCacheCollisionEditorModule"

void FGeometryCacheCollisionEditorModule::StartupModule()
{
	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.RegisterCustomClassLayout(UGeometryCacheCollisionComponent::StaticClass()->GetFName(), FOnGetDetailCustomizationInstance::CreateStatic(&FGeometryCacheCollisionWidgetDetailsCustomization::MakeInstance));
}

void FGeometryCacheCollisionEditorModule::ShutdownModule()
{
	if (!UObjectInitialized())
		return;

	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.UnregisterCustomClassLayout(UGeometryCacheCollisionComponent::StaticClass()->GetFName());

}


#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FGeometryCacheCollisionEditorModule, GeometryCacheCollisionEditor)
