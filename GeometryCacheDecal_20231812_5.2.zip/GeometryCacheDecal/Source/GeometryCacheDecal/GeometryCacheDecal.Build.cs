// Copyright Qibo Pang 2023. All Rights Reserved.

using System.IO;
using UnrealBuildTool;

public class GeometryCacheDecal : ModuleRules
{
	public GeometryCacheDecal(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicIncludePaths.Add(Path.Combine(ModuleDirectory, "Public"));
		PrivateIncludePaths.Add(Path.Combine(ModuleDirectory, "Private"));

		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				"ApplicationCore",
				"CoreUObject",
				"Engine",
				"RenderCore",
				"RHI",
				"PhysicsCore",
				"GeometryCache",
				"GeometryCore",
				"DynamicMesh",
				"GeometryAlgorithms",
				"MeshDescription",
				"StaticMeshDescription",

			}
		);

		PrivateDependencyModuleNames.AddRange(new string[] { });
	}
}
