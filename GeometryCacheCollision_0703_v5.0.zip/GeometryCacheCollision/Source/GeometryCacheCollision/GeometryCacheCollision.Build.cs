// Copyright Qibo Pang 2022. All Rights Reserved.

using System.IO;
using UnrealBuildTool;

public class GeometryCacheCollision : ModuleRules
{
	public GeometryCacheCollision(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicIncludePaths.Add(Path.Combine(ModuleDirectory, "Public"));
		PrivateIncludePaths.Add(Path.Combine(ModuleDirectory, "Private"));

		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				"ApplicationCore",
				"CoreUObject",
				"Engine",
				"RenderCore",
				"RHI",
				"PhysicsCore",
				"GeometryCache",
			}
		);

		PrivateDependencyModuleNames.AddRange(new string[] { });
	}
}
