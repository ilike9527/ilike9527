// Copyright Qibo Pang. All Rights Reserved.


#include "PolygonWidget.h"
#include "Blueprint/SlateBlueprintLibrary.h"
#include "Engine/World.h"

EInterpCurveMode ConvertUMGPolygonTypeToInterpCurveMode(EUMGPolygonType PolygonType)
{
	switch (PolygonType)
	{
	case EUMGPolygonType::LinearEdge:				return CIM_Linear;
	case EUMGPolygonType::CurveEdge:				return CIM_CurveUser;

	default:									return CIM_Unknown;
	}
}

void FUMGPolygonCurves::UpdatePolygon(const FUMGPolygonInfo& PolygonInfo, bool bStationaryEndpoints, int32 InReparamStepsPerSegment, bool bClosedLoopPositionOverride, float LoopPosition, const FVector2D& Scale2D)
{
	ReparamStepsPerSegment = InReparamStepsPerSegment;

	EInterpCurveMode CurveMode = ConvertUMGPolygonTypeToInterpCurveMode(PolygonInfo.PolygonType);

	Position.Points.Reset(PolygonInfo.Points.Num());
	for (int32 Index = 0; Index < PolygonInfo.Points.Num(); Index++)
	{
		Position.Points.Emplace(Index, PolygonInfo.Points[Index].Location, PolygonInfo.Points[Index].Direction, PolygonInfo.Points[Index].Direction, CurveMode);
	}
	
	const int32 NumPoints = Position.Points.Num();
	bool bClosedLoop = true;

	// Ensure splines' looping status matches with that of the spline widget
	if (bClosedLoop)
	{
		const float LastKey = Position.Points.Num() > 0 ? Position.Points.Last().InVal : 0.0f;
		const float LoopKey = bClosedLoopPositionOverride ? LoopPosition : LastKey + 1.0f;
		Position.SetLoopKey(LoopKey);
	}
	else
	{
		Position.ClearLoopKey();
	}

	// Automatically set the tangents on any CurveAuto keys
	// Position.AutoSetTangents(0.0f, bStationaryEndpoints);

	// Now initialize the spline reparam table
	const int32 NumSegments = bClosedLoop ? NumPoints : NumPoints - 1;

	// Start by clearing it
	ReparamTable.Points.Reset(NumSegments * ReparamStepsPerSegment + 1);
	float AccumulatedLength = 0.0f;
	for (int32 SegmentIndex = 0; SegmentIndex < NumSegments; ++SegmentIndex)
	{
		for (int32 Step = 0; Step < ReparamStepsPerSegment; ++Step)
		{
			const float Param = static_cast<float>(Step) / ReparamStepsPerSegment;
			const float SegmentLength = (Step == 0) ? 0.0f : GetSegmentLength(SegmentIndex, Param, bClosedLoop, Scale2D);

			ReparamTable.Points.Emplace(SegmentLength + AccumulatedLength, SegmentIndex + Param, 0.0f, 0.0f, CIM_Linear);
		}
		AccumulatedLength += GetSegmentLength(SegmentIndex, 1.0f, bClosedLoop, Scale2D);
	}

	ReparamTable.Points.Emplace(AccumulatedLength, static_cast<float>(NumSegments), 0.0f, 0.0f, CIM_Linear);
	++Version;
}


float FUMGPolygonCurves::GetSegmentLength(const int32 Index, const float Param, bool bClosedLoop, const FVector2D& Scale2D) const
{
	const int32 NumPoints = Position.Points.Num();
	const int32 LastPoint = NumPoints - 1;

	check(Index >= 0 && ((bClosedLoop && Index < NumPoints) || (!bClosedLoop && Index < LastPoint)));
	check(Param >= 0.0f && Param <= 1.0f);

	// Evaluate the length of a Hermite spline segment.
	// This calculates the integral of |dP/dt| dt, where P(t) is the spline equation with components (x(t), y(t), z(t)).
	// This isn't solvable analytically, so we use a numerical method (Legendre-Gauss quadrature) which performs very well
	// with functions of this type, even with very few samples.  In this case, just 5 samples is sufficient to yield a
	// reasonable result.

	struct FLegendreGaussCoefficient
	{
		float Abscissa;
		float Weight;
	};

	static const FLegendreGaussCoefficient LegendreGaussCoefficients[] =
	{
		{ 0.0f, 0.5688889f },
		{ -0.5384693f, 0.47862867f },
		{ 0.5384693f, 0.47862867f },
		{ -0.90617985f, 0.23692688f },
		{ 0.90617985f, 0.23692688f }
	};

	const auto& StartPoint = Position.Points[Index];
	const auto& EndPoint = Position.Points[Index == LastPoint ? 0 : Index + 1];

	const auto& P0 = StartPoint.OutVal;
	const auto& T0 = StartPoint.LeaveTangent;
	const auto& P1 = EndPoint.OutVal;
	const auto& T1 = EndPoint.ArriveTangent;

	// Special cases for linear or constant segments
	if (StartPoint.InterpMode == CIM_Linear)
	{
		return ((P1 - P0) * Scale2D).Size() * Param;
	}
	else if (StartPoint.InterpMode == CIM_Constant)
	{
		return 0.0f;
	}

	// Cache the coefficients to be fed into the function to calculate the spline derivative at each sample point as they are constant.
	const FVector2D Coeff1 = ((P0 - P1) * 2.0f + T0 + T1) * 3.0f;
	const FVector2D Coeff2 = (P1 - P0) * 6.0f - T0 * 4.0f - T1 * 2.0f;
	const FVector2D Coeff3 = T0;

	const float HalfParam = Param * 0.5f;

	float Length = 0.0f;
	for (const auto& LegendreGaussCoefficient : LegendreGaussCoefficients)
	{
		// Calculate derivative at each Legendre-Gauss sample, and perform a weighted sum
		const float Alpha = HalfParam * (1.0f + LegendreGaussCoefficient.Abscissa);
		const FVector2D Derivative = ((Coeff1 * Alpha + Coeff2) * Alpha + Coeff3) * Scale2D;
		Length += Derivative.Size() * LegendreGaussCoefficient.Weight;
	}
	Length *= HalfParam;

	return Length;
}


float FUMGPolygonCurves::GetPolygonLength() const
{
	const int32 NumPoints = ReparamTable.Points.Num();

	// This is given by the input of the last entry in the remap table
	if (NumPoints > 0)
	{
		return ReparamTable.Points.Last().InVal;
	}

	return 0.0f;
}


/// Slate Overrides ///
const FInterpCurvePointVector2D UPolygonWidget::DummyPointPosition(0.0f, FVector2D::ZeroVector, FVector2D::ZeroVector, FVector2D::ZeroVector, CIM_Constant);

void UPolygonWidget::OnWidgetRebuilt()
{
	// 
	if (!IsDesignTime())
	{
		UpdatePolygon();
	}
}

TSharedRef<SWidget> UPolygonWidget::RebuildWidget()
{
	Polygon = SNew(SWPolygon)
                .PolygonInfo_UObject(this, &UPolygonWidget::GetPolygonInfo);
	
    return Polygon.ToSharedRef();
}

void UPolygonWidget::ReleaseSlateResources(bool bReleaseChildren)
{
    Super::ReleaseSlateResources(bReleaseChildren);

    Polygon.Reset();
}

void UPolygonWidget::UpdatePolygon()
{
    PolygonCurves.UpdatePolygon(PolygonInfo);
}

FVector2D UPolygonWidget::GetLocationAtPolygonEdgeInputKey(float InKey, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const
{
	FVector2D Location = PolygonCurves.Position.Eval(InKey, FVector2D::ZeroVector);

	if (CoordinateSpace == EUMGPolygonCoordinateSpace::Type::Screen)
	{
		return GetCachedGeometry().LocalToAbsolute(Location);
	}
	else if(CoordinateSpace == EUMGPolygonCoordinateSpace::Type::Viewport)
	{
		FVector2D PixelPosition, ViewportPosition;
		USlateBlueprintLibrary::LocalToViewport(GetWorld(), GetCachedGeometry(), Location, PixelPosition, ViewportPosition);
		return ViewportPosition;
	}
	
    return Location;
}

FVector2D UPolygonWidget::GetTangentAtPolygonEdgeInputKey(float InKey, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const
{
	FVector2D Tangent = PolygonCurves.Position.EvalDerivative(InKey, FVector2D::ZeroVector);

	if (CoordinateSpace == EUMGPolygonCoordinateSpace::Type::Screen || CoordinateSpace == EUMGPolygonCoordinateSpace::Type::Viewport)
	{
		return GetCachedGeometry().GetAccumulatedRenderTransform().TransformVector(Tangent);
	}
    return Tangent;
}

FVector2D UPolygonWidget::GetDirectionAtPolygonEdgeInputKey(float InKey, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const
{
	FVector2D Direction = PolygonCurves.Position.EvalDerivative(InKey, FVector2D::ZeroVector).GetSafeNormal();

	if (CoordinateSpace == EUMGPolygonCoordinateSpace::Type::Screen || CoordinateSpace == EUMGPolygonCoordinateSpace::Type::Viewport)
	{
		return GetCachedGeometry().GetAccumulatedRenderTransform().TransformVector(Direction);
	}

	return Direction;
}

float UPolygonWidget::GetRotationAngleAtPolygonEdgeInputKey(float InKey, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const
{
	FVector2D Direction = GetDirectionAtPolygonEdgeInputKey(InKey, CoordinateSpace);
	float AngleInRadians = Direction.IsNearlyZero() ? 0.0f : FMath::Atan2(Direction.Y, Direction.X);

	return FMath::RadiansToDegrees(AngleInRadians);
}

float UPolygonWidget::GetDistanceAlongPolygonAtPolygonEdgeInputKey(float InKey) const
{
	const int32 NumPoints = PolygonCurves.Position.Points.Num();
	const int32 NumSegments =NumPoints;

	if ((InKey >= 0) && (InKey < NumSegments))
	{
		const int32 PointIndex = FMath::FloorToInt(InKey);
		const float Fraction = InKey - PointIndex;
		const int32 ReparamPointIndex = PointIndex * PolygonCurves.ReparamStepsPerSegment;
		const float Distance = PolygonCurves.ReparamTable.Points[ReparamPointIndex].InVal;
		return Distance + PolygonCurves.GetSegmentLength(PointIndex, Fraction, true, FVector2D(1.0f));;
	}
	else if (InKey >= NumSegments)
	{
		return PolygonCurves.GetPolygonLength();
	}

	return 0.0f;
}

void UPolygonWidget::AddPolygonEdgePoint(const FUMGPolygonPoint& PolygonPoint, bool bUpdatePolygon)
{
	PolygonInfo.AddPoint(PolygonPoint);

	if (bUpdatePolygon)
	{
		UpdatePolygon();
	}
}

void UPolygonWidget::AddPolygonEdgePointAtIndex(const FUMGPolygonPoint& PolygonPoint, int32 Index, bool bUpdatePolygon)
{
	PolygonInfo.AddPolygonPointAtIndex(PolygonPoint, Index);
	
	if (bUpdatePolygon)
	{
		UpdatePolygon();
	}
}

void UPolygonWidget::RemovePolygonEdgePoint(int32 Index, bool bUpdatePolygon)
{
	PolygonInfo.DeletePoint(Index);

	if (bUpdatePolygon)
	{
		UpdatePolygon();
	}
}

void UPolygonWidget::RemoveAllPolygonEdgePoint(bool bUpdatePolygon)
{
	PolygonInfo.Points.Empty();

	if (bUpdatePolygon)
	{
		UpdatePolygon();
	}
}

void UPolygonWidget::ChangePolygonEdgePointAtIndex(const FUMGPolygonPoint& PolygonPoint, int32 Index, bool bUpdatePolygon)
{
	PolygonInfo.ChangePolygonPointAtIndex(PolygonPoint, Index);

	if (bUpdatePolygon)
	{
		UpdatePolygon();
	}
}

EUMGPolygonType UPolygonWidget::GetPolygonType() const
{
    return PolygonInfo.PolygonType;
}

void UPolygonWidget::SetPolygonType(EUMGPolygonType Type)
{
    PolygonInfo.PolygonType = Type;
}

int32 UPolygonWidget::GetNumberOfPolygonEdgePoints() const
{
    return PolygonInfo.Points.Num();
}

FVector2D UPolygonWidget::GetLocationAtPolygonEdgePoint(int32 PointIndex, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const
{
	const FInterpCurvePointVector2D& Point = GetPositionPointSafe(PointIndex);
	const FVector2D& Location = Point.OutVal;

	if (CoordinateSpace == EUMGPolygonCoordinateSpace::Type::Screen)
	{
		return GetCachedGeometry().LocalToAbsolute(Location);
	}
	else if (CoordinateSpace == EUMGPolygonCoordinateSpace::Type::Viewport)
	{
		FVector2D PixelPosition, ViewportPosition;
		USlateBlueprintLibrary::LocalToViewport(GetWorld(), GetCachedGeometry(), Location, PixelPosition, ViewportPosition);
		return ViewportPosition;
	}

    return Location;
}

FVector2D UPolygonWidget::GetDirectionAtPolygonEdgePoint(int32 PointIndex, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const
{
	const FInterpCurvePointVector2D& Point = GetPositionPointSafe(PointIndex);
	const FVector2D Direction = Point.LeaveTangent.GetSafeNormal();

	if (CoordinateSpace == EUMGPolygonCoordinateSpace::Type::Screen || CoordinateSpace == EUMGPolygonCoordinateSpace::Type::Viewport)
	{
		return GetCachedGeometry().GetAccumulatedRenderTransform().TransformVector(Direction);
	}

	return Direction;
}

FVector2D UPolygonWidget::GetTangentAtPolygonEdgePoint(int32 PointIndex, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const
{
	const FInterpCurvePointVector2D& Point = GetPositionPointSafe(PointIndex);
	const FVector2D& Direction = Point.LeaveTangent;

	if (CoordinateSpace == EUMGPolygonCoordinateSpace::Type::Screen || CoordinateSpace == EUMGPolygonCoordinateSpace::Type::Viewport)
	{
		return GetCachedGeometry().GetAccumulatedRenderTransform().TransformVector(Direction);
	}

	return Direction;
}

float UPolygonWidget::GetPolygonEdgeLength() const
{
	return PolygonCurves.GetPolygonLength();
}

float UPolygonWidget::GetInputKeyAtDistanceAlongPolygonEdge(float Distance, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const
{
	const int32 NumPoints = PolygonCurves.Position.Points.Num();

	if (NumPoints < 2)
	{
		return 0.0f;
	}

	return PolygonCurves.ReparamTable.Eval(Distance, 0.0f);
}

FVector2D UPolygonWidget::GetLocationAtDistanceAlongPolygonEdge(float Distance, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const
{
	const float Param = PolygonCurves.ReparamTable.Eval(Distance, 0.0f);
	return GetLocationAtPolygonEdgeInputKey(Param, CoordinateSpace);
}

FVector2D UPolygonWidget::GetDirectionAtDistanceAlongPolygonEdge(float Distance, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const
{
	const float Param = PolygonCurves.ReparamTable.Eval(Distance, 0.0f);
	return GetDirectionAtPolygonEdgeInputKey(Param, CoordinateSpace);
}

FVector2D UPolygonWidget::GetTangentAtDistanceAlongPolygonEdge(float Distance, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const
{
	const float Param = PolygonCurves.ReparamTable.Eval(Distance, 0.0f);
	return GetTangentAtPolygonEdgeInputKey(Param, CoordinateSpace);
}

float UPolygonWidget::GetRotationAngleAtDistanceAlongPolygonEdge(float Distance, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const
{
	const float Param = PolygonCurves.ReparamTable.Eval(Distance, 0.0f);
    return GetRotationAngleAtPolygonEdgeInputKey(Param, CoordinateSpace);
}

bool UPolygonWidget::CheckPointInPolygon(const FVector2D& Point) const
{
	if (Polygon)
	{
		return Polygon->CheckPointInPolygon(Point);
	}
	return false;
}




