// Copyright Qibo Pang. All Rights Reserved.

#pragma once

#include "Modules/ModuleManager.h"

class FUMGPolygonModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};
