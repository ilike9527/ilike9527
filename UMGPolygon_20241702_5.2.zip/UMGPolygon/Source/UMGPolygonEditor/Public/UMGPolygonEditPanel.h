// Copyright Qibo Pang. All Rights Reserved.


#pragma once

// Core Include
#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"

// Misc Includes
#include "Misc/Attribute.h"
#include "Input/Reply.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Framework/SlateDelegates.h"
#include "Rendering/DrawElements.h"
#include "Styling/CoreStyle.h"
#include "UMGPolygonDefine.h"

class FPaintArgs;
class FSlateWindowElementList;
class UPolygonWidget;
struct FSlateBrush;

struct FSelectedPolygonTangent
{
    FSelectedPolygonTangent() {}

    bool IsValid() { return PointIndex != -1; }

    int32 PointIndex = -1;

    bool bIsArrial = false;
};

struct FPolygonEditPanelTransform
{
    FVector2D  Offset;
    float      Scale;

    FPolygonEditPanelTransform()
    {
        Offset = FVector2D::ZeroVector;
        Scale = 1.0;
    }

    /** Local Widget Space -> Polygon Input domain. */
    FVector2D LocalToInput(FVector2D Local) const
    {
        return (Scale != 0.0f) ? (Local / Scale + Offset) : Offset;
    }

    /** Polygon Input domain. -> Local Widget Space*/
    FVector2D InputToLocal(FVector2D Input) const
    {
        return (Input - Offset) * Scale;
    }
};

/**
 * Edit panel for a spline
 */
class SUMGPolygonEditPanel : public SCompoundWidget
{
public:

    SLATE_BEGIN_ARGS(SUMGPolygonEditPanel)
        : _PolygonInfo()
        , _OnPolygonInfoValueChanged()
        { }

        /// Attributes ///
    
        SLATE_ATTRIBUTE(FUMGPolygonInfo, PolygonInfo)

        /// Arguments ///
        SLATE_ARGUMENT(UPolygonWidget*, OwningPolygonWidget)

        /// Events ///
   
        /** Invoked when a new value is selected on the spline. */
        SLATE_EVENT(FOnPolygonInfoValueChanged, OnPolygonInfoValueChanged)

    SLATE_END_ARGS()

protected:

    /** Represents the different states of a drag operation. Copy from SCurveEditor.h */
    enum class EDragState
    {
        /** The user has clicked a mouse button, but hasn't moved more then the drag threshold. */
        PreDrag,
        /** The user is dragging the selected keys. */
        DragKey,
        /** The user is free dragging the selected keys. */
        FreeDrag,
        /** The user is dragging a selected tangent handle. */
        DragTangent,
        /** The user is panning the curve view. */
        Pan,
        /** The user is zooming the curve view. */
        Zoom,
        /** There is no active drag operation. */
        None
    };


public:

    /**
     * Construct this widget.
     *
     * @param InArgs The declaration data for this widget.
     */
    void Construct(const FArguments& InArgs);
	
    
#pragma region Overrides
    
    // SWidget overrides
    virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;

    virtual FVector2D ComputeDesiredSize(float) const override;
    
    virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
    
    virtual FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
    
    virtual FReply OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
    
    virtual void   OnMouseCaptureLost(const FCaptureLostEvent& CaptureLostEvent) override;

    virtual FReply OnMouseWheel(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;

    virtual void OnMouseLeave(const FPointerEvent& MouseEvent) override;

    virtual FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;

    virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect,
                          FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle,
                          bool bParentEnabled) const override;

#pragma endregion Overrides


protected:

    /** Paint a spline with custom verts draw function*/
    void PaintPolygon_CustomVerts(const FUMGPolygonInfo& InPolygonInfo, const FGeometry& AllottedGeometry, FSlateWindowElementList& OutDrawElements,
        int32 LayerId, const FSlateRect& MyCullingRect, ESlateDrawEffect DrawEffects, const FWidgetStyle& InWidgetStyle) const;

    /** Paint the keys that make up a curve */
    void PaintPolygonPoints(const FUMGPolygonInfo& InPolygonInfo, FSlateWindowElementList& OutDrawElements, int32 LayerId, int32 SelectedLayerId, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, ESlateDrawEffect DrawEffects, const FWidgetStyle& InWidgetStyle) const;

    /** Paint the tangent for a key with cubic curves */
    void PaintTangent(const FUMGPolygonPoint& PolygonPoint, FSlateWindowElementList& OutDrawElements, int32 LayerId,
        const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, ESlateDrawEffect DrawEffects, int32 LayerToUse, const FWidgetStyle& InWidgetStyle, bool bTangentSelected) const;

    /** Paint Grid lines, these make it easier to visualize relative distance */
    void PaintGridLines(const FGeometry& AllottedGeometry, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FSlateRect& MyCullingRect, ESlateDrawEffect DrawEffects) const;

    /** Paint Background Material */
    void PaintBackgroundMaterial(const FUMGPolygonInfo& InPolygonInfo, const FGeometry& AllottedGeometry, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FSlateRect& MyCullingRect, ESlateDrawEffect DrawEffects) const;

    bool IsPolygonPointSelected(int PointIndex) const;

    void GetTangentPoints(const FVector2D& Location, const FVector2D& Direction, FVector2D& Arrive, FVector2D& Leave) const;

    /** Attempts to start a drag operation when the mouse moves. */
    void TryStartDrag(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);

    /** Processes an ongoing drag operation when the mouse moves. */
    void ProcessDrag(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);

    /** Completes an ongoing drag operation on mouse up. */
    void EndDrag(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);

    /** Zoom the view. */
    void ZoomView(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);

    /** Test a screen space location to find which key was clicked on */
    int32 HitTestPolygonPoints(const FGeometry& InMyGeometry, const FVector2D& HitScreenPosition);

    /** Test a screen space location to find if any cubic tangents were clicked on */
    FSelectedPolygonTangent HitTestCubicTangents(const FGeometry& InMyGeometry, const FVector2D& HitScreenPosition);


    /** Handles a mouse click operation on mouse up */
    void ProcessClick(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent);

    /** Function to create context menu on mouse right click*/
    void CreateContextMenu(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent, bool bShowAddNewPolygonPoint);

    /** Adds a new spline point to the spline. */
    void AddNewPolygonPoint(FGeometry InMyGeometry, FVector2D ScreenPosition);

    /** Called by delete command */
    void DeleteSelectedPolygonPoint();

    float CalculateGridPixelSpacing() const;

    /** Defered Zoom to fit */
    void DeferredZoomToFit();

    /** Active timer that handles deferred zooming until the target zoom is reached */
    EActiveTimerReturnType HandleZoomToFit(double InCurrentTime, float InDeltaTime);

    /** Zoom to fit */
    bool ZoomToFit(bool bFitHorizontal, bool bFitVertical);

    /** Zoom to fit button clicked*/
    FReply ZoomToFitClicked();

    /** Function to create menu on adjust panel height button click*/
    TSharedRef<SWidget> GetPanelHeightMenu();

    /** Panel height Label callback */
    FText GetPanelHeightLabel() const;

    /** Returns the current panel height setting */
    float GetPanelHeightSliderPosition() const;

    /**
     * Sets new panel height
     *
     * @Param	NewValue	Value to set panel height too
     */
    void OnSetPanelHeight(float NewValue);

    /** Function to create menu on spline thickness button click*/
    TSharedRef<SWidget> GetEdgeThicknessFillMenu();

    /** Polygon EdgeThickness Label callback */
    FText GetPolygonEdgeThicknessLabel() const;

    /** Returns  the spline thickness */
    float GetPolygonEdgeThicknessSliderPosition() const;

    /**
     * Sets new panel height
     *
     * @Param	NewValue	Value to set the spline thickness
     */
    void OnSetPolygonEdgeThickness(float NewValue);

    /** Returns the help icon iamge */
    const FSlateBrush* GetHelpImage() const;

    /** Returns the help text */
    FText GetHelpText() const;

private:

    TAttribute<FUMGPolygonInfo> PolygonInfo;

    UPolygonWidget* OwningPolygonWidget = nullptr;

private:

    /** The location of mouse during the last OnMouseButtonDown callback in widget local coordinates. */
    FVector2D MouseDownLocation;

    /** The location of the mouse during the last OnMouseMove callback in widget local coordinates. */
    FVector2D MouseMoveLocation;

    /** The state of the current drag operation happening with the widget, if any. */
    EDragState DragState;

    /** The number of pixels which the mouse must move before a drag operation starts. */
    float DragThreshold;

    /** A map of selected key handle to their starting locations at the beginning of a drag operation. */
    TMap<int32, FVector2D> PreDragPointLocations;

    /** A map of selected key handles to their tangent values at the beginning of a drag operation. */
    TMap<int32, FVector2D> PreDragTangents;

    FSelectedPolygonTangent SelectedTangent;

    int32 DraggedPointIndex;

    int32 SelectedPointIndex;

    FOnPolygonInfoValueChanged OnPolygonInfoValueChanged;

    FPolygonEditPanelTransform TransformInfo;
    FPolygonEditPanelTransform TransformInfoBake;

    bool HideUnselectedTangents = false;

    bool bDeferredZoomToFit = false;

    bool bEditPanelFocus = false;

    TSharedPtr< SImage > HelpIconImage;
    const FSlateBrush* Default;
    const FSlateBrush* Hovered;
    const FSlateBrush* Pressed;

    TSharedPtr <FPoygonVertsCache> PoygonVertsCache = nullptr;
};
