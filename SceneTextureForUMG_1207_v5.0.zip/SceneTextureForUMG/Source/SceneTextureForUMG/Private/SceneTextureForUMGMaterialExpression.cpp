// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SceneTextureForUMGMaterialExpression.h"
#include "MaterialCompiler.h"
#include "SceneTextureForUMGRenderer.h"
#include "Engine/TextureRenderTarget2D.h"

///////////////////////////////////////////////////////////////////////////////
// UMaterialExpressionSceneTextureForUMG
///////////////////////////////////////////////////////////////////////////////
UMaterialExpressionSceneTextureForUMG::UMaterialExpressionSceneTextureForUMG(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
#if WITH_EDITORONLY_DATA
	// Structure to hold one-time initialization
	struct FConstructorStatics
	{
		FText NAME_Texture;
		FConstructorStatics()
			: NAME_Texture(FText::FromString(TEXT("Texture")))
		{
		}
	};
	static FConstructorStatics ConstructorStatics;

	MenuCategories.Add(ConstructorStatics.NAME_Texture);

	bShaderInputData = true;
	bShowOutputNameOnPin = true;
#endif

#if WITH_EDITORONLY_DATA
	Outputs.Reset();
	Outputs.Add(FExpressionOutput(TEXT("Color"), 1, 1, 1, 1, 1));
	Outputs.Add(FExpressionOutput(TEXT("Size")));
	Outputs.Add(FExpressionOutput(TEXT("InvSize")));
#endif
}

#if WITH_EDITOR
int32 UMaterialExpressionSceneTextureForUMG::Compile(class FMaterialCompiler* Compiler, int32 OutputIndex)
{
	UTexture* SceneTexture = GetSceneTextureById();

	if (SceneTexture)
	{
		int32 TextureReferenceIndex = INDEX_NONE;
		int32 TextureCodeIndex = INDEX_NONE;
		
		auto GetSamplerTypeById  = [this]()
		{
			EMaterialSamplerType SamplerType;
			switch (SceneTextureId)
			{
			case ESceneTextureForUMGId::UMG_SceneColor:
			case ESceneTextureForUMGId::UMG_FinalColor:
				SamplerType = EMaterialSamplerType::SAMPLERTYPE_Color;
				break;
			case ESceneTextureForUMGId::UMG_SceneDepth:
			case ESceneTextureForUMGId::UMG_CustomDepth:
				SamplerType = EMaterialSamplerType::SAMPLERTYPE_Data;
				break;
			default:
				break;
			}

			return SamplerType;
		};
		EMaterialSamplerType SamplerType = GetSamplerTypeById();
		ESamplerSourceMode SamplerSource = ESamplerSourceMode::SSM_Wrap_WorldGroupSettings;
		ETextureMipValueMode MipValueMode = ETextureMipValueMode::TMVM_None;
		TextureCodeIndex = Compiler->Texture(SceneTexture, SamplerType, SamplerSource);
		//TextureCodeIndex = Compiler->ExternalTexture(SceneTexture);

		return Compiler->TextureSample(
			TextureCodeIndex,
			Coordinates.GetTracedInput().Expression ? Coordinates.Compile(Compiler) : Compiler->TextureCoordinate(ConstCoordinate, false, false),
			EMaterialSamplerType::SAMPLERTYPE_Color);
	}
	

	return Compiler->Errorf(TEXT("SceneTexture For UMG Invalid, Please enable it in ProjectSettings first."));
}

void UMaterialExpressionSceneTextureForUMG::GetCaption(TArray<FString>& OutCaptions) const
{
	UEnum* Enum = StaticEnum<ESceneTextureForUMGId>();

	check(Enum);

	FString Name = Enum->GetDisplayNameTextByValue(SceneTextureId).ToString();

	OutCaptions.Add(FString(TEXT("SceneTexture For UMG : ")) + Name);
}
#endif // WITH_EDITOR

UObject* UMaterialExpressionSceneTextureForUMG::GetReferencedTexture() const
{
	return GetSceneTextureById();
}

UTexture* UMaterialExpressionSceneTextureForUMG::GetSceneTextureById() const
{
	UTexture* SceneTexture = nullptr;
	switch (SceneTextureId)
	{
	case ESceneTextureForUMGId::UMG_SceneColor:
		SceneTexture = FSceneTextureForUMGRenderer::Get().GetSceneColor();
		break;
	case ESceneTextureForUMGId::UMG_SceneDepth:
		SceneTexture = FSceneTextureForUMGRenderer::Get().GetSceneDepth();
		break;
	case ESceneTextureForUMGId::UMG_CustomDepth:
		SceneTexture = FSceneTextureForUMGRenderer::Get().GetCustomDepth();
		break;
	case ESceneTextureForUMGId::UMG_FinalColor:
		SceneTexture = FSceneTextureForUMGRenderer::Get().GetFinalColor();
		break;
	default:
		break;
	}
	return SceneTexture;
};