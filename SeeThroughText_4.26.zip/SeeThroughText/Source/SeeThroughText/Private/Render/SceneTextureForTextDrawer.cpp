// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SceneTextureForTextDrawer.h"
#include "RenderingThread.h"
#include "UnrealClient.h"
#include "Engine/Engine.h"
#include "EngineModule.h"
#include "Framework/Application/SlateApplication.h"
#include "SceneTextureForTextPostProcessor.h"
#include "SceneTextureForTextShaders.h"
#include "SceneTextureForTextRenderer.h"

#define INVALID_LAYER_ID UINT_MAX

static const FName RendererModuleName("Renderer");

FSceneTextureForTextDrawer::FSceneTextureForTextDrawer()
{
	
}

FSceneTextureForTextDrawer::~FSceneTextureForTextDrawer()
{
	
}

static bool ShouldCullWidget(const FSlateWindowElementList& ElementList)
{
	const FSlateClippingManager& ClippingManager = ElementList.GetClippingManager();
	const int32 CurrentIndex = ClippingManager.GetClippingIndex();
	if (CurrentIndex != INDEX_NONE)
	{
		const FSlateClippingState& ClippingState = ClippingManager.GetClippingStates()[CurrentIndex];
		return ClippingState.HasZeroArea();
	}

	return false;
}

bool FSceneTextureForTextDrawer::InitializeSceneTextureForTextParams(FSlateWindowElementList& ElementList, uint32 InLayer, const FPaintGeometry& PaintGeometry)
{
	PaintGeometry.CommitTransformsIfUsingLegacyConstructor();

	if (ShouldCullWidget(ElementList))
	{
		return false;
	}

	const FSlateRenderTransform& RenderTransform = PaintGeometry.GetAccumulatedRenderTransform();
	const FVector2D& LocalSize = PaintGeometry.GetLocalSize();

	//@todo doesn't work with rotated or skewed objects yet
	const FVector2D& Position = PaintGeometry.DrawPosition;

	const int32 Layer = InLayer;

	// Determine the four corners of the quad
	FVector2D TopLeft = FVector2D::ZeroVector;
	FVector2D TopRight = FVector2D(LocalSize.X, 0);
	FVector2D BotLeft = FVector2D(0, LocalSize.Y);
	FVector2D BotRight = FVector2D(LocalSize.X, LocalSize.Y);

	FVector2D WorldTopLeft = TransformPoint(RenderTransform, TopLeft).RoundToVector();
	FVector2D WorldBotRight = TransformPoint(RenderTransform, BotRight).RoundToVector();

	FVector2D WindowSize = ElementList.GetPaintWindow()->GetViewportSize();;
	FVector2D SizeUV = (WorldBotRight - WorldTopLeft) / WindowSize;

	const FSlateClippingState* ClipState = ResolveClippingState(ElementList);


	// These could be negative with rotation or negative scales.  This is not supported yet
	if (SizeUV.X > 0 && SizeUV.Y > 0)
	{
		RenderParams.QuadPositionData = FVector4(WorldTopLeft, WorldBotRight);
		RenderParams.ClippingState = ClipState;
		RenderParams.ViewportSize = WindowSize;
		return true;
	}

	return false;
}

const FSlateClippingState* FSceneTextureForTextDrawer::ResolveClippingState(FSlateWindowElementList& ElementList) const
{
	FClipStateHandle ClipHandle;
	ClipHandle.SetPreCachedClipIndex(ElementList.GetClippingIndex());

	const TArray<FSlateClippingState>* PrecachedClippingStates = &ElementList.GetClippingManager().GetClippingStates();

	// Do cached first
	if (ClipHandle.GetCachedClipState())
	{
		// We should be working with cached elements if we have a cached clip state
		//check(ElementList);
		return ClipHandle.GetCachedClipState();
	}
	else if (PrecachedClippingStates->IsValidIndex(ClipHandle.GetPrecachedClipIndex()))
	{
		// Store the clipping state so we can use it later for rendering.
		return &(*PrecachedClippingStates)[ClipHandle.GetPrecachedClipIndex()];
	}

	return nullptr;
}

static bool IsMemorylessTexture(const FTexture2DRHIRef& Tex)
{
	if (Tex)
	{
		return (Tex->GetFlags() & TexCreate_Memoryless) != 0;
	}
	return false;
}

static bool UpdateScissorRect(
	FRHICommandList& RHICmdList,
	const FSlateClippingState* ClippingState,
	FGraphicsPipelineStateInitializer& InGraphicsPSOInit,
	bool bForceStateChange)
{
	check(RHICmdList.IsInsideRenderPass());

	if (ClippingState != nullptr || bForceStateChange)
	{
		RHICmdList.SetScissorRect(false, 0, 0, 0, 0);

		// Disable depth/stencil testing
		InGraphicsPSOInit.DepthStencilState = TStaticDepthStencilState<false, CF_Always>::GetRHI();
	}

	return false;
}


void FSceneTextureForTextDrawer::DrawRenderThread(FRHICommandListImmediate& RHICmdList, const void* InWindowBackBuffer)
{
	
	IRendererModule& RendererModule = FModuleManager::GetModuleChecked<IRendererModule>(RendererModuleName);

	// This is the stenciling ref variable we set any time we draw, so that any stencil comparisons use the right mask id.
	{
		//SLATE_DRAW_EVENT(RHICmdList, PostProcess);
		//RHICmdList.EndRenderPass();

		FTexture2DRHIRef ColorTarget = *(FTexture2DRHIRef*)(InWindowBackBuffer);

		FVector4 QuadPositionData = RenderParams.QuadPositionData;
		FIntPoint BackBufferSize = ColorTarget->GetSizeXY();

		const FSlateClippingState* ClippingState = RenderParams.ClippingState;
		const FSlateClippingState* LastClippingState = nullptr;

		// Currently, SceneTextureForText for 3D widget is not supported.
		FVector2D ViewTranslation2D = FVector2D::ZeroVector;
		bool bSwitchVerticalAxis = RHINeedsToSwitchVerticalAxis(GShaderPlatformForFeatureLevel[GMaxRHIFeatureLevel]);

		FCopyRectParams RectParams;
		RectParams.SourceTexture = ColorTarget->GetTexture2D();
		RectParams.SourceRect = FSlateRect(0, 0, ColorTarget->GetSizeX(), ColorTarget->GetSizeY());
		RectParams.DestRect = FSlateRect(QuadPositionData.X, QuadPositionData.Y, QuadPositionData.Z, QuadPositionData.W);
		RectParams.SourceTextureSize = ColorTarget->GetSizeXY();

		RectParams.RestoreStateFunc = [&](FRHICommandListImmediate& InRHICmdList, FGraphicsPipelineStateInitializer& InGraphicsPSOInit) {
			return UpdateScissorRect(
				InRHICmdList,
				ClippingState,
				InGraphicsPSOInit,
				true);
		};

		RectParams.RestoreStateFuncPostPipelineState = [&]() {
			RHICmdList.SetStencilRef(0);
		};
		
		FSceneTextureForTextRenderer::Get().GetPostProcessor()->CopyRect(RHICmdList, RendererModule, RectParams);

		check(RHICmdList.IsOutsideRenderPass());
		// Render pass for slate elements will be restarted on a next loop iteration if any
	}

}



