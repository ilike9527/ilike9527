// Copyright Qibo Pang 2023. All Rights Reserved.

#include "MovieSceneWidgetSubSequenceSection.h"
#include "Logging/MessageLog.h"
#include "MovieScene.h"
#include "UObject/SequencerObjectVersion.h"
#include "MovieSceneTimeHelpers.h"
#include "MovieSceneWidgetSubSequenceTemplate.h"
#include "Animation/WidgetAnimation.h"
#include "Blueprint/UserWidget.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"

#if WITH_EDITOR
#include "Widgets/Notifications/SNotificationList.h"
#include "Framework/Notifications/NotificationManager.h"
#endif

#define LOCTEXT_NAMESPACE "MovieSceneWidgetSubSequenceSection"

namespace
{
	float WidgetSubSequenceMagicNumber = TNumericLimits<float>::Lowest();
}

FMovieSceneWidgetSubSequenceParams::FMovieSceneWidgetSubSequenceParams()
{
	PlayRate = 1.f;
}

UMovieSceneWidgetSubSequenceSection::UMovieSceneWidgetSubSequenceSection(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	BlendType = EMovieSceneBlendType::Absolute;
	EvalOptions.EnableAndSetCompletionMode(EMovieSceneCompletionMode::ProjectDefault);

#if WITH_EDITOR

	PreviousPlayRate = Params.PlayRate;

#endif
}

TOptional<FFrameTime> UMovieSceneWidgetSubSequenceSection::GetOffsetTime() const
{
	return TOptional<FFrameTime>(Params.FirstLoopStartFrameOffset);
}

void UMovieSceneWidgetSubSequenceSection::PostLoad()
{
	Super::PostLoad();

	UMovieScene* MovieSceneOuter = GetTypedOuter<UMovieScene>();

	if (!MovieSceneOuter)
	{
		return;
	}

	FFrameRate DisplayRate = MovieSceneOuter->GetDisplayRate();
	FFrameRate TickResolution = MovieSceneOuter->GetTickResolution();

}

void UMovieSceneWidgetSubSequenceSection::Serialize(FArchive& Ar)
{
	Ar.UsingCustomVersion(FSequencerObjectVersion::GUID);
	Super::Serialize(Ar);
}

FFrameNumber GetFirstLoopStartOffsetAtTrimTime(FQualifiedFrameTime TrimTime, const FMovieSceneWidgetSubSequenceParams& Params, FFrameNumber StartFrame, FFrameRate FrameRate)
{
	const float AnimPlayRate = FMath::IsNearlyZero(Params.PlayRate) ? 1.0f : Params.PlayRate;
	const float AnimPosition = (TrimTime.Time - StartFrame) / TrimTime.Rate * AnimPlayRate;
	const float SeqLength = Params.GetSequenceLength() - FrameRate.AsSeconds(Params.StartFrameOffset + Params.EndFrameOffset) / AnimPlayRate;

	FFrameNumber NewOffset = FrameRate.AsFrameNumber(FMath::Fmod(AnimPosition, SeqLength));
	NewOffset += Params.FirstLoopStartFrameOffset;

	const FFrameNumber SeqLengthInFrames = FrameRate.AsFrameNumber(SeqLength);
	NewOffset = NewOffset % SeqLengthInFrames;

	return NewOffset;
}


TOptional<TRange<FFrameNumber> > UMovieSceneWidgetSubSequenceSection::GetAutoSizeRange() const
{
	FFrameRate FrameRate = GetTypedOuter<UMovieScene>()->GetTickResolution();
	FFrameTime AnimationLength = Params.GetSequenceLength() * FrameRate;
	int32 IFrameNumber = AnimationLength.FrameNumber.Value + (int)(AnimationLength.GetSubFrame() + 0.5f);

	return TRange<FFrameNumber>(GetInclusiveStartFrame(), GetInclusiveStartFrame() + IFrameNumber + 1);
}


void UMovieSceneWidgetSubSequenceSection::TrimSection(FQualifiedFrameTime TrimTime, bool bTrimLeft, bool bDeleteKeys)
{
	SetFlags(RF_Transactional);

	if (TryModify())
	{
		/*if (Params.GetWidgetSubSequence())*/
		{
			if (bTrimLeft)
			{
				FFrameRate FrameRate = GetTypedOuter<UMovieScene>()->GetTickResolution();

			}
		}
	
		Super::TrimSection(TrimTime, bTrimLeft, bDeleteKeys);
	}
}

UMovieSceneSection* UMovieSceneWidgetSubSequenceSection::SplitSection(FQualifiedFrameTime SplitTime, bool bDeleteKeys)
{
	const FFrameNumber InitialFirstLoopStartFrameOffset = Params.FirstLoopStartFrameOffset;

	FFrameRate FrameRate = GetTypedOuter<UMovieScene>()->GetTickResolution();

	const FFrameNumber NewOffset = HasStartFrame() ? GetFirstLoopStartOffsetAtTrimTime(SplitTime, Params, GetInclusiveStartFrame(), FrameRate) : 0;

	UMovieSceneSection* NewSection = Super::SplitSection(SplitTime, bDeleteKeys);
	if (NewSection != nullptr)
	{
		UMovieSceneWidgetSubSequenceSection* NewGeometrySection = Cast<UMovieSceneWidgetSubSequenceSection>(NewSection);
		NewGeometrySection->Params.FirstLoopStartFrameOffset = NewOffset;
	}

	// Restore original offset modified by splitting
	Params.FirstLoopStartFrameOffset = InitialFirstLoopStartFrameOffset;

	return NewSection;
}


void UMovieSceneWidgetSubSequenceSection::GetSnapTimes(TArray<FFrameNumber>& OutSnapTimes, bool bGetSectionBorders) const
{
	Super::GetSnapTimes(OutSnapTimes, bGetSectionBorders);

	const FFrameRate   FrameRate = GetTypedOuter<UMovieScene>()->GetTickResolution();
	const FFrameNumber StartFrame = GetInclusiveStartFrame();
	const FFrameNumber EndFrame = GetExclusiveEndFrame() - 1; // -1 because we don't need to add the end frame twice

	const float AnimPlayRate = FMath::IsNearlyZero(Params.PlayRate) ? 1.0f : Params.PlayRate;
	const float SeqLengthSeconds = Params.GetSequenceLength() - FrameRate.AsSeconds(Params.StartFrameOffset + Params.EndFrameOffset) / AnimPlayRate;
	const float FirstLoopSeqLengthInSeconds = SeqLengthSeconds - FrameRate.AsSeconds(Params.FirstLoopStartFrameOffset) / AnimPlayRate;

	const FFrameTime SequenceFrameLength = SeqLengthSeconds * FrameRate;
	const FFrameTime FirstLoopSequenceFrameLength = FirstLoopSeqLengthInSeconds * FrameRate;
	if (SequenceFrameLength.FrameNumber > 1)
	{
		// Snap to the repeat times
		bool IsFirstLoop = true;
		FFrameTime CurrentTime = StartFrame;
		while (CurrentTime < EndFrame)
		{
			OutSnapTimes.Add(CurrentTime.FrameNumber);
			if (IsFirstLoop)
			{
				CurrentTime += FirstLoopSequenceFrameLength;
				IsFirstLoop = false;
			}
			else
			{
				CurrentTime += SequenceFrameLength;
			}
		}
	}
}

float UMovieSceneWidgetSubSequenceSection::MapTimeToAnimation(float ComponentDuration, FFrameTime InPosition, FFrameRate InFrameRate) const
{
	FMovieSceneWidgetSubSequenceSectionTemplateParameters TemplateParams(Params, GetInclusiveStartFrame(), GetExclusiveEndFrame());
	return TemplateParams.MapTimeToAnimation(ComponentDuration, InPosition, InFrameRate);
}


#if WITH_EDITOR
void UMovieSceneWidgetSubSequenceSection::PreEditChange(FProperty* PropertyAboutToChange)
{
	// Store the current play rate so that we can compute the amount to compensate the section end time when the play rate changes
	PreviousPlayRate = Params.PlayRate;
	PreviousAnimationName = Params.AnimationName;

	Super::PreEditChange(PropertyAboutToChange);
}

void PopNotification(const FText& NotificationMessage, SNotificationItem::ECompletionState State, float ExpireDuration)
{
	FNotificationInfo Info(NotificationMessage);
	Info.bFireAndForget = false;
	Info.bUseSuccessFailIcons = false;
	Info.bUseLargeFont = false;

	TSharedPtr<SNotificationItem> Notification = FSlateNotificationManager::Get().AddNotification(Info);
	if (Notification.IsValid())
	{
		Notification->SetCompletionState(State);

		if (ExpireDuration > 0.0f)
		{
			Notification->SetExpireDuration(ExpireDuration);
		}

		Notification->ExpireAndFadeout();
	}
}
void UMovieSceneWidgetSubSequenceSection::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	// Adjust the duration automatically if the play rate changes
	if (PropertyChangedEvent.Property != nullptr &&
		PropertyChangedEvent.Property->GetFName() == TEXT("AnimationName"))
	{
		if (Params.WidgetBPClass)
		{
			bool bFindMatchAnimation = false;
			for (int32 Index = 0; Index < Params.WidgetBPClass->Animations.Num(); Index++)
			{
				if (Params.WidgetBPClass->Animations[Index]->GetDisplayName().ToString() == Params.AnimationName)
				{
					Params.AnimationObjectName = Params.WidgetBPClass->Animations[Index]->GetName();
					bFindMatchAnimation = true; 
					break;
				}
			}

			if (!bFindMatchAnimation)
			{
				FText MessageText = (LOCTEXT("FindMatchAnimationFailed", "Failed to find match widget sub animation."));
				PopNotification(MessageText, SNotificationItem::ECompletionState::CS_Fail, 1.0f);

				Params.AnimationName = PreviousAnimationName;
			}
		}
	}
	else if (PropertyChangedEvent.Property != nullptr &&
		PropertyChangedEvent.Property->GetFName() == TEXT("PlayRate"))
	{

	}
	else if (PropertyChangedEvent.Property != nullptr &&
		(PropertyChangedEvent.Property->GetFName() == TEXT("StartFrameOffset")
		|| PropertyChangedEvent.Property->GetFName() == TEXT("EndFrameOffset")))
	{
		
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}
#endif

float FMovieSceneWidgetSubSequenceParams::GetSequenceLength() const
{
	return GetValidWidgetAnimation() != nullptr ? GetValidWidgetAnimation()->GetEndTime() : 0.f;
}

UWidgetAnimation* FMovieSceneWidgetSubSequenceParams::GetValidWidgetAnimation() const
{
	if (WidgetBPClass)
	{
		for (int32 Index = 0; Index < WidgetBPClass->Animations.Num(); Index++)
		{
			if (WidgetBPClass->Animations[Index]->GetName() == AnimationObjectName)
			{
				return WidgetBPClass->Animations[Index];
			}
		}
	}
	return nullptr;
}

#undef LOCTEXT_NAMESPACE 
