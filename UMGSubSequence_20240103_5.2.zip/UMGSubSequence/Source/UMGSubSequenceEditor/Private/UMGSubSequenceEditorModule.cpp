// Copyright Qibo Pang 2023. All Rights Reserved.


#include "UMGSubSequenceEditorModule.h"
#include "ISequencerModule.h"
#include "WidgetSubSequenceTrackEditor.h"

#define LOCTEXT_NAMESPACE "FUMGSubSequenceEditorModule"

void FUMGSubSequenceEditorModule::StartupModule()
{
	// Register with the sequencer module that we provide auto-key handlers.
	ISequencerModule& SequencerModule = FModuleManager::Get().LoadModuleChecked<ISequencerModule>("Sequencer");
	TrackEditorBindingHandle = SequencerModule.RegisterTrackEditor(FOnCreateTrackEditor::CreateStatic(&FWidgetSubSequenceTrackEditor::CreateTrackEditor));
}

void FUMGSubSequenceEditorModule::ShutdownModule()
{
	ISequencerModule* SequencerModulePtr = FModuleManager::Get().GetModulePtr<ISequencerModule>("Sequencer");
	if (SequencerModulePtr)
	{
		SequencerModulePtr->UnRegisterTrackEditor(TrackEditorBindingHandle);
	}

}


#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FUMGSubSequenceEditorModule, UMGSubSequenceEditor)
