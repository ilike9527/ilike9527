// Copyright Qibo Pang 2023. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Evaluation/MovieSceneEvalTemplate.h"
#include "MovieSceneWidgetSubSequenceSection.h"
#include "MovieSceneWidgetSubSequenceTemplate.generated.h"

USTRUCT()
struct FMovieSceneWidgetSubSequenceSectionTemplateParameters : public FMovieSceneWidgetSubSequenceParams
{
	GENERATED_BODY()

	FMovieSceneWidgetSubSequenceSectionTemplateParameters() {}
	FMovieSceneWidgetSubSequenceSectionTemplateParameters(const FMovieSceneWidgetSubSequenceParams& BaseParams, FFrameNumber InSectionStartTime, FFrameNumber InSectionEndTime)
		: FMovieSceneWidgetSubSequenceParams(BaseParams)
		, SectionStartTime(InSectionStartTime)
		, SectionEndTime(InSectionEndTime)
	{}

	float MapTimeToAnimation(float ComponentDuration, FFrameTime InPosition, FFrameRate InFrameRate) const;

	UPROPERTY()
	FFrameNumber SectionStartTime;

	UPROPERTY()
	FFrameNumber SectionEndTime;
};

USTRUCT()
struct FMovieSceneWidgetSubSequenceSectionTemplate : public FMovieSceneEvalTemplate
{
	GENERATED_BODY()

	FMovieSceneWidgetSubSequenceSectionTemplate() {}
	FMovieSceneWidgetSubSequenceSectionTemplate(const UMovieSceneWidgetSubSequenceSection& Section);

	virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }
	virtual void Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const override;

	UPROPERTY()
	FMovieSceneWidgetSubSequenceSectionTemplateParameters Params;

};
