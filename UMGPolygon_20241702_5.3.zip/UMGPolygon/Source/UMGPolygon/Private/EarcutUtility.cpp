// Copyright Qibo Pang. All Rights Reserved.

#include "EarcutUtility.h"
#include "earcut.hpp"

namespace mapbox {
namespace util {

template <>
struct nth<0, FVector2D> {
    inline static auto get(const FVector2D &t) {
        return t.X;
    };
};

template <>
struct nth<1, FVector2D> {
    inline static auto get(const FVector2D &t) {
        return t.Y;
    };
};

} // namespace util
} // namespace mapbox

void FECUtils::Earcut(const FECPolygon& Polygon, TArray<int32>& OutIndices, bool bInversed)
{
    mapbox::detail::Earcut<int32> ECImpl;
    ECImpl(Polygon);

    const std::vector<int32>& ECIndices(ECImpl.indices);
    const int32 IndexCount = ECIndices.size();
    const int32 TriCount = IndexCount / 3;

    // Copy result

    OutIndices.SetNumUninitialized(IndexCount);

    if (bInversed)
    {
        FMemory::Memcpy(OutIndices.GetData(), ECIndices.data(), ECIndices.size() * sizeof(int32));
    }
    else
    {
        for (int32 ti=0; ti<TriCount; ++ti)
        {
            const int32 i = ti*3;
            OutIndices[i  ] = ECIndices[i+2];
            OutIndices[i+1] = ECIndices[i+1];
            OutIndices[i+2] = ECIndices[i  ];
        }
    }
}
