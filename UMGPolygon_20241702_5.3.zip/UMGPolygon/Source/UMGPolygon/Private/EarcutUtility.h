////////////////////////////////////////////////////////////////////////////////
//
// Copyright Qibo Pang. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include <vector>

struct FECPointContainer
{
    typedef FVector2D          value_type;
    typedef TArray<value_type> container_type;

    container_type Data;

    FECPointContainer() = default;

    FECPointContainer(const container_type& InPoints)
        : Data(InPoints)
    {
    }

    SIZE_T size() const
    {
        return Data.Num();
    }

    bool empty() const
    {
        return Data.Num() == 0;
    }

    const FVector2D& operator[](SIZE_T Index) const
    {
        return Data[Index];
    }
};

struct FECPolygon
{

    TArray<FECPointContainer> Data;

    FECPolygon() {}

    FECPolygon(const TArray<FECPointContainer>& InPolygon)
        : Data(InPolygon)
    {
    }

    SIZE_T size() const
    {
        return Data.Num();
    }

    bool empty() const
    {
        return Data.Num() == 0;
    }

    FECPointContainer& operator[](SIZE_T i)
    {
        return Data[i];
    }

    const FECPointContainer& operator[](SIZE_T i) const
    {
        return Data[i];
    }
};

class FECUtils
{
public:

    static void Earcut(const FECPolygon& Polygon, TArray<int32>& OutIndices, bool bInversed = false);

    FORCEINLINE static void Earcut(const TArray<FVector2D>& Points, TArray<int32>& OutIndices, bool bInversed = false)
    {
        TArray<FECPointContainer> PointContainer = { FECPointContainer(Points) };

        Earcut(FECPolygon(PointContainer), OutIndices, bInversed);
    }
};
