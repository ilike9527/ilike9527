// Copyright Qibo Pang 2023. All Rights Reserved.

using UnrealBuildTool;

public class GeometryCacheDecalEditor : ModuleRules
{
	public GeometryCacheDecalEditor(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		
		PublicIncludePaths.AddRange(
			new string[] {
				// ... add public include paths required here ...
			}
			);
				
		
		PrivateIncludePaths.AddRange(
			new string[] {
				// ... add other private include paths required here ...
			}
			);
			
		
		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				// ... add other public dependencies that you statically link with here ...
			}
			);
			
		
		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"CoreUObject",
				"Engine",
				"Slate",
				"SlateCore",
				"GeometryCacheDecal",
				"EditorStyle",
				// ... add private dependencies that you statically link with here ...	
			}
			);
        //  4.23+
        if (Target.Type == TargetRules.TargetType.Editor)
        {
            PrivateDependencyModuleNames.AddRange(
				new string[]
				{  
					"BlueprintGraph",
					"KismetCompiler",
					"GraphEditor",
					"UnrealEd",
					"Kismet",
					"ToolMenus",
				}
			);
        }

        DynamicallyLoadedModuleNames.AddRange(
			new string[]
				{
					// ... add any modules that your module loads dynamically here ...
				}
			);
	}
}
