// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

#include "Modules/ModuleManager.h"

class FSceneTextureForUMGModule : public IModuleInterface
{
public:

	static inline FSceneTextureForUMGModule& Get()
	{
		return FModuleManager::LoadModuleChecked<FSceneTextureForUMGModule>("SceneTextureForUMG");
	}

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	void RegisterSettings();
	void UnregisterSettings();

private:

	bool bSettingRegistered = false;
};
