// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

// Core
#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"

// Misc
#include "SFinalColorRecorder.h"

// Generated.h
#include "FinalColorRecorder.generated.h"

DECLARE_MULTICAST_DELEGATE(FOnSTRecorderDestructEvent);
DECLARE_MULTICAST_DELEGATE(FOnSTRecorderTickEvent);

/**
*/
UCLASS(meta=(DisplayName="FinalColorRecorder"))
class UFinalColorRecorder final : public UUserWidget
{
	GENERATED_UCLASS_BODY()

public:

	FOnSTRecorderDestructEvent DestructEvent;
	FOnSTRecorderTickEvent TickEvent;

protected:
	
	virtual TSharedRef<SWidget> RebuildWidget() override;

	// Destroy the widget
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;

	virtual void NativeDestruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

protected:
	TSharedPtr<class SFinalColorRecorder> MyFinalColorRecorder;
};
