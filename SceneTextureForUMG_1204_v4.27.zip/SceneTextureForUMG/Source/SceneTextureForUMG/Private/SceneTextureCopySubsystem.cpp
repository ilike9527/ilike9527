// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SceneTextureCopySubsystem.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"
#include "SceneViewExtension.h"
#include "SceneTextureCopySceneViewExtension.h"
#include "SceneTextureForUMGRenderer.h"
#include "SceneTextureForUMGModule.h"
#include "SceneTextureForUMGSettings.h"

void USceneTextureCopySubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	// Initializing Scene view extension responsible for rendering regions.
	PostProcessSceneViewExtension = FSceneViewExtensions::NewExtension<FSceneTextureCopySceneViewExtension>(this);

	FSceneTextureForUMGModule::Get().RegisterSettings();
	FSceneTextureForUMGRenderer::Get().InitRenderResources();
}

void USceneTextureCopySubsystem::Deinitialize()
{
	//
	ENQUEUE_RENDER_COMMAND(SafeDeleteFinalColorDrawer)(
		[PostProcessSceneViewExtension = PostProcessSceneViewExtension](FRHICommandListImmediate& RHICmdList) mutable
		{
			PostProcessSceneViewExtension->ReleasePooledTextures();
			PostProcessSceneViewExtension.Reset();
		}
	);
	PostProcessSceneViewExtension = nullptr;
#if WITH_EDITOR
#else
	FSceneTextureForUMGRenderer::Get().ReleaseRenderResources();
#endif
}

TStatId USceneTextureCopySubsystem::GetStatId() const
{
	RETURN_QUICK_DECLARE_CYCLE_STAT(USceneTextureCopySubsystem, STATGROUP_Tickables);
}

bool USceneTextureCopySubsystem::IsTickable() const
{
	return !bFinalColorRecorderInited;
}

void USceneTextureCopySubsystem::Tick(float DeltaTime)
{
	if (!bFinalColorRecorderInited)
	{
		bFinalColorRecorderInited = true;

		if (USceneTextureForUMGSettings::GetInstance()->EnableFinalColor)
		{
			FSceneTextureForUMGRenderer::Get().InitFinalColorRecorder(GetWorld());
		}
	}
}