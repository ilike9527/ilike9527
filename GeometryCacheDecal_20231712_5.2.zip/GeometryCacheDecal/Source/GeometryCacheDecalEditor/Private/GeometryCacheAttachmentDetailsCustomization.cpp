// Copyright Qibo Pang 2023. All Rights Reserved.

#include "GeometryCacheDecalDetailsCustomization.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "EditorModeManager.h"

#include "PropertyHandle.h"
#include "DetailLayoutBuilder.h"
#include "DetailWidgetRow.h"
#include "IDetailPropertyRow.h"
#include "DetailCategoryBuilder.h"

#define LOCTEXT_NAMESPACE "GeometryCacheDecal"

//////////////////////////////////////////////////////////////////////////
// FGeometryCacheDecalDetailsCustomization

TSharedRef<IDetailCustomization> FGeometryCacheDecalDetailsCustomization::MakeInstance()
{
	return MakeShareable(new FGeometryCacheDecalDetailsCustomization);
}

void FGeometryCacheDecalDetailsCustomization::CustomizeDetails(IDetailLayoutBuilder& DetailLayout)
{
	const TArray< TWeakObjectPtr<UObject> >& SelectedObjects = DetailLayout.GetSelectedObjects();
	if (SelectedObjects.Num() != 1)
	{
		return;
	}
	
	UGeometryCacheDecalComponent* GeometryCacheDecalComponent = nullptr;
	for (int32 ObjectIndex = 0; ObjectIndex < SelectedObjects.Num(); ++ObjectIndex)
	{
		UObject* TestObject = SelectedObjects[ObjectIndex].Get();
		if (UGeometryCacheDecalComponent* TestGeometryCacheDecalComponent = Cast<UGeometryCacheDecalComponent>(TestObject))
		{
			GeometryCacheDecalComponent = TestGeometryCacheDecalComponent;
			break;
		}
	}

	if (!GeometryCacheDecalComponent)
	{
		return;
	}

	GeometryCacheDecalComponentPtr = GeometryCacheDecalComponent;

	//DetailLayout.HideCategory(TEXT("Transform"));
	DetailLayout.HideCategory(TEXT("Collision"));
	DetailLayout.HideCategory(TEXT("Physics"));
	DetailLayout.HideCategory(TEXT("Lighting"));
	DetailLayout.HideCategory(TEXT("Rendering"));
	DetailLayout.HideCategory(TEXT("Navigation"));
	DetailLayout.HideCategory(TEXT("Tags"));
	DetailLayout.HideCategory(TEXT("Activation"));
	DetailLayout.HideCategory(TEXT("Cooking"));
	DetailLayout.HideCategory(TEXT("HLOD"));
	DetailLayout.HideCategory(TEXT("LOD"));
	DetailLayout.HideCategory(TEXT("Mobile"));
	DetailLayout.HideCategory(TEXT("AssetUserData"));

	MyDetailLayout = &DetailLayout;

	DecalTypeHandle = DetailLayout.GetProperty(GET_MEMBER_NAME_CHECKED(UGeometryCacheDecalComponent, DecalType));

	TAttribute<EVisibility> DecalTypeUVRegionVisibility(this, &FGeometryCacheDecalDetailsCustomization::VisibilityForDecalTypeUVRegion);
	DetailLayout.EditDefaultProperty(DetailLayout.GetProperty(GET_MEMBER_NAME_CHECKED(UGeometryCacheDecalComponent, DecalUVInfo)))->Visibility(DecalTypeUVRegionVisibility);

	TAttribute<EVisibility> DecalTypeBoxRegionVisibility(this, &FGeometryCacheDecalDetailsCustomization::VisibilityForDecalTypeBoxRegion);
	DetailLayout.EditDefaultProperty(DetailLayout.GetProperty(GET_MEMBER_NAME_CHECKED(UGeometryCacheDecalComponent, DecalBoxInfo)))->Visibility(DecalTypeBoxRegionVisibility);

}

EVisibility FGeometryCacheDecalDetailsCustomization::VisibilityForDecalType(EGeometryCacheDecalType DecalType) const
{
	uint8 DecalTypeValue = 0;
	FPropertyAccess::Result Ret = DecalTypeHandle.Get()->GetValue(DecalTypeValue);
	if (Ret == FPropertyAccess::Result::Success)
	{
		return (DecalTypeValue == (uint8)DecalType) ? EVisibility::Visible : EVisibility::Hidden;
	}
	return  EVisibility::Hidden;
}

//////////////////////////////////////////////////////////////////////////

#undef LOCTEXT_NAMESPACE
