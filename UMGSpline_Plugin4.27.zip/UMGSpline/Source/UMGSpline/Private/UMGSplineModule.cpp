// Copyright Qibo Pang 2022. All Rights Reserved.


#include "UMGSplineModule.h"

#define LOCTEXT_NAMESPACE "FUMGSplineModule"

void FUMGSplineModule::StartupModule()
{
	
}

void FUMGSplineModule::ShutdownModule()
{
	
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FUMGSplineModule, UMGSpline)