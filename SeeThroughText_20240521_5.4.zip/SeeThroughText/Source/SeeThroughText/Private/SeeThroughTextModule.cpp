// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SeeThroughTextModule.h"
#include "Interfaces/IPluginManager.h"
#include "Misc/Paths.h"
#include "ShaderCore.h"
#include "Render/SceneTextureForTextRenderer.h"

#define LOCTEXT_NAMESPACE "FSeeThroughTextModule"

void FSeeThroughTextModule::StartupModule()
{
	FString PluginShaderDir = FPaths::Combine(IPluginManager::Get().FindPlugin(TEXT("SeeThroughText"))->GetBaseDir(), TEXT("Shaders"));
	AddShaderSourceDirectoryMapping(TEXT("/Plugin/SeeThroughText"), PluginShaderDir);
}

void FSeeThroughTextModule::ShutdownModule()
{
	;
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FSeeThroughTextModule, SeeThroughText)