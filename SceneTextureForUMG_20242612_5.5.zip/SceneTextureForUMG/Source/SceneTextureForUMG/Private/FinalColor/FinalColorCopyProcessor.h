// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

#include "Layout/SlateRect.h"
#include "Layout/Clipping.h"
#include "ScreenPass.h"

class UTexture;
class UTextureRenderTarget2D;
class IRendererModule;

struct FSlateClippingOp
{
	union
	{
		struct
		{
			FSlateRect Rect;
		} Data_Scissor;

		struct
		{
			TConstArrayView<FSlateClippingZone> Zones;
		} Data_Stencil;
	};

	FVector2f Offset;
	EClippingMethod Method;
	uint8 MaskingId;

	static inline FSlateClippingOp* Scissor(FRDGBuilder& GraphBuilder, FVector2f Offset, FSlateRect Rect)
	{
		FSlateClippingOp* Op = GraphBuilder.AllocPOD<FSlateClippingOp>();
		Op->Data_Scissor.Rect = Rect;
		Op->Offset = Offset;
		Op->Method = EClippingMethod::Scissor;
		Op->MaskingId = 0;
		return Op;
	}

	static inline FSlateClippingOp* Stencil(FRDGBuilder& GraphBuilder, FVector2f Offset, TConstArrayView<FSlateClippingZone> Zones, int32 MaskingId)
	{
		FSlateClippingOp* Op = GraphBuilder.AllocPOD<FSlateClippingOp>();
		Op->Data_Stencil.Zones = Zones;
		Op->Offset = Offset;
		Op->Method = EClippingMethod::Stencil;
		Op->MaskingId = MaskingId;
		return Op;
	}
};

struct FCopyRectParams
{
	FTexture2DRHIRef SourceTexture;
	FSlateRect SourceRect;
	FSlateRect DestRect;
	FIntPoint SourceTextureSize;
	TFunction<void(FRHICommandListImmediate&, FGraphicsPipelineStateInitializer&)> RestoreStateFunc;
	TFunction<void()> RestoreStateFuncPostPipelineState;
};

struct FSlateCopyRectPassInputs
{
	FRDGTexture* InputTexture;
	FRDGTexture* OutputTexture;

	FIntRect InputRect;

	const FSlateClippingOp* ClippingOp = nullptr;
	const FDepthStencilBinding* ClippingStencilBinding = nullptr;
	FIntRect ClippingElementsViewRect;
};

class FFinalColorCopyProcessor
{
public:
	FFinalColorCopyProcessor();
	~FFinalColorCopyProcessor();

	void CopyRect(FRDGBuilder& GraphBuilder, const FSlateCopyRectPassInputs& Inputs);

	void SetRenderTarget(UTextureRenderTarget2D* InRenderTarget) { RenderTarget = InRenderTarget; }
	
	UTexture* GetSceneTexture();

	FVector4 GetViewportTransform() { return Viewport_Transform; }

private:

	TRefCountPtr<IPooledRenderTarget> CopyPooledTexture = nullptr;

	UTextureRenderTarget2D* RenderTarget;

	FIntPoint RenderTargetSize = FIntPoint(100, 100);

	FVector4 Viewport_Transform;
};