// Copyright Qibo Pang 2022. All Rights Reserved.

#include "FinalColorDrawer.h"
#include "RenderingThread.h"
#include "UnrealClient.h"
#include "Engine/Engine.h"
#include "Engine/Texture.h"
#include "EngineModule.h"
#include "Framework/Application/SlateApplication.h"
#include "FinalColorCopyProcessor.h"
#include "SceneTextureCopyMaterial.h"
#include "SceneTextureForUMGRenderer.h"
#include "TextureResource.h"

#define INVALID_LAYER_ID UINT_MAX

static const FName RendererModuleName("Renderer");

FFinalColorDrawer::FFinalColorDrawer()
{
	
}

FFinalColorDrawer::~FFinalColorDrawer()
{
	if (CopyPooledTexture)
	{
		CopyPooledTexture.SafeRelease();
		CopyPooledTexture = nullptr;
	}
}

static bool ShouldCullWidget(const FSlateWindowElementList& ElementList)
{
	const FSlateClippingManager& ClippingManager = ElementList.GetClippingManager();
	const int32 CurrentIndex = ClippingManager.GetClippingIndex();
	if (CurrentIndex != INDEX_NONE)
	{
		const FSlateClippingState& ClippingState = ClippingManager.GetClippingStates()[CurrentIndex];
		return ClippingState.HasZeroArea();
	}

	return false;
}

bool FFinalColorDrawer::InitializeSceneTextureForTextParams(FSlateWindowElementList& ElementList, uint32 InLayer, const FPaintGeometry& PaintGeometry)
{
	PaintGeometry.CommitTransformsIfUsingLegacyConstructor();

	if (ShouldCullWidget(ElementList))
	{
		return false;
	}

	const FSlateRenderTransform& RenderTransform = PaintGeometry.GetAccumulatedRenderTransform();
	const FVector2D& LocalSize = PaintGeometry.GetLocalSize();

	const int32 Layer = InLayer;

	// Determine the four corners of the quad
	FVector2D TopLeft = FVector2D::ZeroVector;
	FVector2D TopRight = FVector2D(LocalSize.X, 0);
	FVector2D BotLeft = FVector2D(0, LocalSize.Y);
	FVector2D BotRight = FVector2D(LocalSize.X, LocalSize.Y);

	FVector2D WorldTopLeft = TransformPoint(RenderTransform, TopLeft).RoundToVector();
	FVector2D WorldBotRight = TransformPoint(RenderTransform, BotRight).RoundToVector();

	FVector2D WindowSize = ElementList.GetPaintWindow()->GetViewportSize();;
	FVector2D SizeUV = (WorldBotRight - WorldTopLeft) / WindowSize;

	const FSlateClippingState* ClipState = ResolveClippingState(ElementList);


	// These could be negative with rotation or negative scales.  This is not supported yet
	if (SizeUV.X > 0 && SizeUV.Y > 0)
	{
		RenderParams.QuadPositionData = FVector4(WorldTopLeft, WorldBotRight);
		RenderParams.ClippingState = ClipState;
		RenderParams.ViewportSize = WindowSize;
		return true;
	}

	return false;
}

const FSlateClippingState* FFinalColorDrawer::ResolveClippingState(FSlateWindowElementList& ElementList) const
{
	FClipStateHandle ClipHandle;
	ClipHandle.SetPreCachedClipIndex(ElementList.GetClippingIndex());

	const TArray<FSlateClippingState>* PrecachedClippingStates = &ElementList.GetClippingManager().GetClippingStates();

	// Do cached first
	if (ClipHandle.GetCachedClipState())
	{
		// We should be working with cached elements if we have a cached clip state
		//check(ElementList);
		return ClipHandle.GetCachedClipState();
	}
	else if (PrecachedClippingStates->IsValidIndex(ClipHandle.GetPrecachedClipIndex()))
	{
		// Store the clipping state so we can use it later for rendering.
		return &(*PrecachedClippingStates)[ClipHandle.GetPrecachedClipIndex()];
	}

	return nullptr;
}

enum class ESlateClippingStencilAction : uint8
{
	None,
	Write,
	Clear
};

struct FSlateClippingCreateContext
{
	uint32 NumStencils = 0;
	uint32 NumScissors = 0;
	uint32 MaskingId = 0;
	ESlateClippingStencilAction StencilAction = ESlateClippingStencilAction::None;
};

const FSlateClippingOp* CreateSlateClipping(FRDGBuilder& GraphBuilder, const FVector2f ElementsOffset, const FSlateClippingState* ClippingState, FSlateClippingCreateContext& Context)
{
	Context.StencilAction = ESlateClippingStencilAction::None;

	if (ClippingState)
	{
		if (ClippingState->GetClippingMethod() == EClippingMethod::Scissor)
		{
			Context.NumScissors++;

			const FSlateClippingZone& ScissorRect = ClippingState->ScissorRect.GetValue();

			return FSlateClippingOp::Scissor(GraphBuilder, ElementsOffset, FSlateRect(ScissorRect.TopLeft.X, ScissorRect.TopLeft.Y, ScissorRect.BottomRight.X, ScissorRect.BottomRight.Y));
		}
		else
		{
			Context.NumStencils++;

			TConstArrayView<FSlateClippingZone> StencilQuads = ClippingState->StencilQuads;
			check(StencilQuads.Num() > 0);

			// Reset the masking ID back to zero if stencil is going to overflow.
			if (Context.MaskingId + StencilQuads.Num() > 255)
			{
				Context.MaskingId = 0;
			}

			// Mark stencil for clear when the masking id is 0.
			Context.StencilAction = Context.MaskingId == 0 ? ESlateClippingStencilAction::Clear : ESlateClippingStencilAction::Write;

			const FSlateClippingOp* Op = FSlateClippingOp::Stencil(GraphBuilder, ElementsOffset, StencilQuads, Context.MaskingId);
			Context.MaskingId += StencilQuads.Num();
			return Op;
		}
	}
	return nullptr;
}


void FFinalColorDrawer::Draw_RenderThread(FRDGBuilder& GraphBuilder, const FDrawPassInputs& Inputs)
{
	if (!TStaticDepthStencilState<false, CF_Always>::GetRHI())
	{
		return;
	}
	
	// Provided output texture is actually the input into our custom post process texture.
	const FScreenPassTexture InputTexture(Inputs.OutputTexture, Inputs.SceneViewRect);

	FSlateClippingCreateContext Context;
	FVector2f ElementsOffset = Inputs.ElementsOffset;
	const FSlateClippingOp* ClippingOp = CreateSlateClipping(GraphBuilder, ElementsOffset, RenderParams.ClippingState, Context);

	{
		FVector4 QuadPositionData = RenderParams.QuadPositionData;
		FSlateCopyRectPassInputs CopyInputs;
		CopyInputs.InputRect = FIntRect(QuadPositionData.X, QuadPositionData.Y, QuadPositionData.Z, QuadPositionData.W);
		CopyInputs.InputTexture = Inputs.OutputTexture;

		CopyInputs.ClippingOp = ClippingOp;
		CopyInputs.ClippingElementsViewRect = CopyInputs.InputRect;

		UTexture* OutputTexture = FSceneTextureForUMGRenderer::Get().GetFinalColorCopyProcessor()->GetSceneTexture();
		FTextureResource* CopyTextureResource;
		if (OutputTexture)
		{
			CopyTextureResource = OutputTexture->GetResource();
		}
		else
		{
			CopyTextureResource = nullptr;
		}
		
		if (CopyTextureResource)
		{
			bool bInitTexture = CopyPooledTexture == nullptr;

			if (/*(CachedCopyTextureResource != CopyTextureResource
				|| QuadPositionData != CachedQuadPositionData) && */CopyPooledTexture)
			{
				CopyPooledTexture.SafeRelease();
				CopyPooledTexture = nullptr;
			}

			if (!CopyPooledTexture)
			{
				/*if (!bInitTexture)
				{
					CachedQuadPositionData = QuadPositionData;
					CachedCopyTextureResource = CopyTextureResource;
				}*/
				CopyPooledTexture = CreateRenderTarget(CopyTextureResource->TextureRHI, TEXT("SlateCopyTexture"));
			}
			CopyInputs.OutputTexture = GraphBuilder.RegisterExternalTexture(CopyPooledTexture);
		}

		if (CopyInputs.OutputTexture)
		{
			FSceneTextureForUMGRenderer::Get().GetFinalColorCopyProcessor()->CopyRect(GraphBuilder, CopyInputs);
		}
	}
}



