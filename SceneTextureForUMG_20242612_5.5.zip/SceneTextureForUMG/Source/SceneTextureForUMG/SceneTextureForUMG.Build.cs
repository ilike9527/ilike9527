// Copyright Qibo Pang 2022. All Rights Reserved.

using System.IO;
using UnrealBuildTool;

public class SceneTextureForUMG : ModuleRules
{
	public SceneTextureForUMG(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicIncludePaths.Add(Path.Combine(ModuleDirectory, "Public"));
        PrivateIncludePaths.Add(Path.Combine(ModuleDirectory, "Private"));

        var EngineDir = Path.GetFullPath(Target.RelativeEnginePath);

		PrivateIncludePaths.AddRange(
			new string[] {
				Path.Combine(EngineDir, "Source/Runtime/Engine"),
				Path.Combine(EngineDir, "Source/Runtime/RHI"),
				Path.Combine(EngineDir, "Source/Runtime/Renderer/Private")
			}
		);

		PublicDependencyModuleNames.AddRange(new string[]
			{
				"Core",
				"CoreUObject",
				"Engine",
				"InputCore",
				"Projects",
				"Slate",
				"SlateCore"
			});

		PrivateDependencyModuleNames.AddRange(new string[]
			{
				"UMG",
				"Renderer",
				"RenderCore",
				"SlateRHIRenderer",
				"RHI",
				"RHICore",
				"MovieSceneCapture",
				"Projects",
				"DeveloperSettings"
			});

		if (Target.Type == TargetType.Editor)
		{
			PublicDependencyModuleNames.Add("UnrealEd");
			PrivateDependencyModuleNames.AddRange(
				new string[]
				{
					"UnrealEd"
				});
		}

		DynamicallyLoadedModuleNames.AddRange(
			new string[]
			{
			}
		);

		if (Target.Type == TargetRules.TargetType.Editor)
		{
			PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"Settings"
			}
			);
		}
	}
}
