// Copyright Qibo Pang 2023. All Rights Reserved.
#include "GeometryCacheToVATNotification.h"

#define LOCTEXT_NAMESPACE "GeometryCacheToVATNotification"

TSharedPtr<SNotificationItem> FGeometryCacheToVATNotification::GeometryCacheToVATNotification = nullptr;

void FGeometryCacheToVATNotification::PopOnce(const FText& NotificationMessage, SNotificationItem::ECompletionState State, float ExpireDuration)
{
	if (!IsInGameThread())
	{
		return;
	}

#if WITH_EDITOR
	FNotificationInfo Info(NotificationMessage);
	Info.bFireAndForget = false;
	Info.bUseSuccessFailIcons = false;
	Info.bUseLargeFont = false;
	
	TSharedPtr<SNotificationItem> Notification = FSlateNotificationManager::Get().AddNotification(Info);
	if (Notification.IsValid())
	{
		Notification->SetCompletionState(State);

		if (ExpireDuration > 0.0f)
		{
			Notification->SetExpireDuration(ExpireDuration);
		}

		Notification->ExpireAndFadeout();
	}
#endif
}

void FGeometryCacheToVATNotification::PopPending(const FText& NotificationMessage, SNotificationItem::ECompletionState State)
{
#if WITH_EDITOR
	TSharedPtr<SNotificationItem> Notification = GetValidNotification();
	if (Notification.IsValid())
	{
		Notification->SetText(NotificationMessage);
		Notification->SetCompletionState(State);
	}
#endif
}

void FGeometryCacheToVATNotification::PendingNotificationFadeout(float ExpireDuration)
{
	if (GeometryCacheToVATNotification.IsValid())
	{
		if (ExpireDuration > 0.0f)
		{
			GeometryCacheToVATNotification->SetExpireDuration(ExpireDuration);
		}
		GeometryCacheToVATNotification->ExpireAndFadeout();
		GeometryCacheToVATNotification = nullptr;
	}
}


void FGeometryCacheToVATNotification::PopPending(TSharedPtr<SNotificationItem>& NotificationItem, const FText& NotificationMessage, SNotificationItem::ECompletionState State)
{
#if WITH_EDITOR
	if (!NotificationItem.IsValid())
	{
		FNotificationInfo Info(NotificationMessage);
		Info.bFireAndForget = false;
		Info.bUseSuccessFailIcons = false;
		Info.bUseLargeFont = false;
		Info.FadeInDuration = 0.0f;

		NotificationItem = FSlateNotificationManager::Get().AddNotification(Info);
	}

	if (NotificationItem.IsValid())
	{
		NotificationItem->SetText(NotificationMessage);
		NotificationItem->SetCompletionState(State);
	}
#endif
}

void FGeometryCacheToVATNotification::PendingNotificationFadeout(TSharedPtr<SNotificationItem>& NotificationItem, float ExpireDuration, float FadeOutDuration)
{
	if (NotificationItem.IsValid())
	{
		if (ExpireDuration > 0.0f)
		{
			NotificationItem->SetExpireDuration(ExpireDuration);
		}

		if (FadeOutDuration > 0.0f)
		{
			NotificationItem->SetFadeOutDuration(FadeOutDuration);
		}

		NotificationItem->ExpireAndFadeout();
		NotificationItem = nullptr;
	}
}

TSharedPtr<SNotificationItem> FGeometryCacheToVATNotification::GetValidNotification()
{
	// Display a progress notification when record stream
	if (GeometryCacheToVATNotification && GeometryCacheToVATNotification.IsValid())
	{
		return GeometryCacheToVATNotification;
	}

	FText UpdateText = LOCTEXT("GeometryCacheGeometryCacheNotification", "Start record notification");
	FNotificationInfo Info(UpdateText);
	Info.bFireAndForget = false;
	Info.bUseSuccessFailIcons = false;
	Info.bUseLargeFont = false;
	Info.FadeInDuration = 0.0f;

	GeometryCacheToVATNotification = FSlateNotificationManager::Get().AddNotification(Info);
	if (GeometryCacheToVATNotification.IsValid())
	{
		GeometryCacheToVATNotification->SetCompletionState(SNotificationItem::CS_Pending);
	}

	return GeometryCacheToVATNotification;
}

void FGeometryCacheToVATNotification::PopConfirm(TSharedPtr<SNotificationItem>& NotificationItem, const FText& NotificationMessage, TFunction<void()> ConfirmCallback, TFunction<void()> CancelCallback)
{
	if (!IsInGameThread())
	{
		return;
	}

#if WITH_EDITOR
	FNotificationInfo Info(NotificationMessage);
	Info.bFireAndForget = false;
	Info.bUseSuccessFailIcons = false;
	Info.bUseLargeFont = false;

	if (ConfirmCallback)
	{
		const FText CancelConfigText = LOCTEXT("GeometryCacheConfirmText", "Yes");
		FSimpleDelegate OnConfirm = FSimpleDelegate::CreateLambda([ConfirmCallback]() 
			{ 
				ConfirmCallback(); 
			});
		Info.ButtonDetails.Add(FNotificationButtonInfo(CancelConfigText, FText(), OnConfirm, SNotificationItem::CS_None));
	}
	
	if (CancelCallback)
	{
		const FText CancelConfigText = LOCTEXT("GeometryCacheCancelText", "No");
		FSimpleDelegate OnCancel = FSimpleDelegate::CreateLambda([CancelCallback]()
			{ 
				CancelCallback(); 
			});
		Info.ButtonDetails.Add(FNotificationButtonInfo(CancelConfigText, FText(), OnCancel, SNotificationItem::CS_None));
	}

	NotificationItem = FSlateNotificationManager::Get().AddNotification(Info);

#endif
}

#undef LOCTEXT_NAMESPACE