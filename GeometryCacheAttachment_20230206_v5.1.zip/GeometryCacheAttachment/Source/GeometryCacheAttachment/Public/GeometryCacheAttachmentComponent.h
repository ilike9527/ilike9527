// Copyright Qibo Pang 2023. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Components/SceneComponent.h"
#include "PhysicsEngine/ConvexElem.h"
#include "Interfaces/Interface_CollisionDataProvider.h"
#include "GeometryCacheMeshData.h"
#include "PrimitiveSceneProxy.h"

#include "DynamicMesh/DynamicMesh3.h"
#include "DynamicMesh/DynamicMeshAABBTree3.h"

#include "GeometryCacheAttachmentComponent.generated.h"

class UGeometryCacheComponent;
class UGeometryCache;
class FGeomCacheTrackProxy;
class FGeometryCacheSceneProxy;

DECLARE_DYNAMIC_DELEGATE_TwoParams(FLineTraceAttachFinishedEvent, bool, bSuccess, const FString&, Message);

UENUM(BlueprintType)
enum class EGeometryCacheAttachType : uint8
{

	AttachToNearestDistance UMETA(DisplayName = "AttachToNearestDistance"),

	AttachToZDirectionHit UMETA(DisplayName = "AttachToZDirectionHit")
};

USTRUCT()
struct FGeometryCacheParentStatus
{
	GENERATED_USTRUCT_BODY()

	UGeometryCacheComponent* GeometryCacheComponent = nullptr;

	UGeometryCache* GeometryCache = nullptr;
	
	FGeometryCacheSceneProxy* GeometryCacheSceneProxy = nullptr;

	bool bStatusReseted = false;

	FGeometryCacheParentStatus() = default;

	FGeometryCacheParentStatus(UGeometryCacheComponent* InGeometryCacheComponent);

	bool IsValid()
	{
		return GeometryCacheComponent && GeometryCache && GeometryCacheSceneProxy;
	}

	bool ResetWhenChanged();

	void Clear()
	{
		GeometryCacheComponent = nullptr;
		GeometryCache = nullptr;
		GeometryCacheSceneProxy = nullptr;
		AnimationTime = -1.0f;
		bStatusReseted = true;
	}

	bool CheckStatusChanged();

	bool TracksInited();

private:

	float AnimationTime = -1.0f;
};

USTRUCT(BlueprintType)
struct FGeometryCacheAttachLocation
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheAttachment")
		int32 TrackIndex = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheAttachment")
		int32 TriangleIndex = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheAttachment")
		FVector BaryCentric;
};


USTRUCT()
struct FGeometryCacheAttachedElement
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(VisibleAnywhere, Category = "GeometryCacheAttachment")
		USceneComponent* ElementComponent;

	UPROPERTY(VisibleAnywhere, Category = "GeometryCacheAttachment")
		FGeometryCacheAttachLocation AttachLocation;

	UPROPERTY()
		FVector RelativePosition;

	UPROPERTY()
		FQuat RelativeQuat;

	UPROPERTY()
		FTransform RelativeTransform;

	UPROPERTY()
		FTransform OrgAttachTransform;

	UPROPERTY()
		FVector2f OrgAttachUV;

	UPROPERTY()
		int32 FrameIndex = -1;
};

USTRUCT(BlueprintType)
struct FGeometryCacheLineTraceResult
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheAttachment")
		int32 TrackIndex = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheAttachment")
		int32 TriangleIndex = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheAttachment")
		FVector BaryCentric;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheAttachment")
		float NearestDistance = 0.0f;
};

USTRUCT()
struct FGeometryCacheAttachedTriangle
{
	GENERATED_USTRUCT_BODY()

	FGeometryCacheAttachedTriangle() {}

	FGeometryCacheAttachLocation AttachLocation;

	FVector3f AttachPosition;

	FVector3f AttachNormal;

	FTransform AttachTransform;

	FVector2f AttachUV;

	int32 FrameIndex = -1;
	float InterpolationFactor = -1.0f;

	bool bFrameUpdated = false;
};

/** Stores the BVH tree info for each individual track */
USTRUCT()
struct FGeometryCacheSectionData
{
	GENERATED_USTRUCT_BODY()

	FGeometryCacheSectionData() {}

	/** Position buffer for this track */
	TArray<FVector3f> PositionBuffer;

	/** UV buffer for this track */
	TArray<FVector2f> UVBuffer;

	/** Index buffer for this track */
	TArray<uint32> IndexBuffer;

	/** Array of per-batch info structs*/
	TArray<FGeometryCacheMeshBatchInfo> BatchesInfo;

	bool TopologyCompatible = false;

	int32 FrameIndex = -1;

	void Clear()
	{
		IndexBuffer.Empty();

		PositionBuffer.Empty();

		UVBuffer.Empty();

		FrameIndex = -1;
		TopologyCompatible = false;
		BatchesInfo.Empty();
	}

	void Prepare(int32 NumVertices)
	{
		if (NumVertices != PositionBuffer.Num())
		{
			// Clear entries but keep allocations.
			PositionBuffer.Reset();
			UVBuffer.Reset();

			// Make sure our capacity fits the requested vertex count
			PositionBuffer.Reserve(NumVertices);
			UVBuffer.Reserve(NumVertices);

			PositionBuffer.AddUninitialized(NumVertices);
			UVBuffer.AddUninitialized(NumVertices);
		}
	}

	void UpdateIndices(const TArray<uint32>& InIndexBuffer)
	{
		IndexBuffer = InIndexBuffer;
	}

	void UpdatePositions(const TArray<FVector3f>& InPositionBuffer)
	{
		PositionBuffer = InPositionBuffer;
	}

	void UpdateUVs(const TArray<FVector2f>& InUVBuffer)
	{
		UVBuffer = InUVBuffer;
	}
};


/** An ActorComponent adding collision for GeometryCache */
UCLASS(ClassGroup = (GeometryCache), meta = (BlueprintSpawnableComponent))
class GEOMETRYCACHEATTACHMENT_API UGeometryCacheAttachmentComponent : public USceneComponent
{
	GENERATED_UCLASS_BODY()

public:

	/** Trace a ray to GeometryCache, and attach element to the hit surface */
	UFUNCTION(BlueprintCallable, Category = "GeometryCacheAttachment")
		void LineTraceAttachElement(const FVector& WorldStart, const FVector& WorldEnd, USceneComponent* ElementComponent, const FTransform& ElementTransform, const FLineTraceAttachFinishedEvent& FinishedEvent);

	/** Attach component at target location */
	UFUNCTION(BlueprintCallable, Category = "GeometryCacheAttachment")
		bool AttachElementAtLocation(const FGeometryCacheAttachLocation& AttachLocation, USceneComponent* ElementComponent, const FTransform& ElementTransform);

	/** Remove all attached components */
	UFUNCTION(BlueprintCallable, Category = "GeometryCacheAttachment")
		void RemoveAllAttachedComponents(bool bDestroyAfterRemove = true);

	/** Remove one attached component */
	UFUNCTION(BlueprintCallable, Category = "GeometryCacheAttachment")
		bool RemoveAttachedComponent(USceneComponent* AttachedComponent, bool bDestroyAfterRemove = true);

	/** Replace one attached component */
	UFUNCTION(BlueprintCallable, Category = "GeometryCacheAttachment")
		bool ReplaceAttachedComponent(USceneComponent* OldAttachedComponent, USceneComponent* NewAttachedComponent, bool bDestroyOldAfterReplace = true);

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

public:

	//~ Begin UActorComponent Interface.
	virtual void OnRegister() override;
	virtual void OnUnregister() override;
	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	//~ End UActorComponent Interface.

	UGeometryCacheComponent* GetGeometryCacheComponent() { return GeometryCacheStatus.GeometryCacheComponent; }

	bool LineTraceGeometryCache(const FVector& WorldStart, const FVector& WorldEnd, FGeometryCacheLineTraceResult& Result);

	void AttachAllElements();

private:
	
	bool ResetGeometryCacheStatusWhenChanged(bool bForceReset);

	void ClearGeometryCacheStatus();

	void CreateTrackData();
	void ClearTrackData();

	void BuildGeometryCacheMeshBVH();

	bool UpdateFrameData();

	bool UpdateAttachedTriangles();

	int FindNearestTriangle(const FVector3d& P, double& NearestDistSqr, int32& NearestTrackIndex) const;

	void UpdateAttachedElements();

	bool CalculateVerticeInfoAtAttachedLocation(const FGeometryCacheAttachLocation& AttachLocation, FTransform& Transform, FVector2f& UV);

	bool RematchAttachLocation(FGeometryCacheAttachedTriangle& AttachedTriangle, FGeometryCacheMeshData* MeshDataToUse);

private:

	/**
	 *	Geometry Cache Attach Type
	 */
	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GeometryCacheAttachment")
		EGeometryCacheAttachType AttachType = EGeometryCacheAttachType::AttachToNearestDistance;

	UPROPERTY()
		FGeometryCacheParentStatus GeometryCacheStatus;

	//UPROPERTY(VisibleAnywhere, Category = "GeometryCacheAttachment")
		int32 NumTracks;

	UPROPERTY(VisibleAnywhere, Category = "GeometryCacheAttachment")
		TArray<FGeometryCacheAttachedElement> AttachedElements;

	TArray <FGeometryCacheAttachedTriangle> AttachedTriangles;

	TArray<FGeometryCacheSectionData*> TrackSections;

	TArray<TUniquePtr<UE::Geometry::FDynamicMesh3>> TrackMeshs;
	TArray<TUniquePtr<UE::Geometry::FDynamicMeshAABBTree3>> TrackMeshSpatials;

	float PreviousTime = 0.0f;

	bool bRuntimeTicking = false;
	bool bRuntimeInited = false;

	bool bFrameUpdated = false;
};
