// Copyright Qibo Pang 2024. All Rights Reserved.

#include "UMGPolygonWidgetDetailsCustomization.h"
#include "Layout/Margin.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SBoxPanel.h"
#include "Framework/Commands/UICommandList.h"
#include "Widgets/Layout/SWrapBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Input/SButton.h"
#include "EditorStyleSet.h"
#include "EditorModeManager.h"

#include "PropertyHandle.h"
#include "DetailLayoutBuilder.h"
#include "DetailWidgetRow.h"
#include "IDetailPropertyRow.h"
#include "DetailCategoryBuilder.h"

#include "IDetailsView.h"
#include "IAssetTools.h"
#include "AssetToolsModule.h"

#include "ScopedTransaction.h"
#include "IPropertyUtilities.h"
#include "Subsystems/AssetEditorSubsystem.h"

#include "UMGPolygonEditPanel.h"
#include "UMGPolygonEditorSettings.h"

#define LOCTEXT_NAMESPACE "PolygonWidgetDetails"

//////////////////////////////////////////////////////////////////////////
// FUMGPolygonWidgetDetailsCustomization

TSharedRef<IDetailCustomization> FUMGPolygonWidgetDetailsCustomization::MakeInstance()
{
	return MakeShareable(new FUMGPolygonWidgetDetailsCustomization);
}

void FUMGPolygonWidgetDetailsCustomization::CustomizeDetails(IDetailLayoutBuilder& DetailLayout)
{
	const TArray< TWeakObjectPtr<UObject> >& SelectedObjects = DetailLayout.GetSelectedObjects();
	if (SelectedObjects.Num() != 1)
	{
		return;
	}
	
	UPolygonWidget* PolygonWidget = nullptr;
	for (int32 ObjectIndex = 0; ObjectIndex < SelectedObjects.Num(); ++ObjectIndex)
	{
		UObject* TestObject = SelectedObjects[ObjectIndex].Get();
		if (UPolygonWidget* TestPolygonWidget = Cast<UPolygonWidget>(TestObject))
		{
			PolygonWidget = TestPolygonWidget;
			break;
		}
	}

	if (!PolygonWidget)
	{
		return;
	}

	PolygonWidgetPtr = PolygonWidget;

	PropertyPolygonInfo = DetailLayout.GetProperty(GET_MEMBER_NAME_CHECKED(UPolygonWidget, PolygonInfo), UPolygonWidget::StaticClass());
	check(PropertyPolygonInfo->IsValidHandle());

	// Make sure the Appearance category is right below the Transform
	IDetailCategoryBuilder& AppearanceCategory = DetailLayout.EditCategory("Appearance", FText::GetEmpty(), ECategoryPriority::TypeSpecific);

	// Make sure the EditPolygon category is right below the Appearance category
	IDetailCategoryBuilder& EditPolygonCategory = DetailLayout.EditCategory("EditPolygon", FText::GetEmpty(), ECategoryPriority::TypeSpecific);

	FText PolygonEditText = LOCTEXT("UMGPolygonEditPanel", "Polygon Edit Panel");
	EditPolygonCategory.AddCustomRow(PolygonEditText)
		[
			SNew(SVerticalBox)
			/* + SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(STextBlock)
				.Font(DetailLayout.GetDetailFont())
				.Text(PolygonEditText)
			]*/
			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SBox)
				.HeightOverride(this, &FUMGPolygonWidgetDetailsCustomization::GetPolygonEditPanelHieght)
				[
					SNew(SUMGPolygonEditPanel)
					.PolygonInfo_UObject(PolygonWidget, &UPolygonWidget::GetPolygonInfo)
					.OwningPolygonWidget(PolygonWidget)
					.Clipping(EWidgetClipping::ClipToBounds)
					.OnPolygonInfoValueChanged(FOnPolygonInfoValueChanged::CreateSP(this, &FUMGPolygonWidgetDetailsCustomization::OnPolygonInfoValueChanged))	
				]
			]
		];


	MyDetailLayout = &DetailLayout;
}

void FUMGPolygonWidgetDetailsCustomization::OnPolygonInfoValueChanged(const FUMGPolygonInfo& NewPolygonInfo)
{
	FString TextValue;
	FUMGPolygonInfo::StaticStruct()->ExportText(TextValue, &NewPolygonInfo, &NewPolygonInfo, nullptr, EPropertyPortFlags::PPF_None, nullptr);

	FPropertyAccess::Result Result = PropertyPolygonInfo->SetValueFromFormattedString(TextValue, EPropertyValueSetFlags::NotTransactable);
	check(Result == FPropertyAccess::Success);
}

FOptionalSize FUMGPolygonWidgetDetailsCustomization::GetPolygonEditPanelHieght() const
{
	return UUMGPolygonEditorSettings::GetPanelHeight();
}

//////////////////////////////////////////////////////////////////////////

#undef LOCTEXT_NAMESPACE
