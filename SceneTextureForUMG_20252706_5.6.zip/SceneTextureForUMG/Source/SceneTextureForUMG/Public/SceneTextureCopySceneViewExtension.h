// Copyright Qibo Pang 2022. All Rights Reserved.
#pragma once
#include "SceneViewExtension.h"
#include "RHI.h"
#include "RHIResources.h"

class USceneTextureCopySubsystem;
class UMaterialInterface;
class FRDGTexture;

class FSceneTextureCopySceneViewExtension : public FSceneViewExtensionBase
{
public:
	FSceneTextureCopySceneViewExtension(const FAutoRegister& AutoRegister, USceneTextureCopySubsystem* InWorldSubsystem);
	
	//~ Begin FSceneViewExtensionBase Interface
	virtual void SetupViewFamily(FSceneViewFamily& InViewFamily) override {};
	virtual void SetupView(FSceneViewFamily& InViewFamily, FSceneView& InView) override {};
	virtual void BeginRenderViewFamily(FSceneViewFamily& InViewFamily) override {};
	virtual void PrePostProcessPass_RenderThread(FRDGBuilder& GraphBuilder, const FSceneView& View, const FPostProcessingInputs& Inputs) override;
	
	virtual void PostRenderBasePassMobile_RenderThread(FRHICommandList& RHICmdList, FSceneView& InView) override;
	
	//~ End FSceneViewExtensionBase Interface

	void InitPooledTextures();
	void ReleasePooledTextures();

private:
	USceneTextureCopySubsystem* WorldSubsystem;

	TRefCountPtr<IPooledRenderTarget> SceneColorPooledTexture = nullptr;
	TRefCountPtr<IPooledRenderTarget> SceneDepthPooledTexture = nullptr;
	TRefCountPtr<IPooledRenderTarget> CustomDepthPooledTexture = nullptr;
	TRefCountPtr<IPooledRenderTarget> CustomStencilPooledTexture = nullptr;
};
	