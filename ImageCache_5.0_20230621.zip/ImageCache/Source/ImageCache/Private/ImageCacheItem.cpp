// Copyright Qibo Pang 2022. All Rights Reserved.

#include "ImageCacheItem.h"
#include "ImageCacheUtil.h"
#include "ImageCacheLibrary.h"
#include "ImageCacheModule.h"

void UCacheItem::InitByCacheIndex(const FString& InURL, const FString& InFileName, int32 InSize, int64 InCreateTime)
{
	URL = InURL;
	FileName = InFileName;
	Size = InSize;
	CreateTime = InCreateTime;

	BeenParsed = false;
}

FString UCacheBinaryItem::GenerateFileName(const FString& InURL)
{
	//use crc as filename
	auto& CharArray = InURL.GetCharArray();
	TArray<TCHAR> OddCharArray, EvenCharArray;
	for (int32 i = 0; i < CharArray.Num(); i++)
	{
		if (i % 2)
			OddCharArray.Add(CharArray[i]);
		else
			EvenCharArray.Add(CharArray[i]);
	}

	uint32 CrcOdd = FCrc::MemCrc32(OddCharArray.GetData(), OddCharArray.GetTypeSize() * OddCharArray.Num());
	uint32 CrcEven = FCrc::MemCrc32(EvenCharArray.GetData(), EvenCharArray.GetTypeSize() * EvenCharArray.Num());
	FString Filename = FString::Printf(TEXT("%010u%010u"), CrcOdd, CrcEven);

	//add extension
	FString Extname = FPaths::GetExtension(InURL, true);
	//if (Extname.Len() < 3 || Extname.Len() > 10)
	{
		switch (FileDesc)
		{
		case EFileTypeDesc::BinaryData:
			Extname = TEXT(".bin");
			break;
		case EFileTypeDesc::ImageFile:
			Extname = TEXT(".jpg");
			break;
		}
	}
	return Filename + Extname;
}

void UCacheBinaryItem::InitByData(const FString& InURL, const TArray<uint8>& InData)
{
	URL = InURL;
	Data = InData;

	CreateTime = UImageCacheUtil::GetNowInSeconds();
	FileName = GenerateFileName(URL);
	Size = Data.Num();

	Parse();
}

bool UCacheBinaryItem::LoadCache()
{
	FString Path = UImageCacheLibrary::GetImageCacheDirectory() + FileName;

	Data.Empty();
	if (!FFileHelper::LoadFileToArray(Data, *Path))
	{
		UE_LOG(ImageCacheLog, Error, TEXT("Fail to read file: %s"), *Path);
		return false;
	}

	return Parse();
}

bool UCacheBinaryItem::SaveCache()
{
	if (FileName.Len() == 0)
	{
		FileName = GenerateFileName(URL);
	}

	if (Data.Num() == 0)
	{
		UE_LOG(ImageCacheLog, Error, TEXT("Save image package failed:%s"), *FileName);
		return false;
	}
	
	FString Filepath = UImageCacheLibrary::GetImageCacheDirectory() + FileName;
	if (UImageCacheUtil::EnsureWritableFile(Filepath))
	{
		if (FFileHelper::SaveArrayToFile(Data, *Filepath))
		{
			return true;
		}
		else
		{
			UE_LOG(ImageCacheLog, Error, TEXT("Save image package failed:%s"), *FileName);
		}
	}

	return false;
}

bool UCacheBinaryItem::DeleteCache()
{
	FString Path = UImageCacheLibrary::GetImageCacheDirectory() + FileName;
	FPlatformFileManager::Get().GetPlatformFile().DeleteFile(*Path);

	return true;
}

bool UCacheBinaryItem::IsIndexMatch()
{
	FString Path = UImageCacheLibrary::GetImageCacheDirectory() + FileName;
	if (!FPaths::FileExists(Path))
	{
		return false;
	}

	return true;
}

static void WriteRawToNetTexture_RenderThread(FTexture2DDynamicResource* TextureResource, TArray64<uint8>* RawData, bool bUseSRGB = true)
{
	check(IsInRenderingThread());

	if (TextureResource)
	{
		FRHITexture2D* TextureRHI = TextureResource->GetTexture2DRHI();

		int32 Width = TextureRHI->GetSizeX();
		int32 Height = TextureRHI->GetSizeY();

		uint32 DestStride = 0;
		uint8* DestData = reinterpret_cast<uint8*>(RHILockTexture2D(TextureRHI, 0, RLM_WriteOnly, DestStride, false, false));

		for (int32 y = 0; y < Height; y++)
		{
			uint8* DestPtr = &DestData[((int64)Height - 1 - y) * DestStride];

			const FColor* SrcPtr = &((FColor*)(RawData->GetData()))[((int64)Height - 1 - y) * Width];
			for (int32 x = 0; x < Width; x++)
			{
				*DestPtr++ = SrcPtr->B;
				*DestPtr++ = SrcPtr->G;
				*DestPtr++ = SrcPtr->R;
				*DestPtr++ = SrcPtr->A;
				SrcPtr++;
			}
		}

		RHIUnlockTexture2D(TextureRHI, 0, false, false);
	}

	delete RawData;
}

bool UCacheImageItem::Parse()
{
	if (Data.Num() > 0)
	{
		//EImageFormat Format = EImageFormat::BMP;
		//Texture = UImageCacheUtil::CreateTextureFromImage(Data.GetData(), Data.Num(), Format);

		IImageWrapperModule& ImageWrapperModule = FModuleManager::LoadModuleChecked<IImageWrapperModule>(FName("ImageWrapper"));
		TSharedPtr<IImageWrapper> ImageWrappers[3] =
		{
			ImageWrapperModule.CreateImageWrapper(EImageFormat::PNG),
			ImageWrapperModule.CreateImageWrapper(EImageFormat::JPEG),
			ImageWrapperModule.CreateImageWrapper(EImageFormat::BMP),
		};

		for (auto ImageWrapper : ImageWrappers)
		{
			if (ImageWrapper.IsValid() && ImageWrapper->SetCompressed(Data.GetData(), Data.Num()))
			{
				TArray64<uint8>* RawData = new TArray64<uint8>();
				const ERGBFormat InFormat = ERGBFormat::BGRA;
				if (ImageWrapper->GetRaw(InFormat, 8, *RawData))
				{
					if (UTexture2DDynamic* TextureDynamic = UTexture2DDynamic::Create(ImageWrapper->GetWidth(), ImageWrapper->GetHeight()))
					{
						TextureDynamic->SRGB = true;
						TextureDynamic->UpdateResource();

						Texture = TextureDynamic;

						FTexture2DDynamicResource* TextureResource = static_cast<FTexture2DDynamicResource*>(Texture->GetResource());
						if (TextureResource)
						{
							ENQUEUE_RENDER_COMMAND(FWriteRawDataToTexture)(
								[TextureResource,RawData](FRHICommandListImmediate& RHICmdList)
							{
								WriteRawToNetTexture_RenderThread(TextureResource, RawData);
							});
						}
						else
						{
							delete RawData;
						}
						break;
					}
				}
			}
		}
		BeenParsed = Texture != nullptr;
	}

	return BeenParsed;
}
