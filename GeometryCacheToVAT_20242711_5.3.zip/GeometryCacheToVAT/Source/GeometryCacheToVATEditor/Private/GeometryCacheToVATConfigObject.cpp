// Copyright Qibo Pang 2023. All Rights Reserved.

#include "GeometryCacheToVATConfigObject.h"
#include "PropertyEditing.h"
#include "EngineUtils.h"

#define LOCTEXT_NAMESPACE "UGeometryCacheAbcConfigObject"

UGeometryCacheToVATConfigObject::UGeometryCacheToVATConfigObject()
{
	InitConfig();
}

void UGeometryCacheToVATConfigObject::InitConfig()
{
	;
}

void UGeometryCacheToVATConfigObject::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	;
}

#undef LOCTEXT_NAMESPACE