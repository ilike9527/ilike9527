// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SSceneTextureRecorder.h"
#include "Render/SceneTextureForTextDrawer.h"

SSceneTextureRecorder::SSceneTextureRecorder()
	: SceneTextureForTextDrawer(new FSceneTextureForTextDrawer())
{
	;
}

SSceneTextureRecorder::~SSceneTextureRecorder()
{
	// for thread safe, drawer must be deleted in render thread
	ENQUEUE_RENDER_COMMAND(SafeDeleteSceneTextureForTextDrawer)(
		[SceneTextureForTextDrawer = SceneTextureForTextDrawer](FRHICommandListImmediate& RHICmdList) mutable
		{
			SceneTextureForTextDrawer.Reset();
		}
	);
	//SceneTextureForTextDrawer = nullptr;
}

void SSceneTextureRecorder::Construct(const FArguments& InArgs)
{
	SetCanTick(false);
}

int32 SSceneTextureRecorder::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	
	int32 OutLayerId = LayerId;
	if (AllottedGeometry.GetLocalSize().GetMin() > 0)
	{
		FSlateRect RenderBoundingRect = AllottedGeometry.GetRenderBoundingRect();
		FPaintGeometry PaintGeometry(RenderBoundingRect.GetTopLeft(), RenderBoundingRect.GetSize(), 1.0f);

		int32 RenderTargetWidth = FMath::RoundToInt(RenderBoundingRect.GetSize().X);
		int32 RenderTargetHeight = FMath::RoundToInt(RenderBoundingRect.GetSize().Y);

		if (RenderTargetWidth > 0 && RenderTargetHeight > 0)
		{
			OutDrawElements.PushClip(FSlateClippingZone(AllottedGeometry));

			if (SceneTextureForTextDrawer->InitializeSceneTextureForTextParams(OutDrawElements, LayerId, PaintGeometry))
			{
				FSlateDrawElement::MakeCustom(OutDrawElements, LayerId, SceneTextureForTextDrawer);
			}

			OutDrawElements.PopClip();
		}

		++OutLayerId;
	}

	return SCompoundWidget::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, OutLayerId, InWidgetStyle, bParentEnabled);
}