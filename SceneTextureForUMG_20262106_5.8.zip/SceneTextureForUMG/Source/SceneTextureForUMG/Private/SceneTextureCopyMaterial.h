// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "UObject/ConstructorHelpers.h"
#include "RHI.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Materials/MaterialInterface.h"
#include "Materials/Material.h"
#include "Runtime/RenderCore/Public/ShaderParameterUtils.h"
#include "Runtime/RenderCore/Public/RenderResource.h"
#include "Runtime/Renderer/Public/MaterialShader.h"
#include "Runtime/RenderCore/Public/RenderGraphResources.h"
#include "Runtime/Renderer/Public/ScreenPass.h"
#include "Runtime/Renderer/Private/SceneTextureParameters.h"

#include "RenderResource.h"
#include "ShaderParameters.h"
#include "Shader.h"
#include "GlobalShader.h"
#include "ShaderParameterUtils.h"
#include "Rendering/RenderingCommon.h"
#include "RHIStaticStates.h"
#include "ShaderPermutation.h"

// The vertex shader used by DrawScreenPass to draw a rectangle.
class FSceneTextureCopyScreenPassVS : public FGlobalShader
{
public:
	DECLARE_GLOBAL_SHADER(FSceneTextureCopyScreenPassVS);

	static bool ShouldCompilePermutation(const FGlobalShaderPermutationParameters&)
	{
		return true;
	}

	FSceneTextureCopyScreenPassVS() = default;
	FSceneTextureCopyScreenPassVS(const ShaderMetaType::CompiledShaderInitializerType& Initializer)
		: FGlobalShader(Initializer)
	{}
};

class FCopyTexturePS : public FGlobalShader
{
	DECLARE_GLOBAL_SHADER(FCopyTexturePS);
	SHADER_USE_PARAMETER_STRUCT(FCopyTexturePS, FGlobalShader);

	class FCopySceneColor : SHADER_PERMUTATION_BOOL("COPY_SCENECOLOR");
	class FCopySceneDepth : SHADER_PERMUTATION_BOOL("COPY_SCENEDEPTH");
	class FCopyCustomDepth : SHADER_PERMUTATION_BOOL("COPY_CUSTOMDEPTH");
	class FCopyCustomStencil : SHADER_PERMUTATION_BOOL("COPY_CUSTOMSTENCIL");
	using FPermutationDomain = TShaderPermutationDomain<FCopySceneColor, FCopySceneDepth, FCopyCustomDepth, FCopyCustomStencil>;

	BEGIN_SHADER_PARAMETER_STRUCT(FParameters, )
		SHADER_PARAMETER(FVector2f, BufferSize)
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, SceneColorCopyTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, SceneColorCopySampler)
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, SceneDepthCopyTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, SceneDepthCopySampler)
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, CustomDepthCopyTexture)
		SHADER_PARAMETER_RDG_TEXTURE_SRV(Texture2D<uint2>, CustomStencilCopyTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, CustomDepthCopySampler)
		RENDER_TARGET_BINDING_SLOTS()
		END_SHADER_PARAMETER_STRUCT()

	static bool ShouldCompilePermutation(const FGlobalShaderPermutationParameters& Parameters)
	{
		return true;// IsFeatureLevelSupported(Parameters.Platform, ERHIFeatureLevel::SM5);
	}

	static void ModifyCompilationEnvironment(const FGlobalShaderPermutationParameters& Parameters, FShaderCompilerEnvironment& OutEnvironment)
	{
		FGlobalShader::ModifyCompilationEnvironment(Parameters, OutEnvironment);
	}
};

class FUMGCopySceneColorPS : public FGlobalShader
{
	DECLARE_GLOBAL_SHADER(FUMGCopySceneColorPS);
	SHADER_USE_PARAMETER_STRUCT(FUMGCopySceneColorPS, FGlobalShader);

	using FPermutationDomain = TShaderPermutationDomain<>;
	BEGIN_SHADER_PARAMETER_STRUCT(FParameters, )
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, SceneColorTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, SceneColorSampler)
		RENDER_TARGET_BINDING_SLOTS()
	END_SHADER_PARAMETER_STRUCT()

	static bool ShouldCompilePermutation(const FGlobalShaderPermutationParameters& Parameters)
	{
		return true;// IsFeatureLevelSupported(Parameters.Platform, ERHIFeatureLevel::SM5);
	}

	static void ModifyCompilationEnvironment(const FGlobalShaderPermutationParameters& Parameters, FShaderCompilerEnvironment& OutEnvironment)
	{
		FGlobalShader::ModifyCompilationEnvironment(Parameters, OutEnvironment);
	}
};


class FUMGCopyDepthPS : public FGlobalShader
{
	DECLARE_GLOBAL_SHADER(FUMGCopyDepthPS);
	SHADER_USE_PARAMETER_STRUCT(FUMGCopyDepthPS, FGlobalShader);

	using FPermutationDomain = TShaderPermutationDomain<>;
	BEGIN_SHADER_PARAMETER_STRUCT(FParameters, )
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, CustomDepthTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, CustomDepthSampler)
		RENDER_TARGET_BINDING_SLOTS()
	END_SHADER_PARAMETER_STRUCT()

	static bool ShouldCompilePermutation(const FGlobalShaderPermutationParameters& Parameters)
	{
		return true;// IsFeatureLevelSupported(Parameters.Platform, ERHIFeatureLevel::SM5);
	}

	static void ModifyCompilationEnvironment(const FGlobalShaderPermutationParameters& Parameters, FShaderCompilerEnvironment& OutEnvironment)
	{
		FGlobalShader::ModifyCompilationEnvironment(Parameters, OutEnvironment);
	}
};

class FFinalColorCopyPS : public FGlobalShader
{
public:

	DECLARE_GLOBAL_SHADER(FFinalColorCopyPS);
	SHADER_USE_PARAMETER_STRUCT(FFinalColorCopyPS, FGlobalShader);

	BEGIN_SHADER_PARAMETER_STRUCT(FParameters, )
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, ElementTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, ElementTextureSampler)
		RENDER_TARGET_BINDING_SLOTS()
	END_SHADER_PARAMETER_STRUCT()

};