// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

class FFinalColorDrawer;
class FFinalColorCopyProcessor;

class UWidget;
class UMaterialInstanceDynamic;

class UTexture;
class UTextureRenderTarget2D;

/**
 * SceneTexture For UMG renderer
 */
class FSceneTextureForUMGRenderer
{
public:
	FSceneTextureForUMGRenderer();
	~FSceneTextureForUMGRenderer();

	static FSceneTextureForUMGRenderer& Get();

	TSharedPtr<FFinalColorCopyProcessor> GetFinalColorCopyProcessor() { return FinalColorCopyProcessor; }

	void InitFinalColorRecorder(UWorld* World);
	void InitFinalColorRecorder_GameThread(UWorld* World);
	void ReleaseFinalColorRecorder();
	
	UTextureRenderTarget2D* GetSceneColor() { return RT_SceneColor; }
	UTextureRenderTarget2D* GetFinalColor() { return RT_FinalColor; }
	UTextureRenderTarget2D* GetSceneDepth() { return RT_SceneDepth; }
	UTextureRenderTarget2D* GetCustomDepth() { return RT_CustomDepth; }
	UTextureRenderTarget2D* GetCustomStencil() { return RT_CustomStencil; }

	bool CheckRenderTargetSizeMatch(const FIntPoint& InRenderTargetSize);
	void UpdateRenderTargetSize_GameThread(const FIntPoint& InRenderTargetSize);
	void UpdateRenderTargetSize(const FIntPoint& InRenderTargetSize);
	FIntPoint GetRenderTargetSize() { return RenderTargetSize; }

	void InitRenderResources();
	void ReleaseRenderResources();

private:

	TSharedPtr<FFinalColorCopyProcessor> FinalColorCopyProcessor;
	class UFinalColorRecorder* FinalColorRecorder = nullptr;
	UTextureRenderTarget2D* RT_FinalColor = nullptr;
	
	UTextureRenderTarget2D* RT_SceneColor = nullptr;
	UTextureRenderTarget2D* RT_SceneDepth = nullptr;
	UTextureRenderTarget2D* RT_CustomDepth = nullptr;
	UTextureRenderTarget2D* RT_CustomStencil = nullptr;

	FIntPoint RenderTargetSize = FIntPoint(256, 256);
};

