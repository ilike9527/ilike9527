// Copyright Qibo Pang 2022. All Rights Reserved.

#include "FinalColorCopyProcessor.h"
#include "Engine/TextureRenderTarget2D.h"
#include "SceneTextureCopyMaterial.h"
#include "ScreenRendering.h"
#include "SceneUtils.h"
#include "RendererInterface.h"
#include "StaticBoundShaderState.h"
#include "PipelineStateCache.h"
#include "CommonRenderResources.h"
#include "Engine/TextureRenderTarget.h"
#include "TextureResource.h"


bool GetCopyClippingPipelineState(const FSlateClippingOp* ClippingStateOp, FRHIDepthStencilState*& OutDepthStencilState, uint8& OutStencilRef)
{
	if (ClippingStateOp && ClippingStateOp->Method == EClippingMethod::Stencil)
	{
		// Setup the stenciling state to be read only now, disable depth writes, and restore the color buffer
		// because we're about to go back to rendering widgets "normally", but with the added effect that now
		// we have the stencil buffer bound with a bunch of clipping zones rendered into it.
		OutDepthStencilState =
			TStaticDepthStencilState<
			/*bEnableDepthWrite*/ false
			, /*DepthTest*/ CF_Always
			, /*bEnableFrontFaceStencil*/ true
			, /*FrontFaceStencilTest*/ CF_Equal
			, /*FrontFaceStencilFailStencilOp*/ SO_Keep
			, /*FrontFaceDepthFailStencilOp*/ SO_Keep
			, /*FrontFacePassStencilOp*/ SO_Keep
			, /*bEnableBackFaceStencil*/ true
			, /*BackFaceStencilTest*/ CF_Equal
			, /*BackFaceStencilFailStencilOp*/ SO_Keep
			, /*BackFaceDepthFailStencilOp*/ SO_Keep
			, /*BackFacePassStencilOp*/ SO_Keep
			, /*StencilReadMask*/ 0xFF
			, /*StencilWriteMask*/ 0xFF>::GetRHI();

		// Set a StencilRef equal to the number of stenciling/clipping masks, so unless the pixel we're rendering
		// to is on top of a stencil pixel with the same number it's going to get rejected, thereby clipping
		// everything except for the cross-section of all the stenciling quads.
		OutStencilRef = ClippingStateOp->MaskingId + ClippingStateOp->Data_Stencil.Zones.Num();
		return true;
	}
	else
	{
		OutDepthStencilState = TStaticDepthStencilState<false, CF_Always>::GetRHI();
		OutStencilRef = 0;
		return false;
	}
}

//////////////////////////////////////////////////////////////////////////

FFinalColorCopyProcessor::FFinalColorCopyProcessor()
{
	
}

FFinalColorCopyProcessor::~FFinalColorCopyProcessor()
{

}

void FFinalColorCopyProcessor::CopyRect(FRDGBuilder& GraphBuilder, const FSlateCopyRectPassInputs& Inputs)
{

	FScreenPassTexture CopyInputTexture(Inputs.InputTexture, Inputs.InputRect);

	const ERHIFeatureLevel::Type FeatureLevel = GMaxRHIFeatureLevel;
	FGlobalShaderMap* ShaderMap = GetGlobalShaderMap(FeatureLevel);
	TShaderMapRef<FFinalColorCopyPS> PixelShader(ShaderMap);
	TShaderMapRef<FSceneTextureCopyScreenPassVS> VertexShader(ShaderMap);

	FScreenPassTextureViewport OutputViewport;
	OutputViewport.Extent = Inputs.OutputTexture->Desc.Extent;
	OutputViewport.Rect = FIntRect(0, 0, OutputViewport.Extent.X, OutputViewport.Extent.Y);

	FScreenPassTextureViewport InputViewport;
	InputViewport.Extent = Inputs.InputTexture->Desc.Extent; 
	InputViewport.Rect = Inputs.InputRect;

	FFinalColorCopyPS::FParameters* PassParameters = GraphBuilder.AllocParameters<FFinalColorCopyPS::FParameters>();
	PassParameters->RenderTargets[0] = FRenderTargetBinding(Inputs.OutputTexture, ERenderTargetLoadAction::EClear); 
	PassParameters->ElementTexture = CopyInputTexture.Texture;
	PassParameters->ElementTextureSampler = TStaticSamplerState<SF_Bilinear>::GetRHI();
	
	// Get BlendState
	FRHIBlendState* BlendState = FScreenPassPipelineState::FDefaultBlendState::GetRHI();
	// Get ViewportSize

	FScreenPassPipelineState PipelineState(VertexShader, PixelShader, BlendState);
	GetCopyClippingPipelineState(Inputs.ClippingOp, PipelineState.DepthStencilState, PipelineState.StencilRef);

	GraphBuilder.AddPass(
		RDG_EVENT_NAME("CopyFinalTexture"),
		PassParameters,
		ERDGPassFlags::Raster,
		[OutputViewport, PixelShader, InputViewport, PassParameters, ClippingElementsViewRect = Inputs.ClippingElementsViewRect, PipelineState, ClippingOp = Inputs.ClippingOp](FRHICommandListImmediate& RHICmdList)
		{

			RHICmdList.SetViewport(0.0f, 0.0f, 0.0f, OutputViewport.Rect.Max.X, OutputViewport.Rect.Max.Y, 1.0f);

			SetScreenPassPipelineState(RHICmdList, PipelineState);
			SetShaderParameters(RHICmdList, PixelShader, PixelShader.GetPixelShader(), *PassParameters);
			DrawScreenPass_PostSetup(RHICmdList, FScreenPassViewInfo(), OutputViewport, InputViewport, PipelineState, EScreenPassDrawFlags::None);
		});
}

UTexture* FFinalColorCopyProcessor::GetSceneTexture()
{
	return RenderTarget;
}