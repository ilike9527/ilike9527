// Copyright Qibo Pang 2022. All Rights Reserved.

#include "SceneTextureCopyMaterial.h"
#include "MaterialShader.h"
#include "MaterialShaderType.h"
#include "Materials/Material.h"
#include "GlobalShader.h"
#include "TextureResource.h"
#include "ShaderCore.h"
#include "ShaderParameterMacros.h"
#include "CoreMinimal.h"
#include "CommonRenderResources.h"
#include "RenderGraph.h"
#include "RendererInterface.h"
#include "Rendering/RenderingCommon.h"
#include "PipelineStateCache.h"

IMPLEMENT_GLOBAL_SHADER(FCopyTexturePS, "/Plugin/SceneTextureForUMG/Private/SceneTextureCopyScreenPass.usf", "CopyPS", SF_Pixel);
IMPLEMENT_GLOBAL_SHADER(FUMGCopySceneColorPS, "/Plugin/SceneTextureForUMG/Private/SceneTextureCopyScreenPass.usf", "CopySceneColorPS", SF_Pixel);
IMPLEMENT_GLOBAL_SHADER(FUMGCopyDepthPS, "/Plugin/SceneTextureForUMG/Private/SceneTextureCopyScreenPass.usf", "CopyDepthPS", SF_Pixel);
IMPLEMENT_GLOBAL_SHADER(FSceneTextureCopyScreenPassVS, "/Plugin/SceneTextureForUMG/Private/SceneTextureCopyScreenPass.usf", "MainVS", SF_Vertex);


IMPLEMENT_GLOBAL_SHADER(FFinalColorCopyPS, "/Plugin/SceneTextureForUMG/Private/SceneFinalColorCopyPixelShader.usf", "CopysampleMain", SF_Pixel);
