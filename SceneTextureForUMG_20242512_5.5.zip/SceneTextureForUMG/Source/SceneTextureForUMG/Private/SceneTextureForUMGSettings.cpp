﻿// Copyright Qibo Pang 2022. All Rights Reserved.


#include "SceneTextureForUMGSettings.h"
#include <string>

USceneTextureForUMGSettings::USceneTextureForUMGSettings()
{
	;
}

USceneTextureForUMGSettings* USceneTextureForUMGSettings::GetMutableInstance()
{
	return GetMutableDefault<USceneTextureForUMGSettings>();
}

const USceneTextureForUMGSettings* USceneTextureForUMGSettings::GetInstance()
{
	return GetDefault<USceneTextureForUMGSettings>();
}


FName USceneTextureForUMGSettings::GetCategoryName() const
{
	return TEXT("Project");
}

#if WITH_EDITOR
FText USceneTextureForUMGSettings::GetSectionText() const
{
	return FText::FromString(TEXT("SceneTextureForUMG"));
}
#endif