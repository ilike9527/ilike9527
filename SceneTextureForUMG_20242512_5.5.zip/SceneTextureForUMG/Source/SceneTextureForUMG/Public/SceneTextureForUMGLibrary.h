// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Components/Widget.h"
#include "Components/EditableText.h"
#include "Components/RichTextBlock.h"
#include "SceneTextureForUMGLibrary.generated.h"

USTRUCT(BlueprintType)
struct FSceneTextureEnableSettings
{
	GENERATED_BODY();

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SceneTextureForUMG")
		bool EnableSceneColor = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SceneTextureForUMG")
		bool EnableSceneDepth = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SceneTextureForUMG")
		bool EnableCustomDepth = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SceneTextureForUMG")
		bool EnableFinalColor = false;
};

/**
 * 
 */
UCLASS()
class SCENETEXTUREFORUMG_API USceneTextureForUMGLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

	
public:
	
	UFUNCTION(BlueprintCallable, Category = "SceneTextureForUMG", meta = (WorldContext = "WorldContextObject"))
		static void EnableSceneTexturesForUMG(const FSceneTextureEnableSettings& Settings, const UObject* WorldContextObject);

};

