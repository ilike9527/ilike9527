// Copyright Qibo Pang 2024. All Rights Reserved.


#include "UMGPolygonModule.h"

#define LOCTEXT_NAMESPACE "FUMGPolygonModule"

void FUMGPolygonModule::StartupModule()
{
	
}

void FUMGPolygonModule::ShutdownModule()
{
	
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FUMGPolygonModule, UMGPolygon)