// Copyright Qibo Pang 2024. All Rights Reserved.

using System.IO;
using UnrealBuildTool;

public class UMGPolygon : ModuleRules
{
	private string ThirdPartyPath
	{
		get { return Path.Combine(ModuleDirectory, "..", "ThirdParty"); }
	}

	public UMGPolygon(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicIncludePaths.Add(Path.Combine(ThirdPartyPath, "mapbox"));

		PublicIncludePaths.Add(Path.Combine(ModuleDirectory, "Public"));
		PrivateIncludePaths.Add(Path.Combine(ModuleDirectory, "Private"));

		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				"ApplicationCore",
				"CoreUObject",
				"Engine",
				"UMG",
				"Slate",
				"SlateCore"
			}
		);
	}
}
