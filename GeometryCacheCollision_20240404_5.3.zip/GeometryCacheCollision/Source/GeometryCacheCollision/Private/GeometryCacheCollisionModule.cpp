// Copyright Qibo Pang 2022. All Rights Reserved.


#include "GeometryCacheCollisionModule.h"

#define LOCTEXT_NAMESPACE "FGeometryCacheCollisionModule"

void FGeometryCacheCollisionModule::StartupModule()
{
	
}

void FGeometryCacheCollisionModule::ShutdownModule()
{
	
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FGeometryCacheCollisionModule, GeometryCacheCollision)