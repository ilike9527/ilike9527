// Copyright Qibo Pang 2024. All Rights Reserved.

/*
* Below Code mainly copy from SlateCore / ElementBatcher.cpp FPolygonBuilder, I made a few changes to support:
* 1. Add uv information for spline geometry
* 2. Made continuous spline geometry
* 3. Calculate spline length when build spline geometry
*/

#include "UMGPolygonBuilder.h"
#include "UMGPolygonRenderBatch.h"
#include "EarcutUtility.h"
#include "Rendering/DrawElementPayloads.h"

const static float      CONST_SplineVScale = 0.01f;
const static float      CONST_EdgeMask = 2.0f;

void FUMGPolygonBuilder::BuildEdgeGeometry(FUMGPolygonRenderBatch& InEdgeRenderBatch, const FColor& InTintColor, float InHalfEdgeThickness, float InEdgeThickness, bool bInCustomPolygonEdge)
{
	SingleColor = InTintColor;
	HalfLineEdgeThickness = InHalfEdgeThickness;
	EdgeThickness = InEdgeThickness;
	bCustomPolygonEdge = bInCustomPolygonEdge;

	EdgeRenderBatch = &InEdgeRenderBatch;
	EdgePoints.Empty();

	SplineLength = 0.0f;
	SplineVCoord = 0.0f;

	NumPointsAdded = 1;

	LastNormal = FVector2D::ZeroVector;
	LastPointAdded[0] = LastPointAdded[1] = UMGPolygonEdgeCurves[0].P0;

	for (int32 Index = 0; Index < UMGPolygonEdgeCurves.Num(); Index++)
	{
		FUMGBezierCurve& Curve = UMGPolygonEdgeCurves[Index];
		Subdivide(Curve.P0, Curve.P1, Curve.P2, Curve.P3, *this, 1.0f);
	}

	Finish(UMGPolygonEdgeCurves[0].P0, InTintColor, true);
}

void FUMGPolygonBuilder::BuildPolygonGeometry(FUMGPolygonRenderBatch& InPolygonRenderBatch, const FColor& InTintColor)
{
	BuildEdgeGeometry(InPolygonRenderBatch, InTintColor, 1.5f, 1.0f, false);

	if (EdgePoints.Num() > 0
		&& (WidgetSize.X > 0.0f && WidgetSize.Y > 0.0f))
	{
		const int32 NumEdgeVerts = EdgeRenderBatch->GetNumVertices();

		TArray<int32> Indices;
		FECUtils::Earcut(EdgePoints, Indices);

		for (int32 Index = 0; Index < EdgePoints.Num(); Index++)
		{
			InPolygonRenderBatch.AddVertex(FSlateVertex::Make<ESlateVertexRounding::Disabled>(RenderTransform, FVector2f(EdgePoints[Index]), ComputeUV(EdgePoints[Index]), FVector2f(0.5f, 0.0f), SingleColor));
		}

		for (int32 Index = 0; Index < Indices.Num(); Index++)
		{
			InPolygonRenderBatch.AddIndex(Indices[Index] + NumEdgeVerts);
		}
	}
}

void FUMGPolygonBuilder::AppendBezierCurve(const FVector2D& P0, const FVector2D& P1, const FVector2D& P2, const FVector2D& P3)
{
	UMGPolygonEdgeCurves.Add({ P0, P1, P2, P3 });
}

void FUMGPolygonBuilder::BuildBezierGeometry(const FVector2D& P0, const FVector2D& P1, const FVector2D& P2, const FVector2D& P3)
{
	Subdivide(P0, P1, P2, P3, *this, 1.0f);
	//Finish(P3, SingleColor);
}

void FUMGPolygonBuilder::Finish(const FVector2D& LastPoint, const FColor& InColor, bool bCloseLoop)
{
	if (NumPointsAdded < 3)
	{
		// Line builder needs at least two line segments (3 points) to
		// complete building its geometry.
		// This will only happen in the case when we have a straight line.
		AppendPoint(LastPoint, InColor);
	}
	else
	{
		// We have added the last point, but the line builder only builds
		// geometry for the previous line segment. Build geometry for the
		// last line segment.
		const FVector2D LastUp = LastNormal * HalfLineEdgeThickness;

		SplineLength += FVector2D::Distance(LastPointAdded[1], LastPointAdded[0]);
		SplineVCoord = SplineLength * CONST_SplineVScale * CustomVertsVCoordScale;

		OnSegmentAdded.ExecuteIfBound(NumPointsAdded - 2, LastPointAdded[0], SplineLength);

		if (bCloseLoop)
		{
			FSlateRenderTransform TempRenderTransform = FSlateRenderTransform(1.0f);
			FVector2f UV0 = FVector2f((*EdgeRenderBatch->SourceVertices)[0].TexCoords[0], (*EdgeRenderBatch->SourceVertices)[0].TexCoords[1]);
			FVector2f UV1 = FVector2f((*EdgeRenderBatch->SourceVertices)[1].TexCoords[0], (*EdgeRenderBatch->SourceVertices)[1].TexCoords[1]);
			if (bCustomPolygonEdge)
			{
				UV0 = FVector2f(1.0, SplineVCoord);
				UV1 = FVector2f(0.0, SplineVCoord);
			}
			
			EdgeRenderBatch->AddVertex(FSlateVertex::Make<ESlateVertexRounding::Disabled>(TempRenderTransform, (*EdgeRenderBatch->SourceVertices)[0].Position, UV0, ComputeEdgeUV2(1.0f), InColor));
			EdgeRenderBatch->AddVertex(FSlateVertex::Make<ESlateVertexRounding::Disabled>(TempRenderTransform, (*EdgeRenderBatch->SourceVertices)[1].Position, UV1, ComputeEdgeUV2(0.0f), InColor));
		}
		else
		{
			EdgeRenderBatch->AddVertex(FSlateVertex::Make<ESlateVertexRounding::Disabled>(RenderTransform, FVector2f(LastPointAdded[0] + LastUp), ComputeEdgeUV1(1.0f, LastPointAdded[0] + LastUp), ComputeEdgeUV2(1.0f), InColor));
			EdgeRenderBatch->AddVertex(FSlateVertex::Make<ESlateVertexRounding::Disabled>(RenderTransform, FVector2f(LastPointAdded[0] - LastUp), ComputeEdgeUV1(0.0f, LastPointAdded[0] - LastUp), ComputeEdgeUV2(0.0f), InColor));

			EdgePoints.Add(LastPointAdded[0]);

		}

		const int32 NumVerts = EdgeRenderBatch->GetNumVertices();

		// Counterclockwise winding on triangles
		EdgeRenderBatch->AddIndex(NumVerts - 3);
		EdgeRenderBatch->AddIndex(NumVerts - 4);
		EdgeRenderBatch->AddIndex(NumVerts - 2);

		EdgeRenderBatch->AddIndex(NumVerts - 3);
		EdgeRenderBatch->AddIndex(NumVerts - 2);
		EdgeRenderBatch->AddIndex(NumVerts - 1);
	}
}

FVector2f FUMGPolygonBuilder::ComputeUV(const FVector2D& Point)
{
	FVector2D UV = FVector2D::ZeroVector;
	if (WidgetSize.X > 0.0f && WidgetSize.Y > 0.0f)
	{
		UV = (Point - WidgetLocation)/ WidgetSize;
	}

	return FVector2f(UV);
}

FVector2f FUMGPolygonBuilder::ComputeEdgeUV1(float U, const FVector2D& Point)
{
	if (bCustomPolygonEdge)
	{
		return FVector2f(U, SplineVCoord);
	}
	else
	{
		return ComputeUV(Point);
	}
}

FVector2f FUMGPolygonBuilder::ComputeEdgeUV2(float U)
{
	if (bCustomPolygonEdge)
	{
		return FVector2f(EdgeThickness, FilterScale);
	}
	else
	{
		return FVector2f(U, CONST_EdgeMask);
	}
}

void FUMGPolygonBuilder::AppendPoint(const FVector2D NewPoint, const FColor& InColor)
{
	// We only add vertexes for the previous line segment.
	// This is because we want to average the previous and new normals
	// In order to prevent overlapping line segments on the spline.
	// These occur especially when curvature is high.

	const FVector2D NewNormal = FVector2D(LastPointAdded[0].Y - NewPoint.Y, NewPoint.X - LastPointAdded[0].X).GetSafeNormal();

	if (NumPointsAdded == 2)
	{
		// Once we have two points, we have a normal, so we can generate the first bit of geometry.
		const FVector2D LastUp = LastNormal * HalfLineEdgeThickness;

		OnSegmentAdded.ExecuteIfBound(NumPointsAdded - 2, LastPointAdded[0], SplineLength);

		EdgePoints.Add(LastPointAdded[1]);

		EdgeRenderBatch->AddVertex(FSlateVertex::Make<ESlateVertexRounding::Disabled>(RenderTransform, FVector2f(LastPointAdded[1] + LastUp), ComputeEdgeUV1(1.0f, LastPointAdded[1] + LastUp), ComputeEdgeUV2(1.0f), InColor));
		EdgeRenderBatch->AddVertex(FSlateVertex::Make<ESlateVertexRounding::Disabled>(RenderTransform, FVector2f(LastPointAdded[1] - LastUp), ComputeEdgeUV1(0.0f, LastPointAdded[1] - LastUp), ComputeEdgeUV2(0.0f), InColor));
	}

	if (NumPointsAdded >= 2)
	{
		const FVector2D AveragedUp = (0.5f * (NewNormal + LastNormal)).GetSafeNormal() * HalfLineEdgeThickness;

		SplineLength += FVector2D::Distance(LastPointAdded[1], LastPointAdded[0]);
		SplineVCoord = SplineLength * CONST_SplineVScale * CustomVertsVCoordScale;

		OnSegmentAdded.ExecuteIfBound(NumPointsAdded - 2, LastPointAdded[0], SplineLength);
		
		EdgePoints.Add(LastPointAdded[0]);

		EdgeRenderBatch->AddVertex(FSlateVertex::Make<ESlateVertexRounding::Disabled>(RenderTransform, FVector2f(LastPointAdded[0] + AveragedUp), ComputeEdgeUV1(1.0f, LastPointAdded[0] + AveragedUp), ComputeEdgeUV2(1.0f), InColor));
		EdgeRenderBatch->AddVertex(FSlateVertex::Make<ESlateVertexRounding::Disabled>(RenderTransform, FVector2f(LastPointAdded[0] - AveragedUp), ComputeEdgeUV1(0.0f, LastPointAdded[0] - AveragedUp), ComputeEdgeUV2(0.0f), InColor));

		const int32 NumVerts = EdgeRenderBatch->GetNumVertices();

		// Counterclockwise winding on triangles
		EdgeRenderBatch->AddIndex(NumVerts - 3);
		EdgeRenderBatch->AddIndex(NumVerts - 4);
		EdgeRenderBatch->AddIndex(NumVerts - 2);

		EdgeRenderBatch->AddIndex(NumVerts - 3);
		EdgeRenderBatch->AddIndex(NumVerts - 2);
		EdgeRenderBatch->AddIndex(NumVerts - 1);
	}

	LastPointAdded[1] = LastPointAdded[0];
	LastPointAdded[0] = NewPoint;
	LastNormal = NewNormal;

	++NumPointsAdded;
}


/**
* Based on comp.graphics.algorithms: Adaptive Subdivision of Bezier Curves.
*
*   P1 + - - - - + P2
*     /           \
* P0 *             * P3
*
* In a perfectly flat curve P1 is the midpoint of (P0, P2) and P2 is the midpoint of (P1,P3).
* Computing the deviation of points P1 and P2 from the midpoints of P0,P2 and P1,P3 provides
* a simple and reliable measure of flatness.
*
* P1Deviation = (P0 + P2)/2 - P1
* P2Deviation = (P1 + P3)/2 - P2
*
* Eliminate divides: same expression but gets us twice the allowable error
* P1Deviation*2 = P0 + P2 - 2*P1
* P2Deviation*2 = P1 + P3 - 2*P2
*
* Use manhattan distance: 2*Deviation = |P1Deviation.x| + |P1Deviation.y| + |P2Deviation.x| + |P2Deviation.y|
*
*/
float FUMGPolygonBuilder::ComputeCurviness(const FVector2D& P0, const FVector2D& P1, const FVector2D& P2, const FVector2D& P3)
{
	FVector2D TwoP1Deviations = P0 + P2 - 2 * P1;
	FVector2D TwoP2Deviations = P1 + P3 - 2 * P2;
	float TwoDeviations = FMath::Abs(TwoP1Deviations.X) + FMath::Abs(TwoP1Deviations.Y) + FMath::Abs(TwoP2Deviations.X) + FMath::Abs(TwoP2Deviations.Y);
	return TwoDeviations;
}


/**
* deCasteljau subdivision of Bezier Curves based on reading of Gernot Hoffmann's Bezier Curves.
*
*       P1 + - - - - + P2                P1 +
*         /           \                    / \
*     P0 *             * P3            P0 *   \   * P3
*                                              \ /
*                                               + P2
*
*
* Split the curve defined by P0,P1,P2,P3 into two new curves L0..L3 and R0..R3 that define the same shape.
*
* Points L0 and R3 are P0 and P3.
* First find points L1, M, R2  as the midpoints of (P0,P1), (P1,P2), (P2,P3).
* Find two more points: L2, R1 defined by midpoints of (L1,M) and (M,R2) respectively.
* The final points L3 and R0 are both the midpoint of (L2,R1)
*
*/
void FUMGPolygonBuilder::deCasteljauSplit(const FVector2D& P0, const FVector2D& P1, const FVector2D& P2, const FVector2D& P3, FVector2D OutCurveParams[7])
{
	FVector2D L1 = (P0 + P1) * 0.5f;
	FVector2D M = (P1 + P2) * 0.5f;
	FVector2D R2 = (P2 + P3) * 0.5f;

	FVector2D L2 = (L1 + M) * 0.5f;
	FVector2D R1 = (M + R2) * 0.5f;

	FVector2D L3R0 = (L2 + R1) * 0.5f;

	OutCurveParams[0] = P0;
	OutCurveParams[1] = L1;
	OutCurveParams[2] = L2;
	OutCurveParams[3] = L3R0;
	OutCurveParams[4] = R1;
	OutCurveParams[5] = R2;
	OutCurveParams[6] = P3;
}

void FUMGPolygonBuilder::Subdivide(const FVector2D& P0, const FVector2D& P1, const FVector2D& P2, const FVector2D& P3, FUMGPolygonBuilder& PolygonBuilder, float MaxBiasTimesTwo)
{
	const float Curviness = ComputeCurviness(P0, P1, P2, P3);
	if (Curviness > MaxBiasTimesTwo)
	{
		// Split the Bezier into two curves.
		FVector2D TwoCurves[7];
		deCasteljauSplit(P0, P1, P2, P3, TwoCurves);
		// Subdivide left, then right
		Subdivide(TwoCurves[0], TwoCurves[1], TwoCurves[2], TwoCurves[3], PolygonBuilder, MaxBiasTimesTwo);
		Subdivide(TwoCurves[3], TwoCurves[4], TwoCurves[5], TwoCurves[6], PolygonBuilder, MaxBiasTimesTwo);
	}
	else
	{
		PolygonBuilder.AppendPoint(P3, PolygonBuilder.SingleColor);
	}
}
