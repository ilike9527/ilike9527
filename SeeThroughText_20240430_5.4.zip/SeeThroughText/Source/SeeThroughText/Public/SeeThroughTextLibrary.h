// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Components/Widget.h"
#include "Components/EditableText.h"
#include "Components/RichTextBlock.h"
#include "SeeThroughTextLibrary.generated.h"

/**
 * 
 */
UCLASS()
class SEETHROUGHTEXT_API USeeThroughTextLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

	
public:
	
	UFUNCTION(BlueprintCallable, Category = "SeeThroughText", meta = (WorldContext = "WorldContextObject"))
		static void AddMaterialForSeeThroughText(UMaterialInstanceDynamic* MaterialInstanceDynamic, const UObject* WorldContextObject);

	UFUNCTION(BlueprintCallable, Category = "SeeThroughText")
		static void RemoveMaterialForSeeThroughText(UMaterialInstanceDynamic* MaterialInstanceDynamic);

	UFUNCTION(BlueprintCallable, Category = "SeeThroughText")
		static void GetStyleFromRichTextStyleRow(const FRichTextStyleRow& Row, FTextBlockStyle& OutStyle);
};

