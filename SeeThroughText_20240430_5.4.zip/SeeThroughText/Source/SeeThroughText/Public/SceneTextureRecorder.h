// Copyright Qibo Pang 2022. All Rights Reserved.

#pragma once

// Core
#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"

// Misc
#include "SSceneTextureRecorder.h"

// Generated.h
#include "SceneTextureRecorder.generated.h"

DECLARE_MULTICAST_DELEGATE(FOnSTRecorderDestructEvent);
DECLARE_MULTICAST_DELEGATE(FOnSTRecorderTickEvent);

/**
*/
UCLASS(meta=(DisplayName="SceneTextureRecorder"))
class SEETHROUGHTEXT_API USceneTextureRecorder final : public UUserWidget
{
	GENERATED_UCLASS_BODY()

public:

	FOnSTRecorderDestructEvent DestructEvent;
	FOnSTRecorderTickEvent TickEvent;

protected:
	
	virtual TSharedRef<SWidget> RebuildWidget() override;

	// Destroy the widget
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;

	virtual void NativeDestruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

protected:
	TSharedPtr<class SSceneTextureRecorder> MySceneTextureRecorder;
};
