// Copyright Qibo Pang 2023. All Rights Reserved.

#include "WidgetSubSequenceTrackEditor.h"

#include "MovieSceneWidgetSubSequenceSection.h"
#include "MovieSceneWidgetSubSequenceTrack.h"
#include "Components/Widget.h"
#include "Containers/ArrayView.h"
#include "ISequencer.h"
#include "Misc/Guid.h"
#include "Templates/Casts.h"
#include "Templates/UnrealTemplate.h"
#include "UObject/WeakObjectPtr.h"
#include "UObject/WeakObjectPtrTemplates.h"
#include "Blueprint/UserWidget.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"

#include "Rendering/DrawElements.h"
#include "Widgets/SBoxPanel.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "GameFramework/Actor.h"
#include "Modules/ModuleManager.h"
#include "Layout/WidgetPath.h"
#include "Framework/Application/MenuStack.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/Layout/SBox.h"
#include "SequencerSectionPainter.h"
#include "Editor/UnrealEdEngine.h"
#include "UnrealEdGlobals.h"
#include "CommonMovieSceneTools.h"
#include "ContentBrowserModule.h"
#include "SequencerUtilities.h"
#include "ISectionLayoutBuilder.h"
#include "EditorStyleSet.h"
#include "MovieSceneTimeHelpers.h"
#include "Fonts/FontMeasure.h"
#include "SequencerTimeSliderController.h"
#include "Misc/MessageDialog.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Styling/SlateIconFinder.h"
#include "LevelSequence.h"
#include "TimeToPixel.h"

class ISequencerTrackEditor;
class UMovieSceneTrack;

namespace WidgetSubSequenceEditorConstants
{
	// @todo Sequencer Allow this to be customizable
	const uint32 AnimationTrackHeight = 20;
}

#define LOCTEXT_NAMESPACE "FWidgetSubSequenceTrackEditor"

static UUserWidget* AcquireUserWidgetFromObjectGuid(const FGuid& Guid, TSharedPtr<ISequencer> SequencerPtr)
{
	UObject* BoundObject = SequencerPtr.IsValid() ? SequencerPtr->FindSpawnedObjectOrTemplate(Guid) : nullptr;

	if (UUserWidget* UserWidget = Cast<UUserWidget>(BoundObject))
	{
		return UserWidget;
	}

	return nullptr;
}


FWidgetSubSequenceSection::FWidgetSubSequenceSection(UMovieSceneSection& InSection, TWeakPtr<ISequencer> InSequencer)
	: Section(*CastChecked<UMovieSceneWidgetSubSequenceSection>(&InSection))
	, Sequencer(InSequencer)
	, InitialFirstLoopStartOffsetDuringResize(0)
	, InitialStartTimeDuringResize(0)
{ }


UMovieSceneSection* FWidgetSubSequenceSection::GetSectionObject()
{
	return &Section;
}


FText FWidgetSubSequenceSection::GetSectionTitle() const
{
	if (!Section.Params.AnimationName.IsEmpty())
	{
		return FText::FromString(Section.Params.AnimationName);
	}
	return LOCTEXT("NoWidgetSubSequenceSection", "No WidgetSubSequence");
}


float FWidgetSubSequenceSection::GetSectionHeight() const
{
	return (float)WidgetSubSequenceEditorConstants::AnimationTrackHeight;
}


int32 FWidgetSubSequenceSection::OnPaintSection(FSequencerSectionPainter& Painter) const
{
	int32 LayerId = Painter.PaintSectionBackground();
	if (!Section.HasStartFrame() || !Section.HasEndFrame())
	{
		return LayerId;
	}

	return PaintCachePlaySection(Painter, LayerId);
}

int32 FWidgetSubSequenceSection::PaintCachePlaySection(FSequencerSectionPainter& Painter, int32 LayerId) const
{
	static const FSlateBrush* GenericDivider = FAppStyle::GetBrush("Sequencer.GenericDivider");
	const ESlateDrawEffect DrawEffects = Painter.bParentEnabled ? ESlateDrawEffect::None : ESlateDrawEffect::DisabledEffect;

	const FTimeToPixel& TimeToPixelConverter = Painter.GetTimeConverter();
	FFrameRate TickResolution = TimeToPixelConverter.GetTickResolution();
	
	// Add lines where the animation starts and ends/loops
	const float AnimPlayRate = FMath::IsNearlyZero(Section.Params.PlayRate) ? 1.0f : Section.Params.PlayRate;
	const float Duration = Section.Params.GetSequenceLength();
	const float SeqLength = Duration - TickResolution.AsSeconds(Section.Params.StartFrameOffset + Section.Params.EndFrameOffset) / AnimPlayRate;
	const float FirstLoopSeqLength = SeqLength - TickResolution.AsSeconds(Section.Params.FirstLoopStartFrameOffset) / AnimPlayRate;

	if (!FMath::IsNearlyZero(SeqLength, KINDA_SMALL_NUMBER) && SeqLength > 0)
	{
		float MaxOffset = Section.GetRange().Size<FFrameTime>() / TickResolution;
		float OffsetTime = FirstLoopSeqLength;
		float StartTime = Section.GetInclusiveStartFrame() / TickResolution;

		while (OffsetTime < MaxOffset)
		{
			float OffsetPixel = TimeToPixelConverter.SecondsToPixel(StartTime + OffsetTime) - TimeToPixelConverter.SecondsToPixel(StartTime);

			FSlateDrawElement::MakeBox(
				Painter.DrawElements,
				LayerId,
				Painter.SectionGeometry.MakeChild(
					FVector2D(2.f, Painter.SectionGeometry.Size.Y - 2.f),
					FSlateLayoutTransform(FVector2D(OffsetPixel, 1.f))
				).ToPaintGeometry(),
				GenericDivider,
				DrawEffects
			);

			OffsetTime += SeqLength;
		}
	}

	return LayerId + 1;
}

void FWidgetSubSequenceSection::BeginResizeSection()
{
	InitialFirstLoopStartOffsetDuringResize = Section.Params.FirstLoopStartFrameOffset;
	InitialStartTimeDuringResize = Section.HasStartFrame() ? Section.GetInclusiveStartFrame() : 0;
}

void FWidgetSubSequenceSection::ResizeSection(ESequencerSectionResizeMode ResizeMode, FFrameNumber ResizeTime)
{
	// Adjust the start offset when resizing from the beginning
	if (ResizeMode == SSRM_LeadingEdge)
	{
		FFrameRate FrameRate = Section.GetTypedOuter<UMovieScene>()->GetTickResolution();
		FFrameNumber StartOffset = FrameRate.AsFrameNumber((ResizeTime - InitialStartTimeDuringResize) / FrameRate * Section.Params.PlayRate);

		StartOffset += InitialFirstLoopStartOffsetDuringResize;

		if (StartOffset < 0)
		{
			// Ensure start offset is not less than 0 and adjust ResizeTime
			ResizeTime = ResizeTime - StartOffset;

			StartOffset = FFrameNumber(0);
		}
		else
		{
			// If the start offset exceeds the length of one loop, trim it back.
			const FFrameNumber SeqLength = FrameRate.AsFrameNumber(Section.Params.GetSequenceLength()) - Section.Params.StartFrameOffset - Section.Params.EndFrameOffset;
			if (SeqLength != 0)
			{
				StartOffset = StartOffset % SeqLength;
			}
		}

		Section.Params.FirstLoopStartFrameOffset = StartOffset;
	}

	ISequencerSection::ResizeSection(ResizeMode, ResizeTime);
}

void FWidgetSubSequenceSection::BeginSlipSection()
{
	BeginResizeSection();
}

void FWidgetSubSequenceSection::SlipSection(FFrameNumber SlipTime)
{
	FFrameRate FrameRate = Section.GetTypedOuter<UMovieScene>()->GetTickResolution();
	FFrameNumber StartOffset = FrameRate.AsFrameNumber((SlipTime - InitialStartTimeDuringResize) / FrameRate * Section.Params.PlayRate);

	StartOffset += InitialFirstLoopStartOffsetDuringResize;

	if (StartOffset < 0)
	{
		// Ensure start offset is not less than 0 and adjust ResizeTime
		SlipTime = SlipTime - StartOffset;

		StartOffset = FFrameNumber(0);
	}
	else
	{
		// If the start offset exceeds the length of one loop, trim it back.
		const FFrameNumber SeqLength = FrameRate.AsFrameNumber(Section.Params.GetSequenceLength()) - Section.Params.StartFrameOffset - Section.Params.EndFrameOffset;
		StartOffset = StartOffset % SeqLength;
	}

	Section.Params.FirstLoopStartFrameOffset = StartOffset;

	ISequencerSection::SlipSection(SlipTime);
}

void FWidgetSubSequenceSection::BeginDilateSection()
{
	Section.PreviousPlayRate = Section.Params.PlayRate; //make sure to cache the play rate
}
void FWidgetSubSequenceSection::DilateSection(const TRange<FFrameNumber>& NewRange, float DilationFactor)
{
	Section.Params.PlayRate = Section.PreviousPlayRate / DilationFactor;
	Section.SetRange(NewRange);
}

FWidgetSubSequenceTrackEditor::FWidgetSubSequenceTrackEditor(TSharedRef<ISequencer> InSequencer)
	: FMovieSceneTrackEditor(InSequencer)
{ }


TSharedRef<ISequencerTrackEditor> FWidgetSubSequenceTrackEditor::CreateTrackEditor(TSharedRef<ISequencer> InSequencer)
{
	return MakeShareable(new FWidgetSubSequenceTrackEditor(InSequencer));
}


//bool FWidgetSubSequenceTrackEditor::SupportsSequence(UMovieSceneSequence* InSequence) const
//{
//	return InSequence && InSequence->IsA(ULevelSequence::StaticClass());
//}

TSharedRef<ISequencerSection> FWidgetSubSequenceTrackEditor::MakeSectionInterface(UMovieSceneSection& SectionObject, UMovieSceneTrack& Track, FGuid ObjectBinding)
{
	check(SupportsType(SectionObject.GetOuter()->GetClass()));

	return MakeShareable(new FWidgetSubSequenceSection(SectionObject, GetSequencer()));
}


FKeyPropertyResult FWidgetSubSequenceTrackEditor::AddKeyInternal(FFrameNumber KeyTime, UObject* Object, UUserWidget* UserWidget, UMovieSceneTrack* Track)
{
	FKeyPropertyResult KeyPropertyResult;

	FFindOrCreateHandleResult HandleResult = FindOrCreateHandleToObject(Object);
	FGuid ObjectHandle = HandleResult.Handle;
	KeyPropertyResult.bHandleCreated |= HandleResult.bWasCreated;
	if (ObjectHandle.IsValid())
	{
		if (!Track)
		{
			Track = AddTrack(GetSequencer()->GetFocusedMovieSceneSequence()->GetMovieScene(), ObjectHandle, UMovieSceneWidgetSubSequenceTrack::StaticClass(), NAME_None);
			KeyPropertyResult.bTrackCreated = true;
		}

		if (ensure(Track))
		{
			Track->Modify();

			UMovieSceneSection* NewSection = Cast<UMovieSceneWidgetSubSequenceTrack>(Track)->AddNewAnimation(KeyTime, UserWidget);
			KeyPropertyResult.bTrackModified = true;
			KeyPropertyResult.SectionsCreated.Add(NewSection);

			GetSequencer()->EmptySelection();
			GetSequencer()->SelectSection(NewSection);
			GetSequencer()->ThrobSectionSelection();
		}
	}

	return KeyPropertyResult;
}


TSharedPtr<SWidget> FWidgetSubSequenceTrackEditor::BuildOutlinerEditWidget(const FGuid& ObjectBinding, UMovieSceneTrack* Track, const FBuildEditWidgetParams& Params)
{
//	UStyle3DComponent* GeomMeshComp = AcquireWidgetSubSequenceFromObjectGuid(ObjectBinding, GetSequencer());
//
//	if (GeomMeshComp)
//	{
//		TWeakPtr<ISequencer> WeakSequencer = GetSequencer();
//
//		auto SubMenuCallback = [this, ObjectBinding, Track]() -> TSharedRef<SWidget>
//		{
//			FMenuBuilder MenuBuilder(true, nullptr);
//
//			TArray<FGuid> ObjectBindings;
//			ObjectBindings.Add(ObjectBinding);
//
//			BuildWidgetSubSequenceTrack(ObjectBindings, Track);
//
//			return MenuBuilder.MakeWidget();
//		};
//
//		return SNew(SHorizontalBox)
//			+ SHorizontalBox::Slot()
//			.AutoWidth()
//			.VAlign(VAlign_Center)
//			[
//				FSequencerUtilities::MakeAddButton(LOCTEXT("WidgetSubSequenceText", "Garment Cache"), FOnGetContent::CreateLambda(SubMenuCallback), Params.NodeIsHovered, GetSequencer())
//			];
//	}
//	else
//	{
//		return TSharedPtr<SWidget>();
//	}
	return TSharedPtr<SWidget>();
}

const FSlateBrush* FWidgetSubSequenceTrackEditor::GetIconBrush() const
{
	return FSlateIconFinder::FindIconForClass(UUserWidget::StaticClass()).GetIcon();
}


bool FWidgetSubSequenceTrackEditor::SupportsType( TSubclassOf<UMovieSceneTrack> Type ) const
{
	return Type == UMovieSceneWidgetSubSequenceTrack::StaticClass();
}

void FWidgetSubSequenceTrackEditor::BuildObjectBindingTrackMenu(FMenuBuilder& MenuBuilder, const TArray<FGuid>& ObjectBindings, const UClass* ObjectClass)
{
	if (ObjectClass->IsChildOf(UUserWidget::StaticClass()))
	{
		UUserWidget* UserWidget = AcquireUserWidgetFromObjectGuid(ObjectBindings[0], GetSequencer());
		
		if (UserWidget/* && UserWidget->Getanima*/)
		{
			UWidgetBlueprintGeneratedClass* WidgetBPClass = Cast<UWidgetBlueprintGeneratedClass>(UserWidget->GetClass());
			if (WidgetBPClass && WidgetBPClass->Animations.Num() > 0)
			{
				//TArray<UWidgetAnimation*>& PreviewAnimations = WidgetBPClass->Animations;

				UMovieSceneTrack* Track = nullptr;

				MenuBuilder.AddMenuEntry(
					NSLOCTEXT("Sequencer", "AddWidgetSubsequence", "Widget Subsequence"),
					NSLOCTEXT("Sequencer", "AddWidgetSubsequenceTooltip", "Adds a Widget Subsequence track."),
					FSlateIcon(),
					FUIAction(
						FExecuteAction::CreateSP(this, &FWidgetSubSequenceTrackEditor::BuildWidgetSubSequenceTrack, ObjectBindings, Track)
					)
				);
			}
		}
	}
}

void FWidgetSubSequenceTrackEditor::BuildWidgetSubSequenceTrack(TArray<FGuid> ObjectBindings, UMovieSceneTrack* Track)
{
	TSharedPtr<ISequencer> SequencerPtr = GetSequencer();

	if (SequencerPtr.IsValid())
	{
		const FScopedTransaction Transaction(LOCTEXT("AddWidgetSubSequence_Transaction", "Add Widget SubSequence"));

		for (FGuid ObjectBinding : ObjectBindings)
		{
			if (ObjectBinding.IsValid())
			{
				UObject* Object = SequencerPtr->FindSpawnedObjectOrTemplate(ObjectBinding);

				UUserWidget* UserWidget = AcquireUserWidgetFromObjectGuid(ObjectBinding, GetSequencer());

				if (Object && UserWidget)
				{
					AnimatablePropertyChanged(FOnKeyProperty::CreateRaw(this, &FWidgetSubSequenceTrackEditor::AddKeyInternal, Object, UserWidget, Track));
				}
			}
		}
	}
}