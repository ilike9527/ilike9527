﻿// Copyright Qibo Pang 2024. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "UMGPolygonEditorSettings.generated.h"


/**
 * Rhino 客户端应用工程全局配置
 */
UCLASS(config = UMGPolygonEditor, defaultconfig)
class UUMGPolygonEditorSettings : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, config, Category = UMGPolygonEditor)
		float PanelHeight = 600.0f;	

	static float GetPanelHeight()
	{
		UUMGPolygonEditorSettings* Settings = GetMutableDefault<UUMGPolygonEditorSettings>();
		if (Settings)
		{
			return Settings->PanelHeight;
		}
		return 600.0f;
	}

	static void SetPanelHeight(float PanelHeight)
	{
		UUMGPolygonEditorSettings* Settings = GetMutableDefault<UUMGPolygonEditorSettings>();
		if (Settings)
		{
			Settings->PanelHeight = PanelHeight;
		}
	}
};
