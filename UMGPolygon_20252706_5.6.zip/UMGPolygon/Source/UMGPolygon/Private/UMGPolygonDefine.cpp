// Copyright Qibo Pang 2024. All Rights Reserved.

#include "UMGPolygonDefine.h"
#include "Styling/SlateBrush.h"
#include "Materials/MaterialInterface.h"

FUMGPolygonInfo::FUMGPolygonInfo(bool Init)
{
    if (Init)
    {
        if (Points.Num() == 0)
        {
            Points.Add(FUMGPolygonPoint(FVector2D(100.0f, 0.0f), FVector2D(100.0f, 0.0f)));
            Points.Add(FUMGPolygonPoint(FVector2D(200.0f, 150.0f), FVector2D(-50.0f, 50.0f)));
            Points.Add(FUMGPolygonPoint(FVector2D(0.0f, 150.0f), FVector2D(-50.0f, -50.0f)));
        }
        
        UMaterialInterface* PolygonMaterial = LoadObject<UMaterialInterface>(nullptr, TEXT("/UMGPolygon/Materials/M_Polygon_AntiAliasing"));
        if (PolygonMaterial)
        {
            PolygonBrush.SetResourceObject(PolygonMaterial);
        }

        UMaterialInterface* EdgeMaterial = LoadObject<UMaterialInterface>(nullptr, TEXT("/UMGPolygon/Materials/M_PolygonEdge_AntiAliasing"));
        if (EdgeMaterial)
        {
            EdgeBrush.SetResourceObject(EdgeMaterial);
        }

        PolygonType = EUMGPolygonType::CurveEdge;
    }
}