// Copyright Qibo Pang 2024. All Rights Reserved.

#pragma once

// Core
#include "CoreMinimal.h"
#include "Components/Widget.h"

// Misc
#include "SWPolygon.h"
#include "Styling/CoreStyle.h"
#include "UMGPolygonDefine.h"

// Generated.h
#include "PolygonWidget.generated.h"

class SWPolygon;

/** Types of coordinate space accepted by the functions. */
UENUM()
namespace EUMGPolygonCoordinateSpace
{
	enum Type
	{
		Local,
		Viewport,
		Screen
	};
}

USTRUCT()
struct UMGPOLYGON_API FUMGPolygonCurves
{
	GENERATED_BODY()

	/** Polygon built from position data. */
	UPROPERTY()
		FInterpCurveVector2D Position;

	/** Input: distance along curve, output: parameter that puts you there. */
	UPROPERTY()
		FInterpCurveFloat ReparamTable;

	UPROPERTY(transient)
		uint32 Version = 0xffffffff;

	UPROPERTY(transient)
		int32 ReparamStepsPerSegment;

	bool operator==(const FUMGPolygonCurves& Other) const
	{
		return Position == Other.Position;
	}

	bool operator!=(const FUMGPolygonCurves& Other) const
	{
		return !(*this == Other);
	}

	/**
	 * Update the spline's internal data according to the passed-in params
	 * @param	PolygonInfo				Polygon Information
	 * @param	bStationaryEndpoints	Whether the endpoints of the spline are considered stationary when traversing the spline at non-constant velocity.  Essentially this sets the endpoints' tangents to zero vectors.
	 * @param	ReparamStepsPerSegment	Number of steps per spline segment to place in the reparameterization table
	 * @param	bClosedLoopPositionOverride	Whether to override the loop position with LoopPosition
	 * @param	LoopPosition			The loop position to use instead of the last key
	 * @param	Scale3D					The world scale to override
	 */
	void UpdatePolygon(const FUMGPolygonInfo& PolygonInfo, bool bStationaryEndpoints = false, int32 InReparamStepsPerSegment = 10, bool bClosedLoopPositionOverride = false, float LoopPosition = 0.0f, const FVector2D& Scale2D = FVector2D(1.0f));

	/** Returns the length of the specified spline segment up to the parametric value given */
	float GetSegmentLength(const int32 Index, const float Param, bool bClosedLoop = true, const FVector2D& Scale2D = FVector2D(1.0f)) const;

	/** Returns total length along this spline */
	float GetPolygonLength() const;
};

//This plugin is finished during Chinese Lunar New Year. Happy tiger year!

/**
 * A spline wdiget can be: 
 * 1. Easy to edit in UMG editor.
 * 2. Built as custom verts, so that you can set a custom brush for the spline geometry.
 * 3. Used as a rail for other widgets, like UPolygonComponent in 3D space.
 *
 * * No Children
 */
UCLASS(meta=(DisplayName="Polygon"))
class UMGPOLYGON_API UPolygonWidget final : public UWidget
{                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
	GENERATED_BODY()

public:

	/*============================================================================\
	|                                Properties                                   |
	\============================================================================*/

	/**  */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Appearance")
		FUMGPolygonInfo PolygonInfo = FUMGPolygonInfo(/* Init */true);

	

	/*============================================================================\
	|                            Blueprint Functions                              |
	\============================================================================*/
	
	/** Update the polygon edge tangents and PolygonReparamTable */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		virtual void UpdatePolygon();

	/** Get location along polygon edge at the provided input key value */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		FVector2D GetLocationAtPolygonEdgeInputKey(float InKey, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const;

	/** Get tangent along polygon edge at the provided input key value */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		FVector2D GetTangentAtPolygonEdgeInputKey(float InKey, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const;

	/** Get unit direction along polygon edge at the provided input key value */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		FVector2D GetDirectionAtPolygonEdgeInputKey(float InKey, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const;

	/** Get rotator corresponding to rotation along polygon edge at the provided input key value */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		float GetRotationAngleAtPolygonEdgeInputKey(float InKey, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const;

	/** Get distance along the polygon edge at the provided input key value */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		float GetDistanceAlongPolygonAtPolygonEdgeInputKey(float InKey) const;

	/** Adds a point to the polygon edge */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		void AddPolygonEdgePoint(const FUMGPolygonPoint& PolygonPoint, bool bUpdatePolygon);

	/** Adds a point to the polygon edge at the specified index */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		void AddPolygonEdgePointAtIndex(const FUMGPolygonPoint& PolygonPoint, int32 Index, bool bUpdatePolygon);

	/** Removes point at specified index from the polygon edge */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		void RemovePolygonEdgePoint(int32 Index, bool bUpdatePolygon);

	/** Removes all points from the polygon edge */
	UFUNCTION(BlueprintCallable, Category = Spline)
		void RemoveAllPolygonEdgePoint(bool bUpdatePolygon);

	/** Change a point to the polygon edge at the specified index */
	UFUNCTION(BlueprintCallable, Category = Spline)
		void ChangePolygonEdgePointAtIndex(const FUMGPolygonPoint& PolygonPoint, int32 Index, bool bUpdatePolygon);

	/** Get the type of polygon edge */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		EUMGPolygonType GetPolygonType() const;

	/** Specify the type of polygon edge */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		void SetPolygonType(EUMGPolygonType Type);

	/** Get the number of points that make up this polygon edge */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		int32 GetNumberOfPolygonEdgePoints() const;

	/** Get the location at polygon edge point */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		FVector2D GetLocationAtPolygonEdgePoint(int32 PointIndex, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const;

	/** Get the direction at polygon edge point */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		FVector2D GetDirectionAtPolygonEdgePoint(int32 PointIndex, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const;

	/** Get the tangent at polygon edge point. This fetches the Leave tangent of the point. */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		FVector2D GetTangentAtPolygonEdgePoint(int32 PointIndex, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const;

	/** Returns total length along this polygon edge */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		float GetPolygonEdgeLength() const;

	/** Given a distance along the length of this polygon edge, return the corresponding input key at that point */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		float GetInputKeyAtDistanceAlongPolygonEdge(float Distance, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const;

	/** Given a distance along the length of this polygon edge, return the point in space where this puts you */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		FVector2D GetLocationAtDistanceAlongPolygonEdge(float Distance, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const;

	/** Given a distance along the length of this polygon edge, return a unit direction vector of the polygon edge tangent there. */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		FVector2D GetDirectionAtDistanceAlongPolygonEdge(float Distance, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const;

	/** Given a distance along the length of this polygon edge, return the tangent vector of the polygon edge there. */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		FVector2D GetTangentAtDistanceAlongPolygonEdge(float Distance, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const;

	/** Given a distance along the length of this polygon edge, return a rotation corresponding to the polygon edge's rotation there. */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		float GetRotationAngleAtDistanceAlongPolygonEdge(float Distance, EUMGPolygonCoordinateSpace::Type CoordinateSpace) const;

	/** Given a 2D point, return whether the point is in the Polygon. */
	UFUNCTION(BlueprintCallable, Category = Polygon)
		bool CheckPointInPolygon(const FVector2D& Point) const;

public:

	inline FUMGPolygonInfo GetPolygonInfo() const { return PolygonInfo; }

protected:
	
	virtual void OnWidgetRebuilt() override;

	// Construct the widget
	virtual TSharedRef<SWidget> RebuildWidget() override;
	
	// Destroy the widget
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	
#if WITH_EDITOR
	
	// For the editor to set the name category in the Widget Explorer.
	virtual inline const FText GetPaletteCategory() override { return NSLOCTEXT("Polygon", "Polygon", "Polygon"); };

#endif
	
private:

	/** The dummy value used for queries when there are no point in a polygon edge */
	static const FInterpCurvePointVector2D DummyPointPosition;

	/** Returns a const reference to the specified position point, but gives back a dummy point if there are no points */
	inline const FInterpCurvePointVector2D& GetPositionPointSafe(int32 PointIndex) const
	{
		const TArray<FInterpCurvePointVector2D>& Points = PolygonCurves.Position.Points;
		const int32 NumPoints = Points.Num();
		if (NumPoints > 0)
		{
			const int32 ClampedIndex = (PointIndex >= NumPoints) ? 0 : FMath::Clamp(PointIndex, 0, NumPoints - 1);
			return Points[ClampedIndex];
		}
		else
		{
			return DummyPointPosition;
		}
	}

	
private:

	/*============================================================================\
	|                              Private Variables                              |
	\============================================================================*/
	
	// Shared Ptr to the Polygon.
	TSharedPtr<SWPolygon> Polygon;

	UPROPERTY(transient)
		FUMGPolygonCurves PolygonCurves;

};
